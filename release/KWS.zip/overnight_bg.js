// KWS 1.2.5.20 — Overnight mode (loaded into background.js right after scan_hub.js).
//
// One pass over a platform's history, channels not searched for longest first — "new VODs only"
// (like a normal history rescan) or "full rescan" (every VOD again) — then it waits for the user.
//
// The point: history is NOT touched until the user releases the mode. A normal scan writes the
// history as soon as it ends — so if Chrome or the computer died overnight, the results (kept in
// session storage) were gone but the history said "searched", and the next "new VODs only" scan
// skipped those VODs for good. Here every finished channel's result goes straight into
// chrome.storage.local (kwsOvernight), and the history is written for all of them at release.
//
// Survives the service worker being killed or Chrome restarting: the queue is in storage, an alarm
// wakes us every minute, and channels that were mid-scan in a dead worker go back to the queue.
// chrome.power keeps the computer from sleeping while it runs.
const OV_KEY = 'kwsOvernight';
const OV_ALARM = 'kwsOvernight';
const ovLive = new Set();        // channels started by THIS service-worker life
let ovState;                     // undefined = not loaded yet, null = off
let ovChain = Promise.resolve(); // every state change runs one after another

function ovSerial(fn) {
  const run = ovChain.then(fn);
  ovChain = run.catch(() => {});
  return run;
}
async function ovLoad() {
  if (ovState !== undefined) return ovState;
  try { ovState = (await chrome.storage.local.get(OV_KEY))[OV_KEY] || null; } catch (_) { ovState = null; }
  return ovState;
}
async function ovSave() {
  try {
    if (ovState) await chrome.storage.local.set({ [OV_KEY]: ovState });
    else await chrome.storage.local.remove(OV_KEY);
  } catch (e) { console.warn('[KWS OV] save failed', e && e.message); }
}
function ovKeepAwake(on) {
  try { if (on) chrome.power.requestKeepAwake('system'); else chrome.power.releaseKeepAwake(); } catch (_) {}
}

// History IDs of `platform` not searched for `olderThanDays` days (0 = all), oldest first.
async function ovTargets(platform, olderThanDays) {
  const key = SP_HISTORY_KEYS[platform];
  if (!key) return [];
  let hist = {};
  try { hist = (await chrome.storage.local.get(key))[key] || {}; } catch (_) {}
  const now = Date.now();
  const minAge = olderThanDays > 0 ? olderThanDays * 86400000 : 0;
  const seen = new Set();
  return Object.entries(hist)
    .filter(([k, v]) => k && !k.startsWith('_') && v && typeof v === 'object')
    .map(([k, v]) => ({ ch: kws_normalizeChannel(k).replace(/^@/, ''), at: Date.parse(v.searchedAt || v.savedAt || '') || 0 }))
    .filter((x) => x.ch && (!minAge || now - x.at >= minAge))
    .sort((a, b) => a.at - b.at)
    .map((x) => x.ch)
    .filter((ch) => (seen.has(ch) ? false : (seen.add(ch), true)));
}

async function ovFillNow() {
  if (!ovState || !ovState.active || ovState.finished || ovState.releasing) return;
  await spEnsureLoaded();
  // channels that were scanning in a service worker that has since died: back to the front
  for (const ch of [...ovState.running]) {
    if (!ovLive.has(ch)) {
      ovState.running = ovState.running.filter((x) => x !== ch);
      ovState.queue.unshift(ch);
    }
  }
  const max = SP_MAX_CONCURRENT[ovState.platform] || 1;
  while (ovState.running.length < max && ovState.queue.length) {
    const ch = ovState.queue.shift();
    ovState.running.push(ch);
    ovLive.add(ch);
    await ovSave();
    let r = null;
    try { r = await spStart({ platform: ovState.platform, channel: ch, mode: ovState.mode === 'full' ? 'full' : 'new', overnight: true }); }
    catch (e) { r = { ok: false, error: e && e.message }; }
    if (!r || !r.ok) { // e.g. the user is already scanning this channel by hand
      ovLive.delete(ch);
      ovState.running = ovState.running.filter((x) => x !== ch);
      ovState.results[ch] = { status: 'skipped', error: (r && (r.reason || r.error)) || '?', finishedAt: Date.now() };
    }
  }
  if (!ovState.running.length && !ovState.queue.length) {
    ovState.finished = true;
    ovState.finishedAt = Date.now();
    ovKeepAwake(false);
    try { chrome.alarms.clear(OV_ALARM); } catch (_) {}
  }
  await ovSave();
}

// Called by scan_hub.js spRun when an overnight scan ends (done / error / stopped).
// Failures of the site tab a SOOP / YouTube scan runs in — nothing to do with the channel itself.
function ovIsTabError(msg) {
  return /did not respond|tab closed|tab reloaded|already scanning|busy|Receiving end|context invalidated/i.test(String(msg || ''));
}

function ovScanEnded(e) {
  return ovSerial(async () => {
    await ovLoad();
    ovLive.delete(e.channel);
    if (ovState && ovState.active && !ovState.releasing && ovState.platform === e.platform && ovState.running.includes(e.channel)) {
      ovState.running = ovState.running.filter((x) => x !== e.channel);
      // a site-tab problem (not the channel's fault): back to the end of the queue, once
      ovState.retried = ovState.retried || {};
      if (e.status === 'error' && ovIsTabError(e.error) && !ovState.retried[e.channel]) {
        ovState.retried[e.channel] = true;
        ovState.queue.push(e.channel);
        if (spScans && spScans[e.id] === e) { delete spScans[e.id]; await spPersist(true); }
        await ovFillNow();
        return;
      }
      ovState.results[e.channel] = {
        status: e.status, error: e.error, finishedAt: Date.now(),
        params: e.params, keywords: e.keywords, historyPatch: e.historyPatch, nickname: e.nickname,
        matchedLines: e.matchedLines || 0, matchedDays: e.matchedDays || 0, failedChunks: e.failedChunks || 0,
        totalSessions: e.totalSessions, subOnly: e.subOnly, kicklogzVods: e.kicklogzVods, archiveVods: e.archiveVods, kicklogzOn: e.kicklogzOn,
        groups: e.matchedLines ? (e.groups || []) : [],
      };
    }
    // the result lives in kwsOvernight now; drop the hub entry so tabs don't pile up overnight
    if (spScans && spScans[e.id] === e) { delete spScans[e.id]; await spPersist(true); }
    await ovFillNow();
  });
}

function ovStart({ platform, olderThanDays, mode }) {
  return ovSerial(async () => {
    await ovLoad();
    if (ovState && ovState.active) return { ok: false, reason: 'active' };
    if (!SP_RUNNERS[platform]) return { ok: false, reason: 'unsupported' };
    const queue = await ovTargets(platform, olderThanDays);
    if (!queue.length) return { ok: false, reason: 'empty' };
    ovState = { active: true, finished: false, platform, olderThanDays, mode: mode === 'full' ? 'full' : 'new', startedAt: Date.now(), total: queue.length, queue, running: [], results: {} };
    await ovSave();
    ovKeepAwake(true);
    try { chrome.alarms.create(OV_ALARM, { periodInMinutes: 1 }); } catch (_) {}
    const total = queue.length; // (ovFillNow takes channels off the queue)
    await ovFillNow();
    return { ok: true, total };
  });
}

// Release: stop what is still running (its history stays as it was, so it comes up again next
// time), write the history of every finished channel, and show the channels with hits as tabs.
const OV_RELEASE_KEY = 'kwsOvRelease'; // chrome.storage.session — { phase, done, total } while releasing
async function ovReleaseProgress(p) { try { if (p) await chrome.storage.session.set({ [OV_RELEASE_KEY]: p }); else await chrome.storage.session.remove(OV_RELEASE_KEY); } catch (_) {} }

// Release: stop what is still running (its history stays as it was, so it comes up again next
// time), write the history of every finished channel, and show the channels with hits as tabs.
// 1.2.5.20: the veil stays up until all of this is saved (state.releasing + a progress key), and
// the history is read and written ONCE — one read/write per channel took minutes on 500+ channels.
function ovRelease() {
  const asked = Date.now();
  return ovSerial(async () => {
    if (Date.now() - asked > 500) console.log('[KWS OV] release waited', Date.now() - asked, 'ms for earlier overnight work');
    await ovLoad();
    if (!ovState) return { ok: true, shown: 0 };
    const t0 = Date.now();
    const st = ovState;
    const results = Object.entries(st.results || {});
    st.releasing = true;           // ovScanEnded / ovFillNow leave it alone from here on
    await ovReleaseProgress({ phase: 'stop', done: 0, total: results.length });
    await ovSave();
    ovKeepAwake(false);
    try { chrome.alarms.clear(OV_ALARM); } catch (_) {}
    await spEnsureLoaded();
    for (const ch of st.running || []) {
      const id = spId(st.platform, ch);
      const e = spScans[id];
      if (e && e.overnight) {
        e.stopRequested = true;
        try { SP_RUNNERS[e.platform].stop(e); } catch (_) {}
        delete spScans[id];
      }
      ovLive.delete(ch);
    }
    const t1 = Date.now();

    // history: one read, every change in memory, one write (same fields as spSaveHistory / spMarkSearched)
    const key = SP_HISTORY_KEYS[st.platform];
    let hist = {};
    try { hist = (await chrome.storage.local.get(key))[key] || {}; } catch (_) {}
    const lowerKeys = new Map(Object.keys(hist).map((k) => [k.toLowerCase(), k]));
    const now = new Date().toISOString();
    let shown = 0;
    let i = 0;
    for (const [ch, r] of results) {
      i++;
      try {
        if (r.status === 'done' && r.params && r.params.endDate) {
          const words = (r.keywords || []).map((k) => String(k).replace(/^~/, '')).filter(Boolean);
          const entry = { keywords: words, savedAt: now, searchedAt: now, lastDate: r.params.endDate };
          if (st.platform === 'soop') entry.matchedCount = r.matchedLines || 0;
          else { entry.matchedLines = r.matchedLines || 0; entry.matchedDays = r.matchedDays || 0; }
          if (r.historyPatch) Object.assign(entry, r.historyPatch);
          hist[ch] = Object.assign({}, hist[ch] || {}, entry);
          if (!entry.partial) delete hist[ch].partial; // SOOP keeps it when VODs failed (1.2.5.52)
        } else if (r.status === 'error' && !ovIsTabError(r.error)) {
          // only a real channel error counts as "searched"; a site-tab failure leaves the history as it was
          const k = lowerKeys.get(String(ch).toLowerCase());
          if (k && hist[k] && typeof hist[k] === 'object') hist[k] = Object.assign({}, hist[k], { searchedAt: now, savedAt: now, lastError: String(r.error || '').slice(0, 120) });
        }
      } catch (err) { console.warn('[KWS OV] history update failed for', ch, err && err.message); }
      if (r.status === 'done' && r.matchedLines > 0) {
        const id = spId(st.platform, ch);
        spScans[id] = {
          id, platform: st.platform, channel: ch, params: r.params || {}, keywords: r.keywords || [],
          matchedLines: r.matchedLines || 0, matchedDays: r.matchedDays || 0, historyPatch: r.historyPatch, error: r.error,
          status: 'done', mode: st.mode === 'full' ? 'full' : 'new', createdAt: r.finishedAt, startedAt: r.finishedAt, finishedAt: r.finishedAt,
          done: 1, total: 1, failedChunks: r.failedChunks || 0, groups: r.groups || [], nickname: r.nickname,
          totalSessions: r.totalSessions, subOnly: r.subOnly, kicklogzVods: r.kicklogzVods, archiveVods: r.archiveVods, kicklogzOn: r.kicklogzOn,
          overnight: false, fromOvernight: true,
        };
        shown++;
      }
      if (i % 50 === 0) await ovReleaseProgress({ phase: 'history', done: i, total: results.length });
    }
    await ovReleaseProgress({ phase: 'save', done: results.length, total: results.length });
    try { await chrome.storage.local.set({ [key]: hist }); } catch (err) { console.warn('[KWS OV] history write failed', err && err.message); }
    const t2 = Date.now();
    await spPersist(true);
    // only now does the veil go away
    ovState = null;
    await ovSave();
    await ovReleaseProgress(null);
    console.log('[KWS OV] released:', results.length, 'results,', shown, 'tabs | stop', t1 - t0, 'ms · history', t2 - t1, 'ms · save', Date.now() - t2, 'ms');
    return { ok: true, shown, platform: st.platform };
  });
}

function ovResume() {
  return ovSerial(async () => {
    await ovLoad();
    if (ovState && ovState.releasing) { ovSerial(() => Promise.resolve()); setTimeout(() => ovRelease(), 0); return; } // worker died mid-release: finish it
    if (!ovState || !ovState.active || ovState.finished) return;
    ovKeepAwake(true);
    try { if (!(await chrome.alarms.get(OV_ALARM))) chrome.alarms.create(OV_ALARM, { periodInMinutes: 1 }); } catch (_) {}
    await ovFillNow();
  });
}

chrome.alarms.onAlarm.addListener((a) => { if (a && a.name === OV_ALARM) ovResume(); });
chrome.runtime.onStartup.addListener(() => { ovResume(); });
setTimeout(() => { ovResume(); }, 1500); // the service worker (re)started

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.type !== 'string' || !msg.type.startsWith('KWS_OV_')) return;
  (async () => {
    if (msg.type === 'KWS_OV_COUNT') return { ok: true, count: (await ovTargets(msg.platform, Number(msg.olderThanDays) || 0)).length };
    if (msg.type === 'KWS_OV_START') return ovStart({ platform: msg.platform, olderThanDays: Number(msg.olderThanDays) || 0, mode: msg.mode });
    if (msg.type === 'KWS_OV_RELEASE') return ovRelease();
    return { ok: false, reason: 'unknown' };
  })().then(sendResponse, (e) => sendResponse({ ok: false, error: String(e && e.message || e) }));
  return true;
});
