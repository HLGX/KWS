// KWS 1.2.5 — keyword text format.
//
// Text-first so lists can be kept in Notepad and pasted back in. Same notation the 1.2.4
// keyword string already uses, so old strings paste in unchanged:
//
//   레전드        exact match (=)        also "=레전드" or "+레전드"
//   ~ㅋㅋㅋ       contains (≈)           also "≈ㅋㅋㅋ"
//   -광고         exclude                (in the "find" box; moved to the exclude list)
//
// Separators: new line, comma, tab, semicolon, "，" "、" "；". Bullets ("• ", "* ", "- ",
// "1. ", "2) ") and surrounding quotes are dropped. Words are lower-cased (as the 1.2.4
// editor does) and duplicates are merged case-insensitively; if a word appears both as
// exact and contains, contains wins (it already covers the exact case).
(function (global) {
  'use strict';

  const SPLIT_RE = /[\n\r,\t;，、；]+/;
  const INVISIBLE_RE = /[​-‍⁠﻿]/g;
  const BULLET_RE = /^(?:[•·▪◦‣●○■□*]\s*|-\s+|[–—]\s+|\d{1,3}[.)]\s+)/;

  function cleanToken(raw) {
    let s = String(raw).replace(INVISIBLE_RE, '').replace(/ /g, ' ').trim();
    // repeated bullets like "• - word"
    for (let i = 0; i < 3 && BULLET_RE.test(s); i++) s = s.replace(BULLET_RE, '').trim();
    const q = s.match(/^["'“‘「『](.*)["'”’」』]$/);
    if (q) s = q[1].trim();
    return s.replace(/\s+/g, ' ');
  }

  // One token → { word, mode: 'exact' | 'contains' | 'exclude' } or null.
  function parseToken(raw, inExcludeBox) {
    let s = cleanToken(raw);
    if (!s) return null;
    let mode = 'exact';
    if (inExcludeBox) {
      s = s.replace(/^-+/, '').trim();
      mode = 'exclude';
    } else if (/^[~≈]/.test(s)) {
      s = s.replace(/^[~≈]+/, '').trim();
      mode = 'contains';
    } else if (/^-/.test(s)) {
      s = s.replace(/^-+/, '').trim();
      mode = 'exclude';
    } else if (/^[=+]/.test(s)) {
      s = s.replace(/^[=+]+/, '').trim();
    }
    s = cleanToken(s).toLowerCase();
    if (!s) return null;
    return { word: s, mode };
  }

  // Parse the two boxes. Returns the 1.2.4 profile parts plus what was tidied up.
  //   plus  : ['word', '~word', ...]   (order kept, first appearance wins)
  //   minus : ['word', ...]
  function parseKeywordText(findText, excludeText) {
    const include = new Map(); // word -> 'exact' | 'contains'
    const exclude = new Map(); // word -> true
    let duplicates = 0;
    let movedToExclude = 0;

    const addExclude = (word) => {
      if (exclude.has(word)) { duplicates++; return; }
      exclude.set(word, true);
    };

    const moved = [];
    for (const raw of String(findText || '').split(SPLIT_RE)) {
      const tok = parseToken(raw, false);
      if (!tok) continue;
      if (tok.mode === 'exclude') { movedToExclude++; moved.push(tok.word); continue; }
      if (include.has(tok.word)) {
        duplicates++;
        if (tok.mode === 'contains') include.set(tok.word, 'contains');
        continue;
      }
      include.set(tok.word, tok.mode);
    }
    // existing exclude list first, words moved out of the find box go after it
    for (const raw of String(excludeText || '').split(SPLIT_RE)) {
      const tok = parseToken(raw, true);
      if (tok) addExclude(tok.word);
    }
    for (const w of moved) addExclude(w);

    const plus = [...include].map(([w, m]) => (m === 'contains' ? '~' : '') + w);
    const minus = [...exclude.keys()];
    const contains = plus.filter((w) => w.startsWith('~')).length;
    return { plus, minus, exact: plus.length - contains, contains, duplicates, movedToExclude };
  }

  // 1.2.4 keyword string, e.g. "레전드, ~ㅋㅋㅋ, -광고" (kwsKeyword / soopKeyword / profile.keyword).
  function toKeywordString(plus, minus) {
    return plus.concat(minus.map((x) => '-' + x)).join(', ');
  }

  // For the editor boxes: one per line.
  function plusToText(plus) { return (plus || []).join('\n'); }
  function minusToText(minus) { return (minus || []).join('\n'); }

  // Everything as one Notepad-friendly block; pasting it into the "find" box restores both lists.
  function toCopyText(plus, minus) {
    return (plus || []).concat((minus || []).map((x) => '-' + x)).join('\n');
  }

  // Read what the 1.2.4 storage holds: profile first, else the keyword string.
  function fromStored(profile, keywordString) {
    if (profile && Array.isArray(profile.plus) && profile.plus.length) {
      return { plus: profile.plus.map(String), minus: Array.isArray(profile.minus) ? profile.minus.map(String) : [] };
    }
    const s = (profile && profile.keyword) || keywordString || '';
    if (!s.trim()) return null;
    const r = parseKeywordText(s, '');
    return { plus: r.plus, minus: r.minus };
  }

  global.KWSKeywords = { parseKeywordText, toKeywordString, plusToText, minusToText, toCopyText, fromStored };
})(globalThis);
