async function requestFromBackground(obj) {
  return new Promise((res, rej) =>
    chrome.runtime.sendMessage(obj, (response) => res(response)),
  );
}

/*
https://voddownloader.com
**Now allows for viewing/downloading stories, highlights and clips.
Version 3.19 update: (4 Feb 2025)
1)

*/
const ext_version_number = 3.26;
const ext_last_updated = `21 Feb 2026`;
const ext_updates = [
  {
    date: `21 Feb 2026`,
    version: '3.26',
    items: [
      `Fixed bug in kick VODs where my stream data logger wasnt returning hidden VODs.`,
      `Fixed bug in kick VOD list where title was not showing.`,
    ]
  },
  {
    date: `2 Dec 2026`,
    version: '3.25',
    items: [
      `Fixed bug in auth flow`,
      `Fixed issue with kick endpoint variability`,
      `Fixed issue with UHD Twitch video viewing and download`,
      `Added notification for VOD availability with partners`,
    ]
  },
  {
    date: `21 Nov 2025`,
    version: '3.24',
    items: [
      `Added a stream logging database. No longer reliant on twitchtracker`,
      `Added Account creation so users can access the new stream logging database`,
      `Twitch VODs API bug fix`,
      `Kick VODs bug fix`,
    ]
  },
  {
    date: `17 Nov 2025`,
    version: '3.23',
    items: [
      `Kick update. bug fixes`,
    ]
  },
  {
    date: `11 Feb 2025`,
    version: '3.21',
    items: [
      `Bugfix- Addressed remaining icon issues with the recent darkmode changes`,
      `Bugfix- Addressed scrollbar issue on the icon introduced in last update`,
      `Bugfix- Addressed issue where saved resolution not existing within the current VOD resolution caused failure for VOD to load.`,
      `Bugfix- Addressed issue where users were allowed to run a search with nothing in the input field`,
      `Some background stuff for implementing Kick, but it is not yet complete.`,
    ]
  },
  {
    date: `9 Feb 2025`,
    version: '3.19',
    items: [
      `UI change- Added ability to select from 6 different border/button color options within the settings menu.`,
      `UI change- Added ability to change resolution selection on the download page rather than just taking the selection from the VOD view.`,
      `UI change- Added settings for default file name format. (no. mp4 is not available)`,
      `Bugfix- Failure to retrieve hidden VODs no longer blocks retrieving the displayed VODs. This does not yet address the underlying issue where some people are getting blocked from accessing hidden VODs.`,
      `Bugfix- Addressed issue with mod view where channel name did not populate.`,
      `Bugfix- Addressed issues with darkmode setting.`,
      `Bugfix- Addressed issue with file name where end time was the start of the last fragment instead of the end -- thus causing the time displayed to be off by around 10 seconds.`,
      `Bugfix- Addressed issue where fractional fragments were causing the slider UI to fail to re-align on window resize.`,
      `UX change- Clicking any view will bring it to the front/top of the stack. Prior behavior required a user to drag a view to bring to the front.`,
    ],
    demo_link:`https://youtu.be/0ac5fgIQ1hU`,
  },
  {
    date: `3 Feb 2025`,
    version: '3.18',
    items: [
      `Bug fix- Addressed issue with VOD controls interference with view dragging.`
    ],
  },
  {
    date: `1 Feb 2025`,
    version: '3.17',
    items: [
      `Bug fix- Addressed issue with VODs sometimes failing to be found where streamer name includes underscore`,
      `Bug fix- Addressed issue with file names on multiple file downloads`,
      `Downloading multiple files no longer requires the tab to remain in view`,
      `Added ability to download stories.`,
      `Added chat view back where available. Not all VODs or even livestreams will have chat available.`,
      `Added titles to recent streams menu where available.`,
      `Added color to the resize edge of containers in an effort be more visible.`,
      `Added menu for users to review updates.`,
      `Added slider selector back to the VOD download.`
    ],
    demo_link:`https://youtu.be/jaUo3ROumE8`,
  },
  {
    date: `30 Jan 2025`,
    version: '3.16',
    items: [`bugfix- Attempt to resolve issue where some viewers are not getting video controls.`]
  },
  {
    date: `29 Jan 2025`,
    version: '3.15',
    items: [`bugfix- resolved issue with VOD page views due to a change implemented in v3.14.`,
    `minor UI changes.`]
  },
  {
    date: `28 Jan 2025`,
    version: '3.14',
    items: [`Added view/download functionality for highlights.`,
      `bux fix- another attempt to resolve the main app button showing in theatre mode. clicking the theatre mode button OR using the command Alt+T should now work.`,
      `bug fix- hiding main app button on pop-out views.`,
      `added back discord and donation buttons to the main menu.`,`
      added darkmode option to settings menu.`]
  },
  {
    date: `27 Jan 2025`,
    version: '3.13',
    items: [`bug fix- resolved issue with VOD list failing to find hidden VODs`,`
      bug fix- resolved issue with view-current-stream and current-vod buttons introduced in 3.12`,`
      bug fix- hide main app button when in theatre mode.`,`
      added clip download functionality. (clips are mp4 files from the server)`,`
      moved settings button to bottom of main menu.`]
  },
  {
    date: `23 Jan 2025`,
    version: '3.12',
    items: [`Added View Current stream and current VOD for people who refuse to watch the demo video and thus think functionality has been removed.
    `]
  },

  {
    date: `20 Jan 2025`,
    version: '3.11',
    items: [`Chat removed for now`,`
    UI overhaul. See demo video`],
    demo_link:'https://youtu.be/AMNDcljbjB0',
  },
];

const subArr = (r, n) => r.reduceRight((a, b, c, d) => [...a, d.splice(0, n)], []);
// btoaJSON/atobJSON moved to domUtils.js (loaded on more platforms, incl. SOOP)

var nthFloat = (n, m, t) =>
  Math[t ? t : "floor"](
    n *
      parseInt(
        `1${Array(m)
          .fill()
          .map((i) => "0")
          .reduce((a, b) => a + b)}`,
      ),
  ) /
  parseInt(
    `1${Array(m)
      .fill()
      .map((i) => "0")
      .reduce((a, b) => a + b)}`,
  );
var getDecimal = (n, m, t) => nthFloat(n % 1, m || 3, t || "round");

const delay = (ms) => new Promise((res) => setTimeout(res, ms));
const rando = (n) => Math.round(Math.random() * n);
var unqHsh = (a, o) => a.filter((i) => (o.hasOwnProperty(i) ? false : (o[i] = true)));
function unqKey(array, key) {
  var q = [];
  var map = new Map();
  for (const item of array) {
    if (!map.has(item[key])) {
      map.set(item[key], true);
      q.push(item);
    }
  }
  return q;
}


var cleanObject = (ob) =>
  ob
    ? Object.entries(ob).reduce((r, [k, v]) => {
        if (
          v != null &&
          v != undefined &&
          v !== "" &&
          (["string", "number", "boolean", "function", "symbol"].some(
            (opt) => typeof v == opt,
          ) ||
            (typeof v == "object" &&
              ((Array.isArray(v) && v.length) || Array.isArray(v) != true)))
        ) {
          r[k] = v;
          return r;
        } else {
          return r;
        }
      }, {})
    : null;
function domplate(output) {
  var el = document.createElement("textarea");
  document.body.appendChild(el);
  el.value = output;
  el.select();
  document.execCommand("copy");
  el.remove();
}

function dateString(d) {
  var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec",];
  var date = new Date(d);
  return `${date.getDate()} ${months[date.getMonth()]} ${date.getFullYear()}`;
}

function dateTimeString(d) {
  var week = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec",];
  var date = new Date(d);
  let hours = date.getHours();
  let mins = date.getMinutes();
  let hour =
    hours > 12
      ? hours - 12 > 9
        ? `${hours - 12}`
        : `0${hours - 12}`
      : hours == 0
        ? "12"
        : `${hours}`;
  let min = mins > 9 ? `${mins}` : `0${mins}`;
  let am_pm = hours >= 12 ? "PM" : "AM";
  return `${week[date.getDay()]}, ${date.getDate()} ${months[date.getMonth()]} ${date.getFullYear()} ${hour}:${min} ${am_pm}`;
}

var isValidDate = (s) => !new Date(s).valueOf() === false;
function normalizeDateTimeInput(str) {
  var str = str?.replace(/\Bpm$|\Bam$/gi, (s) => ` ${s}`);
  if (isValidDate(str)) {
    var pm = /pm$/i.exec(str)?.[0];
    var time_map = Array.from(
      str.match(/\d{1,2}(?=:)|(?<=:)\d{2}/g) || [],
    )?.map((t) => parseInt(t?.replace(/^0/, "")));
    // console.log("time_map", time_map);
    var date_string = dateString(str);
    if (time_map.length > 1) {
      var fixed_time_map =
        time_map.length == 2
          ? [
              pm && time_map[0] < 12 && time_map[0] != 0
                ? time_map[0] + 12
                : time_map[0],
              time_map[1],
              0,
            ]
          : time_map.length == 3
            ? time_map.slice(0, 3)
            : [""];
      var time_string = fixed_time_map
        ?.map((t) => (t < 10 ? `0${t}` : `${t}`))
        .reduce((a, b) => a + ":" + b);
      var date_time_string = `${date_string} ${time_string}`;
      // console.log("date_time_string", date_time_string);
      return isValidDate(date_time_string) ? new Date(date_time_string) : false;
    } else {
      // console.log('date_string',date_string);
      return new Date(date_string);
    }
  } else {
    // console.log('Invalid Date')
    return false;
  }
}
function validateRecentYearInDateString(str){
    let has_year =  /\b20\d\d\b/.test(str);
    let input_year = new Date(str).getFullYear();
    let current_year = new Date().getFullYear();
    let input_month = new Date(str).getMonth();
    let current_month = new Date().getMonth();
    // let months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    // let now = new Date().getTime();
    if(has_year){
        return str;
    }else{
        let current = str.replace(/(?=\d{1,2}:\d{1,2})/,`${current_year} `);
        let last = str.replace(/(?=\d{1,2}:\d{1,2})/,`${current_year-1} `);
        // let d1 = new Date(current).getTime();
        // let d2 = new Date(last).getTime();
        return current_month >= input_month ? current : last;
    }
}


function parseTimeOffset(s) {
  // content_offset_seconds: 1427.737
  const timeString = (n, k) => `${n >= 1 && n < 10 ? "0" + n.toString() : n >= 10 && n >= 1 ? n : "00"}${k}`;
  let hours = s / 3600;
  let minutes = hours.toString().replace(/\d+(?=\.)/, "");
  let seconds = 60 * parseFloat(minutes);
  let time_arr = [Math.floor(hours),Math.floor(60 * minutes),Math.floor(60 * seconds.toString().replace(/\d+(?=\.)/, "")),];
  return `${timeString(time_arr[0], "h")}${timeString(time_arr[1] >= 60 ? 0 : time_arr[1], "m")}${timeString(time_arr[2] >= 60 ? 0 : time_arr[2], "s")}`;
} //new version. 24 Aug 2023.-AndreB
function getTimeValueFromInputString(s) {
  const intFromStringTime = (v, k) => new RegExp(`(\\d+)${k}`, "i").exec(v)?.[0]?.replace(/^0/, "") ? parseInt(new RegExp(`(\\d+)${k}`, "i").exec(v)?.[0]?.replace(/^0/, "")) : 0;
  const intFromColonTime = (v) => v.split(/:/).map((i) => i.trim()).filter((i) => /\d+/.test(s)).map((i) => parseInt(i));
  let sh = /:/.test(s) ? intFromColonTime(s).at(-3) * 3600 : intFromStringTime(s, "h") * 3600;
  let sm = /:/.test(s) ? intFromColonTime(s).at(-2) * 60 : intFromStringTime(s, "m") * 60;
  let ss = /:/.test(s) ? intFromColonTime(s).at(-1) : intFromStringTime(s, "s");
  return sh + sm + ss;
}
function fixUTClocalityTimestamp(params) {
  //passes time back through to ensure we are getting the correct offset for the time of year (daylight savings time). This will fail if the time happens to be within the scope of a time change.
  var { timestamp, timestamp_seconds, startDateTime, published_at } = params;
  var time =
    timestamp ||
    Math.floor(timestamp_seconds / 1000) ||
    (startDateTime
      ? new Date(startDateTime).getTime()
      : published_at
        ? new Date(published_at).getTime()
        : null);
  if (time) {
    return timestamp + -(new Date(time).getTimezoneOffset() * 60000);
  } else {
    return null;
  }
}

function getTimeValueFromInputString(s) {
  const intFromStringTime = (v, k) =>
    new RegExp(`(\\d+)${k}`, "i").exec(v)?.[0]?.replace(/^0/, "")
      ? parseInt(new RegExp(`(\\d+)${k}`, "i").exec(v)?.[0]?.replace(/^0/, ""))
      : 0;
  const intFromColonTime = (v) =>
    v
      .split(/:/)
      .map((i) => i.trim())
      .filter((i) => /\d+/.test(s))
      .map((i) => parseInt(i));
  let sh = /:/.test(s)
    ? intFromColonTime(s).at(-3) * 3600
    : intFromStringTime(s, "h") * 3600;
  let sm = /:/.test(s)
    ? intFromColonTime(s).at(-2) * 60
    : intFromStringTime(s, "m") * 60;
  let ss = /:/.test(s) ? intFromColonTime(s).at(-1) : intFromStringTime(s, "s");
  return sh + sm + ss;
}

const unqDiveKey = (a, o, keys) =>
  a.filter((i) =>
    o.hasOwnProperty(dive(i, keys)) ? false : (o[dive(i, keys)] = true),
  );
const dive = (ob, keys) => keys.map((itm) => (ob = ob?.[itm])).at(-1);
function getTokensFromCookies() {
  var c = document.cookie;
  return cleanObject({
    client_session_id: Array.from(document.querySelectorAll("img") || [])
      .map((elm) => /(?<=sessionid=)\S+?(?=\&)/.exec(elm.src)?.[0])
      ?.filter(Boolean)?.[0],
    video_id: /twitch\.tv\/videos\/(\d+)/.exec(window.location.href)?.[1],
    // channel_login: !/twitch\.tv\/videos\/(\d+)|twitch\.tv\/\w+\/videos/.test(window.location.href) ? /(?<=tv\/)\w+/.exec(window.location.href)?.[0] : null,
    api_token: /(?<=api_token\=).+?(?=;)/.exec(c)?.[0],
    device_id: /(?<=unique_id\=).+?(?=;)/.exec(c)?.[0],
    authorization: /(?<=%22authToken%22:%22).+?(?=%22)/.exec(c)?.[0]
      ? "OAuth " + /(?<=%22authToken%22:%22).+?(?=%22)/.exec(c)?.[0]
      : "",
    oauth: /(?<=%22authToken%22:%22).+?(?=%22)/.exec(c)?.[0]
      ? "OAuth " + /(?<=%22authToken%22:%22).+?(?=%22)/.exec(c)?.[0]
      : "",
    client_id:
      /(?<="Client-ID":"|clientId=").+?(?=")/.exec(
        Array.from(document.getElementsByTagName("script"))?.filter((i) =>
          /(?<="Client-ID":"|clientId=").+?(?=")/.test(i.innerHTML),
        )?.[0]?.innerHTML,
      )?.[0] || "kimne78kx3ncx6brgo4mv6wki5h1ko",
    user_id: /%22id%22:%22(\d+)%/.exec(c)?.[1],
    user_login: /%22login%22:%22(\w+)%/.exec(c)?.[1],
  });
}
function getChannelLogin() {
  var channelHref = () => {
    let mod_view = /(?<=twitch.tv\/moderator\/)\w+/.exec(window.location.href)?.[0];
    let kick_channel = document.getElementById("channel-username")?.textContent?.toLocaleLowerCase() || /(?<=kick\.com\/)\w+/.exec(window.location.href)?.[0];
    let twitch_channel_href = Array.from(document.getElementById('live-channel-stream-information')?.getElementsByTagName('h1') || [])?.[0]?.parentElement?.href;
    let twitch_channel = document.getElementsByClassName("channel-info-content")?.[0]?.getElementsByTagName("section")?.[0]?.getElementsByTagName("a");
    return mod_view ? `twitch.tv/${mod_view}` : kick_channel ? `kick.com/${kick_channel}` : twitch_channel_href || Array.from(twitch_channel || []).filter((r) => /(?<=\.tv\/)\w+|(?<=kick\.com\/)\w+/.test(r?.href),)?.[1]?.href;
  };
  let channel_login = /(?<=\.tv\/)\w+|(?<=kick\.com\/)\w+/.exec(channelHref(),)?.[0];
  if (channel_login) {
    return channel_login?.toLowerCase();
  } else {
    return /(?<=tv\/)\w+|(?<=kick\.com\/)\w+/.exec(channelHref())?.[0]?.toLowerCase();
  }
}

async function getDownloadableArrayBuffer(params){
  var { url } = params;
  try{
    var res = await fetch(url);
    var headers = res.headers;
    var content_type = headers.get('content-type');
    var content_length = headers.get('content-length');
    var last_modified = headers.get('last-modified')
    var buffer = await res.arrayBuffer();
    if(buffer?.byteLength){
      return { ...params, ...{ buffer,content_type,content_length,last_modified } };
    }else{
      return { ...params, ...{ content_type,content_length,last_modified } };
    }
  }catch(err){
    return params;
  }
}
//
// async function getDownloadableArrayBuffer(url) {
//   function getResBlob(url) {
//     return new Promise((res) => {
//       var xhr = new XMLHttpRequest();
//       xhr.open("GET", url, true);
//       xhr.responseType = "arraybuffer";
//       var content_type = xhr.getResponseHeader('Content-Type');
//       xhr.onload = function (e) {
//         if (this.status == 200) {
//           res(this.response);
//         } else {
//           res(false);
//         }
//       };
//       xhr.send();
//     });
//   }
//   return await getResBlob(url);
// }
async function fetchText(url) {
  try {
    var res = await fetch(url);
    var text = await res.text();
    return text;
  } catch (err) {
    return null;
  }
}

const getLiveTimeFromDOM = () =>
  document.getElementsByClassName("live-time")[0]
    ? getTimeValueFromInputString(
        document.getElementsByClassName("live-time")[0].innerText,
      )
    : null;


var awsDateTime = (d)=>new Date(d).toISOString()?.replace(/\.\d+?(?=Z)/, '')?.replace(/\W+/g, '')
var friendlyDate = (d) => { if (!d) return ''; const dt = new Date(d > 1e11 ? d : d * 1000); const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']; return String(dt.getDate()) + ' ' + months[dt.getMonth()] + ' ' + dt.getFullYear(); }

var floatString = (s)=> /[\d,\.]+/.exec(s)?.[0] ?parseFloat(/[\d,\.]+/.exec(s)?.[0]?.replace(/,/g,'')) : 0;
var nthFloat = (n,m,t)=> Math[(t ? t : 'floor')]((n)*parseInt(`1${Array(m).fill().map(i=> '0').reduce((a,b)=> a+b)}`))/parseInt(`1${Array(m).fill().map(i=> '0').reduce((a,b)=> a+b)}`);
var getDecimal = (n,m,t)=> nthFloat((n % 1),(m||3),(t||'round'));


var unqMultiKey = (a,o,keys) => {
    return a.filter(i=> {
        let mergekey = (keys.map(key=> i[key]).reduce((a,b)=> a+b));
        return o.hasOwnProperty(mergekey) ? false : (o[mergekey] = true);
    })
};

function validateTimeInput(params){
    var {input} = params;
    var zeroFront = (str)=> str < 10 ? `0${str}` : str;
    // var valid = /\d{1,2}\D{1}\d{1,2}\D{1}\d{1,2}/.exec(input)?.[0];
    var nums = input?.split(/\D/);
    var hour = floatString(nums?.[0]);
    var min = parseTimeOver60(floatString(nums?.[1]));
    var sec = parseTimeOver60(floatString(nums?.[2]));
    var s = sec.base;
    var m = min.base + sec.overage;
    var h = hour + min.overage;
    return `${zeroFront(h)}h${zeroFront(m)}m${zeroFront(s)}s`;
}
function parseTimeOver60(t){
    let num = Math.floor(t/60);
    let base = t-(num * 60);
    return {base:base,overage:num};
}

function getInfoFromM3u8Link(params){
    var {source, channel_login, timestamp, timestamp_seconds, resolution} = params;
    var extraction = /(?<=https:\/\/)(\w+?)\.cloudfront\.net\/(\w+?)_(\w+?)_(\d+?)_(\d+?)\/(\w+?)\//.exec(source);
    // Twitch VOD URLs (*.cloudfront.net/<hash>_<channel_login>_<streamid>_<timestamp>/<res>/...) embed
    // this metadata right in the URL, but Kick's VOD URLs (stream.kick.com/.../ivs/v1/.../media/hls/...)
    // don't follow that convention at all, so `extraction` comes back null and every field below used to
    // silently become `undefined` — which is why the Kick download filename showed a literal "undefined"
    // where the channel name should be. Falling back to whatever the caller already passed in (buildVideoViewer
    // always supplies channel_login/timestamp/resolution itself) fixes this without touching Twitch's path,
    // since there `extraction` succeeds and these fallbacks never get used.
    return {
        source:source,
        m3u8_server:extraction?.[1],
        hash:extraction?.[2],
        channel_login:extraction?.[3] || channel_login,
        stream_id:extraction?.[4],
        timestamp_seconds:extraction?.[5] != null ? parseInt(extraction[5]) : (timestamp_seconds ?? (timestamp != null ? Math.floor(timestamp/1000) : undefined)),
        timestamp:extraction?.[5] != null ? parseInt(extraction[5])*1000 : timestamp,
        name:extraction?.[6] || resolution,
        resolution:extraction?.[6] || resolution,
    }
}

function pauseOtherVideoElms(){
    Array.from(document.getElementsByTagName('video'))?.filter(v=> !/pop_out_video/.test(v.className)).forEach(v=> {
        if(v.paused === false){
            v.pause()
        }
    })
}













/*
TT
Array.from(document.querySelectorAll('[type="application/json"]') || []).map(r=> JSON.parse(r.innerHTML))
    ?.map(r=> r?.['__DEFAULT_SCOPE__']?.['webapp.video-detail']?.['itemInfo']?.['itemStruct']?.['video']?.['bitrateInfo']?.map(b=> b?.PlayAddr))?.filter(r=> r)?.[0]?.map(r=> {
        return {
            ...r,
            ...{
                resolution:/(?<=_)\d+(?=p_)/.exec(r?.UrlKey)?.[0] ? parseInt(/(?<=_)\d+(?=p_)/.exec(r?.UrlKey)?.[0]) : '',
                name:/(?<=_)\d+p(?=_)/.exec(r?.UrlKey)?.[0],
                url:r?.['UrlList']?.[1],
                size:r?.DataSize ? parseInt(r?.DataSize) : 0,
            }
        }
    }).sort((a,b)=> a.resolution > b.resolution ? -1 : 0)
*/


// parseTimeOver60(59)
// `00h00m00s
// 00h60m02s
// 00:00:00`.split(/\n/)?.map(r=> validateTimeInput({input:r}))


/**


Version 2.30 update: (16 Nov 2024)
1) Copy m3u8 icon on livestream view will now copy the livestream m3u8 link instead of the VOD.
2) Added storage permission so the application can make fewer requests by storing your twitch tokens in local storage. This will also allow for users to change UI settings in the next update.
3) Fixed text color issue with UI on Twitch Light mode.

Version 2.29 update: (19 Sep 2024)
1) partial patch bringing back SOME functionality on the "recent streams" option.

Version 2.28 update: (8 Jan 2024)
1) Added chat history for VODs which HAVE NOT been deleted/unpublished. Deleted/unpublished chats will NOT be available.

Version 2.27 update: (6 Jan 2024)
1) Small patch which will fix SOME of the issues with retrieving streams.

Version 2.26 update: (26 Dec 2023)
1) Fixed bug introduced in v2.25 that caused miscount in segments.
2) Information update on "find recent vods" option.

Version 2.25 update: (23 Dec 2023)
1) Fixed bug introduced in v2.24 that caused full VOD downloads to fail.
2) Small UI bugfix on the progress download indicator.

Version 2.24 update: (22 Dec 2023)
1) Fixed VOD selection clipping issue where selection timing did not align.

Version 2.23 update: (18 Dec 2023)
1) Bug fixes and minor UI changes.
2) Changed video output to m4v file to help with loading into video editor tools.

Version 2.22 update: (21 Oct 2023)
1) Added ability to seek in video viewer by 10 seconds. Shift+ArrowUp will go forward 10 seconds and Shift+ArrowDown will go back 10 seconds.

Version 2.19 updates: (4 July 2023)
1) Fixed some UI bugs related to displaying the stream date
2) Added discord invite link to menu (discord.gg/sSJsqjKyYg)

Version 2.17 updates: (2 Jul 2023)
1) Fixed issue with retrieving recent VODs
2) Added donation button

Version 2.16 updates: (25 Jan 2023)
1) Changed download to mp4 format
2) Video player now attempts to find the first valid VOD segment before playing. This fixes the hang-up when a deleted VOD is available but has missing segments. This is just a partial fix. It will drop you where the first valid segment exists, but it will not skip over missing segments.
3) Changed the UI behavior. Hovering over the button no longer pulls up the menu. Clicking now opens the menu and you can click from there for further actions.

Version 2.14 updates: (22 Nov 2022)
1) UI improvements

Version 2.12 updates: (21 Nov 2022)
1) Fixed bug introduced in 2.11 where livestream download segment selection caused failure.
2) Added UI notices for why a VOD is failing to download for the leech bed blobs who complain about free software not holding their hand.

Version 2.11 updates: (16 Nov 2022)
1) Added ability to pull stream with streamcharts or twitchtracker stream link
2) UI changes
3) refactoring and bug fixes

Version 1.26 updates: (6 Nov 2022)
Reversion to v1.24 due to stability issues in 1.25

Version 1.25 updates: (5 Nov 2022)
    1) Added ability to watch current stream within the VOD viewer. Using this to view the current live stream bypasses ads. This approach is a bit choppy and will have a 10-15 second delay from the stream.
    2) Added ability to slow and speed up video player from 0.1x to 3.0x
    3) Added ability select quality options on VOD Viewer including audio only

Version 1.24 updates: (28 Oct 2022)
    1) Added resolution download options to deleted VODs
    2) Bug fixes from 1.23 updates

Version 1.23 updates: (27 Oct 2022)
    1) Added ability to play VOD from within the individual VOD download section. This allows one to bypass ads and view sub-only VODs.
    2) Added ability to one-click skip to the unmuted portion of a VOD while in the VOD viewer.
    3) Fixed issue with muted audio being deleted from be download
    4) Fixed issue with being unable to watch VODs with muted sections

Version 1.22 updates: (26 Oct 2022)
    1) Added ability to view the 20 most recent streams regardless of if the VODs were deleted.
    2) Fixed issue with not being able to download sub only VODs (can only download if the VOD was recent)

Version 1.20 updates: (25 Oct 2022)
    1) bug fixes and small UI updates.

Version 1.19 updates: (24 Oct 2022)
    1) Added ability to download the 20 most recent streams regardless of if the VODs were deleted. This can be run from the main channel or the videos section of a stream but not within a specific VOD.

Version 1.18 updates: (20 Oct 2022)
    1) Bugfix - audio-only download was broken from changes in v1.17

Version 1.17 updates: (17 Oct 2022)
    1) Added ability to download current stream

Version 1.16 updates: (12 Oct 2022)
    1) Added ability to download an audio only file
    2) Filename download now includes the date of the VOD

Version 1.15 updates:
    1) Improved video slider selection
    2) selections can be manually entered within the slider labels
    3) fixed issue with the button failing to load on navigation

Version 1.14 updates:
    1) added ability to select video quality
    2) user interface is now proportional to the width of the current window

*/
