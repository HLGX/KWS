// VOD KWS — Unified History Window
(function() {
  if (window.KWSHistoryUI) return;

  const esc = s => String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');


  function open({ platform, HISTORY, HISTORY_KEY, onScan, onIdClick, accentColor = '#60a5fa', onImport, onScanComplete, onGetScanState }) {
    const WIN_ID = `kws-history-win-${platform}`;
    const existing = document.getElementById(WIN_ID);
    if (existing) { existing.remove(); return; }

    const win = document.createElement('div');
    win.id = WIN_ID;
    if (!document.getElementById('kws-history-win-scrollbar-style')) {
      const scrollStyle = document.createElement('style');
      scrollStyle.id = 'kws-history-win-scrollbar-style';
      scrollStyle.textContent = `
        #${WIN_ID} ::-webkit-scrollbar { width:8px; }
        #${WIN_ID} ::-webkit-scrollbar-track { background:transparent; }
        #${WIN_ID} ::-webkit-scrollbar-thumb { background:rgba(255,255,255,0.15);border-radius:99px; }
      `;
      document.head.appendChild(scrollStyle);
    }
    win.style.cssText = [
      'position:fixed;top:60px;right:20px;width:360px;max-height:80vh;',
      'background:#0f1117;border:1px solid rgba(255,255,255,0.1);border-radius:14px;',
      `box-shadow:0 8px 32px rgba(0,0,0,0.6);z-index:${typeof topZIndexer === 'function' ? topZIndexer() : 2147483640};`,
      'display:flex;flex-direction:column;overflow:hidden;font-family:-apple-system,sans-serif;',
    ].join('');

    // 헤더
    const header = document.createElement('div');
    header.style.cssText = 'display:flex;flex-direction:column;gap:8px;padding:13px 16px 11px;border-bottom:1px solid rgba(255,255,255,0.08);cursor:grab;flex-shrink:0;background:rgba(255,255,255,0.03);';
    header.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;">
        <div style="display:flex;align-items:center;gap:6px;min-width:0;">
          <span style="font-size:12px;font-weight:800;color:${accentColor};letter-spacing:0.05em;white-space:nowrap;">SEARCH HISTORY</span>
          <span id="${WIN_ID}-count" style="font-size:11px;color:rgba(255,255,255,0.4);"></span>
        </div>
        <button id="${WIN_ID}-close" style="box-sizing:border-box;width:26px;height:26px;padding:0;border:none;border-radius:8px;background:rgba(255,255,255,0.08);color:rgba(255,255,255,0.6);cursor:pointer;font-size:15px;line-height:1;flex-shrink:0;display:inline-flex;align-items:center;justify-content:center;text-shadow:none;filter:none;">×</button>
      </div>
      <div style="display:flex;align-items:center;gap:5px;">
        <button id="${WIN_ID}-export" style="box-sizing:border-box;flex:1;padding:5px 12px;border:1px solid rgba(255,255,255,0.15);border-radius:8px;background:rgba(255,255,255,0.08);color:rgba(255,255,255,0.8);cursor:pointer;font-size:11px;font-weight:700;text-shadow:none;-webkit-text-stroke:0;filter:none;">Export</button>
        <button id="${WIN_ID}-import" style="box-sizing:border-box;flex:1;padding:5px 12px;border:1px solid ${accentColor}66;border-radius:8px;background:${accentColor}22;color:${accentColor};cursor:pointer;font-size:11px;font-weight:700;text-shadow:none;-webkit-text-stroke:0;filter:none;">Import</button>
        <button id="${WIN_ID}-clear" style="box-sizing:border-box;flex:1;padding:5px 12px;border:1px solid rgba(239,68,68,0.3);border-radius:8px;background:rgba(239,68,68,0.1);color:rgba(248,113,113,0.85);cursor:pointer;font-size:11px;font-weight:700;text-shadow:none;-webkit-text-stroke:0;filter:none;">Clear</button>
      </div>
    `;

    // 필터
    const filterBar = document.createElement('div');
    filterBar.style.cssText = 'padding:8px 14px;border-bottom:1px solid rgba(255,255,255,0.07);flex-shrink:0;background:rgba(255,255,255,0.02);';
    filterBar.innerHTML = `<input id="${WIN_ID}-filter" type="text" placeholder="Filter by name or memo..." style="width:100%;box-sizing:border-box;padding:5px 10px;border-radius:8px;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.05);color:#e2e8f0;font-size:11px;outline:none;font-family:inherit;">`;

    // 리스트
    const scroll = document.createElement('div');
    scroll.style.cssText = 'overflow-y:auto;flex:1;padding:8px 10px;display:flex;flex-direction:column;gap:4px;scrollbar-width:thin;scrollbar-color:rgba(255,255,255,0.2) transparent;';

    win.appendChild(header);
    win.appendChild(filterBar);
    win.appendChild(scroll);
    document.body.appendChild(win);

    // 드래그
    let dragging = false, dx = 0, dy = 0;
    header.addEventListener('mousedown', e => {
      if (e.target.tagName === 'BUTTON') return;
      dragging = true; dx = e.clientX - win.offsetLeft; dy = e.clientY - win.offsetTop;
      header.style.cursor = 'grabbing';
      if (typeof topZIndexer === 'function') win.style.zIndex = topZIndexer();
    });
    win.addEventListener('mousedown', () => {
      if (typeof topZIndexer === 'function') win.style.zIndex = topZIndexer();
    });
    document.addEventListener('mousemove', e => {
      if (!dragging) return;
      win.style.left = (e.clientX - dx) + 'px';
      win.style.top  = (e.clientY - dy) + 'px';
      win.style.right = 'auto';
    });
    document.addEventListener('mouseup', () => { dragging = false; header.style.cursor = 'grab'; });

    // 버튼 이벤트
    document.getElementById(`${WIN_ID}-close`).addEventListener('click', () => win.remove());
    document.getElementById(`${WIN_ID}-filter`).addEventListener('input', () => render());

    document.getElementById(`${WIN_ID}-export`).addEventListener('click', () => {
      // 통합 포맷으로 Export (KWSUnifiedHistory 사용)
      const doExport = async () => {
        let exportData;
        if (window.KWSUnifiedHistory) {
          exportData = await window.KWSUnifiedHistory.exportAll();
        } else {
          exportData = HISTORY;
        }
        const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        const _d = new Date();
        const _dateStr = `${_d.getFullYear()}-${String(_d.getMonth()+1).padStart(2,'0')}-${String(_d.getDate()).padStart(2,'0')}`;
        a.download = `kws-history-${_dateStr}.json`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      };
      doExport();
    });

    document.getElementById(`${WIN_ID}-import`).addEventListener('click', () => {
      const input = document.createElement('input');
      input.type = 'file'; input.accept = '.json';
      input.onchange = async e => {
        try {
          const text = await e.target.files[0].text();
          const data = JSON.parse(text);
          let imported = 0;
          const META_KEYS = new Set(['schema','version','exportedAt','settings','records','_globalKeyword']);

          if (Array.isArray(data.records)) {
            // 플랫폼별로 분류해서 각각 저장
            const platformKeys = { soop: 'soopSearchHistory', twitch: 'twitchKwsHistory', kick: 'kickKwsHistory', youtube: 'ytKwsHistory' };
            const platformData = { soop: {}, twitch: {}, kick: {}, youtube: {} };

            for (const r of data.records) {
              if (!r.id || !platformData[r.platform]) continue;
              const id = r.id.toLowerCase();
              platformData[r.platform][id] = {
                nickname: r.displayName || '',
                lastDate: r.lastDate || '',
                searchedAt: r.searchedAt || r.savedAt || '',
                matchedCount: r.matchedCount ?? 0,
                matchedLines: r.matchedCount ?? 0,
                matchedDays: r.matchedDays ?? 0,
                memo: r.memo || '',
                clickedTimes: r.clickedTimes || {},
              };
              if (r.platform === platform) imported++;
            }

            // 모든 플랫폼 storage에 저장 (chrome.storage.local 직접 사용)
            const setObj = {};
            for (const [p, key] of Object.entries(platformKeys)) {
              if (Object.keys(platformData[p]).length > 0) {
                // 기존 데이터와 병합
                try {
                  const existingData = await chrome.storage.local.get([key]);
                  const existing = existingData[key] || {};
                  setObj[key] = Object.assign({}, existing, platformData[p]);
                } catch {
                  setObj[key] = platformData[p];
                }
              }
            }
            // settings 전체 복원 — export 시 이미 SETTINGS_KEYS로 걸러진 값이므로 그대로 신뢰
            // (예전엔 keyword 관련 몇 개만 골라서 복원해서, auto-close/검색엔진 같은 설정은
            //  export/import 해도 반영이 안 됐음)
            if (data.settings && typeof data.settings === 'object') {
              Object.assign(setObj, data.settings);
            }

            await chrome.storage.local.set(setObj);

            // 현재 플랫폼 HISTORY 갱신
            Object.assign(HISTORY, platformData[platform] || {});
          } else {
            // 직접 포맷: { id: {...} }
            for (const [k, v] of Object.entries(data)) {
              if (META_KEYS.has(k) || k.startsWith('_')) continue;
              if (!v || typeof v !== 'object' || Array.isArray(v)) continue;
              HISTORY[k] = v;
              imported++;
            }
            await chrome.storage.local.set({ [HISTORY_KEY]: HISTORY });
          }

          render();
          if (onImport) onImport();
          // Import 후 키워드 input에 즉시 반영
          try {
            const kwData = await chrome.storage.local.get(['twitchKwsKeywordProfile','soopKeyword']);
            const kw = kwData.twitchKwsKeywordProfile?.keyword || kwData.soopKeyword || '';
            if (kw) {
              // 모든 플랫폼의 KWS keyword input에 값 설정 (존재하는 것만 반영됨)
              const KW_PAIRS = [
                ['soop-keyword','soop-keyword-preview'],
                ['kws-keyword','kws-keyword-preview'],
                ['kkws-keyword','kkws-keyword-preview'],
                ['yt-kws-keyword','yt-kws-kw-preview'],
              ];
              KW_PAIRS.forEach(([id, previewId]) => {
                const el = document.getElementById(id);
                if (!el) return;
                el.value = kw; el.dispatchEvent(new Event('input'));
                if (window.KWSSharedKeywordEditor) window.KWSSharedKeywordEditor.updatePreview(id, previewId);
              });
            }
          } catch {}
          alert('Imported ' + imported + ' entries.');
        } catch(err) { alert('Import failed: ' + err.message); }
      };
      input.click();
    });

    document.getElementById(`${WIN_ID}-clear`).addEventListener('click', async () => {
      if (!confirm('Clear all history?')) return;
      for (const k of Object.keys(HISTORY)) delete HISTORY[k];
      await chrome.storage.local.set({ [HISTORY_KEY]: HISTORY });
      render();
    });

    let _filtered = [];

    function buildRow(id, h) {
        const row = document.createElement('div');
        row.style.cssText = 'padding:9px 11px;border-radius:12px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07);transition:all .15s;cursor:pointer;';
        row.addEventListener('mouseenter', () => { row.style.background='rgba(255,255,255,0.08)'; row.style.borderColor='rgba(255,255,255,0.12)'; });
        row.addEventListener('mouseleave', () => { row.style.background='rgba(255,255,255,0.04)'; row.style.borderColor='rgba(255,255,255,0.07)'; });

        const daysAgo = h.searchedAt ? Math.floor((Date.now() - new Date(h.searchedAt)) / 86400000) : null;
        const dateLabel = daysAgo === 0 ? 'Today' : daysAgo === 1 ? 'Yesterday' : daysAgo !== null ? `${daysAgo}d ago` : '';
        const dateColor = daysAgo !== null && daysAgo > 14 ? '#f87171' : (daysAgo !== null && daysAgo <= 1 ? '#4ade80' : '#fbbf24');
        const nick = h.nickname || h.displayName || '';
        const hits = h.matchedCount ?? h.matchedLines ?? 0;
        const memo = h.memo || '';

        row.innerHTML = `
          <div style="display:flex;align-items:flex-start;gap:8px;">
            <div style="flex:1;min-width:0;">
              <div style="display:flex;align-items:baseline;gap:5px;margin-bottom:3px;">
                <span style="font-size:12px;font-weight:700;color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${nick ? esc(nick) : esc(id)}</span>
                ${nick ? `<span style="font-size:10px;color:rgba(255,255,255,0.35);flex-shrink:0;">${esc(id)}</span>` : ''}
              </div>
              <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
                <span style="font-size:10px;color:rgba(255,255,255,0.45);">${hits} hits</span>
              </div>
            </div>
            <div style="display:flex;align-items:center;gap:4px;flex-shrink:0;">
              <span class="kws-hw-scan" style="padding:2px 8px;border:1px solid ${dateColor}66;border-radius:99px;background:${dateColor}22;color:${dateColor};cursor:pointer;font-size:10px;font-weight:700;white-space:nowrap;line-height:1.6;">${dateLabel || 'Searched'}${memo ? `<span style="color:#f87171;margin-left:4px;">${esc(memo.length > 12 ? memo.slice(0,12)+'…' : memo)}</span>` : ''}</span>
              <button class="kws-hw-memo" title="Edit memo" style="box-sizing:border-box;width:22px;height:22px;padding:0;border:none;border-radius:5px;background:rgba(255,255,255,0.05);color:rgba(248,113,113,0.6);cursor:pointer;font-size:11px;display:inline-flex;align-items:center;justify-content:center;text-shadow:none;filter:none;">📋</button>
              <button class="kws-hw-del" title="Delete" style="box-sizing:border-box;width:22px;height:22px;padding:0;border:none;border-radius:5px;background:rgba(255,255,255,0.05);color:rgba(255,255,255,0.3);cursor:pointer;font-size:13px;font-weight:700;display:inline-flex;align-items:center;justify-content:center;text-shadow:none;filter:none;">×</button>
            </div>
          </div>
          <div class="kws-hw-memo-wrap" style="display:none;margin-top:6px;">
            <input class="kws-hw-memo-input" type="text" value="${esc(memo)}" placeholder="Add memo... (Enter to save)"
              style="width:100%;box-sizing:border-box;padding:5px 9px;border-radius:7px;border:1px solid rgba(248,113,113,0.35);background:rgba(255,255,255,0.06);color:#fff;font-size:11px;outline:none;font-family:inherit;">
          </div>
        `;

        // 클릭 → ID 채우기
        row.addEventListener('click', e => {
          if (e.target.closest('.kws-hw-scan, .kws-hw-memo, .kws-hw-del, .kws-hw-memo-input')) return;
          if (onIdClick) onIdClick(id, h);
        });

        // 초기 스캔 상태 반영
        const _initState = onGetScanState ? onGetScanState(id) : 'idle';
        if (_initState !== 'idle') {
          const _badge = row.querySelector('.kws-hw-scan');
          if (_initState === 'running') {
            _badge.textContent = '⏳ scanning';
            _badge.style.cssText = _badge.style.cssText.replace(/border:[^;]+/, 'border:1px solid rgba(251,146,60,0.4)');
            _badge.style.background = 'rgba(251,146,60,0.15)';
            _badge.style.color = '#fb923c';
          } else if (_initState === 'queued') {
            _badge.textContent = '⏳ queued';
            _badge.style.background = 'rgba(6,182,212,0.15)';
            _badge.style.color = '#22d3ee';
          }
          // 폴링 시작
          const _poll = setInterval(() => {
            if (!document.contains(row)) { clearInterval(_poll); return; }
            const st = onGetScanState ? onGetScanState(id) : 'idle';
            if (st === 'idle') { clearInterval(_poll); render(); }
            else if (st === 'running') { _badge.textContent = '⏳ scanning'; _badge.style.background='rgba(251,146,60,0.15)'; _badge.style.color='#fb923c'; }
            else if (st === 'queued') { _badge.textContent = '⏳ queued'; _badge.style.background='rgba(6,182,212,0.15)'; _badge.style.color='#22d3ee'; }
          }, 1000);
        }

        // KWS ▶ - 클릭 시 상태 폴링으로 실시간 업데이트
        row.querySelector('.kws-hw-scan').addEventListener('click', e => {
          e.stopPropagation();
          const scanBadge = row.querySelector('.kws-hw-scan');
          // 즉시 queued 표시
          const setQueued = () => {
            scanBadge.textContent = '⏳ queued';
            scanBadge.style.borderColor = 'rgba(6,182,212,0.4)';
            scanBadge.style.background = 'rgba(6,182,212,0.15)';
            scanBadge.style.color = '#22d3ee';
          };
          setQueued();
          if (onScan) onScan(id, h);
          // 스캔 상태 폴링 — 클릭 직후 몇 초는 백엔드가 아직 queued 상태를 등록 못 했을 수 있어서
          // (특히 새 탭을 열어야 하는 경우) 'idle'로 읽혀도 곧바로 "끝났다"고 오판하지 않도록 유예를 둠
          const clickedAt = Date.now();
          const GRACE_MS = 5000;
          const pollInterval = setInterval(() => {
            if (!document.contains(row)) { clearInterval(pollInterval); return; }
            // onGetScanState 콜백으로 상태 조회
            const state = onGetScanState ? onGetScanState(id) : null;
            if (!state || state === 'idle') {
              if (Date.now() - clickedAt < GRACE_MS) return; // 아직 유예 기간 — 무시하고 계속 폴링
              clearInterval(pollInterval);
              render(); // 완료 후 날짜로 갱신
            } else if (state === 'running') {
              scanBadge.textContent = '⏳ scanning';
              scanBadge.style.borderColor = 'rgba(251,146,60,0.4)';
              scanBadge.style.background = 'rgba(251,146,60,0.15)';
              scanBadge.style.color = '#fb923c';
            } else if (state === 'queued') {
              setQueued();
            }
          }, 1000);
        });

        // 메모
        const memoBtn  = row.querySelector('.kws-hw-memo');
        const memoWrap = row.querySelector('.kws-hw-memo-wrap');
        const memoInp  = row.querySelector('.kws-hw-memo-input');

        memoBtn.addEventListener('click', e => {
          e.stopPropagation();
          memoWrap.style.display = memoWrap.style.display === 'none' ? 'block' : 'none';
          if (memoWrap.style.display !== 'none') { memoInp.focus(); memoInp.select(); }
        });

        const saveMemo = async () => {
          const val = memoInp.value.trim();
          HISTORY[id] = { ...HISTORY[id], memo: val };
          await chrome.storage.local.set({ [HISTORY_KEY]: HISTORY });
          render();
        };
        memoInp.addEventListener('keydown', e => {
          if (e.key === 'Enter') { e.preventDefault(); saveMemo(); }
          else if (e.key === 'Escape') { memoWrap.style.display = 'none'; }
        });
        memoInp.addEventListener('blur', () => saveMemo());

        // 삭제
        row.querySelector('.kws-hw-del').addEventListener('click', async e => {
          e.stopPropagation();
          if (!confirm(`Delete history for "${nick || id}"?`)) return;
          delete HISTORY[id];
          await chrome.storage.local.set({ [HISTORY_KEY]: HISTORY });
          render();
        });

        return row;
    }

    function render() {
      const filterVal = (document.getElementById(`${WIN_ID}-filter`)?.value || '').toLowerCase();
      const META_KEYS = new Set(['schema','version','exportedAt','settings','records']);
      const entries = Object.entries(HISTORY)
        .filter(([id, h]) => !id.startsWith('_') && !META_KEYS.has(id) && h && typeof h === 'object')
        .sort((a, b) => (b[1].searchedAt || '').localeCompare(a[1].searchedAt || ''));

      _filtered = filterVal
        ? entries.filter(([id, h]) =>
            id.toLowerCase().includes(filterVal) ||
            (h.nickname || '').toLowerCase().includes(filterVal) ||
            (h.memo || '').toLowerCase().includes(filterVal))
        : entries;

      const countEl = document.getElementById(`${WIN_ID}-count`);
      if (countEl) countEl.textContent = `(${entries.length})`;

      scroll.innerHTML = '';

      if (!_filtered.length) {
        scroll.innerHTML = '<div style="font-size:11px;color:rgba(255,255,255,0.3);padding:12px 4px;text-align:center;">No history found</div>';
        return;
      }

      const frag = document.createDocumentFragment();
      for (const [id, h] of _filtered) frag.appendChild(buildRow(id, h));
      scroll.appendChild(frag);
    }

    render();
    // render 함수를 외부에서 호출 가능하게 노출
    if (onScanComplete) onScanComplete(render);
  }

  window.KWSHistoryUI = { open };
})();
