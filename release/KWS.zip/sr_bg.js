// KWS 1.2.6.0 — StreamRecorder (streamrecorder.io), service-worker side.
//
//  · Twitch chat from StreamRecorder recordings ("dual core" with Zonian): StreamRecorder keeps the
//    Twitch chat of every recording it makes, readable without an account:
//      streamrecorder.io/twitch/<login>  → window.ALT_DAILY_DATA (every recorded stream, by day)
//      img.streamrecorder.io/media/<id>/chatindex.json → chat_N.json (message, display_name,
//      tmi_sent_ts = when it was sent, video_ts_ms = where in the recording)
//    Only streamers somebody records on StreamRecorder have it — it fills gaps, Zonian stays first.
//  · Playing a moment from a StreamRecorder recording in a small popup window (streamRecorderOpen.js
//    does the work inside the user's own logged-in StreamRecorder page). One window is reused.
//  · Account status for the settings (logged in? Premium? targets used/max) — read in a background
//    streamrecorder.io tab like the KickLogz check, so the user's own cookies are used.
'use strict';

const SR_USE_KEY = 'kwsSrUse';               // connected-services switch (off by default)
const SR_POPUP_KEY = 'kwsSrPopup';           // { windowId, tabId } (session)
const SR_SIZE_KEY = 'kwsSrPopupSize';        // { width, height, left, top }
const SR_BASE = 'https://streamrecorder.io';
const SR_IMG = 'https://img.streamrecorder.io';

async function sr_isOn() {
  try {
    const d = await chrome.storage.local.get([SR_USE_KEY, 'kwsSrWatch']);
    if (typeof d[SR_USE_KEY] === 'boolean') return d[SR_USE_KEY];
    return !!d.kwsSrWatch; // 1.2.5.60's switch
  } catch (_) { return false; }
}

// ── public recording list of a channel: [{ id, date, durationSec, title }] ──
const sr_dailyCache = new Map(); // key → { at, list }
async function sr_listRecordings(icon, target) {
  const key = icon + '/' + target;
  const c = sr_dailyCache.get(key);
  if (c && Date.now() - c.at < 10 * 60000) return c.list;
  const res = await fetch(`${SR_BASE}/${icon}/${encodeURIComponent(target)}`, { cache: 'no-store', credentials: 'omit' });
  if (res.status === 404) { sr_dailyCache.set(key, { at: Date.now(), list: [] }); return []; }
  if (!res.ok) throw new Error('StreamRecorder HTTP ' + res.status);
  const html = await res.text();
  const i = html.indexOf('window.ALT_DAILY_DATA');
  const list = [];
  if (i >= 0) {
    const s = html.indexOf('{', i);
    // the object ends where its script statement ends
    let depth = 0, e = s, inStr = false, esc = false;
    for (; e < html.length; e++) {
      const ch = html[e];
      if (inStr) { if (esc) esc = false; else if (ch === '\\') esc = true; else if (ch === '"') inStr = false; continue; }
      if (ch === '"') inStr = true;
      else if (ch === '{') depth++;
      else if (ch === '}') { depth--; if (!depth) break; }
    }
    let data = {};
    try { data = JSON.parse(html.slice(s, e + 1)); } catch (_) {}
    for (const [date, day] of Object.entries(data || {})) {
      for (const st of (day && day.streams) || []) {
        const m = String(st.thumbnail || '').match(/media\/(\d+)\//);
        if (m) list.push({ id: m[1], date, durationSec: Number(st.duration) || 0, title: st.title || '' });
      }
    }
  }
  sr_dailyCache.set(key, { at: Date.now(), list });
  return list;
}

async function sr_fetchJson(url) {
  const r = await fetch(url, { cache: 'no-store', credentials: 'omit' });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  const t = await r.text();
  if (!t || t[0] !== '{') throw new Error('not json');
  return JSON.parse(t);
}

// ── Twitch chat from StreamRecorder, in the same group shape as Zonian results ──
async function sr_scanTwitchChat({ channel, keyword, startDate, endDate, cancelToken, onProgress }) {
  const nc = kws_normalizeChannel(channel);
  const { keywords, excludeKeywords } = kws_resolveKeywords(keyword);
  if (!keywords.length) return { matchedGroups: [], matchedLines: 0, total: 0, recordings: 0 };
  let list = [];
  try { list = await sr_listRecordings('twitch', nc); } catch (e) { console.warn('[KWS SR] list failed', nc, e); return { matchedGroups: [], matchedLines: 0, total: 0, error: String(e.message || e) }; }
  const lo = new Date(startDate + 'T00:00:00Z').getTime() - 86400000;
  const hi = new Date((endDate || kws_format(new Date())) + 'T23:59:59Z').getTime() + 86400000;
  const recs = list.filter((r) => { const t = Date.parse(r.date + 'T12:00:00Z'); return t >= lo && t <= hi; });
  const groups = new Map();
  let done = 0, lines = 0;
  const startMs = new Date(startDate + 'T00:00:00').getTime();
  const endMs = new Date((endDate || kws_format(new Date())) + 'T23:59:59').getTime();
  const one = async (rec) => {
    if (cancelToken && cancelToken.cancelled) return;
    let idx;
    try { idx = await sr_fetchJson(`${SR_IMG}/media/${rec.id}/chatindex.json`); } catch (_) { return; }
    const files = Object.values((idx && idx.files) || {}).map((f) => f && f.name).filter(Boolean);
    for (const name of files) {
      if (cancelToken && cancelToken.cancelled) return;
      let chat;
      try { chat = await sr_fetchJson(`${SR_IMG}/media/${rec.id}/${encodeURIComponent(name)}`); } catch (_) { continue; }
      for (const m of Object.values(chat || {})) {
        const message = String((m && m.message) || '').trim();
        if (!message) continue;
        const lower = message.toLowerCase();
        const hit = keywords.filter(({ word, substring }) => substring ? lower.includes(word) : kws_matchesWholeWord(lower, word)).map(({ word }) => word);
        const rx = kws_matchesIncludeRegex(message);
        if (!(hit.length || rx) || kws_isExcluded(message, excludeKeywords)) continue;
        const ms = Number(m.tmi_sent_ts) || 0;
        if (!ms || ms < startMs || ms > endMs) continue;
        const iso = new Date(ms).toISOString();
        const localDate = kws_localDateFromTimestamp(iso);
        const kw = hit.length ? hit : ['икает/икнул'];
        const user = String(m.display_name || (m.tags && m.tags['display-name']) || '?');
        const row = {
          ts: kws_formatTimestamp(iso), rawTs: iso, localDate, keywords: kw, username: user, message,
          playback_offset: null, playback_ts: null, vod_id: null, vod_title: null,
          sr_rec: rec.id, sr_off: Math.round((Number(m.video_ts_ms) || 0) / 1000), // the moment in the recording
        };
        if (!groups.has(localDate)) groups.set(localDate, { date: localDate, sourceDate: localDate, displayDate: localDate, lines: [], rawMessages: [], source: 'external', sourceServices: ['streamrecorder'] });
        const g = groups.get(localDate);
        g.rawMessages.push(row);
        g.lines.push(`[${row.ts}] [${kw.join(', ')}] ${user}: ${message}`);
        lines++;
      }
    }
  };
  let next = 0;
  const worker = async () => { while (next < recs.length) { const r = recs[next++]; await one(r); done++; if (typeof onProgress === 'function') onProgress({ done, total: recs.length, matchedLines: lines }); } };
  await Promise.all([worker(), worker(), worker()]);
  return { matchedGroups: [...groups.values()], matchedLines: lines, total: recs.length, recordings: recs.length };
}

// Wraps a Twitch scan: Zonian/Native as before + StreamRecorder chat when the service is on.
async function sr_withTwitchChat(args, mainPromise) {
  if (!(await sr_isOn())) return mainPromise;
  const busy = (b) => { try { args.onSrBusy && args.onSrBusy(b); } catch (_) {} };
  busy(true);
  const srP = sr_scanTwitchChat({ channel: args.channel, keyword: args.keyword, startDate: args.startDate, endDate: args.endDate, cancelToken: args.cancelToken })
    .catch((e) => { console.warn('[KWS SR] chat scan failed', e); return null; })
    .finally(() => busy(false));
  const [main, sr] = await Promise.all([mainPromise, srP]);
  if (!sr || !sr.matchedGroups.length) return main;
  const matchedGroups = kws_mergeMatchedGroups(main && main.matchedGroups, sr.matchedGroups);
  return { ...(main || {}), matchedGroups, matchedDays: matchedGroups.length, matchedLines: matchedGroups.reduce((s, g) => s + g.rawMessages.length, 0), srLines: sr.matchedLines };
}

// ── the popup player window (one, reused) ──
async function sr_raise(tab) {
  try {
    const w = await chrome.windows.get(tab.windowId);
    if (w.state === 'minimized') await chrome.windows.update(w.id, { state: 'normal' });
    await chrome.tabs.update(tab.id, { active: true }).catch(() => {});
    await chrome.windows.update(w.id, { focused: true });
    // Windows can refuse focus to a background app — flash the taskbar button then
    setTimeout(() => chrome.windows.get(w.id).then((x) => { if (!x.focused) chrome.windows.update(w.id, { drawAttention: true }).catch(() => {}); }).catch(() => {}), 400);
  } catch (_) {}
}
async function sr_open(req) {
  let st = null;
  try { st = (await chrome.storage.session.get(SR_POPUP_KEY))[SR_POPUP_KEY] || null; } catch (_) {}
  if (st && st.tabId) {
    try {
      const tab = await chrome.tabs.get(st.tabId);
      if (tab && /^https:\/\/streamrecorder\.io\//.test(tab.url || tab.pendingUrl || '')) {
        // 1.2.6.8: bring the window to the front first (minimized / behind other windows), then play
        await sr_raise(tab);
        await chrome.tabs.sendMessage(st.tabId, { type: 'KWS_SR_PLAY', req });
        return { ok: true, reused: true };
      }
    } catch (_) {}
  }
  let size = {};
  try { size = (await chrome.storage.local.get(SR_SIZE_KEY))[SR_SIZE_KEY] || {}; } catch (_) {}
  const url = `${SR_BASE}/robots.txt#kwsSR=` + encodeURIComponent(JSON.stringify(req)); // 1.2.6.1: a tiny page (the list page takes ~40 s)
  const win = await chrome.windows.create({
    url, type: 'popup', focused: true,
    width: Math.max(480, size.width || 980), height: Math.max(300, size.height || 600),
    ...(Number.isFinite(size.left) ? { left: size.left } : {}), ...(Number.isFinite(size.top) ? { top: size.top } : {}),
  });
  const tabId = win.tabs && win.tabs[0] && win.tabs[0].id;
  await chrome.storage.session.set({ [SR_POPUP_KEY]: { windowId: win.id, tabId } }).catch(() => {});
  return { ok: true };
}
chrome.windows.onBoundsChanged && chrome.windows.onBoundsChanged.addListener(async (w) => {
  try {
    const st = (await chrome.storage.session.get(SR_POPUP_KEY))[SR_POPUP_KEY];
    if (st && st.windowId === w.id) chrome.storage.local.set({ [SR_SIZE_KEY]: { width: w.width, height: w.height, left: w.left, top: w.top } });
  } catch (_) {}
});

// ── account status (logged in / Premium / targets used·max) ──
// 1.2.6.1: no more hidden tab on a big page (it timed out and left FAQ tabs behind):
//   /accounts         200 = logged in · 401 "Not authenticated" = logged out   (tiny JSON)
//   /userdashboard    "97 / 100 Streamers Monitored"                          (~2 s; /userrecordings takes ~40 s)
// The worker's own request carries the streamrecorder.io cookies (host permission). If it says
// "logged out", it is double-checked from inside a streamrecorder.io/robots.txt tab (tiny, fast).
async function sr_pageAccount() { // MAIN world of a streamrecorder.io page — self-contained
  try {
    const a = await fetch('/accounts', { credentials: 'include', cache: 'no-store' });
    if (a.status === 401) return { loggedIn: false };
    if (!a.ok) return { error: 'HTTP ' + a.status };
    const d = await fetch('/userdashboard', { credentials: 'include', cache: 'no-store' });
    const txt = (await d.text()).replace(/<script[\s\S]*?<\/script>/g, ' ').replace(/<[^>]+>/g, ' ');
    const m = txt.match(/(\d[\d,]*)\s*\/\s*(\d[\d,]*)\s*Streamers Monitored/i);
    const used = m ? +m[1].replace(/,/g, '') : null, max = m ? +m[2].replace(/,/g, '') : null;
    return { loggedIn: true, used, max, premium: max != null ? max > 3 : null };
  } catch (e) { return { error: String((e && e.message) || e) }; }
}
let sr_acct = null; // { at, res }
async function sr_checkAccount(force) {
  const c = sr_acct;
  if (!force && c && Date.now() - c.at < (c.res.loggedIn ? 300000 : 20000)) return c.res;
  const withTimeout = (p, ms) => Promise.race([p, new Promise((r) => setTimeout(() => r({ error: 'timeout' }), ms))]);
  // 1) from the worker itself (same code, run here)
  let out = await withTimeout((async () => {
    try {
      const a = await fetch(SR_BASE + '/accounts', { credentials: 'include', cache: 'no-store' });
      if (a.status === 401) return { loggedIn: false };
      if (!a.ok) return { error: 'HTTP ' + a.status };
      const d = await fetch(SR_BASE + '/userdashboard', { credentials: 'include', cache: 'no-store' });
      const txt = (await d.text()).replace(/<script[\s\S]*?<\/script>/g, ' ').replace(/<[^>]+>/g, ' ');
      const m = txt.match(/(\d[\d,]*)\s*\/\s*(\d[\d,]*)\s*Streamers Monitored/i);
      const used = m ? +m[1].replace(/,/g, '') : null, max = m ? +m[2].replace(/,/g, '') : null;
      return { loggedIn: true, used, max, premium: max != null ? max > 3 : null };
    } catch (e) { return { error: String((e && e.message) || e) }; }
  })(), 25000);
  // 2) "logged out" / failed → confirm inside a tiny streamrecorder.io page (the page's own cookies)
  if (!out || out.error || out.loggedIn === false) {
    let tabId = null, made = false;
    try {
      const nt = await chrome.tabs.create({ url: SR_BASE + '/robots.txt', active: false });
      tabId = nt.id; made = true;
      await new Promise((resolve) => {
        const to = setTimeout(resolve, 10000);
        const l = (id, info) => { if (id === tabId && info.status === 'complete') { clearTimeout(to); chrome.tabs.onUpdated.removeListener(l); resolve(); } };
        chrome.tabs.onUpdated.addListener(l);
      });
      const [res] = await withTimeout(chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: sr_pageAccount }), 20000).then((r) => Array.isArray(r) ? r : [{ result: r }]);
      const r2 = res && res.result;
      if (r2 && !r2.error) out = r2;
    } catch (_) {}
    finally { if (made && tabId != null) chrome.tabs.remove(tabId).catch(() => {}); }
  }
  if (out && !out.error) sr_acct = { at: Date.now(), res: out };
  return out || { error: 'no result' };
}

// 1.2.6.7: Twitch hides VOD lists from region-blocked IPs (Korea): edges [] but hasNextPage true.
let sr_geo = null; // { at, blocked }
async function sr_twitchGeoBlocked(channel) {
  if (sr_geo && Date.now() - sr_geo.at < 10 * 60000) return sr_geo.blocked;
  try {
    const body = JSON.stringify([{ operationName: 'FilterableVideoTower_Videos', variables: { limit: 5, channelOwnerLogin: String(channel || 'twitch'), broadcastType: 'ARCHIVE', videoSort: 'TIME' }, extensions: { persistedQuery: { version: 1, sha256Hash: '67004f7881e65c297936f32c75246470629557a393788fb5a69d6d9a25a8fd5f' } } }]);
    const r = await fetch('https://gql.twitch.tv/gql', { method: 'POST', headers: { 'content-type': 'text/plain;charset=UTF-8', 'client-id': 'kimne78kx3ncx6brgo4mv6wki5h1ko' }, body });
    const d = await r.json();
    const v = d && d[0] && d[0].data && d[0].data.user && d[0].data.user.videos;
    if (!v) return false; // unknown channel etc. → no verdict
    const blocked = !(v.edges && v.edges.length) && !!(v.pageInfo && v.pageInfo.hasNextPage);
    sr_geo = { at: Date.now(), blocked };
    return blocked;
  } catch (_) { return false; }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;
  if (msg.type === 'KWS_TW_GEO') { sr_twitchGeoBlocked(msg.channel).then((b) => sendResponse({ blocked: b }), () => sendResponse({ blocked: false })); return true; }
  if (msg.type === 'KWS_SR_OPEN') { sr_open(msg.req || {}).then(sendResponse, (e) => sendResponse({ ok: false, error: String((e && e.message) || e) })); return true; }
  if (msg.type === 'KWS_SR_ACCOUNT') { sr_checkAccount(!!msg.force).then(sendResponse, (e) => sendResponse({ error: String((e && e.message) || e) })); return true; }
  if (msg.type === 'KWS_SR_CLOSE') {
    const wid = sender && sender.tab && sender.tab.windowId;
    if (wid != null) chrome.windows.remove(wid).catch(() => {});
    return;
  }
});
