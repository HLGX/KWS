// KWS 1.2.5.17 — default playback quality for the inline players (Twitch · Kick · SOOP · CHZZK).
// Setting "kwsSpDefaultQuality" (side panel → settings): 'last' (default: the quality picked last
// time, per site) · 'max' · a height such as '1080' / '720' / '480' (the best quality at or below
// it; if every quality is above it, the lowest one).
(function () {
  if (globalThis.KWSQuality) return;
  const KEY = 'kwsSpDefaultQuality';
  async function pref() {
    try { const d = await chrome.storage.local.get(KEY); return d[KEY] || 'last'; } catch (_) { return 'last'; }
  }
  // items: the qualities; h(item) → its height (Infinity for "Source", 0 for audio only)
  function pick(items, h, p) {
    const list = (items || []).filter((i) => h(i) > 0);
    if (!list.length) return (items || [])[0] || null;
    const best = (a, b) => (h(b) > h(a) ? b : a);
    if (p === 'max') return list.reduce(best);
    const n = Number(p);
    if (!n) return null; // 'last' — the caller uses its own memory
    const below = list.filter((i) => h(i) <= n);
    return below.length ? below.reduce(best) : list.reduce((a, b) => (h(b) < h(a) ? b : a));
  }
  globalThis.KWSQuality = { KEY, pref, pick };
})();
