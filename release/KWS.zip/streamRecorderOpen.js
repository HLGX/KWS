// KWS 1.2.5.60 — "watch on StreamRecorder" (Twitch hits; mainly for Korea, where Twitch VODs are blocked,
// and for broadcasts whose VOD is gone). The side panel opens
//   https://streamrecorder.io/userrecordings#kwsSR=<channel>|<unix ms of the chat message>
// and this script, running in the user's own logged-in StreamRecorder page:
//   1. finds the channel among the account's recording targets — if it isn't there, adds it (Premium
//      accounts see the recordings other users already made, right away). When the account is full,
//      KWS removes the target least recently searched in KWS (never one whose recordings would be
//      deleted for good) — the settings text says so.
//   2. finds the recording that covers that moment (recorded_at is UTC) and opens its page with
//      #kwsT=<seconds>; there, once the player has restored its own resume point, it seeks there.
(function () {
  'use strict';
  if (window.__kwsSrOpen) return;
  window.__kwsSrOpen = true;
  const T = (k, ...a) => { try { return chrome.i18n.getMessage(k, a.map(String)) || k; } catch (_) { return k; } };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const HISTORY_KEYS = ['twitchKwsHistory', 'kickKwsHistory', 'soopSearchHistory', 'ytKwsHistory', 'chzzkKwsHistory'];
  const TWITCH = '1';

  // ── status box ──
  let box = null;
  function say(text, kind) {
    if (!box) {
      box = document.createElement('div');
      box.style.cssText = 'position:fixed;z-index:2147483647;right:18px;bottom:18px;max-width:380px;padding:12px 16px;border-radius:14px;background:rgba(15,17,23,.94);color:#e5e7eb;font:600 13px/1.5 -apple-system,"Malgun Gothic",sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.45);white-space:pre-line';
      const tag = document.createElement('div');
      tag.textContent = 'KWS';
      tag.style.cssText = 'font-size:10.5px;font-weight:800;letter-spacing:.08em;color:#9146FF;margin-bottom:3px';
      box.append(tag, document.createElement('div'));
      document.body.appendChild(box);
    }
    box.lastChild.textContent = text;
    box.lastChild.style.color = kind === 'err' ? '#fca5a5' : kind === 'ok' ? '#86efac' : '#e5e7eb';
    if (kind === 'ok') setTimeout(() => box && box.remove(), 6000);
  }

  const api = async (path) => {
    const r = await fetch(path, { credentials: 'include' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  };

  // targets of this account: [{ name, platformid, targetId, requestId, latest, irreversible }]
  function readTargets(doc) {
    return [...doc.querySelectorAll('.recordings-streamer-card')].map((c) => ({
      name: String(c.dataset.srTarget || '').toLowerCase(),
      platformid: String(c.dataset.srTargetPlatformid || ''),
      targetId: (c.id || '').replace(/^target-/, ''),
      requestId: c.dataset.srRequestid,
      latest: Number(c.dataset.srLatestRecording) || 0,
      irreversible: c.dataset.srWillIrreversiblyDeleted === '1',
    })).filter((x) => x.name && x.targetId);
  }
  async function freshTargets() {
    const html = await (await fetch('/userrecordings', { credentials: 'include' })).text();
    return readTargets(new DOMParser().parseFromString(html, 'text/html'));
  }
  function readLimit(text) {
    const m = String(text || '').match(/(\d[\d,]*)\s*\/\s*(\d[\d,]*)\s*STREAMERS MONITORED/i);
    return m ? { used: +m[1].replace(/,/g, ''), max: +m[2].replace(/,/g, '') } : null;
  }

  // when KWS last searched each channel (any platform) → the least recently used target goes first
  async function kwsLastUse() {
    const out = {};
    try {
      const d = await chrome.storage.local.get(HISTORY_KEYS);
      for (const k of HISTORY_KEYS) {
        for (const [id, h] of Object.entries(d[k] || {})) {
          if (!h || typeof h !== 'object') continue;
          const t = Date.parse(h.searchedAt || h.savedAt || h.lastDate || '') || 0;
          const key = id.toLowerCase();
          if (t > (out[key] || 0)) out[key] = t;
        }
      }
    } catch (_) {}
    return out;
  }

  async function addTarget(ch) {
    const d = await api('/api/user/addrecordingtargetv2?q=' + encodeURIComponent(ch) + '&platformid=' + TWITCH);
    if (d && d.error) throw new Error(d.error === 'unknownTarget' ? T('srNotFound', ch) : d.error);
    const requestId = d && d[3];
    if (!requestId) throw new Error(T('srNotFound', ch));
    for (let i = 0; i < 40; i++) {
      const s = await api('/api/user/getrecordingrequeststatus?requestid=' + encodeURIComponent(requestId)).catch(() => null);
      if (s && s.status === 'found') return;
      if (s && s.status === 'notfound') throw new Error(T('srNotFound', ch));
      if (s && s.status === 'error') throw new Error(s.message || 'error');
      await sleep(1000);
    }
    throw new Error('timeout');
  }

  async function findRecording(targetId, tsMs) {
    for (let offset = 0; offset < 3000; offset += 50) {
      const j = await api(`/api/user/recordingsv2?targetid=${encodeURIComponent(targetId)}&offset=${offset}&limit=50`);
      const rows = (j && j.data) || [];
      for (const r of rows) {
        const start = Date.parse(String(r.recorded_at || '') + 'Z');
        const dur = Number(r.duration) || 0;
        if (start && tsMs >= start - 60000 && tsMs <= start + dur * 1000 + 60000) {
          return { rec: r, sec: Math.max(0, Math.round((tsMs - start) / 1000)) };
        }
      }
      const oldest = rows.length ? Date.parse(String(rows[rows.length - 1].recorded_at || '') + 'Z') : 0;
      if (!rows.length || rows.length < 50 || (oldest && oldest < tsMs - 86400000)) break; // newest first
    }
    return null;
  }

  async function run(ch, tsMs) {
    say(T('srStepFind', ch));
    // the cards are server-rendered; wait a moment for the page
    let targets = [];
    for (let i = 0; i < 30 && !(targets = readTargets(document)).length; i++) await sleep(300);
    if (!targets.length) {
      if (/\/login/.test(location.pathname) || !document.querySelector('a[href*="logout"], .recordings-streamer-card, #recordings')) { say(T('srLogin'), 'err'); return; }
    }
    let t = targets.find((x) => x.platformid === TWITCH && x.name === ch);
    if (!t) {
      const lim = readLimit(document.body.innerText);
      if (lim && lim.used >= lim.max) {
        const use = await kwsLastUse();
        const victims = targets.filter((x) => !x.irreversible && !(x.platformid === TWITCH && x.name === ch))
          .sort((a, b) => ((use[a.name] || 0) - (use[b.name] || 0)) || (a.latest - b.latest));
        // StreamRecorder refuses to remove a target added only minutes ago → try the next one
        let dropped = false;
        for (const v of victims.slice(0, 6)) {
          say(T('srStepDrop', v.name));
          const r = await api('/api/user/deleterecordingrequest?requestid=' + encodeURIComponent(v.requestId)).catch(() => null);
          if (r && r.success) { dropped = true; break; }
        }
        if (!dropped) { say(T('srFull'), 'err'); return; }
      }
      say(T('srStepAdd', ch));
      await addTarget(ch);
      targets = await freshTargets();
      t = targets.find((x) => x.platformid === TWITCH && x.name === ch);
      if (!t) throw new Error(T('srNotFound', ch));
    }
    say(T('srStepRec'));
    const hit = await findRecording(t.targetId, tsMs);
    if (!hit) { say(T('srNoRec', ch), 'err'); return; }
    if (hit.rec.premium_required || hit.rec.after_adding_locked) { say(T('srLocked'), 'err'); return; }
    location.href = '/userrecordings/recording/' + encodeURIComponent(hit.rec.token || hit.rec.id) + '#kwsT=' + Math.max(0, hit.sec - 5);
  }

  // recording page: seek once the player has applied its own resume position
  async function seekTo(sec) {
    say(T('srStepSeek'));
    let v = null;
    for (let i = 0; i < 60 && !(v = document.querySelector('video')); i++) await sleep(250);
    if (!v) { say(T('srNoPlayer'), 'err'); return; }
    for (let i = 0; i < 40 && !(v.readyState >= 1 && v.duration > 0); i++) await sleep(250);
    await sleep(1200); // the site restores "continue watching" first
    for (let i = 0; i < 8; i++) {
      v.currentTime = Math.min(sec, Math.max(0, (v.duration || sec + 1) - 1));
      await sleep(700);
      if (Math.abs(v.currentTime - sec) < 5) break;
    }
    v.play().catch(() => {});
    // the site may still apply its saved position a moment later — put it back once
    const guardEnd = Date.now() + 5000;
    const guard = () => { if (Date.now() < guardEnd && Math.abs(v.currentTime - sec) > 30) v.currentTime = sec; };
    v.addEventListener('seeked', guard);
    setTimeout(() => v.removeEventListener('seeked', guard), 5200);
    say(T('srDone'), 'ok');
    try { history.replaceState(null, '', location.pathname); } catch (_) {}
  }

  const h = location.hash;
  const mSr = h.match(/kwsSR=([^&]+)/);
  const mT = h.match(/kwsT=(\d+)/);
  if (mSr) {
    const [chRaw, tsRaw] = decodeURIComponent(mSr[1]).split('|');
    const ch = String(chRaw || '').toLowerCase().replace(/[^a-z0-9_]/g, '');
    const ts = Number(tsRaw);
    try { history.replaceState(null, '', location.pathname); } catch (_) {}
    if (ch && ts > 0) run(ch, ts).catch((e) => say(T('srFailed', (e && e.message) || e), 'err'));
  } else if (mT && /\/userrecordings\/recording\//.test(location.pathname)) {
    seekTo(Number(mT[1]));
  }
})();
