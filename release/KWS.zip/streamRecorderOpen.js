// KWS 1.2.6.0 — StreamRecorder player (runs in the user's own logged-in streamrecorder.io page,
// opened by sr_bg.js as a small popup window that is reused for the next hit).
//
//   #kwsSR=<json> on /userrecordings, or a KWS_SR_PLAY message to an open popup:
//     { platform, channel, ts?: unix ms of the chat line, date?: 'YYYY-MM-DD', off?: s into the VOD,
//       recId?: StreamRecorder recording id, recOff?: s into that recording, title? }
//   1. the channel must be one of the account's recording targets — if not, KWS adds it (Premium
//      accounts see recordings made before that right away); when the list is full, KWS removes the
//      target least recently searched in KWS (never one whose recordings would be deleted for good)
//   2. the recording covering that moment (recorded_at is UTC) is played in a KWS player that takes
//      over the page (same look as the inline players), 30 s before the moment
//   3. ⬇ clip download: the recording is plain fMP4 HLS (init + .m4s, no encryption) → the segments
//      covering the range are fetched here and saved as one .mp4
(function () {
  'use strict';
  if (window.__kwsSrOpen) return;
  window.__kwsSrOpen = true;
  const T = (k, ...a) => { try { return chrome.i18n.getMessage(k, a.map(String)) || k; } catch (_) { return k; } };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const HISTORY_KEYS = ['twitchKwsHistory', 'kickKwsHistory', 'soopSearchHistory', 'ytKwsHistory', 'chzzkKwsHistory'];
  const PID = { twitch: '1', kick: '5', soop: '7', chzzk: '9' };
  const LEAD = 30; // seconds before the chat line, like the other players

  // ── status box ──
  let box = null;
  // 1.2.6.8: the loading screen is a small "HLGX · Keyword Searcher" header over a live terminal log —
  // the user's words (say) in white, the technical steps (log) dimmed, errors in red
  function tline(text, cls) {
    const el = P && P.load && P.load.querySelector('.lterm');
    if (!el) return;
    const prev = el.querySelector('.tl.cur');
    if (prev && cls !== 'dim') { prev.classList.remove('cur'); if (cls !== 'bad') prev.classList.add('ok'); } // a step is done when the next one starts
    const d = document.createElement('div');
    d.className = 'tl ' + (cls || '');
    const ts = document.createElement('span'); ts.className = 'tts'; ts.textContent = new Date().toTimeString().slice(0, 8);
    const tx = document.createElement('span'); tx.className = 'ttx'; tx.textContent = text;
    d.append(ts, tx);
    el.append(d);
    while (el.children.length > 80) el.firstChild.remove();
    el.scrollTop = el.scrollHeight;
  }
  function log(text) { tline(text, 'dim'); }
  function say(text, kind) {
    // 1.2.6.2: inside the KWS player window the status is the KWS loading screen, not a toast
    if (P && P.load) {
      const L = P.load;
      if (kind === 'ok') { L.hidden = true; return; }
      L.hidden = false;
      L.classList.toggle('err', kind === 'err');
      tline(text, kind === 'err' ? 'bad' : 'cur');
      L.querySelector('.lclose').hidden = kind !== 'err';
      return;
    }
    if (!box || !document.contains(box)) {
      box = document.createElement('div');
      box.style.cssText = 'position:fixed;z-index:2147483647;right:16px;bottom:16px;max-width:380px;padding:11px 15px;border-radius:14px;background:rgba(15,17,23,.94);color:#e5e7eb;font:600 13px/1.5 -apple-system,"Malgun Gothic",sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.45);white-space:pre-line';
      const tag = document.createElement('div');
      tag.textContent = 'KWS';
      tag.style.cssText = 'font-size:10.5px;font-weight:800;letter-spacing:.08em;color:#9146FF;margin-bottom:3px';
      box.append(tag, document.createElement('div'));
      document.documentElement.appendChild(box);
    }
    box.lastChild.textContent = text;
    box.lastChild.style.color = kind === 'err' ? '#fca5a5' : kind === 'ok' ? '#86efac' : '#e5e7eb';
    clearTimeout(say._t);
    if (kind === 'ok') say._t = setTimeout(() => box && box.remove(), 2500);
  }

  const api = async (path) => {
    const r = await fetch(path, { credentials: 'include' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  };

  function readTargets(doc) {
    return [...doc.querySelectorAll('.recordings-streamer-card')].map((c) => ({
      name: String(c.dataset.srTarget || '').toLowerCase(),
      platformid: String(c.dataset.srTargetPlatformid || ''),
      targetId: (c.id || '').replace(/^target-/, ''),
      requestId: c.dataset.srRequestid,
      latest: Number(c.dataset.srLatestRecording) || 0,
      irreversible: c.dataset.srWillIrreversiblyDeleted === '1',
    })).filter((x) => x.name && x.targetId);
  }
  async function fetchTargets() {
    const r = await fetch('/userrecordings', { credentials: 'include', cache: 'no-store' });
    if (/\/login/.test(r.url)) return { loggedOut: true, targets: [] };
    const doc = new DOMParser().parseFromString(await r.text(), 'text/html');
    const m = (doc.body ? doc.body.textContent : '').match(/(\d[\d,]*)\s*\/\s*(\d[\d,]*)\s*Streamers Monitored/i);
    return { targets: readTargets(doc), lim: m ? { used: +m[1].replace(/,/g, ''), max: +m[2].replace(/,/g, '') } : null, loggedOut: !doc.querySelector('.recordings-streamer-card') && !m };
  }

  async function kwsLastUse() {
    const out = {};
    try {
      const d = await chrome.storage.local.get(HISTORY_KEYS);
      for (const k of HISTORY_KEYS) {
        for (const [id, h] of Object.entries(d[k] || {})) {
          if (!h || typeof h !== 'object') continue;
          const t = Date.parse(h.searchedAt || h.savedAt || h.lastDate || '') || 0;
          const key = id.toLowerCase();
          if (t > (out[key] || 0)) out[key] = t;
        }
      }
    } catch (_) {}
    return out;
  }

  async function addTarget(ch, pid) {
    const d = await api('/api/user/addrecordingtargetv2?q=' + encodeURIComponent(ch) + '&platformid=' + pid);
    if (d && d.error) throw new Error(d.error === 'unknownTarget' ? T('srNotFound', ch) : d.error);
    const requestId = d && d[3];
    if (!requestId) throw new Error(T('srNotFound', ch));
    for (let i = 0; i < 40; i++) {
      const s = await api('/api/user/getrecordingrequeststatus?requestid=' + encodeURIComponent(requestId)).catch(() => null);
      if (s && s.status === 'found') return;
      if (s && s.status === 'notfound') throw new Error(T('srNotFound', ch));
      if (s && s.status === 'error') throw new Error(s.message === 'platformPremiumOnly' ? T('srLocked') : (s.message || 'error'));
      await sleep(1000);
    }
    throw new Error('timeout');
  }

  // 1.2.6.1: StreamRecorder's own search says whether the channel is already on the list (monitored),
  // its target id and how many recordings exist — fast, and no slot is spent on a channel nobody recorded.
  // (The list page /userrecordings is ~1.8 MB / ~40 s — only read when a slot has to be freed.)
  async function lookup(ch, pid) {
    const r = await fetch('/search/recordingtarget2?q=' + encodeURIComponent(ch) + '&filter=' + pid, { credentials: 'include', cache: 'no-store' });
    if (r.status === 401 || /\/login/.test(r.url)) { const e = new Error(T('srLogin')); e.login = true; throw e; }
    const list = await r.json().catch(() => []);
    return (Array.isArray(list) ? list : []).find((x) => String(x.platformid) === pid && String(x.target || '').toLowerCase().replace(/^@/, '') === ch) || null;
  }
  async function readLimit() {
    try {
      const txt = (await (await fetch('/userdashboard', { credentials: 'include', cache: 'no-store' })).text()).replace(/<script[\s\S]*?<\/script>/g, ' ').replace(/<[^>]+>/g, ' ');
      const m = txt.match(/(\d[\d,]*)\s*\/\s*(\d[\d,]*)\s*Streamers Monitored/i);
      return m ? { used: +m[1].replace(/,/g, ''), max: +m[2].replace(/,/g, '') } : null;
    } catch (_) { return null; }
  }
  async function ensureTarget(ch, pid) {
    const a = await fetch('/accounts', { credentials: 'include', cache: 'no-store' }).catch(() => null);
    log('auth  GET /accounts → ' + (a ? a.status : 'no answer'));
    if (a && a.status === 401) { const e = new Error(T('srLogin')); e.login = true; throw e; }
    const found = await lookup(ch, pid);
    log('lookup  ' + ch + ' (platform ' + pid + ') → ' + (found ? 'target ' + found.targetid + ' · ' + (found.monitored ? 'monitored' : 'not on list') + ' · ' + (found.recording_count || 0) + ' recordings' : 'not found'));
    if (found && found.monitored) return { targetId: String(found.targetid), name: ch };
    if (!found || !(Number(found.recording_count) > 0)) { const e = new Error(T('srNoRec', ch)); e.noRec = true; throw e; }
    const lim = await readLimit();
    if (lim) log('slots  ' + lim.used + ' / ' + lim.max + (lim.used >= lim.max ? '  (full → drop least-used)' : ''));
    if (lim && lim.used >= lim.max) {
      say(T('srStepList'));
      const { targets } = await fetchTargets();
      const use = await kwsLastUse();
      const victims = targets.filter((x) => !x.irreversible)
        .sort((a, b) => ((use[a.name] || 0) - (use[b.name] || 0)) || (a.latest - b.latest));
      let dropped = false;
      for (const v of victims.slice(0, 6)) { // StreamRecorder refuses to remove one added minutes ago → next
        say(T('srStepDrop', v.name));
        const r = await api('/api/user/deleterecordingrequest?requestid=' + encodeURIComponent(v.requestId)).catch(() => null);
        log('drop  ' + v.name + ' → ' + (r && r.success ? 'ok' : 'refused (added too recently?)'));
        if (r && r.success) { dropped = true; break; }
      }
      if (!dropped) throw new Error(T('srFull'));
    }
    say(T('srStepAdd', ch));
    await addTarget(ch, pid);
    log('add  ' + ch + ' → found');
    return { targetId: String(found.targetid), name: ch };
  }

  // newest first; stop paging once past the moment
  async function findRecording(targetId, req) {
    const exact = Number(req.ts) > 0;
    const dayMs = req.date ? Date.parse(req.date + 'T12:00:00Z') : 0;
    let best = null;
    for (let offset = 0; offset < 3000; offset += 50) {
      const j = await api(`/api/user/recordingsv2?targetid=${encodeURIComponent(targetId)}&offset=${offset}&limit=50`);
      const rows = (j && j.data) || [];
      for (const r of rows) {
        if (req.recId && String(r.id) === String(req.recId)) return { rec: r, sec: Number(req.recOff) || 0 };
        const start = Date.parse(String(r.recorded_at || '') + 'Z');
        const dur = Number(r.duration) || 0;
        if (!start) continue;
        if (exact) {
          if (req.ts >= start - 60000 && req.ts <= start + dur * 1000 + 60000) return { rec: r, sec: Math.max(0, Math.round((req.ts - start) / 1000)) };
        } else if (dayMs && Math.abs(start - dayMs) < 36 * 3600000 && (Number(req.off) || 0) <= dur + 60) {
          // no exact time (e.g. a SOOP VOD offset): the recording of that day long enough for it
          const score = Math.abs(start - dayMs);
          if (!best || score < best.score) best = { rec: r, sec: Number(req.off) || 0, score };
        }
      }
      const oldest = rows.length ? Date.parse(String(rows[rows.length - 1].recorded_at || '') + 'Z') : 0;
      const target = exact ? req.ts : dayMs;
      if (!rows.length || rows.length < 50 || (oldest && target && oldest < target - 2 * 86400000)) break;
    }
    return best;
  }

  // ───────────────────────── the player ─────────────────────────
  let P = null; // { cont, video, hls, rec, ... }
  const fmt = (s) => { s = Math.max(0, Math.floor(s || 0)); return [Math.floor(s / 3600), Math.floor((s % 3600) / 60), s % 60].map((v) => String(v).padStart(2, '0')).join(':'); };
  const pf = (s) => { const p = String(s).split(':').map(Number); return p.length === 3 ? p[0] * 3600 + p[1] * 60 + p[2] : p.length === 2 ? p[0] * 60 + p[1] : parseFloat(s) || 0; };

  function css() {
    if (document.getElementById('kws-srp-css')) return;
    const st = document.createElement('style');
    st.id = 'kws-srp-css';
    // 1.2.6.2: the same look as the KWS inline players (the SOOP inline player's skin, soopSearcher.js),
    // with KWS-only class names (StreamRecorder's own Bootstrap ".row" etc. must not touch it)
    st.textContent = `
html.kws-srp-on, html.kws-srp-on body { background:#000 !important; overflow:hidden !important; margin:0 !important; }
html.kws-srp-on body > *:not(#kwsSrP) { display:none !important; }
#kwsSrP { position:fixed; inset:0; z-index:2147483646; background:#000; }
#kwsSrP .kbody { position:relative; width:100%; height:100%; }
#kwsSrP button { font-family:inherit; }

      #kwsSrP { box-sizing:border-box; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; }
      #kwsSrP video { width:100%; height:100%; display:block; object-fit:contain; background:#000; }
      #kwsSrP .soop-glassbar { position:absolute; left:12px; right:12px; top:12px; z-index:7; display:flex; align-items:center; justify-content:space-between; gap:10px; padding:9px 10px; border-radius:18px; background:rgba(20,24,34,.58); border:1px solid rgba(255,255,255,.14); backdrop-filter:blur(18px); -webkit-backdrop-filter:blur(18px); opacity:0; transform:translateY(-6px); transition:opacity .16s ease, transform .16s ease; pointer-events:none; }
      #kwsSrP:hover .soop-glassbar { opacity:1; transform:translateY(0); pointer-events:auto; }
      #kwsSrP .soop-glassbar.visible { opacity:1; transform:translateY(0); pointer-events:auto; }
      #kwsSrP .soop-vod-title { min-width:0; color:#fff; font:800 12px/1.25 -apple-system,sans-serif; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      #kwsSrP .soop-vod-subtitle { color:rgba(255,255,255,.52); font:600 10px/1.2 -apple-system,sans-serif; margin-top:2px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      #kwsSrP .soop-actions { display:flex; align-items:center; gap:6px; flex-wrap:wrap; justify-content:flex-end; }
      #kwsSrP .soop-pill, #kwsSrP .soop-iconbtn { border:1px solid rgba(255,255,255,.16); background:rgba(255,255,255,.10); color:rgba(255,255,255,.86); border-radius:999px; min-height:28px; padding:0 10px; font:800 11px/1 -apple-system,sans-serif; cursor:pointer; display:inline-flex; align-items:center; justify-content:center; gap:5px; box-shadow:inset 0 1px 0 rgba(255,255,255,.08); }
      #kwsSrP .soop-pill:hover, #kwsSrP .soop-iconbtn:hover { background:rgba(255,255,255,.20); color:#fff; border-color:rgba(255,255,255,.30); }
      #kwsSrP .soop-pill.checked { background:rgba(250,204,21,.22) !important; color:#facc15 !important; border-color:rgba(250,204,21,.5) !important; }
      #kwsSrP .soop-iconbtn { width:30px; padding:0; font-size:13px; }
      #kwsSrP .soop-res-group { display:flex; gap:5px; align-items:center; max-width:42vw; overflow:auto; scrollbar-width:none; }
      #kwsSrP .soop-res-group::-webkit-scrollbar { display:none; }
      #kwsSrP video { cursor:pointer; }
      #kwsSrP .kws-unified-close { width:30px; height:30px; border-radius:999px; background:linear-gradient(135deg,rgba(255,255,255,.18),rgba(255,255,255,.07)); border:1px solid rgba(255,255,255,.18); box-shadow:0 8px 18px rgba(0,0,0,.35),inset 0 1px 0 rgba(255,255,255,.18); display:flex; align-items:center; justify-content:center; font-size:15px; color:#fff; cursor:pointer; transition:transform .14s,background .14s,border-color .14s; }
      #kwsSrP .kws-unified-close:hover { background:linear-gradient(135deg,rgba(248,113,113,.95),rgba(220,38,38,.88)); border-color:rgba(255,255,255,.28); transform:scale(1.06); }
      /* 컨트롤바 override - css.js의 visibility:hidden 무력화 */
      #kwsSrP .custom_video_controls_cont { height:auto !important; display:flex !important; flex-direction:column !important; gap:6px !important; visibility:visible !important; opacity:0; background:rgba(12,15,23,.66) !important; border:1px solid rgba(255,255,255,.12) !important; border-radius:18px !important; padding:7px 10px !important; backdrop-filter: blur(14px) !important; -webkit-backdrop-filter: blur(14px) !important; transform:translateY(6px); transition:opacity .16s ease, transform .16s ease; pointer-events:none; box-sizing:border-box !important; }
      #kwsSrP:hover .custom_video_controls_cont { opacity:1 !important; transform:translateY(0); pointer-events:auto; }
      #kwsSrP .custom_video_controls_cont > div { max-width:100% !important; box-sizing:border-box !important; flex-shrink:0 !important; flex-grow:0 !important; }
      #kwsSrP .custom_video_controls_cont > div:first-child { display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:nowrap; }
      #kwsSrP .custom_video_controls_cont .speed_cont,
      #kwsSrP .custom_video_controls_cont .volume_cont { background:rgba(255,255,255,.07) !important; border-radius:999px !important; padding:3px 8px !important; height:32px !important; box-sizing:border-box !important; display:flex !important; align-items:center !important; }
      #kwsSrP .custom_video_controls_cont .volume_bar { visibility:visible !important; width:86px !important; transform:none !important; accent-color:#facc15 !important; }
      #kwsSrP .custom_video_controls_cont .speed_bar { visibility:visible !important; width:70px !important; transform:none !important; accent-color:#facc15 !important; }
      #kwsSrP .custom_video_controls_cont .speed_display { visibility:visible !important; width:42px !important; }
    
#kwsSrP .kctl { position:absolute; left:12px; right:12px; bottom:12px; z-index:7; }
#kwsSrP .custom_video_controls_cont .kinfo { display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:nowrap; }
#kwsSrP .kleft { display:flex; align-items:center; gap:8px; }
#kwsSrP .kright { display:flex; align-items:center; gap:6px; }
#kwsSrP .kic { cursor:pointer; display:flex; align-items:center; }
#kwsSrP .ktime { color:#fff; font-size:11px; font-weight:700; font-variant-numeric:tabular-nums; white-space:nowrap; }
#kwsSrP .kseek { width:100%; accent-color:#60a5fa; margin:0; }
#kwsSrP.show .soop-glassbar, #kwsSrP.show .custom_video_controls_cont { opacity:1 !important; transform:none !important; pointer-events:auto; }
#kwsSrP .load { position:absolute; inset:0; z-index:8; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:14px; background:radial-gradient(circle at 50% 40%, #1a1330 0%, #07070b 70%); color:#e5e7eb; text-align:center; padding:24px; }
#kwsSrP .load[hidden] { display:none; }
#kwsSrP .lhead { position:absolute; left:18px; top:14px; font:700 11px/1 ui-monospace,Consolas,"D2Coding",monospace; letter-spacing:.06em; color:rgba(255,255,255,.55); }
#kwsSrP .lhead b { color:#b992ff; font-weight:800; letter-spacing:.14em; }
#kwsSrP .lterm { width:min(640px, 92%); max-height:62%; overflow:hidden auto; text-align:left; padding:14px 16px; border-radius:10px; background:rgba(0,0,0,.55); border:1px solid rgba(185,146,255,.18); box-shadow:0 0 0 1px rgba(0,0,0,.4), 0 18px 50px rgba(0,0,0,.5); font:12.5px/1.7 ui-monospace,Consolas,"D2Coding","Malgun Gothic",monospace; color:#e5e7eb; scrollbar-width:thin; scrollbar-color:rgba(255,255,255,.2) transparent; }
#kwsSrP .tl { display:flex; gap:10px; white-space:pre-wrap; word-break:break-word; }
#kwsSrP .tts { flex:none; color:rgba(255,255,255,.28); }
#kwsSrP .ttx::before { content:'> '; color:#b992ff; }
#kwsSrP .tl.dim .ttx { color:rgba(148,163,184,.75); }
#kwsSrP .tl.dim .ttx::before { content:'  '; }
#kwsSrP .tl.ok .ttx { color:#86efac; }
#kwsSrP .tl.ok .ttx::after { content:'  ✓'; color:#4ade80; }
#kwsSrP .tl.cur .ttx::after { content:'▌'; margin-left:4px; color:#b992ff; animation:kwsSrBlink 1s steps(1) infinite; }
#kwsSrP .tl.bad .ttx { color:#fca5a5; }
#kwsSrP .tl.bad .ttx::before { content:'✗ '; color:#f87171; }
@keyframes kwsSrBlink { 50% { opacity:0; } }
#kwsSrP .lclose { width:34px; height:34px; border-radius:999px; background:linear-gradient(135deg,rgba(255,255,255,.18),rgba(255,255,255,.07)); border:1px solid rgba(255,255,255,.18); color:#fff; font-size:15px; cursor:pointer; }
#kwsSrP .lclose:hover { background:linear-gradient(135deg,rgba(248,113,113,.95),rgba(220,38,38,.88)); }
@keyframes kwsSrSpin { to { transform:rotate(360deg); } }
#kwsSrP .dl { position:absolute; right:12px; top:56px; z-index:9; width:300px; padding:12px; border-radius:16px; background:rgba(8,10,16,.95); border:1px solid rgba(255,255,255,.14); color:#e2e8f0; font-weight:600; font-size:12px; line-height:1.4; display:flex; flex-direction:column; gap:8px; }
#kwsSrP .dl input { width:100%; box-sizing:border-box; background:rgba(255,255,255,.07); border:1px solid rgba(255,255,255,.14); border-radius:8px; color:#fff; padding:5px 8px; font-weight:700; font-size:13px; }
#kwsSrP .dl .two { display:grid; grid-template-columns:1fr 1fr; gap:8px; }
#kwsSrP .dl .lab { font-size:10px; color:rgba(255,255,255,.5); text-transform:uppercase; letter-spacing:.05em; }
#kwsSrP .dl .go { background:linear-gradient(135deg,rgba(37,99,235,.8),rgba(59,130,246,.8)); color:#fff; min-height:32px; }
#kwsSrP .dl .msg { color:rgba(255,255,255,.65); font-size:11px; min-height:15px; }`;
    document.documentElement.appendChild(st);
  }

  function buildPlayer() {
    css();
    document.documentElement.classList.add('kws-srp-on');
    // StreamRecorder's own player must not play underneath
    document.querySelectorAll('video').forEach((v) => { if (!v.closest('#kwsSrP')) { try { v.pause(); v.muted = true; } catch (_) {} } });
    const cont = document.createElement('div');
    cont.id = 'kwsSrP';
    const SVG_PLAY = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 16 16"><path fill="white" d="M2 1v14l12-7z"/></svg>';
    const SVG_PAUSE = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 16 16"><path fill="white" d="M2 2h4v12h-4z"/><path fill="white" d="M8 2h4v12h-4z"/></svg>';
    const SVG_VOL = '<svg xmlns="http://www.w3.org/2000/svg" fill="white" height="20" width="20" viewBox="0 0 24 24"><path d="M13,23.1L5.6,17H0V7h5.6L13,0.9C13,0.9,13,23.1,13,23.1z M2,15h4.4l4.6,3.9V5.1L6.4,9H2V15z M15,21v-2c3.9,0,7-3.1,7-7s-3.1-7-7-7V3c5,0,9,4,9,9S20,21,15,21z M15,17v-2c1.7,0,3-1.3,3-3s-1.3-3-3-3V7c2.8,0,5,2.2,5,5S17.8,17,15,17z"/></svg>';
    const SVG_MUTE = '<svg xmlns="http://www.w3.org/2000/svg" fill="white" height="20" width="20" viewBox="0 0 24 24"><path d="M13,23.1L5.6,17H0V7h5.6L13,0.9V23.1z M2,15h4.4l4.6,3.9V5.1L6.4,9H2V15z"/><path d="M16 8l6 8M22 8l-6 8" stroke="white" stroke-width="2"/></svg>';
    cont.innerHTML = `
      <div class="kbody">
        <video playsinline></video>
        <div class="load"><div class="lhead"><b>HLGX</b> · Keyword Searcher</div><div class="lterm" role="log" aria-live="polite"></div><button class="lclose" hidden>✕</button></div>
        <div class="soop-glassbar">
          <div style="min-width:0;flex:1"><div class="soop-vod-title k-ttl"></div><div class="soop-vod-subtitle k-sub"></div></div>
          <div class="soop-actions"><div class="soop-res-group k-q"></div>
            <button type="button" class="soop-iconbtn k-open" title="StreamRecorder">🔗</button>
            <button type="button" class="soop-iconbtn k-dlb" title="Download">⬇</button>
            <button type="button" class="soop-iconbtn k-fs" title="Fullscreen">⛶</button>
            <button type="button" class="kws-unified-close k-x" title="Close">✕</button></div>
        </div>
        <div class="kctl"><div class="custom_video_controls_cont">
          <div class="kinfo">
            <div class="kleft">
              <div class="kic k-play" title="Play/Pause">${SVG_PLAY}</div>
              <div class="kic k-back" title="-30s"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 16 16"><text fill="white" x="4" y="11" font-size="8">30</text><path fill="white" d="M8 0c-3 0-5.6 1.6-6.9 4.1l-1.1-1.1v4h4l-1.5-1.5c1-2 3.1-3.5 5.5-3.5 3.3 0 6 2.7 6 6s-2.7 6-6 6c-1.8 0-3.4-0.8-4.5-2.1l-1.5 1.3c1.4 1.7 3.6 2.8 6 2.8 4.4 0 8-3.6 8-8s-3.6-8-8-8z"/></svg></div>
              <div class="kic k-fwd" title="+30s"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 16 16"><text fill="white" x="4" y="11" font-size="8">30</text><path fill="white" d="M16 7v-4l-1.1 1.1c-1.3-2.5-3.9-4.1-6.9-4.1-4.4 0-8 3.6-8 8s3.6 8 8 8c2.4 0 4.6-1.1 6-2.8l-1.5-1.3c-1.1 1.3-2.7 2.1-4.5 2.1-3.3 0-6-2.7-6-6s2.7-6 6-6c2.4 0 4.5 1.5 5.5 3.5l-1.5 1.5h4z"/></svg></div>
              <div class="ktime k-time">00:00:00 / 00:00:00</div>
            </div>
            <div class="kright">
              <div class="speed_cont k-spd" style="display:flex;gap:3px;align-items:center;color:#fff;"></div>
              <div class="volume_cont" style="gap:6px"><div class="kic k-mute">${SVG_VOL}</div><input type="range" class="volume_bar k-vol" min="0" max="100" value="80"></div>
            </div>
          </div>
          <div><input type="range" class="kseek k-seek" min="0" max="1000" value="0"></div>
        </div></div>
      </div>`;
    document.body.appendChild(cont);
    const $ = (s) => cont.querySelector(s);
    const video = $('video');
    const p = { cont, video, $, hls: null, rec: null, load: $('.load') };
    $('.lclose').onclick = () => { try { chrome.runtime.sendMessage({ type: 'KWS_SR_CLOSE' }); } catch (_) { window.close(); } };
    video.addEventListener('playing', () => { p.load.hidden = true; });
    p.load.addEventListener('click', (e) => { if (p.load.classList.contains('err') && p.rec && e.target === p.load) p.load.hidden = true; }); // an error over a playing video → click away
    document.title = 'KWS · StreamRecorder';
    // speeds 1–4x
    const spd = $('.k-spd');
    [1, 2, 3, 4].forEach((n) => {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'soop-pill soop-speed-pill' + (n === 1 ? ' checked' : ''); b.textContent = n + 'x';
      b.onclick = () => { video.playbackRate = n; spd.querySelectorAll('button').forEach((x) => x.classList.toggle('checked', x === b)); };
      spd.appendChild(b);
    });
    const play = $('.k-play');
    const togglePlay = () => { video.paused ? video.play().catch(() => {}) : video.pause(); };
    play.onclick = togglePlay;
    video.addEventListener('click', (e) => { if (e.defaultPrevented) return; togglePlay(); });
    video.addEventListener('play', () => { play.innerHTML = SVG_PAUSE; });
    video.addEventListener('pause', () => { play.innerHTML = SVG_PLAY; });
    $('.k-back').onclick = () => { video.currentTime = Math.max(0, video.currentTime - 30); };
    $('.k-fwd').onclick = () => { video.currentTime = Math.min((video.duration || 1e9) - 1, video.currentTime + 30); };
    const vol = $('.k-vol');
    try { const v = Number(localStorage.getItem('kwsSrVol')); if (v >= 0 && v <= 100 && localStorage.getItem('kwsSrVol') !== null) vol.value = String(v); } catch (_) {}
    video.volume = Number(vol.value) / 100;
    vol.oninput = () => { video.volume = Number(vol.value) / 100; video.muted = false; try { localStorage.setItem('kwsSrVol', vol.value); } catch (_) {} };
    $('.k-mute').onclick = () => { video.muted = !video.muted; $('.k-mute').innerHTML = video.muted ? SVG_MUTE : SVG_VOL; };
    const seek = $('.k-seek');
    let dragging = false;
    seek.addEventListener('input', () => { dragging = true; $('.k-time').textContent = fmt(seek.value) + ' / ' + fmt(video.duration); });
    seek.addEventListener('change', () => { dragging = false; video.currentTime = Number(seek.value); });
    video.addEventListener('timeupdate', () => {
      $('.k-time').textContent = fmt(video.currentTime) + ' / ' + fmt(video.duration);
      if (!dragging) { seek.max = String(Math.floor(video.duration || 0)); seek.value = String(Math.floor(video.currentTime)); }
    });
    $('.k-fs').onclick = () => { document.fullscreenElement ? document.exitFullscreen().catch(() => {}) : cont.requestFullscreen().catch(() => {}); };
    video.addEventListener('dblclick', () => { $('.k-fs').click(); });
    $('.k-x').onclick = () => { try { chrome.runtime.sendMessage({ type: 'KWS_SR_CLOSE' }); } catch (_) { window.close(); } };
    $('.k-open').onclick = () => { if (p.rec) window.open('/userrecordings/recording/' + encodeURIComponent(p.rec.token || p.rec.id), '_blank'); };
    $('.k-dlb').onclick = () => toggleDownload(p);
    document.addEventListener('keydown', (e) => {
      if (e.target && /input|textarea/i.test(e.target.tagName)) return;
      if (e.key === ' ') { e.preventDefault(); togglePlay(); }
      else if (e.key === 'ArrowLeft') video.currentTime = Math.max(0, video.currentTime - 10);
      else if (e.key === 'ArrowRight') video.currentTime += 10;
      else if (e.key === 'f') $('.k-fs').click();
    });
    // double-click left/right ±10 s + hold for 4x — the same as the other KWS players (platform.js)
    try { globalThis.KWSDblSeek && globalThis.KWSDblSeek(video, { host: cont }); } catch (_) {}
    return p;
  }

  function loadRecording(p, rec, sec, info) {
    p.rec = rec;
    p.info = info;
    p.$('.k-ttl').textContent = rec.streamtitle || info.title || info.channel;
    const when = String(rec.recorded_at || '').slice(0, 10);
    p.$('.k-sub').textContent = [rec.target_name || info.channel, when, 'StreamRecorder'].filter(Boolean).join(' · ');
    document.title = (rec.target_name || info.channel) + ' · KWS';
    const src = '/recordings/hls/' + encodeURIComponent(rec.id) + '/master.m3u8';
    const startAt = Math.max(0, sec - LEAD);
    const video = p.video;
    const Hls = globalThis.Hls;
    if (p.hls) { try { p.hls.destroy(); } catch (_) {} p.hls = null; }
    const go = () => { try { video.currentTime = startAt; } catch (_) {} video.play().catch(() => {}); };
    if (Hls && Hls.isSupported()) {
      const hls = new Hls({ enableWorker: true, startPosition: startAt, xhrSetup: (xhr) => { xhr.withCredentials = false; } });
      p.hls = hls;
      hls.on(Hls.Events.MANIFEST_PARSED, (_, data) => {
        log('hls  ' + (hls.levels || []).map((l) => (l.height || '?') + 'p').join(' / ') + ' · start @ ' + fmt(startAt) + ' (−' + LEAD + 's)');
        const q = p.$('.k-q');
        q.replaceChildren();
        (hls.levels || []).map((l, i) => ({ i, h: l.height || 0 })).sort((a, b) => b.h - a.h).forEach(({ i, h }, k) => {
          const b = document.createElement('button');
          b.type = 'button'; b.className = 'soop-pill';
          b.textContent = h ? h + 'p' : 'L' + i;
          if (k === 0) { b.classList.add('checked'); hls.currentLevel = i; }
          b.onclick = () => { hls.currentLevel = i; q.querySelectorAll('button').forEach((x) => x.classList.toggle('checked', x === b)); };
          q.appendChild(b);
        });
        video.play().catch(() => {});
      });
      hls.on(Hls.Events.ERROR, (_, d) => { if (d && d.fatal) say(T('srFailed', d.details || 'error'), 'err'); });
      // master.m3u8 lives on streamrecorder.io (needs the login cookie); the parts come from its CDN
      hls.loadSource(new URL(src, location.href).href);
      hls.attachMedia(video);
    } else {
      video.src = src;
      video.addEventListener('loadedmetadata', go, { once: true });
    }
    p.cont.classList.add('show');
    setTimeout(() => p.cont.classList.remove('show'), 2500);
  }

  // fMP4 clip: start it at 0 (tfdt minus the first part's time, per track) and give it its own length
  // (mvhd / tkhd / mdhd / mehd) — otherwise players show the whole recording's length, hours in.
  function fixClip(initBuf, segBufs, lenSec) {
    const walk = (dv, start, end, fn) => {
      let o = start;
      while (o + 8 <= end) {
        let size = dv.getUint32(o);
        const type = String.fromCharCode(dv.getUint8(o + 4), dv.getUint8(o + 5), dv.getUint8(o + 6), dv.getUint8(o + 7));
        let hdr = 8;
        if (size === 1) { size = Number(dv.getBigUint64(o + 8)); hdr = 16; } else if (size === 0) size = end - o;
        if (size < hdr || o + size > end) break;
        fn(type, o, o + hdr, o + size);
        o += size;
      }
    };
    try {
      const idv = new DataView(initBuf);
      let ts = 1000;
      const setDur = (p, v1off, v0off, scale) => { const val = Math.round(lenSec * scale); if (idv.getUint8(p) === 1) idv.setBigUint64(p + v1off, BigInt(val)); else idv.setUint32(p + v0off, val >>> 0); };
      walk(idv, 0, idv.byteLength, (t, o, p, e) => {
        if (t !== 'moov') return;
        walk(idv, p, e, (t2, o2, p2, e2) => {
          if (t2 === 'mvhd') { ts = idv.getUint8(p2) === 1 ? idv.getUint32(p2 + 20) : idv.getUint32(p2 + 12); setDur(p2, 24, 16, ts); }
          else if (t2 === 'mvex') walk(idv, p2, e2, (t3, o3, p3) => { if (t3 === 'mehd') setDur(p3, 4, 4, ts); });
          else if (t2 === 'trak') walk(idv, p2, e2, (t3, o3, p3, e3) => {
            if (t3 === 'tkhd') setDur(p3, 28, 20, ts);
            else if (t3 === 'mdia') walk(idv, p3, e3, (t4, o4, p4) => { if (t4 === 'mdhd') setDur(p4, 24, 16, idv.getUint8(p4) === 1 ? idv.getUint32(p4 + 20) : idv.getUint32(p4 + 12)); });
          });
        });
      });
      const first = new Map(); // track id → first part's decode time
      for (const buf of segBufs) {
        const dv = new DataView(buf);
        walk(dv, 0, dv.byteLength, (t, o, p, e) => {
          if (t !== 'moof') return;
          walk(dv, p, e, (t2, o2, p2, e2) => {
            if (t2 !== 'traf') return;
            let track = 0;
            walk(dv, p2, e2, (t3, o3, p3) => {
              if (t3 === 'tfhd') track = dv.getUint32(p3 + 4);
              else if (t3 === 'tfdt') {
                const v = dv.getUint8(p3);
                const cur = v === 1 ? dv.getBigUint64(p3 + 4) : BigInt(dv.getUint32(p3 + 4));
                if (!first.has(track)) first.set(track, cur);
                let nv = cur - first.get(track); if (nv < 0n) nv = 0n;
                if (v === 1) dv.setBigUint64(p3 + 4, nv); else dv.setUint32(p3 + 4, Number(nv) >>> 0);
              }
            });
          });
        });
      }
    } catch (e) { console.warn('[KWS SR] clip fix skipped', e); }
  }

  // ── clip download (fMP4: init + the parts covering the range) ──
  function toggleDownload(p) {
    const old = p.cont.querySelector('.dl');
    if (old) { old.remove(); return; }
    if (!p.rec || !p.hls) return;
    // 1.2.6.3: the same "Clip Downloader" popup as the Twitch / Kick / SOOP players
    const d = document.createElement('div');
    d.className = 'dl';
    const cur = Math.floor(p.video.currentTime || 0);
    d.style.cssText = 'position:absolute;top:58px;right:12px;z-index:9;width:340px;background:rgba(8,10,16,.92);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,.14);border-radius:18px;box-shadow:0 16px 50px rgba(0,0,0,.6);font-family:-apple-system,sans-serif;color:#e2e8f0;font-size:12px;overflow:hidden;padding:0;display:block;';
    d.innerHTML = `<div class="dhead" style="display:flex;align-items:center;justify-content:space-between;padding:11px 14px;border-bottom:1px solid rgba(255,255,255,.07);cursor:move;background:rgba(255,255,255,.04);"><span style="font-size:11px;font-weight:800;letter-spacing:.05em;color:rgba(255,255,255,.55);text-transform:uppercase;">Clip Downloader</span><button type="button" class="dclose" style="width:22px;height:22px;border-radius:999px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.18);color:#fff;font-size:12px;cursor:pointer;padding:0;min-height:0;">✕</button></div>
      <div style="padding:12px 14px;display:flex;flex-direction:column;gap:10px;">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
          <div style="background:rgba(250,204,21,.07);border:1px solid rgba(250,204,21,.2);border-radius:10px;padding:8px 10px;"><div style="font-size:9px;font-weight:700;text-transform:uppercase;color:rgba(250,204,21,.6);margin-bottom:4px;">Start</div><input class="s" type="text" value="${fmt(cur)}" style="width:100%;box-sizing:border-box;background:transparent;border:none;outline:none;font-size:13px;font-weight:800;color:#facc15;margin-bottom:6px;font-family:inherit;padding:0;"/><button type="button" class="ss" style="width:100%;padding:4px;border-radius:7px;font-size:10px;font-weight:800;background:rgba(250,204,21,.25);border:1px solid rgba(250,204,21,.4);color:#fde68a;cursor:pointer;min-height:0;">Set to Current</button></div>
          <div style="background:rgba(96,165,250,.07);border:1px solid rgba(96,165,250,.2);border-radius:10px;padding:8px 10px;"><div style="font-size:9px;font-weight:700;text-transform:uppercase;color:rgba(96,165,250,.6);margin-bottom:4px;">End</div><input class="e" type="text" value="${fmt(cur + 300)}" style="width:100%;box-sizing:border-box;background:transparent;border:none;outline:none;font-size:13px;font-weight:800;color:#60a5fa;margin-bottom:6px;font-family:inherit;padding:0;"/><button type="button" class="se" style="width:100%;padding:4px;border-radius:7px;font-size:10px;font-weight:800;background:rgba(96,165,250,.25);border:1px solid rgba(96,165,250,.4);color:#93c5fd;cursor:pointer;min-height:0;">Set to Current</button></div>
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;padding:6px 10px;border-radius:9px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);"><span style="font-size:9px;font-weight:700;text-transform:uppercase;color:rgba(255,255,255,.3);">Duration</span><span class="dur" style="font-size:13px;font-weight:800;color:rgba(255,255,255,.75);">${fmt(300)}</span></div>
        <div class="q2" style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;padding:4px 0;"><span style="font-size:9px;font-weight:700;text-transform:uppercase;color:rgba(255,255,255,.35);">Quality:</span></div>
        <div style="display:flex;align-items:center;gap:5px;padding:6px 9px;border-radius:9px;background:rgba(251,191,36,.08);border:1px solid rgba(251,191,36,.22);color:#fde68a;font-size:10px;">⚠️ Keep this window open while downloading.</div>
        <button type="button" class="go" style="width:100%;padding:9px;border-radius:11px;font-size:12px;font-weight:800;background:linear-gradient(135deg,rgba(37,99,235,.7),rgba(59,130,246,.7));color:#fff;border:1px solid rgba(99,137,255,.4);cursor:pointer;min-height:0;">💾 Download</button>
        <div class="msg" style="font-size:11px;color:rgba(255,255,255,.65);min-height:14px;"></div>
      </div>`;
    p.cont.appendChild(d);
    const s = d.querySelector('.s'), e = d.querySelector('.e'), msg = d.querySelector('.msg');
    const upd = () => { d.querySelector('.dur').textContent = fmt(Math.max(0, pf(e.value) - pf(s.value))); };
    s.addEventListener('input', upd); e.addEventListener('input', upd);
    d.querySelector('.ss').onclick = () => { s.value = fmt(p.video.currentTime); upd(); };
    d.querySelector('.se').onclick = () => { e.value = fmt(p.video.currentTime); upd(); };
    d.querySelector('.dclose').onclick = () => d.remove();
    { // drag by the header, like the other players' popup
      let dg = false, ox = 0, oy = 0;
      d.querySelector('.dhead').addEventListener('mousedown', (ev) => { if (ev.target.closest('.dclose')) return; dg = true; const r = d.getBoundingClientRect(); d.style.right = 'auto'; d.style.left = r.left + 'px'; d.style.top = r.top + 'px'; ox = ev.clientX - r.left; oy = ev.clientY - r.top; ev.preventDefault(); });
      window.addEventListener('mousemove', (ev) => { if (dg) { d.style.left = (ev.clientX - ox) + 'px'; d.style.top = (ev.clientY - oy) + 'px'; } });
      window.addEventListener('mouseup', () => { dg = false; });
    }
    // 1.2.6.8: always the best quality by default, whatever is playing
    let level = (p.hls.levels || []).reduce((best, l, i, a) => ((l.height || 0) > ((a[best] && a[best].height) || 0) ? i : best), 0);
    const q2 = d.querySelector('.q2');
    const qBtns = [];
    const paint = () => qBtns.forEach(({ b, i }) => { const on = i === level; b.style.cssText = `padding:3px 10px;border-radius:999px;font-size:10px;font-weight:800;cursor:pointer;min-height:0;border:1px solid ${on ? 'rgba(250,204,21,.6)' : 'rgba(255,255,255,.15)'};background:${on ? 'rgba(250,204,21,.18)' : 'rgba(255,255,255,.06)'};color:${on ? '#facc15' : 'rgba(255,255,255,.7)'};`; });
    (p.hls.levels || []).map((l, i) => ({ l, i })).sort((x, y) => (y.l.height || 0) - (x.l.height || 0)).forEach(({ l, i }) => {
      const b = document.createElement('button'); b.type = 'button'; b.textContent = (l.height || '?') + 'p';
      b.onclick = () => { level = i; paint(); };
      qBtns.push({ b, i }); q2.appendChild(b);
    });
    paint();
    d.querySelector('.go').onclick = async (ev) => {
      const btn = ev.currentTarget;
      const a = pf(s.value), b = pf(e.value);
      if (!(b > a)) { msg.textContent = T('srDlRange'); return; }
      // 1.2.6.4: like the other KWS downloaders — ask where to save first (needs this click), same
      // file name style as the SOOP player: "<id> <d Mon yyyy>.mp4"
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const day = String(p.rec.recorded_at || '').slice(0, 10).split('-').map(Number);
      const when = day.length === 3 && day[0] ? `${day[2]} ${months[day[1] - 1]} ${day[0]}` : 'StreamRecorder';
      const who = String(p.rec.target_name || p.info.channel || 'stream').replace(/[\\/:*?"<>|]+/g, '_');
      const suggestedName = `${who} ${when}.mp4`;
      let fh = null;
      if (typeof window.showSaveFilePicker === 'function') {
        try { fh = await window.showSaveFilePicker({ suggestedName, startIn: 'downloads', types: [{ description: 'MP4 Video', accept: { 'video/mp4': ['.mp4'] } }] }); }
        catch (err) { if (err && err.name === 'AbortError') return; fh = null; }
      }
      btn.disabled = true;
      try {
        const lvl = p.hls.levels[level];
        const url = (lvl && (lvl.url && (Array.isArray(lvl.url) ? lvl.url[0] : lvl.url))) || '';
        const pl = await (await fetch(url)).text();
        const base = new URL(url, location.href);
        const lines = pl.split('\n').map((x) => x.trim());
        const mapLine = lines.find((x) => x.startsWith('#EXT-X-MAP'));
        const init = mapLine && (mapLine.match(/URI="([^"]+)"/) || [])[1];
        const segs = [];
        let t = 0, first = null;
        for (let i = 0; i < lines.length; i++) {
          const m = lines[i].match(/^#EXTINF:([\d.]+)/);
          if (!m) continue;
          const dur = parseFloat(m[1]);
          const u = lines[i + 1];
          if (u && !u.startsWith('#') && t + dur > a && t < b) { segs.push(new URL(u, base).href); if (first == null) first = t; }
          t += dur;
          if (t >= b) break;
        }
        if (!segs.length) throw new Error('no parts');
        const parts = new Array(segs.length + 1);
        if (init) parts[0] = await (await fetch(new URL(init, base).href)).arrayBuffer();
        let next = 0, done = 0;
        const w = async () => { while (next < segs.length) { const k = next++; parts[k + 1] = await (await fetch(segs[k])).arrayBuffer(); done++; msg.textContent = T('srDlProgress', done, segs.length); } };
        await Promise.all([w(), w(), w(), w()]);
        if (parts[0]) fixClip(parts[0], parts.slice(1), t - (first || 0));
        const blob = new Blob(parts.filter(Boolean), { type: 'video/mp4' });
        if (fh) {
          const ws = await fh.createWritable();
          await ws.write(blob);
          await ws.close();
        } else { // no file picker (very old Chrome): a normal download
          const href = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = href; link.download = suggestedName; document.body.appendChild(link); link.click(); link.remove();
          setTimeout(() => URL.revokeObjectURL(href), 60000);
        }
        msg.textContent = T('srDlDone', (blob.size / 1048576).toFixed(1));
      } catch (err) {
        msg.textContent = T('srFailed', (err && err.message) || err);
      } finally { btn.disabled = false; }
    };
  }

  // ───────────────────────── request flow ─────────────────────────
  let busy = null;
  async function handle(req) {
    const platform = req.platform || 'twitch';
    const pid = PID[platform];
    const ch = String(req.channel || '').toLowerCase().trim();
    if (!pid || !ch) return;
    // same recording already open → just seek
    if (P && P.rec && req.recId && String(P.rec.id) === String(req.recId)) { P.video.currentTime = Math.max(0, (Number(req.recOff) || 0) - LEAD); P.video.play().catch(() => {}); return; }
    if (P && P.rec && req.ts > 0 && P.info && P.info.channel === ch) {
      const start = Date.parse(String(P.rec.recorded_at || '') + 'Z');
      if (start && req.ts >= start && req.ts <= start + (Number(P.rec.duration) || 0) * 1000) { P.video.currentTime = Math.max(0, Math.round((req.ts - start) / 1000) - LEAD); P.video.play().catch(() => {}); return; }
    }
    if (!P) P = buildPlayer(); // the KWS window right away (loading screen), never the StreamRecorder site
    if (P.hls) { try { P.video.pause(); } catch (_) {} }
    { const term = P.load.querySelector('.lterm'); if (term) term.replaceChildren(); }
    log('kws sr --platform ' + platform + ' --channel ' + ch + (req.ts > 0 ? ' --at ' + new Date(Number(req.ts)).toISOString() : req.date ? ' --date ' + req.date + ' --off ' + (req.off || 0) : '') + (req.recId ? ' --rec ' + req.recId : ''));
    say(T('srStepFind', ch));
    const t = await ensureTarget(ch, pid);
    say(T('srStepRec'));
    const hit = await findRecording(t.targetId, req);
    if (!hit) { say(T('srNoRec', ch), 'err'); return; }
    log('recording  #' + hit.rec.id + ' · ' + String(hit.rec.recorded_at || '').replace('T', ' ') + ' UTC · ' + fmt(hit.rec.duration) + ' long · moment @ ' + fmt(hit.sec));
    if (hit.rec.premium_required || hit.rec.after_adding_locked) { say(T('srLocked'), 'err'); return; }
    say(T('srStepPlay'));
    loadRecording(P, hit.rec, hit.sec, { channel: ch, title: req.title || '' });
  }
  function run(req) {
    const job = (busy || Promise.resolve()).then(() => handle(req)).catch((e) => say(e && (e.login || e.noRec) ? e.message : T('srFailed', (e && e.message) || e), 'err'));
    busy = job;
    return job;
  }

  try {
    chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
      if (msg && msg.type === 'KWS_SR_PLAY') { run(msg.req || {}); sendResponse({ ok: true }); }
    });
  } catch (_) {}

  const h = location.hash;
  const mSr = h.match(/kwsSR=([^&]+)/);
  if (mSr) {
    let req = null;
    const raw = decodeURIComponent(mSr[1]);
    try { req = JSON.parse(raw); } catch (_) {
      const [c, ts] = raw.split('|'); // 1.2.5.60 links: <channel>|<ms>
      req = { platform: 'twitch', channel: c, ts: Number(ts) };
    }
    try { history.replaceState(null, '', location.pathname); } catch (_) {}
    if (req) run(req);
  }
})();
