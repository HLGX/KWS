// KWS 1.2.6.0 — StreamRecorder player (runs in the user's own logged-in streamrecorder.io page,
// opened by sr_bg.js as a small popup window that is reused for the next hit).
//
//   #kwsSR=<json> on /userrecordings, or a KWS_SR_PLAY message to an open popup:
//     { platform, channel, ts?: unix ms of the chat line, date?: 'YYYY-MM-DD', off?: s into the VOD,
//       recId?: StreamRecorder recording id, recOff?: s into that recording, title? }
//   1. the channel must be one of the account's recording targets — if not, KWS adds it (Premium
//      accounts see recordings made before that right away); when the list is full, KWS removes the
//      target least recently searched in KWS (never one whose recordings would be deleted for good)
//   2. the recording covering that moment (recorded_at is UTC) is played in a KWS player that takes
//      over the page (same look as the inline players), 30 s before the moment
//   3. ⬇ clip download: the recording is plain fMP4 HLS (init + .m4s, no encryption) → the segments
//      covering the range are fetched here and saved as one .mp4
(function () {
  'use strict';
  if (window.__kwsSrOpen) return;
  window.__kwsSrOpen = true;
  const T = (k, ...a) => { try { return chrome.i18n.getMessage(k, a.map(String)) || k; } catch (_) { return k; } };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const HISTORY_KEYS = ['twitchKwsHistory', 'kickKwsHistory', 'soopSearchHistory', 'ytKwsHistory', 'chzzkKwsHistory'];
  const PID = { twitch: '1', kick: '5', soop: '7', chzzk: '9' };
  const LEAD = 30; // seconds before the chat line, like the other players

  // ── status box ──
  let box = null;
  function say(text, kind) {
    if (!box || !document.contains(box)) {
      box = document.createElement('div');
      box.style.cssText = 'position:fixed;z-index:2147483647;right:16px;bottom:16px;max-width:380px;padding:11px 15px;border-radius:14px;background:rgba(15,17,23,.94);color:#e5e7eb;font:600 13px/1.5 -apple-system,"Malgun Gothic",sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.45);white-space:pre-line';
      const tag = document.createElement('div');
      tag.textContent = 'KWS';
      tag.style.cssText = 'font-size:10.5px;font-weight:800;letter-spacing:.08em;color:#9146FF;margin-bottom:3px';
      box.append(tag, document.createElement('div'));
      document.documentElement.appendChild(box);
    }
    box.lastChild.textContent = text;
    box.lastChild.style.color = kind === 'err' ? '#fca5a5' : kind === 'ok' ? '#86efac' : '#e5e7eb';
    clearTimeout(say._t);
    if (kind === 'ok') say._t = setTimeout(() => box && box.remove(), 2500);
  }

  const api = async (path) => {
    const r = await fetch(path, { credentials: 'include' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  };

  function readTargets(doc) {
    return [...doc.querySelectorAll('.recordings-streamer-card')].map((c) => ({
      name: String(c.dataset.srTarget || '').toLowerCase(),
      platformid: String(c.dataset.srTargetPlatformid || ''),
      targetId: (c.id || '').replace(/^target-/, ''),
      requestId: c.dataset.srRequestid,
      latest: Number(c.dataset.srLatestRecording) || 0,
      irreversible: c.dataset.srWillIrreversiblyDeleted === '1',
    })).filter((x) => x.name && x.targetId);
  }
  async function fetchTargets() {
    const r = await fetch('/userrecordings', { credentials: 'include', cache: 'no-store' });
    if (/\/login/.test(r.url)) return { loggedOut: true, targets: [] };
    const doc = new DOMParser().parseFromString(await r.text(), 'text/html');
    const m = (doc.body ? doc.body.textContent : '').match(/(\d[\d,]*)\s*\/\s*(\d[\d,]*)\s*Streamers Monitored/i);
    return { targets: readTargets(doc), lim: m ? { used: +m[1].replace(/,/g, ''), max: +m[2].replace(/,/g, '') } : null, loggedOut: !doc.querySelector('.recordings-streamer-card') && !m };
  }

  async function kwsLastUse() {
    const out = {};
    try {
      const d = await chrome.storage.local.get(HISTORY_KEYS);
      for (const k of HISTORY_KEYS) {
        for (const [id, h] of Object.entries(d[k] || {})) {
          if (!h || typeof h !== 'object') continue;
          const t = Date.parse(h.searchedAt || h.savedAt || h.lastDate || '') || 0;
          const key = id.toLowerCase();
          if (t > (out[key] || 0)) out[key] = t;
        }
      }
    } catch (_) {}
    return out;
  }

  async function addTarget(ch, pid) {
    const d = await api('/api/user/addrecordingtargetv2?q=' + encodeURIComponent(ch) + '&platformid=' + pid);
    if (d && d.error) throw new Error(d.error === 'unknownTarget' ? T('srNotFound', ch) : d.error);
    const requestId = d && d[3];
    if (!requestId) throw new Error(T('srNotFound', ch));
    for (let i = 0; i < 40; i++) {
      const s = await api('/api/user/getrecordingrequeststatus?requestid=' + encodeURIComponent(requestId)).catch(() => null);
      if (s && s.status === 'found') return;
      if (s && s.status === 'notfound') throw new Error(T('srNotFound', ch));
      if (s && s.status === 'error') throw new Error(s.message === 'platformPremiumOnly' ? T('srLocked') : (s.message || 'error'));
      await sleep(1000);
    }
    throw new Error('timeout');
  }

  async function ensureTarget(ch, pid) {
    let { targets, lim, loggedOut } = await fetchTargets();
    if (loggedOut) { const e = new Error(T('srLogin')); e.login = true; throw e; }
    let t = targets.find((x) => x.platformid === pid && x.name === ch);
    if (t) return t;
    if (lim && lim.used >= lim.max) {
      const use = await kwsLastUse();
      const victims = targets.filter((x) => !x.irreversible)
        .sort((a, b) => ((use[a.name] || 0) - (use[b.name] || 0)) || (a.latest - b.latest));
      let dropped = false;
      for (const v of victims.slice(0, 6)) { // StreamRecorder refuses to remove one added minutes ago → next
        say(T('srStepDrop', v.name));
        const r = await api('/api/user/deleterecordingrequest?requestid=' + encodeURIComponent(v.requestId)).catch(() => null);
        if (r && r.success) { dropped = true; break; }
      }
      if (!dropped) throw new Error(T('srFull'));
    }
    say(T('srStepAdd', ch));
    await addTarget(ch, pid);
    ({ targets } = await fetchTargets());
    t = targets.find((x) => x.platformid === pid && x.name === ch);
    if (!t) throw new Error(T('srNotFound', ch));
    return t;
  }

  // newest first; stop paging once past the moment
  async function findRecording(targetId, req) {
    const exact = Number(req.ts) > 0;
    const dayMs = req.date ? Date.parse(req.date + 'T12:00:00Z') : 0;
    let best = null;
    for (let offset = 0; offset < 3000; offset += 50) {
      const j = await api(`/api/user/recordingsv2?targetid=${encodeURIComponent(targetId)}&offset=${offset}&limit=50`);
      const rows = (j && j.data) || [];
      for (const r of rows) {
        if (req.recId && String(r.id) === String(req.recId)) return { rec: r, sec: Number(req.recOff) || 0 };
        const start = Date.parse(String(r.recorded_at || '') + 'Z');
        const dur = Number(r.duration) || 0;
        if (!start) continue;
        if (exact) {
          if (req.ts >= start - 60000 && req.ts <= start + dur * 1000 + 60000) return { rec: r, sec: Math.max(0, Math.round((req.ts - start) / 1000)) };
        } else if (dayMs && Math.abs(start - dayMs) < 36 * 3600000 && (Number(req.off) || 0) <= dur + 60) {
          // no exact time (e.g. a SOOP VOD offset): the recording of that day long enough for it
          const score = Math.abs(start - dayMs);
          if (!best || score < best.score) best = { rec: r, sec: Number(req.off) || 0, score };
        }
      }
      const oldest = rows.length ? Date.parse(String(rows[rows.length - 1].recorded_at || '') + 'Z') : 0;
      const target = exact ? req.ts : dayMs;
      if (!rows.length || rows.length < 50 || (oldest && target && oldest < target - 2 * 86400000)) break;
    }
    return best;
  }

  // ───────────────────────── the player ─────────────────────────
  let P = null; // { cont, video, hls, rec, ... }
  const fmt = (s) => { s = Math.max(0, Math.floor(s || 0)); return [Math.floor(s / 3600), Math.floor((s % 3600) / 60), s % 60].map((v) => String(v).padStart(2, '0')).join(':'); };
  const pf = (s) => { const p = String(s).split(':').map(Number); return p.length === 3 ? p[0] * 3600 + p[1] * 60 + p[2] : p.length === 2 ? p[0] * 60 + p[1] : parseFloat(s) || 0; };

  function css() {
    if (document.getElementById('kws-srp-css')) return;
    const st = document.createElement('style');
    st.id = 'kws-srp-css';
    st.textContent = `
html.kws-srp-on, html.kws-srp-on body { background:#000 !important; overflow:hidden !important; }
html.kws-srp-on body > *:not(#kwsSrP) { display:none !important; }
#kwsSrP { position:fixed; inset:0; z-index:2147483646; background:#000; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Malgun Gothic",sans-serif; }
#kwsSrP video { width:100%; height:100%; display:block; object-fit:contain; background:#000; cursor:pointer; }
#kwsSrP .bar { position:absolute; left:10px; right:10px; top:10px; z-index:7; display:flex; align-items:center; justify-content:space-between; gap:10px; padding:8px 10px; border-radius:16px; background:rgba(20,24,34,.62); border:1px solid rgba(255,255,255,.14); backdrop-filter:blur(16px); opacity:0; transform:translateY(-6px); transition:opacity .16s, transform .16s; }
#kwsSrP .ctl { position:absolute; left:10px; right:10px; bottom:10px; z-index:7; display:flex; flex-direction:column; gap:6px; padding:7px 11px; border-radius:16px; background:rgba(12,15,23,.7); border:1px solid rgba(255,255,255,.12); backdrop-filter:blur(14px); opacity:0; transform:translateY(6px); transition:opacity .16s, transform .16s; }
#kwsSrP:hover .bar, #kwsSrP:hover .ctl, #kwsSrP.show .bar, #kwsSrP.show .ctl { opacity:1; transform:none; }
#kwsSrP .ttl { min-width:0; color:#fff; font-weight:800; font-size:12px; line-height:1.25; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
#kwsSrP .sub { color:rgba(255,255,255,.55); font-weight:600; font-size:10px; line-height:1.2; margin-top:2px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
#kwsSrP .acts, #kwsSrP .row, #kwsSrP .grp { display:flex; align-items:center; gap:5px; }
#kwsSrP .row { justify-content:space-between; gap:10px; }
#kwsSrP .grp.pill { background:rgba(255,255,255,.07); border-radius:999px; padding:3px 7px; }
#kwsSrP button { border:1px solid rgba(255,255,255,.16); background:rgba(255,255,255,.10); color:rgba(255,255,255,.88); border-radius:999px; min-height:26px; padding:0 9px; font-weight:800; font-size:11px; line-height:1; cursor:pointer; display:inline-flex; align-items:center; justify-content:center; }
#kwsSrP button:hover { background:rgba(255,255,255,.2); color:#fff; }
#kwsSrP button.on { background:rgba(250,204,21,.22); color:#facc15; border-color:rgba(250,204,21,.5); }
#kwsSrP button.ic { width:28px; padding:0; font-size:13px; }
#kwsSrP button.x:hover { background:rgba(220,38,38,.85); }
#kwsSrP .icn { background:none; border:0; min-height:0; padding:0; width:22px; }
#kwsSrP .time { color:#fff; font-weight:700; font-size:11px; line-height:1; font-variant-numeric:tabular-nums; white-space:nowrap; }
#kwsSrP input[type=range].seek { width:100%; accent-color:#60a5fa; margin:0; }
#kwsSrP input[type=range].vol { width:80px; accent-color:#facc15; }
#kwsSrP .dl { position:absolute; right:12px; top:56px; z-index:9; width:300px; padding:12px; border-radius:16px; background:rgba(8,10,16,.95); border:1px solid rgba(255,255,255,.14); color:#e2e8f0; font-weight:600; font-size:12px; line-height:1.4; display:flex; flex-direction:column; gap:8px; }
#kwsSrP .dl input { width:100%; box-sizing:border-box; background:rgba(255,255,255,.07); border:1px solid rgba(255,255,255,.14); border-radius:8px; color:#fff; padding:5px 8px; font-weight:700; font-size:13px; }
#kwsSrP .dl .two { display:grid; grid-template-columns:1fr 1fr; gap:8px; }
#kwsSrP .dl .lab { font-size:10px; color:rgba(255,255,255,.5); text-transform:uppercase; letter-spacing:.05em; }
#kwsSrP .dl .go { background:linear-gradient(135deg,rgba(37,99,235,.8),rgba(59,130,246,.8)); color:#fff; min-height:32px; }
#kwsSrP .dl .msg { color:rgba(255,255,255,.65); font-size:11px; min-height:15px; }`;
    document.documentElement.appendChild(st);
  }

  function buildPlayer() {
    css();
    document.documentElement.classList.add('kws-srp-on');
    // StreamRecorder's own player must not play underneath
    document.querySelectorAll('video').forEach((v) => { if (!v.closest('#kwsSrP')) { try { v.pause(); v.muted = true; } catch (_) {} } });
    const cont = document.createElement('div');
    cont.id = 'kwsSrP';
    cont.innerHTML = `
      <video playsinline></video>
      <div class="bar"><div style="min-width:0;flex:1"><div class="ttl"></div><div class="sub"></div></div>
        <div class="acts"><div class="grp q"></div><button class="ic open" title="StreamRecorder">🔗</button><button class="ic dlb" title="Download">⬇</button><button class="ic fs" title="Fullscreen">⛶</button><button class="ic x" title="Close">✕</button></div></div>
      <div class="ctl"><div class="row">
        <div class="grp"><button class="icn play" title="Play/Pause">▶</button><button class="icn back" title="-30s">⟲</button><button class="icn fwd" title="+30s">⟳</button><span class="time">00:00:00 / 00:00:00</span></div>
        <div class="grp"><div class="grp pill spd"></div><div class="grp pill"><button class="icn mute">🔊</button><input type="range" class="vol" min="0" max="100" value="80"></div></div>
      </div><input type="range" class="seek" min="0" max="1000" value="0"></div>`;
    document.body.appendChild(cont);
    const $ = (s) => cont.querySelector(s);
    const video = $('video');
    const p = { cont, video, $, hls: null, rec: null };
    // speeds 1–4x
    const spd = $('.spd');
    [1, 2, 3, 4].forEach((n) => {
      const b = document.createElement('button'); b.textContent = n + 'x'; b.dataset.s = n; if (n === 1) b.classList.add('on');
      b.onclick = () => { video.playbackRate = n; spd.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b)); };
      spd.appendChild(b);
    });
    const play = $('.play');
    const togglePlay = () => { video.paused ? video.play().catch(() => {}) : video.pause(); };
    play.onclick = togglePlay;
    video.addEventListener('click', (e) => { if (e.defaultPrevented) return; togglePlay(); });
    video.addEventListener('play', () => { play.textContent = '❚❚'; });
    video.addEventListener('pause', () => { play.textContent = '▶'; });
    $('.back').onclick = () => { video.currentTime = Math.max(0, video.currentTime - 30); };
    $('.fwd').onclick = () => { video.currentTime = Math.min((video.duration || 1e9) - 1, video.currentTime + 30); };
    const vol = $('.vol');
    try { const v = Number(localStorage.getItem('kwsSrVol')); if (v >= 0 && v <= 100 && localStorage.getItem('kwsSrVol') !== null) vol.value = String(v); } catch (_) {}
    video.volume = Number(vol.value) / 100;
    vol.oninput = () => { video.volume = Number(vol.value) / 100; video.muted = false; try { localStorage.setItem('kwsSrVol', vol.value); } catch (_) {} };
    $('.mute').onclick = () => { video.muted = !video.muted; $('.mute').textContent = video.muted ? '🔇' : '🔊'; };
    const seek = $('.seek');
    let dragging = false;
    seek.addEventListener('input', () => { dragging = true; $('.time').textContent = fmt(seek.value) + ' / ' + fmt(video.duration); });
    seek.addEventListener('change', () => { dragging = false; video.currentTime = Number(seek.value); });
    video.addEventListener('timeupdate', () => {
      $('.time').textContent = fmt(video.currentTime) + ' / ' + fmt(video.duration);
      if (!dragging) { seek.max = String(Math.floor(video.duration || 0)); seek.value = String(Math.floor(video.currentTime)); }
    });
    $('.fs').onclick = () => { document.fullscreenElement ? document.exitFullscreen().catch(() => {}) : cont.requestFullscreen().catch(() => {}); };
    video.addEventListener('dblclick', () => { $('.fs').click(); });
    $('.x').onclick = () => { try { chrome.runtime.sendMessage({ type: 'KWS_SR_CLOSE' }); } catch (_) { window.close(); } };
    $('.open').onclick = () => { if (p.rec) window.open('/userrecordings/recording/' + encodeURIComponent(p.rec.token || p.rec.id), '_blank'); };
    $('.dlb').onclick = () => toggleDownload(p);
    document.addEventListener('keydown', (e) => {
      if (e.target && /input|textarea/i.test(e.target.tagName)) return;
      if (e.key === ' ') { e.preventDefault(); togglePlay(); }
      else if (e.key === 'ArrowLeft') video.currentTime = Math.max(0, video.currentTime - 10);
      else if (e.key === 'ArrowRight') video.currentTime += 10;
      else if (e.key === 'f') $('.fs').click();
    });
    // double-click left/right ±10 s + hold for 4x — the same as the other KWS players (platform.js)
    try { globalThis.KWSDblSeek && globalThis.KWSDblSeek(video, { host: cont }); } catch (_) {}
    return p;
  }

  function loadRecording(p, rec, sec, info) {
    p.rec = rec;
    p.info = info;
    p.$('.ttl').textContent = rec.streamtitle || info.title || info.channel;
    const when = String(rec.recorded_at || '').slice(0, 10);
    p.$('.sub').textContent = [rec.target_name || info.channel, when, 'StreamRecorder'].filter(Boolean).join(' · ');
    document.title = (rec.target_name || info.channel) + ' · KWS';
    const src = '/recordings/hls/' + encodeURIComponent(rec.id) + '/master.m3u8';
    const startAt = Math.max(0, sec - LEAD);
    const video = p.video;
    const Hls = globalThis.Hls;
    if (p.hls) { try { p.hls.destroy(); } catch (_) {} p.hls = null; }
    const go = () => { try { video.currentTime = startAt; } catch (_) {} video.play().catch(() => {}); };
    if (Hls && Hls.isSupported()) {
      const hls = new Hls({ enableWorker: true, startPosition: startAt, xhrSetup: (xhr) => { xhr.withCredentials = false; } });
      p.hls = hls;
      hls.on(Hls.Events.MANIFEST_PARSED, (_, data) => {
        const q = p.$('.q');
        q.replaceChildren();
        (hls.levels || []).map((l, i) => ({ i, h: l.height || 0 })).sort((a, b) => b.h - a.h).forEach(({ i, h }, k) => {
          const b = document.createElement('button');
          b.textContent = h ? h + 'p' : 'L' + i;
          if (k === 0) { b.classList.add('on'); hls.currentLevel = i; }
          b.onclick = () => { hls.currentLevel = i; q.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b)); };
          q.appendChild(b);
        });
        video.play().catch(() => {});
      });
      hls.on(Hls.Events.ERROR, (_, d) => { if (d && d.fatal) say(T('srFailed', d.details || 'error'), 'err'); });
      // master.m3u8 lives on streamrecorder.io (needs the login cookie); the parts come from its CDN
      hls.loadSource(new URL(src, location.href).href);
      hls.attachMedia(video);
    } else {
      video.src = src;
      video.addEventListener('loadedmetadata', go, { once: true });
    }
    p.cont.classList.add('show');
    setTimeout(() => p.cont.classList.remove('show'), 2500);
  }

  // fMP4 clip: start it at 0 (tfdt minus the first part's time, per track) and give it its own length
  // (mvhd / tkhd / mdhd / mehd) — otherwise players show the whole recording's length, hours in.
  function fixClip(initBuf, segBufs, lenSec) {
    const walk = (dv, start, end, fn) => {
      let o = start;
      while (o + 8 <= end) {
        let size = dv.getUint32(o);
        const type = String.fromCharCode(dv.getUint8(o + 4), dv.getUint8(o + 5), dv.getUint8(o + 6), dv.getUint8(o + 7));
        let hdr = 8;
        if (size === 1) { size = Number(dv.getBigUint64(o + 8)); hdr = 16; } else if (size === 0) size = end - o;
        if (size < hdr || o + size > end) break;
        fn(type, o, o + hdr, o + size);
        o += size;
      }
    };
    try {
      const idv = new DataView(initBuf);
      let ts = 1000;
      const setDur = (p, v1off, v0off, scale) => { const val = Math.round(lenSec * scale); if (idv.getUint8(p) === 1) idv.setBigUint64(p + v1off, BigInt(val)); else idv.setUint32(p + v0off, val >>> 0); };
      walk(idv, 0, idv.byteLength, (t, o, p, e) => {
        if (t !== 'moov') return;
        walk(idv, p, e, (t2, o2, p2, e2) => {
          if (t2 === 'mvhd') { ts = idv.getUint8(p2) === 1 ? idv.getUint32(p2 + 20) : idv.getUint32(p2 + 12); setDur(p2, 24, 16, ts); }
          else if (t2 === 'mvex') walk(idv, p2, e2, (t3, o3, p3) => { if (t3 === 'mehd') setDur(p3, 4, 4, ts); });
          else if (t2 === 'trak') walk(idv, p2, e2, (t3, o3, p3, e3) => {
            if (t3 === 'tkhd') setDur(p3, 28, 20, ts);
            else if (t3 === 'mdia') walk(idv, p3, e3, (t4, o4, p4) => { if (t4 === 'mdhd') setDur(p4, 24, 16, idv.getUint8(p4) === 1 ? idv.getUint32(p4 + 20) : idv.getUint32(p4 + 12)); });
          });
        });
      });
      const first = new Map(); // track id → first part's decode time
      for (const buf of segBufs) {
        const dv = new DataView(buf);
        walk(dv, 0, dv.byteLength, (t, o, p, e) => {
          if (t !== 'moof') return;
          walk(dv, p, e, (t2, o2, p2, e2) => {
            if (t2 !== 'traf') return;
            let track = 0;
            walk(dv, p2, e2, (t3, o3, p3) => {
              if (t3 === 'tfhd') track = dv.getUint32(p3 + 4);
              else if (t3 === 'tfdt') {
                const v = dv.getUint8(p3);
                const cur = v === 1 ? dv.getBigUint64(p3 + 4) : BigInt(dv.getUint32(p3 + 4));
                if (!first.has(track)) first.set(track, cur);
                let nv = cur - first.get(track); if (nv < 0n) nv = 0n;
                if (v === 1) dv.setBigUint64(p3 + 4, nv); else dv.setUint32(p3 + 4, Number(nv) >>> 0);
              }
            });
          });
        });
      }
    } catch (e) { console.warn('[KWS SR] clip fix skipped', e); }
  }

  // ── clip download (fMP4: init + the parts covering the range) ──
  function toggleDownload(p) {
    const old = p.cont.querySelector('.dl');
    if (old) { old.remove(); return; }
    if (!p.rec || !p.hls) return;
    const d = document.createElement('div');
    d.className = 'dl';
    const cur = Math.floor(p.video.currentTime || 0);
    d.innerHTML = `<div class="two"><div><div class="lab">Start</div><input class="s" value="${fmt(cur)}"></div><div><div class="lab">End</div><input class="e" value="${fmt(cur + 300)}"></div></div>
      <div class="two"><button class="ss">${T('srSetNow')}</button><button class="se">${T('srSetNow')}</button></div>
      <div class="grp q2"></div><button class="go">⬇ Download</button><div class="msg"></div>`;
    p.cont.appendChild(d);
    const s = d.querySelector('.s'), e = d.querySelector('.e'), msg = d.querySelector('.msg');
    d.querySelector('.ss').onclick = () => { s.value = fmt(p.video.currentTime); };
    d.querySelector('.se').onclick = () => { e.value = fmt(p.video.currentTime); };
    let level = p.hls.currentLevel >= 0 ? p.hls.currentLevel : 0;
    const q2 = d.querySelector('.q2');
    (p.hls.levels || []).forEach((l, i) => {
      const b = document.createElement('button'); b.textContent = (l.height || '?') + 'p'; if (i === level) b.classList.add('on');
      b.onclick = () => { level = i; q2.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b)); };
      q2.appendChild(b);
    });
    d.querySelector('.go').onclick = async (ev) => {
      const btn = ev.currentTarget;
      const a = pf(s.value), b = pf(e.value);
      if (!(b > a)) { msg.textContent = T('srDlRange'); return; }
      btn.disabled = true;
      try {
        const lvl = p.hls.levels[level];
        const url = (lvl && (lvl.url && (Array.isArray(lvl.url) ? lvl.url[0] : lvl.url))) || '';
        const pl = await (await fetch(url)).text();
        const base = new URL(url, location.href);
        const lines = pl.split('\n').map((x) => x.trim());
        const mapLine = lines.find((x) => x.startsWith('#EXT-X-MAP'));
        const init = mapLine && (mapLine.match(/URI="([^"]+)"/) || [])[1];
        const segs = [];
        let t = 0, first = null;
        for (let i = 0; i < lines.length; i++) {
          const m = lines[i].match(/^#EXTINF:([\d.]+)/);
          if (!m) continue;
          const dur = parseFloat(m[1]);
          const u = lines[i + 1];
          if (u && !u.startsWith('#') && t + dur > a && t < b) { segs.push(new URL(u, base).href); if (first == null) first = t; }
          t += dur;
          if (t >= b) break;
        }
        if (!segs.length) throw new Error('no parts');
        const parts = new Array(segs.length + 1);
        if (init) parts[0] = await (await fetch(new URL(init, base).href)).arrayBuffer();
        let next = 0, done = 0;
        const w = async () => { while (next < segs.length) { const k = next++; parts[k + 1] = await (await fetch(segs[k])).arrayBuffer(); done++; msg.textContent = T('srDlProgress', done, segs.length); } };
        await Promise.all([w(), w(), w(), w()]);
        if (parts[0]) fixClip(parts[0], parts.slice(1), t - (first || 0));
        const blob = new Blob(parts.filter(Boolean), { type: 'video/mp4' });
        const name = `${(p.rec.target_name || p.info.channel || 'stream').replace(/[^\w.-]+/g, '_')}_${String(p.rec.recorded_at || '').slice(0, 10)}_${fmt(a).replace(/:/g, '')}-${fmt(b).replace(/:/g, '')}.mp4`;
        const href = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = href; link.download = name; document.body.appendChild(link); link.click(); link.remove();
        setTimeout(() => URL.revokeObjectURL(href), 60000);
        msg.textContent = T('srDlDone', (blob.size / 1048576).toFixed(1));
      } catch (err) {
        msg.textContent = T('srFailed', (err && err.message) || err);
      } finally { btn.disabled = false; }
    };
  }

  // ───────────────────────── request flow ─────────────────────────
  let busy = null;
  async function handle(req) {
    const platform = req.platform || 'twitch';
    const pid = PID[platform];
    const ch = String(req.channel || '').toLowerCase().trim();
    if (!pid || !ch) return;
    // same recording already open → just seek
    if (P && P.rec && req.recId && String(P.rec.id) === String(req.recId)) { P.video.currentTime = Math.max(0, (Number(req.recOff) || 0) - LEAD); P.video.play().catch(() => {}); return; }
    if (P && P.rec && req.ts > 0 && P.info && P.info.channel === ch) {
      const start = Date.parse(String(P.rec.recorded_at || '') + 'Z');
      if (start && req.ts >= start && req.ts <= start + (Number(P.rec.duration) || 0) * 1000) { P.video.currentTime = Math.max(0, Math.round((req.ts - start) / 1000) - LEAD); P.video.play().catch(() => {}); return; }
    }
    say(T('srStepFind', ch));
    const t = await ensureTarget(ch, pid);
    say(T('srStepRec'));
    const hit = await findRecording(t.targetId, req);
    if (!hit) { say(T('srNoRec', ch), 'err'); return; }
    if (hit.rec.premium_required || hit.rec.after_adding_locked) { say(T('srLocked'), 'err'); return; }
    if (!P) P = buildPlayer();
    loadRecording(P, hit.rec, hit.sec, { channel: ch, title: req.title || '' });
    say(T('srDone'), 'ok');
  }
  function run(req) {
    const job = (busy || Promise.resolve()).then(() => handle(req)).catch((e) => say(e && e.login ? T('srLogin') : T('srFailed', (e && e.message) || e), 'err'));
    busy = job;
    return job;
  }

  try {
    chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
      if (msg && msg.type === 'KWS_SR_PLAY') { run(msg.req || {}); sendResponse({ ok: true }); }
    });
  } catch (_) {}

  const h = location.hash;
  const mSr = h.match(/kwsSR=([^&]+)/);
  if (mSr) {
    let req = null;
    const raw = decodeURIComponent(mSr[1]);
    try { req = JSON.parse(raw); } catch (_) {
      const [c, ts] = raw.split('|'); // 1.2.5.60 links: <channel>|<ms>
      req = { platform: 'twitch', channel: c, ts: Number(ts) };
    }
    try { history.replaceState(null, '', location.pathname); } catch (_) {}
    if (req) run(req);
  }
})();
