// capture.js — MediaSource 후킹 방식 VOD 캡처

const params    = new URLSearchParams(location.search);
const playerUrl = params.get('playerUrl') || '';
const startSecP = parseFloat(params.get('startSec') || '0');
const titleStr  = params.get('title') || 'VOD';
const nick      = params.get('nick') || '';
const sid       = params.get('sid') || '';
const dateStr   = params.get('dateStr') || '';

document.getElementById('vod-title').textContent = titleStr;
document.getElementById('vod-meta').textContent = (nick ? nick + ' ' : '') + (sid ? '(' + sid + ')' : '') + (dateStr ? ' · ' + dateStr : '');

// ── 시간 입력 ────────────────────────────────────────────────
function makeTime(prefix) {
  const segs = ['hh','mm','ss'].map(s => document.getElementById(prefix+'-'+s));
  let cur = -1, buf = '';
  function clamp(i,v){return Math.min(i===0?99:59,Math.max(0,v));}
  function get(i){return parseInt(segs[i].textContent)||0;}
  function set(i,v){segs[i].textContent=String(clamp(i,v)).padStart(2,'0');}
  function activate(i){segs.forEach((s,j)=>s.classList.toggle('active',j===i));cur=i;buf='';}
  segs.forEach((el,i)=>{
    el.addEventListener('mousedown',e=>{e.preventDefault();el.focus();activate(i);});
    el.setAttribute('tabindex','0');
    el.addEventListener('keydown',e=>{
      if(e.key>='0'&&e.key<='9'){e.preventDefault();buf+=e.key;set(cur,parseInt(buf.padStart(2,'0')));if(buf.length>=2){buf='';if(cur<2)activate(cur+1);}}
      else if(e.key==='Backspace'){e.preventDefault();buf=buf.slice(0,-1);if(!buf)set(cur,0);}
      else if(e.key==='Tab'||e.key===':'){e.preventDefault();if(buf){set(cur,parseInt(buf));buf='';}activate(e.shiftKey?Math.max(0,cur-1):Math.min(2,cur+1));}
      else if(e.key==='ArrowUp'){e.preventDefault();set(cur,get(cur)+1);}
      else if(e.key==='ArrowDown'){e.preventDefault();set(cur,get(cur)-1);}
    });
  });
  return {
    toSeconds(){return get(0)*3600+get(1)*60+get(2);},
    fromSeconds(s){s=Math.max(0,Math.floor(s));set(0,Math.floor(s/3600));set(1,Math.floor((s%3600)/60));set(2,s%60);}
  };
}
const startTime = makeTime('s');
const endTime   = makeTime('e');
startTime.fromSeconds(startSecP);
endTime.fromSeconds(Math.min(startSecP + 300, 99*3600));

// ── 속도 선택 ────────────────────────────────────────────────
let captureSpeed = 4;
document.querySelectorAll('.speed-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.speed-btn').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    captureSpeed = parseFloat(btn.dataset.speed);
    document.getElementById('header-speed').textContent = captureSpeed + '×';
  });
});
document.getElementById('header-speed').textContent = '4×';

// VOD fileItems 로드
let FILE_ITEMS = null, totalSecs = 0;

async function loadVodInfo() {
  try {
    const res = await chrome.runtime.sendMessage({ type: 'OPEN_VOD_TAB', playerUrl });
    if (!res?.success || !res.fileItems?.length) throw new Error(res?.error || 'Could not load VOD');
    FILE_ITEMS = res.fileItems;
    totalSecs = FILE_ITEMS.reduce((s,f) => s+(f.duration||0), 0);
    function fmt(s){s=Math.max(0,Math.floor(s));return[Math.floor(s/3600),Math.floor((s%3600)/60),s%60].map(v=>String(v).padStart(2,'0')).join(':');}
    document.getElementById('vod-meta').textContent += '  ·  Total: ' + fmt(totalSecs);
    endTime.fromSeconds(Math.min(startSecP + 300, totalSecs));
    document.getElementById('btn-capture').disabled = false;
  } catch(e) {
    document.getElementById('vod-meta').textContent = 'Error: ' + e.message;
  }
}
loadVodInfo();

// ── 캡처 ─────────────────────────────────────────────────────
let captureTabId = null, captured = [], capturing = false, endSec = 0;

document.getElementById('btn-capture').addEventListener('click', async () => {
  if (!FILE_ITEMS) return;
  const startSec = startTime.toSeconds();
  endSec = endTime.toSeconds();
  if (endSec <= startSec) { alert('End must be after start'); return; }

  const nick2 = nick, sid2 = sid, date2 = dateStr;
  function fmt(s){s=Math.max(0,Math.floor(s));return[Math.floor(s/3600),Math.floor((s%3600)/60),s%60].map(v=>String(v).padStart(2,'0')).join(':');}
  const filename = [nick2,sid2?'('+sid2+')':'',date2,'['+fmt(startSec).replace(/:/g,'-')+' - '+fmt(endSec).replace(/:/g,'-')+']'].filter(Boolean).join(' ').replace(/[\\/:*?"<>|]/g,'_')+'.mp4';

  // UI 업데이트
  document.getElementById('btn-capture').style.display = 'none';
  document.getElementById('btn-stop').style.display = 'block';
  document.getElementById('prog-wrap').style.display = 'block';
  document.getElementById('status-dot').className = 'capturing';
  capturing = true;
  captured = [];

  // background에 캡처 탭 열기 요청
  const res = await chrome.runtime.sendMessage({
    type: 'START_VOD_CAPTURE',
    playerUrl, startSec, endSec, captureSpeed, filename,
    fileItems: FILE_ITEMS
  });

  if (!res?.captureId) {
    resetUI('Failed to start capture');
    return;
  }

  const captureId = res.captureId;

  // 진행 폴링
  const poll = setInterval(async () => {
    const prog = await chrome.runtime.sendMessage({ type: 'CAPTURE_PROGRESS', captureId });
    if (!prog) return;
    if (prog.error) { clearInterval(poll); resetUI('Error: ' + prog.error); return; }
    const pct = prog.progress || 0;
    document.getElementById('bar').style.width = pct + '%';
    function fmt(s){s=Math.max(0,Math.floor(s));return[Math.floor(s/3600),Math.floor((s%3600)/60),s%60].map(v=>String(v).padStart(2,'0')).join(':');}
    document.getElementById('prog-text').textContent = fmt(Math.max(0,prog.captured||0)) + ' / ' + fmt(endSec - startSec) + '  (' + Math.round(pct) + '%)';
    if (prog.done) {
      clearInterval(poll);
      document.getElementById('bar').style.width = '100%';
      document.getElementById('prog-text').textContent = '✅ Capture complete! Saving...';
      document.getElementById('status-dot').className = 'done';
      // 저장 요청
      chrome.runtime.sendMessage({ type: 'SAVE_VOD_CAPTURE', captureId, filename });
    }
  }, 500);
});

document.getElementById('btn-stop').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'STOP_VOD_CAPTURE' });
  resetUI('Stopped');
});

function resetUI(msg) {
  capturing = false;
  document.getElementById('btn-capture').style.display = 'block';
  document.getElementById('btn-stop').style.display = 'none';
  document.getElementById('status-dot').className = '';
  document.getElementById('prog-text').textContent = msg || '';
}

// background에서 저장 완료 메시지 수신 + 자동 다운로드
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'CAPTURE_SAVED' && msg.dataUrl) {
    const a = document.createElement('a');
    a.href = msg.dataUrl;
    a.download = msg.filename;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    document.getElementById('prog-text').textContent = '✅ Saved: ' + msg.filename;
    document.getElementById('btn-capture').style.display = 'block';
    document.getElementById('btn-stop').style.display = 'none';
  }
});
