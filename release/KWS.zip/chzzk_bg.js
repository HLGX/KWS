// KWS 1.2.5.6 — CHZZK (치지직) VOD chat search, run in the background service worker.
//
// CHZZK keeps the chat of its replays and serves it in order:
//   GET api.chzzk.naver.com/service/v1/channels/{channelId}/videos?sortType=LATEST&pagingType=PAGE&page=N&size=30
//       → content.data[] { videoNo, videoTitle, publishDateAt, duration (s), channel { channelId, channelName } }
//   GET api.chzzk.naver.com/service/v1/videos/{videoNo}/chats?playerMessageTime={ms}&previousVideoChatSize=50
//       → content.videoChats[] { messageTime (epoch ms), playerMessageTime (VOD ms), content,
//                                messageTypeCode (1 chat · 30 system), profile (JSON: nickname) }
//         + content.nextPlayerMessageTime (null at the end)
// The host permission for api.chzzk.naver.com is optional: the panel asks for it on first use.

const CHZZK_API = 'https://api.chzzk.naver.com';
const CHZZK_ORIGINS = ['https://api.chzzk.naver.com/*', 'https://chzzk.naver.com/*'];
const CHZZK_REQ_CONCURRENCY = 6; // requests in flight per channel (up to 4 channels at once)

async function chzzk_hasPermission() {
  try { return await chrome.permissions.contains({ origins: CHZZK_ORIGINS }); } catch (_) { return false; }
}

async function chzzk_json(url, tries = 4) {
  let last = null;
  for (let a = 0; a < tries; a++) {
    try {
      // 1.2.5.31: a request that never answers used to hold its pool slot forever (scan stuck at N%)
      const ac = new AbortController();
      const tid = setTimeout(() => ac.abort(), 20000);
      let r;
      try { r = await fetch(url, { credentials: 'include', signal: ac.signal }); } finally { clearTimeout(tid); }
      if (r.status === 404) return { notFound: true };
      if (r.status === 429) { last = 429; await kws_sleep(2000 * (a + 1)); continue; } // slow down, then retry
      if (r.ok) { const j = await r.json(); if (j && j.content !== undefined) return j; }
      last = r.status;
    } catch (e) { last = e && e.message; }
    await kws_sleep(600 * (a + 1));
  }
  throw new Error('CHZZK API ' + (last || 'failed'));
}

// Replays of a channel, newest first, back to startMs.
async function chzzk_listVods(channelId, startMs, token) {
  const out = [];
  let channelName = '';
  for (let page = 0; page < 200; page++) {
    if (token.cancelled) break;
    const j = await chzzk_json(`${CHZZK_API}/service/v1/channels/${encodeURIComponent(channelId)}/videos?sortType=LATEST&pagingType=PAGE&page=${page}&size=30`);
    if (j.notFound) throw new Error('KWS_ID_NOT_FOUND');
    const c = j.content || {};
    const data = Array.isArray(c.data) ? c.data : [];
    let older = false;
    for (const v of data) {
      if (!channelName && v.channel && v.channel.channelName) channelName = v.channel.channelName;
      const dur = Number(v.duration) || 0;
      const endMs = Number(v.publishDateAt) || 0;
      const startAt = endMs - dur * 1000; // publishDateAt is (about) when the replay was published, after the stream
      if (startMs && endMs && endMs < startMs) { older = true; continue; }
      if (v.videoType && v.videoType !== 'REPLAY') continue;
      out.push({ videoNo: v.videoNo, title: v.videoTitle || '', durationSec: dur, startAt, endMs });
    }
    if (older || !data.length || page + 1 >= (c.totalPages || 0)) break;
  }
  return { vods: out, channelName };
}

async function chzzk_scanChannelRange({ channel, keyword, startDate, endDate, onStart, onProgress, token }) {
  const channelId = String(channel || '').trim().toLowerCase();
  if (!/^[0-9a-f]{32}$/.test(channelId)) throw new Error('KWS_CHZZK_BAD_ID');
  if (!(await chzzk_hasPermission())) throw new Error('KWS_CHZZK_PERMISSION');
  const { keywords, excludeKeywords } = kws_resolveKeywords(keyword);
  const startMs = startDate ? new Date(startDate + 'T00:00:00').getTime() : 0;
  // the channel's name first (from the channel API), so even a channel without replays gets named
  let chName = '';
  try { const cj = await chzzk_json(`${CHZZK_API}/service/v1/channels/${channelId}`, 2); if (cj.notFound) throw new Error('KWS_ID_NOT_FOUND'); chName = (cj.content && cj.content.channelName) || ''; }
  catch (e) { if (e && e.message === 'KWS_ID_NOT_FOUND') throw e; }
  const listed = await chzzk_listVods(channelId, startMs, token);
  // 1.2.5.31: oldest first, so a scan that stops part-way has searched one unbroken stretch from the
  // start — "save so far" (tab menu) can then record how far it got and the next "new VODs" scan resumes there.
  const vods = listed.vods.slice().sort((a, b) => (a.startAt || a.endMs) - (b.startAt || b.endMs));
  const channelName = chName || listed.channelName;

  onStart && onStart({
    totalDates: Math.max(1, vods.length), channel: channelId, channelName,
    keywords: keywords.map((k) => (k.substring ? '~' + k.word : k.word)), excludeKeywords,
    resolvedEndDate: endDate, totalSessions: vods.length,
  });

  // Speed (1.2.5.8): the chat API can start at any moment of a replay, so every replay is cut
  // into 15-minute slices and a small pool works through all slices of all replays at once
  // (instead of one replay page after page). Overlaps at slice edges are dropped by the seen-set.
  const SLICE_MS = 15 * 60 * 1000;
  const groups = {}; // videoNo → group
  const seenByVod = {};
  const vodStartByNo = {};
  const failedVods = new Set();
  const slices = [];
  for (const v of vods) {
    groups[v.videoNo] = { key: String(v.videoNo), date: kws_format(new Date(v.startAt || v.endMs)), displayDate: kws_format(new Date(v.startAt || v.endMs)), startAt: v.startAt, messages: [], channel: channelId, vod_title: v.title };
    seenByVod[v.videoNo] = new Set();
    const durMs = Math.max(1, v.durationSec || 0) * 1000;
    for (let from = 0; from < durMs; from += SLICE_MS) slices.push({ v, from, to: Math.min(from + SLICE_MS, durMs), last: from + SLICE_MS >= durMs });
  }
  // slices left per replay; a replay counts as searched once all its slices finished without error
  const sliceLeft = {};
  for (const sl of slices) sliceLeft[sl.v.videoNo] = (sliceLeft[sl.v.videoNo] || 0) + 1;
  // Everything before the first replay that isn't fully searched is done → "safe through" that
  // replay's start date (the next "new VODs" scan starts that day, so it's searched again from there).
  const safeThrough = () => {
    for (const v of vods) if (sliceLeft[v.videoNo] > 0 || failedVods.has(v.videoNo)) return v === vods[0] ? null : kws_format(new Date(v.startAt || v.endMs));
    return endDate || kws_format(new Date());
  };
  let matched = 0, done = 0, lastSent = 0;
  const send = (force) => {
    if (!onProgress) return;
    const now = Date.now();
    if (!force && now - lastSent < 500) return;
    lastSent = now;
    const list = Object.values(groups).filter((g) => g.messages.length)
      .sort((a, b) => (a.startAt < b.startAt ? 1 : -1))
      .map((g, i) => ({ ...g, messages: g.messages.slice().sort((x, y) => x.playback_offset - y.playback_offset), order: i }));
    onProgress({ done, total: Math.max(1, slices.length), matchedLines: matched, matchedDays: list.length, matchedGroups: list, failedChunks: failedVods.size, channel: channelId, safeThrough: safeThrough() });
  };

  function take(v, m) {
    if (m.messageTypeCode === 30 || m.userIdHash === 'SYSTEM_MESSAGE') return;
    const seen = seenByVod[v.videoNo];
    const id = m.messageTime + '|' + m.userIdHash + '|' + m.content;
    if (seen.has(id)) return;
    seen.add(id);
    const message = String(m.content || '');
    if (!message) return;
    const g = groups[v.videoNo];
    if (vodStartByNo[v.videoNo] == null && m.messageTime && m.playerMessageTime != null) {
      vodStartByNo[v.videoNo] = m.messageTime - m.playerMessageTime;
      g.startAt = vodStartByNo[v.videoNo]; g.date = g.displayDate = kws_format(new Date(g.startAt));
    }
    const lower = message.toLowerCase();
    const hits = keywords.filter(({ word, substring }) => (substring ? lower.includes(word) : kws_matchesWholeWord(lower, word))).map(({ word }) => word);
    const regexHit = kws_matchesIncludeRegex(message);
    if (!(hits.length || regexHit)) return;
    if (kws_isExcluded(message, excludeKeywords)) return;
    let nick = '?';
    try { nick = JSON.parse(m.profile || '{}').nickname || '?'; } catch (_) {}
    const sec = Math.max(0, Math.floor((Number(m.playerMessageTime) || 0) / 1000));
    const tsMs = Number(m.messageTime) || null;
    g.messages.push({
      ts: tsMs ? new Date(tsMs).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }) : '?',
      rawTs: tsMs, localDate: tsMs ? kws_format(new Date(tsMs)) : g.date,
      keywords: hits.length ? hits : ['regex'], username: nick, message,
      playback_offset: sec, playback_ts: kws_formatPlayback(sec),
      vod_id: String(v.videoNo), vod_title: v.title, vod_channel: channelId,
    });
    matched++;
  }

  async function scanSlice({ v, from, to, last }) {
    let t = from, guard = 0;
    while (!token.cancelled && guard++ < 5000) {
      const j = await chzzk_json(`${CHZZK_API}/service/v1/videos/${v.videoNo}/chats?playerMessageTime=${t}&previousVideoChatSize=50`);
      if (j.notFound) return;
      const c = j.content || {};
      for (const m of (c.videoChats || [])) take(v, m);
      send(false);
      const next = c.nextPlayerMessageTime;
      if (next == null || !(next > t)) return;
      if (!last && next >= to) return; // the next slice takes it from here
      t = next;
    }
  }

  const queue = slices.slice();
  await Promise.all(Array.from({ length: Math.min(CHZZK_REQ_CONCURRENCY, queue.length) }, async () => {
    while (queue.length && !token.cancelled) {
      const sl = queue.shift();
      let ok = false;
      try { await scanSlice(sl); ok = !token.cancelled; } catch (e) { failedVods.add(sl.v.videoNo); console.warn('[KWS CHZZK] slice', sl.v.videoNo, sl.from, e); }
      if (ok) sliceLeft[sl.v.videoNo]--;
      done++;
      send(false);
    }
  }));
  send(true); // stopped or finished: the hub marks it 'stopped' when a stop was asked
  return { failedChunks: failedVods.size, channelName };
}

// The CHZZK page badge (chzzkBadge.js) runs only once the optional permission is granted, so it
// is registered here rather than in the manifest.
async function chzzk_syncContentScript() {
  try {
    const has = await chzzk_hasPermission();
    const JS = ['hls.js', 'dlGuard.js', 'quality.js', 'platform.js', 'fab.js', 'chzzkBadge.js', 'chzzkPlayer.js']; // fab = the side-panel opener tab
    const reg = await chrome.scripting.getRegisteredContentScripts({ ids: ['kws-chzzk-badge'] });
    if (has && reg.length && JSON.stringify(reg[0].js) !== JSON.stringify(JS)) { // an older build's list
      await chrome.scripting.unregisterContentScripts({ ids: ['kws-chzzk-badge'] });
      reg.length = 0;
    }
    if (has && !reg.length) {
      await chrome.scripting.registerContentScripts([{ id: 'kws-chzzk-badge', matches: ['https://chzzk.naver.com/*'], js: JS, runAt: 'document_idle', persistAcrossSessions: true }]);
      // CHZZK tabs that are already open get it now too (a registered script only runs on new loads)
      const tabs = await chrome.tabs.query({ url: 'https://chzzk.naver.com/*' }).catch(() => []);
      for (const t of tabs) chrome.scripting.executeScript({ target: { tabId: t.id }, files: JS }).catch(() => {});
    } else if (!has && reg.length) {
      await chrome.scripting.unregisterContentScripts({ ids: ['kws-chzzk-badge'] });
    }
  } catch (e) { console.warn('[KWS CHZZK] content script', e); }
}
chzzk_syncContentScript();
try { chrome.permissions.onAdded.addListener(chzzk_syncContentScript); chrome.permissions.onRemoved.addListener(chzzk_syncContentScript); } catch (_) {}
