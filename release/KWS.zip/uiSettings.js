var is_kick = /kick\.com/.test(window.location.href);
var is_twitch = /twitch\.tv/.test(window.location.href);
var channel_settings;

var uiSettings = () => {
  return {
    background: main_background_gradient(),
    application_label: "",
    border_radius: "0.8em",
    inner_radius: "0.2em",
    header_height: 12,
    left_panel_width: 12,
    right_panel_width: 12,
    footer_height: 12,
    close_btn_px: 12,
    moveable_head: true,
    movable_left: true,
    movable_right: true,
    movable_footer: true,
    resizeable: true,
  }
}
var main_input_fields = [
  ...[
    // {
    //   placeholder: "channel_name",
    //   label: "View Highlights From Channel Name",
    //   id: "highlights_channel",
    // },
    {
      placeholder: "channel_name",
      label: "Show Recent Streams From Channel Name",
      id: "recent_streams_channel",
    },
  ],
...(is_twitch ? [
    {
      placeholder: "41084886805",
      id: "stream_id",
      label: "Find with stream ID",
    },
    {
      placeholder: dateTimeString(
        new Date(new Date().getTime() - 86400000).toString(),
      ).replace(/^\w+,\s+/, ""),
      id: "stream_start",
      label: "Find with stream start date-time",
    }] : []
  ),
  ...[
    {
      placeholder: "m3u8 link",
      input_id: "m3u8_url",
      id: "m3u8_url",
      label: "View/Download with m3u8 Link",
    }
  ]
]
/** FILTER REMOVES TWITCH FEATURES IF NOT ON TWITCH */


function getSmallestKickThumbnail(params) {
  let kick_thumbs = params?.thumbnail?.srcset?.replace(/\s\d+w/g, "")?.split(/,\s*/);
  let resolutions = kick_thumbs?.map((href) => parseInt(/\d+(?=\.webp)/.exec(href)?.[0]),);
  let smallest = Math.min(...resolutions);
  return resolutions ? kick_thumbs[resolutions.indexOf(smallest)] : "";
}
