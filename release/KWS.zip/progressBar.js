


function getArrayOfDifferences(arr){
	let diff = Math.floor(arr[1]-arr[0]);
  let left = Math.floor(arr[0]) -1;
	return diff > 0 ? Array(diff+2).fill().map((_,i)=> left+i) : [arr[0],arr[1]];
}



var unqHsh = (a,o) => a.filter(i=> o.hasOwnProperty(i) ? false : (o[i] = true));

var findDupes = (a,o) => a?.filter(i=> o.hasOwnProperty(i) ? true : (o[i] = false));




function spreadOverlappingXacrossY(params){
		var {display,block_elm}=params;
    let block_elm_rect = block_elm?.getBoundingClientRect();
    let all_displays = Array.from(cn(block_elm,'vid_time_display') || []);
    let displays_l_r_scope = all_displays?.length ? all_displays.map(r=> getArrayOfDifferences([(r.getBoundingClientRect().left-block_elm_rect.left),(r.getBoundingClientRect().right-block_elm_rect.left)])) : null;

		let marked_overlapped_displays = displays_l_r_scope?.map((rr,i)=> {
				let not_this_scope = displays_l_r_scope.filter((arr,ii)=> ii !== i);
        return {
						is_acted_elm:all_displays[i].id == display.id,
            elm:all_displays[i],
            rect:all_displays[i].getBoundingClientRect(),
            is_overlapped:rr.some(n=> not_this_scope.some(arr=> arr.some(ii=> ii===n))),
            initial_top: all_displays[i].getAttribute('data-initial_top') ? parseFloat(all_displays[i].getAttribute('data-initial_top')) : 0,
        }
    });
    let overlapped_displays = marked_overlapped_displays?.filter(r=> r.is_overlapped === true)
    let not_overlapped_displays = marked_overlapped_displays?.filter(r=> r.is_overlapped === false);
    let acted_elm = marked_overlapped_displays?.filter(r=> r.is_acted_elm === true)?.[0];

    inlineStyler(display,`{top:${parseInt(display.getAttribute('data-initial_top'))}px;}`);

    overlapped_displays?.filter(r=> r.is_acted_elm == false)?.forEach((d,i)=> {
    		let {initial_top,is_acted_elm,is_overlapped,rect,elm} = d;
    		if(is_overlapped === true && is_acted_elm === false){
						let num_non_acted = overlapped_displays?.filter(d=> d.elm.id !== display.id)?.length;
        		let offset_y =  overlapped_displays.some(d=> d.elm.id == display.id) ? (num_non_acted > 1 ? num_non_acted-1 : 1) : 0;
        		inlineStyler(elm,`{top:${initial_top+(rect.height*(i+offset_y))}px;}`);
        }
    });
    not_overlapped_displays?.forEach((d,i)=> {
    		let {initial_top,is_acted_elm,is_overlapped,rect,elm} = d;
    		if(is_overlapped === false){
        		inlineStyler(elm,`{top:${initial_top}px;}`);
        }
    });

}


function updatePlayerUI(params){
    var {ball,bar,display,left_pos,available_fragments,display_key,block_elm,valueToDisplay,displayToValue} = params;
    let bar_rect = bar.getBoundingClientRect();
  	let ball_rect = ball.getBoundingClientRect();
    let display_rect = display ? display.getBoundingClientRect() : null;
 	spreadOverlappingXacrossY({display,block_elm,valueToDisplay,displayToValue})

    let offset_allowance = (ball_rect.width/2);
    let ball_offset = offset_allowance + ball.offsetLeft;
    let percent = ball_offset/bar_rect.width;

    updateFragmentPlacement({percent,available_fragments,display_key,display,valueToDisplay,displayToValue})
    ball.style.zIndex = topZIndexer();
    display.style.zIndex = topZIndexer();
}






function updateBallRelativeToInput(params){
	var {block_elm,bar,ball,display,available_fragments,display_key,valueToDisplay,displayToValue} = params;
    var max_secs = available_fragments.at(-1).seconds.at(-1);
    var min_secs = available_fragments[0].seconds[0];
    var val = display.value;
    var secs = displayToValue(val);
    var matched = min_secs >= secs ? available_fragments[0] : max_secs <= secs ? available_fragments.at(-1) : available_fragments.filter(r=> r.seconds.some(s=> Math.floor(s) == Math.floor(secs)))?.[0]
    // console.log({matched})
    var percent = matched?.percent;
	var ball_rect = ball.getBoundingClientRect();
    var bar_rect = bar.getBoundingClientRect();
    var display_rect = display.getBoundingClientRect();
    //THIS WAS THE ISSUE => SUBSTRACT LEFT FROM RIGHT TO GET POSITION
	let left_pos = ((bar_rect.right-bar_rect.left) * (percent)) - (ball_rect.width/2);
    let ball_left = left_pos < 0 ? left_pos : left_pos > bar_rect.right ? left_pos-ball_rect.width : left_pos;
    let d_left = left_pos < 0 ? (left_pos+(display_rect.width/2)) - (ball_rect.width) : (left_pos - (display_rect.width/2));
    inlineStyler(display,`{left:${d_left}px;}`);
    inlineStyler(ball,`{left:${ball_left}px;}`);
    updateFragmentPlacement({percent,available_fragments,display_key,display,valueToDisplay,displayToValue})
}


function getNearestFragmentFromPercent(params){
    var {percent,available_fragments} = params;
    let nearest_over = available_fragments.findIndex(i=> i.percent >= percent);
    let target_fragments = available_fragments.slice(nearest_over-2,nearest_over+2);
    let diffs = target_fragments.map(p=> Math.abs(p.percent-percent));
    let nearest = percent <= 0 ? available_fragments[0] : percent >= 1 ? available_fragments.at(-1) : target_fragments[diffs.indexOf(Math.min(...diffs))];
    return nearest;
}

function updateFragmentPlacement(params){
    var {percent,available_fragments,display_key,display,valueToDisplay} = params;
  // console.log({ updateFragmentPlacement: params });
    let nearest = getNearestFragmentFromPercent(params)
    // console.log({nearest})
    display.value = valueToDisplay(nearest[display_key]);
    current_ball_positions[display.id] = nearest;
    // console.log({current_ball_positions})
}


function followTargetXPosition(params){
	var {block_elm_rect,target,follower,prev_offset,cur_offset} = params;
  var target_rect = target.getBoundingClientRect();
  var follower_rect = follower.getBoundingClientRect();
  var is_moving_left = cur_offset - prev_offset < 0;
  var is_moving_right = cur_offset - prev_offset > 0;
  var left_diff = target_rect.left-follower_rect.left
  let width_diff = follower_rect.width-target_rect.width;
  let right_diff = (width_diff-left_diff);
	if(is_moving_left && left_diff<1){
    inlineStyler(follower,`{left:${(target_rect.left)-block_elm_rect.left}px; z-index:${topZIndexer()};}`);
  }
  if(is_moving_right && right_diff<2){
    inlineStyler(follower,`{left:${((target_rect.left-follower_rect.width)+(target_rect.width))-block_elm_rect.left}px; z-index:${topZIndexer()};}`);
  }
}

function dragBall(params){
    var {ref_elm,available_fragments,display_key,block_elm,valueToDisplay,displayToValue}=params;
    var block_elm_rect = block_elm.getBoundingClientRect();
		let viewport_left_offset = 0;
    let bar_id = ref_elm.getAttribute('data-bar_id');
    let display_id = ref_elm.getAttribute('data-current_time_id');
    let bar = gi(document,bar_id);
    let ball = ref_elm;

    let display = gi(document,display_id);
    let display_rect = display.getBoundingClientRect();
		let bar_rect = bar.getBoundingClientRect();
    let ball_rect = ball.getBoundingClientRect();

    let offset_allowance = ball_rect.width/2;
		var prev_offset = ball.offsetLeft;
    ball.onmousedown = dragMouseDown;
    function dragMouseDown(e) {
        pos2 = e.clientX;
        document.onmouseup = closeDragElement;
        document.onmousemove = elementDrag;
    }
    function elementDrag(e) {
        let cur_offset = ball.offsetLeft;
				let left_pos = ((e.clientX) -(ball_rect.width))-block_elm_rect.left;
        let left_in_boundary = (left_pos+(offset_allowance)) >= 0;
        let right_in_boundary = (left_pos+(offset_allowance)) <= (bar_rect.width);

        if(left_in_boundary && right_in_boundary){
        //console.log(block_elm_rect.left,e.clientX,cur_offset,left_pos)
            inlineStyler(ball,`{left:${left_pos}px; z-index:${topZIndexer()};}`);
						followTargetXPosition({
            	block_elm_rect:block_elm_rect,
              target:ball,
              follower:display,
              prev_offset:prev_offset,
              cur_offset:cur_offset,
              valueToDisplay:valueToDisplay,
              displayToValue:displayToValue,
            });
            prev_offset = cur_offset;
            updatePlayerUI({display,ball,bar,left_pos,available_fragments,display_key,block_elm,valueToDisplay,displayToValue});
        }
    }
    function closeDragElement() {
        document.onmouseup = null;
        document.onmousemove = null;
    }
}




function getNearestBall(params){
		var {block_elm,client_x} = params;
    var balls = Array.from(cn(block_elm,'vid_control_ball')||[]);
    var ball_rects = balls.map(b=> b.getBoundingClientRect());
    let diffs = ball_rects.map(r=> Math.abs((r.left+(ball_rects[0].width/2)) - (client_x)));
    let closest = Math.min(...diffs);
    let ball = balls[diffs.indexOf(closest)];
    let other_balls = balls?.filter(b=> b.id !== ball?.id);
    if(other_balls?.length) {other_balls?.forEach(b=> b.classList.remove('active'))};
    return ball;
}

function placeBall(params){
    var {block_elm,available_fragments,display_key,client_x,valueToDisplay,displayToValue}=params;
    // console.log('placeBall');
		var block_elm_rect = block_elm.getBoundingClientRect();
		let ref_elm = getNearestBall({block_elm,client_x});
    let target_ball_rect = ref_elm.getBoundingClientRect();

    let bar_id = ref_elm.getAttribute('data-bar_id');
    let display_id = ref_elm.getAttribute('data-current_time_id');
    let bar = gi(document,bar_id);
    let ball = ref_elm;

    let display = gi(document,display_id);
    let display_rect = display.getBoundingClientRect();

    let bar_rect = bar.getBoundingClientRect();
    let ball_rect = ball.getBoundingClientRect();
		let left_pos = (client_x-ball_rect.width)-block_elm_rect.left;
		let adj_left_pos = left_pos < block_elm_rect.left ? left_pos+((display_rect.width/2)-(ball_rect.width/2)): left_pos+display_rect.width > (bar_rect.right-block_elm_rect.left) ? left_pos-((display_rect.width/2)-(ball_rect.width/3)) : left_pos;
    inlineStyler(ball,`{left:${(left_pos)}px; z-index:${topZIndexer()};}`);
    inlineStyler(display,`{left:${(adj_left_pos)}px; z-index:${topZIndexer()};}`);
    updatePlayerUI({display,ball,bar,left_pos,available_fragments,display_key,block_elm,valueToDisplay,displayToValue});
    //spreadOverlappingXacrossY({block_elm,display})

}


function buildTimePreview(params){
		var {balls,block_elm,bar,client_x,percent,available_fragments,display_key,valueToDisplay,displayToValue} = params;
    if(gi(document,'time_preview_cont')){
    		gi(document,'time_preview_cont').remove();
    }
    let bar_rect = bar.getBoundingClientRect();
    let cont = ele();
    a(cont,[['id','time_preview_cont'],['draggable','false']]);
    inlineStyler(cont,`{z-index:${topZIndexer()};position:fixed; left:${client_x-20}px; top:${bar_rect.top-(balls?.[0]?.height*0.8)}px; font-weight:700; font-size:10px;}`);
    block_elm.appendChild(cont);
    let nearest = getNearestFragmentFromPercent({percent,available_fragments,displayToValue});
    let nearest_ball = getNearestBall({balls,block_elm,client_x});
    nearest_ball.classList.add('active');
    cont.textContent = valueToDisplay(nearest[display_key]);
}


function displayFromXhover(params){
		var {bar,block_elm,available_fragments,display_key,valueToDisplay,displayToValue}=params;
    bar.onmousemove = mouseMoved;
    function mouseMoved(e) {
    		let percent = percentFromXhover({...params,...{client_x:e.clientX}});
        bar.onmouseleave = closeMovement;
        buildTimePreview({...params,...{
        	client_x:e.clientX,
          percent:percent,
          valueToDisplay:valueToDisplay,
          displayToValue:displayToValue,
        }});
    }
    function closeMovement(e){
    		if(gi(document,'time_preview_cont')){
    			gi(document,'time_preview_cont').remove();
    		}
    		bar.onmousemove = null;
        bar.onmouseleave = null;
    }

}

function percentFromXhover(params){
		var {client_x,bar,block_elm,available_fragments,balls} = params;
    let block_elm_rect = block_elm.getBoundingClientRect();
    let bar_rect = bar.getBoundingClientRect();
    var largest_ball_size = Math.max(...balls.map(r=> r.height));
    var largest_ball = balls[balls.findIndex(r=> r.height == largest_ball_size)];
    var bar_offset_left = (largest_ball.width/2);
    let left_pos = (client_x) - (block_elm_rect.left + bar_offset_left);
    let percent = left_pos/bar_rect.width;
    return percent;
}



function setBarStyle(params){
    var {balls,parent_elm,bar,bar_2,bar_height}=params;
    var parent_rect = parent_elm.getBoundingClientRect();
    var largest_ball_size = Math.max(...balls.map(r=> r.height));
    var largest_ball = balls[balls.findIndex(r=> r.height == largest_ball_size)];
    var bar_offset_top = largest_ball.height;
    var bar_offset_left = (largest_ball.width/2);
    var bar_width = (parent_rect.width-largest_ball.width);
    //${bar_width}px
  	inlineStyler(bar,`{height:${ bar_height|| 20}px; width: calc(100% - ${largest_ball.width}px); position:absolute; top:${bar_offset_top}px; left:${bar_offset_left}px;}`);
    if(bar_2){
				inlineStyler(bar_2,`{height:${ bar_height|| 20}px; width:${bar_width}px; position:absolute; top:${bar_offset_top}px; left:${bar_offset_left}px;}`);
    }
    return {bar_width,bar_offset_top,bar_offset_left}
}

function buildVideoProgressBar(params){
    var {parent_elm,total_segments,current_max_segment_avail,balls,id,display_width,display_height,display_font_size,available_fragments,display_key,bar_height,valueToDisplay,displayToValue} = params;
    var block_elm = parent_elm;
    var block_elm_rect = parent_elm.getBoundingClientRect();

    var bar = ele();
    a(bar,[['class','vid_control_bar'],['id',`${id}_vid_control_bar`],['draggable','false']]);
    parent_elm.appendChild(bar);

    var {bar_width,bar_offset_top,bar_offset_left} = setBarStyle({balls,parent_elm,bar,bar_height});
 		bar.addEventListener('mouseenter', (e)=>{
    	displayFromXhover({...{balls,bar,block_elm,available_fragments,display_key,valueToDisplay,displayToValue}})
    });
    bar.addEventListener('mousedown',(e)=>{
      placeBall({block_elm:parent_elm,available_fragments:available_fragments,display_key:display_key,client_x:e.clientX,valueToDisplay:valueToDisplay,displayToValue:displayToValue})
    })   ;
    let controls = balls.map((b,i)=>{
        let ball_offset = i==0 ? 0-(b.width/2) : i == (balls.length-1) ? ((bar_offset_left+bar_width)-b.width) : i*b.width;
        let display_offset= i==0 ? 0 : i == (balls.length-1) ? ((bar_offset_left+bar_width)-display_width) : i*(display_width-(b.width/2));
        let ball_left = i+b.width;
        let ball_top = (bar_height/2)-(b.height/2);
        let display_top = ball_top+(b.height*2);
        let display_left = ball_left;
        let ball = ele();
        bar.appendChild(ball);
        inlineStyler(ball,`{position:absolute;left:${ball_offset}px; top:${ball_top}px; width:${b.width}px;height:${b.height}px;}`);
        a(ball,[['class','vid_control_ball'],['draggable','false'],['id',`${id}_vid_control_ball_${i}`],['data-current_time_id',`${id}_vid_control_time_${i}`],['data-bar_id',`${id}_vid_control_bar`]]);
        ball.addEventListener('mouseover',()=>{
            dragBall({block_elm:parent_elm,ref_elm:ball,available_fragments:available_fragments,display_key:display_key,valueToDisplay:valueToDisplay,displayToValue:displayToValue,})
        });
        let display = ele('input');
        parent_elm.appendChild(display);
        a(display,[['id',`${id}_vid_control_time_${i}`],
        ['class','vid_time_display'],
        ['data-initial_top',((display_top))],
        ['data-initial_left',display_left],['draggable','false']])
        inlineStyler(display,`{z-index:${topZIndexer()}; color:#ffffff; position:absolute;font-size:${display_font_size}px;left:${((display_offset))}px; top:${((display_top))}px; width:${display_width}px; height:${display_height}px;}`);
        display.value = i == 0 ? valueToDisplay(available_fragments[0][display_key]) : valueToDisplay(available_fragments.at(-1)[display_key]);
        display.addEventListener('keyup',(e)=>{
            if(['Enter','Tab'].some(k=> k === e.key)){
              updateBallRelativeToInput({block_elm:parent_elm,bar:bar,available_fragments:available_fragments,display:display,ball:ball,display_key:display_key,valueToDisplay:valueToDisplay,displayToValue:displayToValue})
            }
        });
        display.addEventListener('blur',()=>{
            updateBallRelativeToInput({block_elm:parent_elm,bar:bar,available_fragments:available_fragments,display:display,ball:ball,display_key:display_key,valueToDisplay:valueToDisplay,displayToValue:displayToValue})
        });
        let left_pos = display_offset;
      	updatePlayerUI({display,ball,bar,left_pos,available_fragments,display_key,block_elm,valueToDisplay,displayToValue});
        return {ball,display}
    });
	var controls_object = {bar:bar,balls:controls.map(r=> r.ball),displays:controls.map(r=> r.display),available_fragments,display_key,block_elm,valueToDisplay,displayToValue};
    var initial_controls_bar_width = bar_width;

    (parent_elm?.parentElement || parent_elm).addEventListener('mouseenter',()=> {
        var current_controls_bar_width = bar.getBoundingClientRect().width;
        if(initial_controls_bar_width != current_controls_bar_width){
            controls.forEach((b,i)=>{
                updateBallRelativeToInput({
                    block_elm:parent_elm,
                    bar:bar,
                    available_fragments:available_fragments,
                    display:controls[i].display,
                    ball:controls[i].ball,
                    display_key:display_key,
                    valueToDisplay:valueToDisplay,
                    displayToValue:displayToValue
                })
            });
            initial_controls_bar_width = current_controls_bar_width;
        }else{
            // console.log('no change')
        }
    });
    return controls_object;
}

var current_max_segment_avail = 1876;
var fragments = Array(6080).fill().map((_,i)=> ({
	dur:((9)+rando(3)),
  path:`${i+1}.ts`
}));
var available_fragments = fragments.slice(0,current_max_segment_avail).map((p,i,rr)=> {
    let current_time = rr.slice(0,(i+1)).map(r=> r.dur).reduce((a,b)=> a+b) - p.dur;
    let seconds = Array(p.dur).fill().map((_,i)=> (current_time+i));
    return {
      ...p,
      ...{current_time,seconds}
    }
}).map((p,i,rr)=> {
		let percent = p.current_time/(rr.at(-1).current_time);
    return {
    ...p,
    ...{percent}
    }
});
/*
console.log(available_fragments.slice(0,3));
console.log(available_fragments.slice(available_fragments.length-3,available_fragments.length));
console.log(available_fragments.map(r=> r.dur).reduce((a,b)=> a+b)); */

/* var hls_video_fragment_information = {
  fragments:fragments,
  current_max_segment_avail:676,
}; */









function updateSegments(){

}

// function buildPlayerOptionsContainer(params){
// 		var {parent_elm,height,width,id} = params;
//     var cont = ele();
//     a(cont,[['id',id]])
//     parent_elm.appendChild(cont);
//     inlineStyler(cont,`{height:${height}px; width:${width ? width+'px' : 'calc(100% - 18px)'}; position:relative;}`);
// 		return {cont};
// }

/*
console.log(available_fragments.slice(0,3));
console.log(available_fragments.slice(available_fragments.length-3,available_fragments.length));
console.log(available_fragments.map(r=> r.dur).reduce((a,b)=> a+b)); */

/* var hls_video_fragment_information = {
  fragments:fragments,
  current_max_segment_avail:676,
}; */









// function updateSegments(){

// }

function buildPlayerOptionsContainer(params){
		var {parent_elm,height,width,id} = params;
    var cont = ele();
    a(cont,[['id',id]])
    parent_elm.appendChild(cont);
    inlineStyler(cont,`{height:${height}px; width:${width ? width+'px' : 'calc(100% - 18px)'}; position:relative;}`);
		return {cont};
}

var current_ball_positions = {};
// var video_player_cont = buildPlayerOptionsContainer({width:500,parent_elm:main_contaier.menu_body,height:100,id:'video_player_controls_cont'})

// var video_player_params = {
//     id:'progress',
//     parent_elm:video_player_cont.cont,
//     bar_height:6,
//     total_segments:2080,
//     current_max_segment_avail:676,
//     display_width:64,
//     display_height:14,
//     display_font_size:12,
//     display_key:'current_time',
//     available_fragments:available_fragments,
//     balls:[
//         {
//             height:22,
//             width:22
//         },
//         {
//             height:22,
//             width:22
//         },
//     ],
// 		//fn:updateSegments,
//     //valueToDisplay:parseTimeOffset,
//     //displayToValue:getTimeValueFromInputString,
// }

// buildVideoProgressBar(video_player_params)
