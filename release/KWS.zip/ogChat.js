async function initChat(params){
    var {video_elm,stream_info,stream_duration,msg_cont} = params;


    function clearAllMessages(){
        if(msg_cont) {
            Array.from(tn(msg_cont,'p')).forEach(chat=> {            chat.remove()        });
        }
    }
    function removeSiteEntryChats(){
        let site_entry_chats= Array.from(tn(msg_cont,'p'));
        if(site_entry_chats?.length) {
            let not_gen = site_entry_chats.filter(p=> p.className != 'stream-chat-message-container');
            not_gen.forEach(chat=> {            chat.remove()        })
        }
    }
    var token_params = getTokensFromCookies();
    var messages = [];

    function getRecentMessagesInMemory(){
        var msgs = messages.filter(m=> Math.ceil(m.offset_seconds) <= Math.ceil(video_elm?.currentTime))
        return msgs.reverse().slice(0,50).reverse();
    }

    async function addRecentMessages(){
        var current_time = Math.floor(video_elm?.currentTime);
        var target_offset = current_time < 1300 ? 0 : (current_time - 1300);
        var msgs = getRecentMessagesInMemory();
        if(msgs.length){
            await delay(1000);
            clearAllMessages();
            addMessagesToDOM(msgs);
        }else{
            var msgs = await getChatMessages({
              ...token_params,
              ...params,
              ...stream_info,
              ...{offset_seconds:current_time}
            });
            messages = unqKey([...messages,...msgs],'id').sort((a,b)=> a.timestamp < b.timestamp ? -1 : 0).reverse().slice(0,350).reverse();
            let recents = messages.filter(m=> Math.ceil(m.offset_seconds) <= Math.ceil(video_elm?.currentTime)).reverse().slice(0,50).reverse()
            clearAllMessages();
            addMessagesToDOM(recents);
        }
    }
    async function altRecentMessages(){
        var current_time = Math.floor(video_elm?.currentTime-1);
        var msgs = await getChatMessages({
          ...token_params,
          ...params,
          ...stream_info,
          ...{offset_seconds:current_time}
        });
      console.log({ msgs });
        messages = unqKey([...messages,...msgs],'id').sort((a,b)=> a.timestamp < b.timestamp ? -1 : 0).reverse().slice(0,350).reverse();
        let recents = messages.filter(m=> Math.ceil(m.offset_seconds) <= Math.ceil(video_elm?.currentTime)).reverse().slice(0,50).reverse()
        addMessagesToDOM(recents);
    }

    var last_vod_time = Math.floor(video_elm.currentTime);

    async function updateMesages(){
        let newmsgs = messages.filter(m=> Math.floor(m.offset_seconds) == Math.floor(video_elm.currentTime));
        if(newmsgs.length){
            // console.log(newmsgs);
            addMessagesToDOM(newmsgs);
        }else{
            if(Math.floor(video_elm.currentTime) != last_vod_time){
                altRecentMessages();
                last_vod_time = Math.floor(video_elm.currentTime)
            }
        }
    }

    // video_elm.onplay = async ()=>{
    //     await delay(1000);
        await addRecentMessages();
    // }

    video_elm.addEventListener('timeupdate',updateMesages)
    video_elm.onseeked = addRecentMessages;





    async function addMessagesToDOM(msgs){
        removeSiteEntryChats();
        let new_chats = msgs.filter(msg=> ((msg.offset_seconds)-1) < video_elm.currentTime);
        new_chats.filter(m=> m.commenter_display_name).forEach(m=> {
            var chats = Array.from(document.getElementsByClassName('stream-chat-message-container'));
            if(chats.length > 350){
                chats[0].remove();
            }
            if(!gi(document,m.id)){
                let p = ele('p');
                a(p,[['id',`${m.id}`],['class','stream-chat-message-container'],['data-offset_seconds', m.offset_seconds]]);
                inlineStyler(p,`{opacity: 1; transition: opacity 0.25s ease-in-out 0s;}`);
                msg_cont.appendChild(p)

                let timesent = ele('span');
                p.appendChild(timesent);
                inlineStyler(timesent,`{margin-top: 50%; font-size:0.66em; cursor:pointer; color:#dbdbdb; border:2px solid transparent;}`);
                a(timesent,[['data-video_offset',Math.floor(m.offset_seconds)]]);
                timesent.innerText = parseTimeOffsetColon(m.offset_seconds);
                timesent.onclick = async ()=> {
                    video_elm.currentTime = Math.floor(m.offset_seconds);
                    await delay(333);
                    addRecentMessages();
                }

                if(/moderator/.test(m.is_mod)){
                    let badge = ele('span');
                    a(badge,[['class','stream-chat-badge']]);
                    p.appendChild(badge);
                    let img = ele('img');
                    a(img,[['src','https://static-cdn.jtvnw.net/badges/v1/3267646d-33f0-4b17-b3df-f923a41db1d0/1']]);
                    inlineStyler(img,`{background-size: contain; background-repeat: no-repeat; background-position: center center; margin-right: 0.25rem; display: inline-block; vertical-align: middle; border-radius: 4px; border: 1px solid rgb(101, 75, 123); box-shadow: rgb(101, 75, 123) 0px 0px 0px 1px;}`);
                    badge.appendChild(img);
                }

                let usera = ele('a');
                p.appendChild(usera);
                a(usera,[['href',`https://twitch.tv/${m.commenter_display_name.toLowerCase()}`],['target',"_blank"],['class',"stream-chat-username-link"]]);
                let username = ele('span');
                usera.appendChild(username);
                a(username,[['class',"stream-chat-username"]]);
                inlineStyler(username,`{color: ${m.commenter_color ? m.commenter_color: 'rgb(168, 113, 73)'};}`);
                username.innerText = m.commenter_display_name;

                let msg_divider = ele('span');
                p.appendChild(msg_divider);
                a(msg_divider,[['class',"stream-chat-divider"]]);
                inlineStyler(msg_divider,`{color:#ffffff;}`);
                msg_divider.innerText = `: `;

                let msg = ele('span');
                p.appendChild(msg);
                a(msg,[['class',"stream-chat-message"]]);
                msg.innerHTML =`${m.message_body?.replace(/http(s|):\/\/\S+|\w+\.\b(co|io|net|org|biz|news|tv)\S*/g,url=> '<a href="'+url+'">'+/\w+\.\b\S*?(?=\?|$)/.exec(url)?.[0]+'</a>')}`;
                p.scrollIntoView();
            }
        })
    }
}



function parseTimeOffsetColon(s){
    // offset_seconds: 1427.737
    const timeString = (n,k)=> `${n >= 1 && n < 10 ? '0'+n.toString() : n >= 10 && n >= 1 ? n : '00'}${k}`;
    let hours = (s/3600);
    let minutes = hours.toString().replace(/\d+(?=\.)/,'');
    let seconds = 60 * parseFloat(minutes);
    let time_arr = [
        Math.floor(hours),
        Math.floor(60 * minutes),
        Math.floor(60*seconds.toString().replace(/\d+(?=\.)/,''))
    ];
    return `${timeString(time_arr[0],':')}${timeString((time_arr[1] >= 60 ? 0 : time_arr[1]),':')}${timeString((time_arr[2] >= 60 ? 0 : time_arr[2]),'')}`;
}//new version. 24 Aug 2023.-AndreB



async function getChatMessages(params){
  if(!params?.vod_id){
    let robotty_chat = await requestFromBackground({
      cmd:'getRobottyChats',
        params:{
          after:((params?.timestamp + (params?.offset_seconds * 1000)) - 1000),
          before:((params?.timestamp + (params?.offset_seconds * 1000)) + 1000),
          // limit:100,
          channel_login:params?.channel_login,
          timestamp:params?.timestamp,
        },
    });
    if(robotty_chat){
      let irc_msgs = parseIRCmessages({ messages: robotty_chat?.messages, timestamp: params?.timestamp });
      console.log({ irc_msgs });
      return irc_msgs?.length ? irc_msgs : [];
    }
  }else{
    let chat_messages = await requestFromBackground({
        cmd: 'vodChatExtraction',
        params:params,
    });
    let comments = [...parseChatMessages(chat_messages?.[1],params?.vod_id),...parseChatMessages(chat_messages?.[0],params?.vod_id)];
    return unqKey(comments?.filter(r=> r.message_body),'id');
  }
}

function parseChatMessages(d,vod_id){
    let has_next_page = d?.data?.video?.comments?.pageInfo?.hasNextPage;
    return d?.data?.video?.comments?.edges?.length ? d?.data?.video?.comments?.edges?.map(r=> {
        return {
            ...{
                cursor:r?.cursor,
                message_body:r.node?.message?.fragments?.map(m=> m.text)?.length ? r.node?.message?.fragments?.map(m=> m.text).reduce((a,b)=> a+' '+b) : '',
                id: r?.node?.id,
                vod_id: vod_id,
                offset_seconds: r?.node?.contentOffsetSeconds,
                // type: r?.node?.__typename,
                created_at: r?.node?.createdAt,
                timestamp: new Date(r?.node?.createdAt).getTime(),
                // updated_at: r?.node?.updatedAt,
                video_offset_link: `https://www.twitch.tv/videos/${vod_id}?t=${parseTimeOffsetColon(r.node?.contentOffsetSeconds)}`,
                commenter_color:r?.node?.message?.userColor,
                commenter_display_name: r?.node?.commenter?.displayName,
                commenter_id: r?.node?.commenter?.id,
                has_next_page:has_next_page,
            },
        }
    }) : [];
}

function parseIRCmessages(params){
  var {messages,timestamp}=params;
  return messages?.map(m=> {
      let data = /^.+?(?=\:\w+\!\w+\@\w+.tmi.twitch.tv PRIVMSG\s+#\w+\s+)/.exec(m)?.[0];
      let badge = /(?<=badges=)[\w\/,-]+/.exec(data)?.[0];
      let badges = badge?.split(/,/);
      let emotes = /(?<=emotes=).*?(?=;)/.exec(data)?.[0]?.split(/,/)?.filter(em=> em);

  // "badges=vip/1,subscriber/12,sub-gifter/100"
      let msg = /(?<=^.+?\:\w+\!\w+\@\w+.tmi.twitch.tv PRIVMSG\s+#\w+\s+).+/.exec(m)?.[0]?.replace(/^:/,'');
      let msg_received = /(?<=rm-received-ts=)\d+/.exec(data)?.[0];
      let offset_seconds = msg_received ? Math.round((parseInt(msg_received) - timestamp)/1000) : 0;
      // console.log(data)
      return cleanObject({
          reply_parent_user_id:/(?<=reply-thread-parent-user-id=)\d+/.exec(data)?.[0]?.replace(/\\s/g,' '),
          reply_parent_user_login:/(?<=reply-parent-user-login=).+?(?=;)/.exec(data)?.[0]?.replace(/\\s/g,' '),
          reply_parent_msg:/(?<=reply-parent-msg-body=).+?(?=;)/.exec(data)?.[0]?.replace(/\\s/g,' '),
          commenter_display_name:/(?<=[^-]display-name=)\w+/.exec(data)?.[0],
          commenter_id:/(?<=[^-]user-id=)\d+/.exec(data)?.[0],
          is_first_msg:/first-msg\/[1-9]/.test(data),
          commenter_color: /(?<=\@color\=)#\w+/.exec(data)?.[0],
          is_vip: /vip\/1/.test(badge),
          is_sub: /subscriber\/[1-9]+/.test(badge),
          is_mod: /moderator\/1/.test(badge),
          is_broadcaster: /broadcaster\/1/.test(badge),
          emotes:emotes?.length ? emotes : null,
          message_body:msg,
          badges:badges,
          offset_seconds:offset_seconds,
          id:/(?<=[^-]id=)[\w-]+(?=;)/.exec(data)?.[0],
          timestamp:msg_received,
          // data:data,
      });
  })
}
// parseIRCmessages({messages:d?.messages,timestamp:timestamp})


async function initChatViewerApp(params){
  var {msg_cont,video} = params;
  await delay(1333);
  // might change this to a listener for when video starts playing.
  initChat({
    msg_cont:msg_cont,
    stream_info:params,
    video_elm: video,
    stream_duration:video,
  })
}


function buildChatContainer(params){
  var ui_settings = uiSettings();
  let chat_viewer = buildContainer({
    ...{
      top: 1,
      left: params?.rect?.left && params?.rect?.width ? params?.rect?.left : 2,
      container_id: "tvd_chat_viewer_cont",
    },
    ...ui_settings,
    ...{header_height: 16}
  });



  if (typeof kwsEnsureInlineVodSkin === 'function') kwsEnsureInlineVodSkin();
  chat_viewer.cont?.classList?.add('kws-ios-chat-log');
  const chatLabel = document.getElementById('tvd_chat_viewer_cont_top_label');
  if (chatLabel) chatLabel.textContent = '';

  // 오른쪽 상단 X 버튼
  const chatCloseBtn = document.createElement('button');
  chatCloseBtn.className = 'kws-unified-close';
  chatCloseBtn.textContent = '✕';
  chatCloseBtn.title = 'Close';
  chatCloseBtn.style.cssText = 'position:absolute;top:12px;right:18px;z-index:10;';
  chatCloseBtn.addEventListener('click', () => { chat_viewer.cont?.remove(); });
  // cont는 이미 position:fixed — header 안에 append
  const chatHeader = document.getElementById('tvd_chat_viewer_cont_top_label')?.parentElement;
  if (chatHeader) {
    chatHeader.style.position = 'relative';
    chatHeader.appendChild(chatCloseBtn);
  } else {
    chat_viewer.cont.appendChild(chatCloseBtn);
  }
  inlineStyler(chat_viewer.menu_body, `{color:${main_app_colors()?.text};}`)
  let chat_body = ele('div');
  chat_viewer.menu_body.appendChild(chat_body);
  let tbod_offset = -((ui_settings.header_height));
  a(chat_body, [['id', 'stream-chat-messages'],['data-css',btoaJSON({height:tbod_offset,width:-4})]]);
  inlineStyler(chat_viewer.menu_body, `{padding: 10px; height:${(window.innerHeight * 0.40) + tbod_offset}px; overflow:auto;}`);

    alignChatElmToVODElm();
    initChatViewerApp({
        ...params,
        ...{msg_cont:chat_viewer.menu_body},
    });
}
function alignChatElmToVODElm(){
    let chat_header = document.getElementById('tvd_chat_viewer_cont_top_label');
    chat_header.textContent = '';
    inlineStyler(chat_header, `{text-align:right; font-size:11px; font-weight:800; color:rgba(255,255,255,.72);}`);
    let chat_elm_cont = document.getElementById('tvd_chat_viewer_cont');
    let chat_elm_menu_body = document.getElementById('tvd_chat_viewer_cont_menu_body');
    let vod_elm = document.getElementById('tvd_video_viewer');
    let menu_body = document.getElementById('tvd_video_viewer_menu_body');
    let parent_dimensions = document.getElementById('tvd_video_viewer_foot_resizer').getAttribute('data-parent_dimensions') ? atobJSON(document.getElementById('tvd_video_viewer_foot_resizer').getAttribute('data-parent_dimensions')) : null;
    chat_elm_cont?.classList?.add('kws-ios-chat-log');
    inlineStyler(chat_elm_cont,`{top:22px;left:18px;}`);
    inlineStyler(chat_elm_menu_body, `{width:${Math.max(280, Math.floor(window.innerWidth * 0.27))}px;}`);
    let main_width = Math.floor(window.innerWidth * .7);
    let mw = Math.floor(main_width - ((parent_dimensions?.left_panel_width || 0) + (parent_dimensions?.right_panel_width || 0)));
    inlineStyler(vod_elm,`{top:22px; left:${Math.round(window.innerWidth*.30)}px; width:${main_width}px;}`);
    inlineStyler(menu_body,`{top:0px; width:${mw}px;}`);
}


// initChat(params){
//     var {video_elm,stream_info,stream_duration,msg_cont}

// {
//     vod_id: "2022426018",
//     channel_login: "chudlogic",
//     timestamp: 1704371918000,
//     total_seconds: 32014.963,
// }
