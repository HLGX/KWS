// KWS side panel i18n helper.
// Language follows Chrome's UI language (chrome.i18n). Unsupported languages fall back
// to manifest "default_locale" (en). Strings live in _locales/<lang>/messages.json,
// generated from i18n/strings/*.json by tools/build_locales.py.
//
// HTML pages are NOT substituted by Chrome automatically (only manifest.json and CSS are),
// so markup carries keys and this file fills them in:
//   <span data-i18n="scanStart"></span>                  -> textContent
//   <input data-i18n-placeholder="placeholderChannel">   -> placeholder
//   <button data-i18n-aria-label="close">                -> aria-label
//   <button data-i18n-title="openAtMoment">              -> title
// Dynamic text:  t('doneSummary', 30, 37)  ->  "완료 · VOD 30개 · 히트 37건"
(function (global) {
  'use strict';

  const ATTRS = [
    ['data-i18n-placeholder', 'placeholder'],
    ['data-i18n-aria-label', 'aria-label'],
    ['data-i18n-title', 'title'],
  ];

  function t(key, ...subs) {
    const args = subs.map((s) => (s == null ? '' : String(s)));
    const msg = chrome.i18n.getMessage(key, args);
    if (!msg) {
      console.warn('[KWS i18n] missing key:', key);
      return key;
    }
    return msg;
  }

  // Fill every tagged element under root (default: whole document).
  function apply(root) {
    const scope = root || document;
    scope.querySelectorAll('[data-i18n]').forEach((el) => {
      el.textContent = t(el.getAttribute('data-i18n'));
    });
    for (const [dataAttr, target] of ATTRS) {
      scope.querySelectorAll('[' + dataAttr + ']').forEach((el) => {
        el.setAttribute(target, t(el.getAttribute(dataAttr)));
      });
    }
  }

  // Chrome's UI language, e.g. "ko", "en-US", "pt-BR", "zh-TW".
  const uiLang = (chrome.i18n.getUILanguage && chrome.i18n.getUILanguage()) || 'en';

  // Locale-aware dates and numbers (2026.10.12 in ko, 10/12/2026 in en-US, 12.10.2026 in de ...).
  const dateFmt = new Intl.DateTimeFormat(uiLang, { year: 'numeric', month: '2-digit', day: '2-digit' });
  const shortDateFmt = new Intl.DateTimeFormat(uiLang, { month: '2-digit', day: '2-digit' });
  const numFmt = new Intl.NumberFormat(uiLang);

  const formatDate = (d) => dateFmt.format(d instanceof Date ? d : new Date(d));
  const formatShortDate = (d) => shortDateFmt.format(d instanceof Date ? d : new Date(d));
  const formatNumber = (n) => numFmt.format(n);

  // "오늘" / "어제" / "N일 전" for history badges.
  function daysAgoLabel(date) {
    const days = Math.floor((Date.now() - new Date(date).getTime()) / 86400000);
    if (days <= 0) return t('histToday');
    if (days === 1) return t('histYesterday');
    return t('histDaysAgo', formatNumber(days));
  }

  function init() {
    document.documentElement.lang = uiLang;
    apply(document);
  }

  global.KWSi18n = { t, apply, init, uiLang, formatDate, formatShortDate, formatNumber, daysAgoLabel };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})(globalThis);
