// KWS 1.2.5.54 — one-click self update (side panel).
//
// An unpacked extension can't write its own files, but the side panel can write into a folder the
// user picked (File System Access, the same way the data folder works). So:
//   1. once: allow github.com (optional permission) and pick the folder KWS is loaded from
//      — checked: its manifest.json must be KWS with exactly the version that is running now
//   2. download KWS.zip from the latest GitHub release, unzip it in memory (DecompressionStream)
//      and check it really is a newer KWS
//   3. only then write every file over the folder and chrome.runtime.reload()
// Every step that needs Chrome's / the user's OK runs from the button click; when Chrome says the
// click "expired" (a dialog took too long) the caller just asks for one more click.
(function (global) {
  'use strict';
  const ZIP_URL = 'https://github.com/HLGX/KWS/releases/latest/download/KWS.zip';
  const GH_ORIGINS = ['https://github.com/*', 'https://*.githubusercontent.com/*'];
  const DIR_KEY = 'extDir';

  // ── the folder handle lives in the same IndexedDB as the data folder's ──
  function idb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open('kws-sp', 1);
      req.onupgradeneeded = () => req.result.createObjectStore('kv');
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  async function kv(key, value) {
    const db = await idb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('kv', value === undefined ? 'readonly' : 'readwrite');
      const st = tx.objectStore('kv');
      const r = value === undefined ? st.get(key) : st.put(value, key);
      r.onsuccess = () => resolve(value === undefined ? r.result : undefined);
      r.onerror = () => reject(r.error);
    });
  }

  // ── a tiny unzip (stored + deflate entries, which is all KWS.zip uses) ──
  async function inflateRaw(bytes) {
    const ds = new DecompressionStream('deflate-raw');
    const out = new Response(new Blob([bytes]).stream().pipeThrough(ds));
    return new Uint8Array(await out.arrayBuffer());
  }
  async function unzip(buf) {
    const u8 = new Uint8Array(buf);
    const dv = new DataView(buf);
    let eocd = -1;
    for (let i = u8.length - 22; i >= Math.max(0, u8.length - 65557); i--) {
      if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('not a zip file');
    const count = dv.getUint16(eocd + 10, true);
    let p = dv.getUint32(eocd + 16, true);
    const dec = new TextDecoder();
    const files = [];
    for (let n = 0; n < count; n++) {
      if (dv.getUint32(p, true) !== 0x02014b50) throw new Error('broken zip directory');
      const method = dv.getUint16(p + 10, true);
      const csize = dv.getUint32(p + 20, true);
      const nlen = dv.getUint16(p + 28, true), xlen = dv.getUint16(p + 30, true), clen = dv.getUint16(p + 32, true);
      const lho = dv.getUint32(p + 42, true);
      const name = dec.decode(u8.subarray(p + 46, p + 46 + nlen)).replace(/\\/g, '/');
      p += 46 + nlen + xlen + clen;
      if (name.endsWith('/')) continue; // folder entry
      const start = lho + 30 + dv.getUint16(lho + 26, true) + dv.getUint16(lho + 28, true);
      const raw = u8.subarray(start, start + csize);
      let data;
      if (method === 0) data = raw.slice();
      else if (method === 8) data = await inflateRaw(raw);
      else throw new Error('unsupported zip method ' + method);
      files.push({ name, data });
    }
    return files;
  }

  const verParts = (v) => String(v || '').replace(/^v/i, '').split('.').map((x) => parseInt(x, 10) || 0);
  const verCmp = (a, b) => { const x = verParts(a), y = verParts(b); for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; } return 0; };
  const mine = () => chrome.runtime.getManifest().version;

  async function readManifest(dir) {
    try {
      const fh = await dir.getFileHandle('manifest.json');
      return JSON.parse(await (await fh.getFile()).text());
    } catch (_) { return null; }
  }
  const isKws = (m) => !!(m && m.manifest_version === 3 && m.name === '__MSG_appName__' && m.side_panel && /sidepanel\.html/.test(m.side_panel.default_path || ''));

  // Errors carry a `code` the panel turns into text: perm · folder · wrongFolder · again · notNewer · net · write
  const fail = (code, extra) => Object.assign(new Error(code + (extra ? ': ' + extra : '')), { code, extra });
  const isActivation = (e) => /user activation|user gesture|transient activation|not allowed/i.test(String((e && e.message) || e)) || (e && e.name === 'SecurityError');

  async function ensureGitHub() {
    let ok = false;
    try { ok = await chrome.permissions.contains({ origins: GH_ORIGINS }); } catch (_) {}
    if (ok) return;
    try { ok = await chrome.permissions.request({ origins: GH_ORIGINS }); }
    catch (e) { throw isActivation(e) ? fail('again') : fail('perm', e.message); }
    if (!ok) throw fail('perm');
  }

  async function ensureFolder(onStep) {
    let dir = null;
    try { dir = await kv(DIR_KEY); } catch (_) {}
    if (dir) {
      let st = 'prompt';
      try { st = await dir.queryPermission({ mode: 'readwrite' }); } catch (_) {}
      if (st !== 'granted') {
        try { st = await dir.requestPermission({ mode: 'readwrite' }); }
        catch (e) { if (isActivation(e)) throw fail('again'); st = 'denied'; }
      }
      if (st === 'granted') {
        const m = await readManifest(dir);
        if (isKws(m) && m.version === mine()) return dir;
      }
      dir = null; // gone, moved, or not the running copy any more → pick again
    }
    onStep && onStep('folder');
    try { dir = await global.showDirectoryPicker({ id: 'kws-ext-folder', mode: 'readwrite' }); }
    catch (e) {
      if (e && e.name === 'AbortError') throw fail('folder');
      throw isActivation(e) ? fail('again') : fail('folder', e.message);
    }
    const m = await readManifest(dir);
    if (!isKws(m)) throw fail('wrongFolder', '');
    if (m.version !== mine()) throw fail('wrongFolder', m.version); // another copy of KWS, not the one Chrome runs
    try { await kv(DIR_KEY, dir); } catch (_) {}
    return dir;
  }

  async function writeAll(dir, files, onProgress) {
    let i = 0;
    for (const f of files) {
      const parts = f.name.split('/').filter(Boolean);
      if (!parts.length || parts.some((x) => x === '..' || x === '.')) continue;
      let d = dir;
      for (const seg of parts.slice(0, -1)) d = await d.getDirectoryHandle(seg, { create: true });
      const fh = await d.getFileHandle(parts[parts.length - 1], { create: true });
      const w = await fh.createWritable();
      await w.write(f.data);
      await w.close();
      onProgress && onProgress(++i, files.length);
    }
  }

  // onStep(step, a, b): 'perm' · 'folder' · 'download' · 'write' (a/b = done/total) · 'done'
  async function selfUpdate(onStep) {
    onStep && onStep('perm');
    await ensureGitHub();
    const dir = await ensureFolder(onStep);
    onStep && onStep('download');
    let buf;
    try {
      const r = await fetch(ZIP_URL, { cache: 'no-store' });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      buf = await r.arrayBuffer();
    } catch (e) { throw fail('net', (e && e.message) || String(e)); }
    let files;
    try { files = await unzip(buf); } catch (e) { throw fail('net', e.message); }
    const mf = files.find((f) => f.name === 'manifest.json');
    let nm = null;
    try { nm = mf && JSON.parse(new TextDecoder().decode(mf.data)); } catch (_) {}
    if (!isKws(nm)) throw fail('net', 'KWS.zip is not KWS');
    if (verCmp(nm.version, mine()) <= 0) throw fail('notNewer', nm.version);
    // manifest.json last, so a stop half-way leaves the old version number (the panel offers it again)
    const ordered = files.filter((f) => f.name !== 'manifest.json').concat([mf]);
    try { await writeAll(dir, ordered, (a, b) => onStep && onStep('write', a, b)); }
    catch (e) { throw fail('write', (e && e.message) || String(e)); }
    onStep && onStep('done', nm.version);
    setTimeout(() => chrome.runtime.reload(), 900);
    return nm.version;
  }

  global.KWSUpdater = { selfUpdate, ZIP_URL };
})(typeof globalThis !== 'undefined' ? globalThis : window);
