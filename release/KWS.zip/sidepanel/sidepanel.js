// KWS 1.2.5 side panel — transitional build.
// Platform tabs follow the active tab on platform sites and stay put on other sites (so what you
// are searching stays visible); click a tab to switch. Shows the user's real saved keywords
// (header button, text editor) and history (opens above the ID input), read straight from the
// 1.2.4 storage keys. Scans run in the background hub (scan_hub.js); this page renders them.
(async function () {
  'use strict';

  const { t, daysAgoLabel, formatNumber, formatDate } = KWSi18n;
  const P = KWSPlatform;
  const $ = (id) => document.getElementById(id);
  const root = document.documentElement;

  // ── theme: system / light / dark / hacker (PKWS-style: black + cyan) ──
  const THEME_KEY = 'kwsSpTheme';
  // 1.2.5.58: "classic" (legacy) is gone (it looked like dark) → paper + midnight. A skin is a light or
  // dark base plus its own colours (data-skin), so every light/dark rule still applies to it.
  const THEMES = ['system', 'light', 'dark', 'paper', 'midnight', 'hacker'];
  const SKIN_BASE = { paper: 'light', midnight: 'dark' };
  function applyTheme(v) {
    if (v === 'legacy') { v = 'dark'; chrome.storage.local.set({ [THEME_KEY]: 'dark' }).catch(() => {}); }
    if (v && v !== 'system' && THEMES.includes(v)) root.dataset.theme = SKIN_BASE[v] || v; else delete root.dataset.theme;
    if (SKIN_BASE[v]) root.dataset.skin = v; else delete root.dataset.skin;
    try { localStorage.setItem(THEME_KEY, v || 'system'); } catch (_) {}
  }
  try { applyTheme(localStorage.getItem(THEME_KEY)); } catch (_) {}
  chrome.storage.local.get(THEME_KEY).then((d) => applyTheme(d[THEME_KEY])).catch(() => {});
  chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && c[THEME_KEY]) applyTheme(c[THEME_KEY].newValue); });

  const KEYWORD_PROFILE_KEY = 'twitchKwsKeywordProfile';
  const WATCHED_KEYS = new Set([KEYWORD_PROFILE_KEY, ...Object.values(P.HISTORY_KEYS)]);
  const KW_CHIP_LIMIT = 12;

  const input = $('chInput');
  const histPop = $('histPop');

  const SELECTED_KEY = 'kwsSpPlatform'; // last platform shown (new key, 1.2.5)
  const PLATFORMS = ['twitch', 'kick', 'soop', 'youtube', 'chzzk'];

  let windowId = null;
  let current = null;       // the active tab: parseVodUrl(...) + tabId, or null on other sites
  let selected = null;      // platform shown in the panel (follows the page, else stays put)
  let currentHistory = {};  // history object of the selected platform (1.2.4 storage shape)
  let renderSeq = 0;
  // 1.2.6.0: StreamRecorder as a connected service (sr_bg.js · streamRecorderOpen.js): hits KWS can't
  // play open in its recording; Twitch hits always do when "srTwAlways" is on (Korea: VODs blocked).
  const SR_USE_KEY = 'kwsSrUse', SR_TW_KEY = 'kwsSrTwitchAlways';
  const srDefaultTw = /^ko/i.test(navigator.language || '');
  let srUse = false, srTwAlways = srDefaultTw, srAcct = null, klPlanSeen = null;
  chrome.storage.local.get([SR_USE_KEY, SR_TW_KEY, 'kwsSrWatch', 'kwsKickKicklogzPlan', 'kwsSrAcctSeen']).then((d) => {
    klPlanSeen = d.kwsKickKicklogzPlan || null;
    srAcct = d.kwsSrAcctSeen || null;
    srUse = typeof d[SR_USE_KEY] === 'boolean' ? d[SR_USE_KEY] : !!d.kwsSrWatch;
    srTwAlways = typeof d[SR_TW_KEY] === 'boolean' ? d[SR_TW_KEY] : srDefaultTw;
  }).catch(() => {});
  chrome.storage.onChanged.addListener((c, area) => {
    if (area !== 'local' || !(c[SR_USE_KEY] || c[SR_TW_KEY])) return;
    if (c[SR_USE_KEY]) srUse = !!c[SR_USE_KEY].newValue;
    if (c[SR_TW_KEY]) srTwAlways = !!c[SR_TW_KEY].newValue;
    bodyVer++; renderResults();
  });
  let activeIndex = -1;     // keyboard highlight in the history list
  let redDays = 14;         // history badge turns red after this many days (settings)
  // badge click: 'ask' (popup every time, default) / 'new' (always continue from the last search) / 'full' (always from the start)
  const BADGE_CLICK_KEY = 'kwsSpBadgeClick';
  let badgeClick = 'ask';
  try { chrome.storage.local.get(BADGE_CLICK_KEY).then((d) => { if (['ask', 'new', 'full'].includes(d[BADGE_CLICK_KEY])) badgeClick = d[BADGE_CLICK_KEY]; }); } catch (_) {}
  chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && c[BADGE_CLICK_KEY]) badgeClick = c[BADGE_CLICK_KEY].newValue || 'ask'; });
  try { chrome.storage.local.get('kwsSpBadgeRedDays').then((d) => { if (Number.isFinite(d.kwsSpBadgeRedDays)) { redDays = d.kwsSpBadgeRedDays; } }); } catch (_) {}
  let hub = {};             // scan hub state (chrome.storage.session kwsSpScans), see scans & results

  // Tell the background this window's panel is open (floating buttons hide while it is).
  const port = chrome.runtime.connect({ name: 'kws-sidepanel' });
  try {
    windowId = (await chrome.windows.getCurrent()).id;
    port.postMessage({ type: 'hello', windowId });
  } catch (e) {
    console.warn('[KWS SP] windows.getCurrent failed', e);
  }

  $('ytStreamsBtn').addEventListener('click', () => {
    if (current && current.ytHandle && current.tabId != null) {
      chrome.tabs.update(current.tabId, { url: 'https://www.youtube.com/' + current.ytHandle + '/streams' });
    }
  });

  // ───────────────────────── platform tabs ─────────────────────────
  const tabButtons = [...document.querySelectorAll('.ptab')];

  function selectPlatform(p, { remember = true } = {}) {
    if (!PLATFORMS.includes(p)) return;
    selected = p;
    if (remember) chrome.storage.local.set({ [SELECTED_KEY]: p }).catch(() => {});
  }

  tabButtons.forEach((b) => {
    b.addEventListener('click', () => {
      // CHZZK: ask for its one optional permission right from this click (badges, player, search)
      if (b.dataset.p === 'chzzk') { try { chrome.permissions.request({ origins: ['https://api.chzzk.naver.com/*', 'https://chzzk.naver.com/*'] }).catch(() => {}); } catch (_) {} }
      if (b.dataset.p === selected) return;
      closeHistPop();
      selectPlatform(b.dataset.p);
      render(++renderSeq);
    });
  });
  $('ptabs').addEventListener('keydown', (e) => {
    if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
    e.preventDefault();
    const i = PLATFORMS.indexOf(selected);
    const next = PLATFORMS[(i + (e.key === 'ArrowRight' ? 1 : PLATFORMS.length - 1)) % PLATFORMS.length];
    tabButtons.find((b) => b.dataset.p === next).click();
    tabButtons.find((b) => b.dataset.p === next).focus();
  });

  // ───────────────────────── active tab → view ─────────────────────────
  async function getActiveTab() {
    const query = windowId != null ? { active: true, windowId } : { active: true, currentWindow: true };
    const [tab] = await chrome.tabs.query(query);
    return tab || null;
  }

  async function sync() {
    const seq = ++renderSeq;
    let tab = null;
    try { tab = await getActiveTab(); } catch (_) {}
    if (seq !== renderSeq) return; // a newer tab switch already started
    const parsed = tab && tab.url ? P.parseVodUrl(tab.url) : null;
    current = parsed ? Object.assign(parsed, { tabId: tab.id }) : null;
    if (current) {
      // on a platform site the panel follows the page
      if (selected !== current.platform) selectPlatform(current.platform);
    } else if (!selected) {
      // other site: keep showing the last platform used
      let last = null;
      try { last = (await chrome.storage.local.get(SELECTED_KEY))[SELECTED_KEY]; } catch (_) {}
      selectPlatform(PLATFORMS.includes(last) ? last : 'twitch', { remember: false });
    }
    await render(seq);
  }

  // Is the active tab on the platform the panel is showing?
  const pageIsSelected = () => !!current && current.platform === selected;

  async function render(seq) {
    const p = selected;
    root.dataset.platform = p;
    for (const b of tabButtons) {
      const on = b.dataset.p === p;
      b.setAttribute('aria-selected', on ? 'true' : 'false');
      b.tabIndex = on ? 0 : -1;
    }
    renderPill();

    // YouTube scans only from a channel's Live tab: say so unless we are on one.
    // 1.2.5.8: YouTube takes a typed @handle like the others (the hub opens the Live tab itself)
    $('ytNote').hidden = true;
    $('ytStreamsBtn').hidden = true;

    let data = {};
    try {
      data = await chrome.storage.local.get([KEYWORD_PROFILE_KEY, P.HISTORY_KEYS[p]]);
    } catch (e) {
      console.warn('[KWS SP] storage read failed', e);
    }
    if (seq !== renderSeq) return;
    const hist = data[P.HISTORY_KEYS[p]];
    currentHistory = hist && typeof hist === 'object' ? hist : {};
    renderKeywords(data[KEYWORD_PROFILE_KEY]);
    renderHistoryList();
    updateHistoryHint();
    if (p === 'chzzk') backfillChzzkNames();
    bodyVer++;
    renderResults();
    updateGo();
  }

  function renderPill() {
    const isSoop = selected === 'soop';
    const isYt = selected === 'youtube';
    $('chLabel').textContent = t(isSoop ? 'labelStreamerId' : 'labelChannel');
    input.placeholder = t(isYt ? 'placeholderYt' : isSoop ? 'placeholderStreamerId' : selected === 'chzzk' ? 'placeholderChzzk' : 'placeholderChannel');
    input.readOnly = false;
    $('lockIcon').hidden = true;
    let pageChannel = '';
    if (pageIsSelected()) {
      if (!isYt) pageChannel = current.channel;
      else if (current.ytHandle && current.ytHandle.startsWith('@')) { try { pageChannel = decodeURIComponent(current.ytHandle); } catch (_) { pageChannel = current.ytHandle; } }
    }
    // Keep what the user typed unless the platform or the page's channel actually changed.
    const source = selected + '|' + pageChannel;
    if (input.dataset.source !== source) {
      input.value = pageChannel;
      input.dataset.source = source;
    }
    $('goBtn').setAttribute('aria-label', t(isYt ? 'scanThisChannel' : 'scanStart'));
  }

  // ───────────────────────── keywords preview (settings) ─────────────────────────
  // Profile shape (sharedKeywordEditor.js): { keyword, plus: ['word', '~contains'], minus: [...] }
  function renderKeywords(profile) {
    const box = $('kwPreview');
    box.replaceChildren();
    const plus = Array.isArray(profile && profile.plus) ? profile.plus.filter(Boolean).map(String) : [];
    const minus = Array.isArray(profile && profile.minus) ? profile.minus.filter(Boolean) : [];
    if (!plus.length) {
      $('kwSummary').textContent = t('kwDefaultActive');
      return;
    }
    const contains = plus.filter((w) => w.startsWith('~')).length;
    $('kwSummary').textContent = t('kwCounts', formatNumber(plus.length), formatNumber(plus.length - contains), formatNumber(contains))
      + (minus.length ? ' · ' + t('kwExclude') + ' ' + formatNumber(minus.length) : '');
    for (const raw of plus.slice(0, KW_CHIP_LIMIT)) {
      const isContains = raw.startsWith('~');
      const chip = document.createElement('span');
      chip.className = 'kw';
      const mode = document.createElement('span');
      mode.className = 'kw-mode';
      mode.textContent = isContains ? '≈' : '=';
      const word = document.createElement('span');
      word.textContent = raw.replace(/^~+/, '');
      chip.append(mode, word);
      box.append(chip);
    }
  }

  // ───────────────────────── history (opens above the ID input) ─────────────────────────
  // History shape: { [id]: { nickname|displayName, searchedAt|savedAt, matchedCount|matchedLines, memo, lastDate, keywords } }
  // 1.2.5.32: "!" on a history entry whose last search stopped part-way (tab menu "save progress", or
  // a stopped scan) — the range after `partial.through` hasn't been searched yet.
  function partialMark(h) {
    const m = document.createElement('span');
    m.className = 'r-partial';
    m.textContent = '!';
    m.title = h.partial && h.partial.through ? t('histPartial', h.partial.through) : t('histPartialNoDate');
    m.setAttribute('aria-label', m.title);
    return m;
  }
  function historyEntries() {
    return Object.entries(currentHistory)
      .filter(([id, h]) => h && typeof h === 'object' && !id.startsWith('_'))
      .map(([id, h]) => ({ id, h, name: h.nickname || h.displayName || id, at: h.searchedAt || h.savedAt || '' }))
      // favorites (★, 1.2.5 field `favorite`) always on top, then newest first
      .sort((a, b) => (!!b.h.favorite - !!a.h.favorite) || (a.at < b.at ? 1 : a.at > b.at ? -1 : 0));
  }

  function inputId() {
    const v = input.value.trim();
    if (selected === 'chzzk') { const m = /[0-9a-f]{32}/i.exec(v); return m ? m[0].toLowerCase() : v.toLowerCase(); } // a pasted channel URL works too
    if (selected === 'youtube') { const m = /youtube\.com\/@([^/?#\s]+)/i.exec(v); let h = m ? m[1] : v.replace(/^@/, ''); try { h = decodeURIComponent(h); } catch (_) {} return h.trim().toLowerCase(); }
    return v.replace(/^@/, '').toLowerCase();
  }

  // ID helpers above the history list ("검색 helper"): ways to get a channel ID quickly.
  const DISCOVER_URL = {
    twitch: 'https://streamrecorder.io/latest/twitch',
    kick: 'https://streamrecorder.io/latest/kick',
    soop: 'https://streamrecorder.io/latest/afreecatv',
    youtube: 'https://streamrecorder.io/latest/yt',
    chzzk: 'https://streamrecorder.io/latest/czk',
  };
  const ICON_PAGE = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="14" rx="2"/><path d="M8 21h8"/></svg>';
  const ICON_FIND = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.5 3.4-5.5 6.5-5.5"/><circle cx="17" cy="15" r="3"/><path d="M21.5 19.5l-2.3-2.3"/></svg>';
  const ICON_KWTAB = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6"/><path d="M20 20l-5-5"/></svg>';
  const ICON_KWFIND = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6"/><path d="M20 20l-5-5"/><path d="M8 10.5h5"/></svg>';
  const ICON_LINK = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/></svg>';

  function helperButton(icon, label, onPick) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'helper';
    b.tabIndex = -1;
    b.innerHTML = icon;
    const span = document.createElement('span');
    span.textContent = label;
    b.append(span);
    // mousedown so the input keeps focus (the list would close on blur first)
    b.addEventListener('mousedown', (e) => { e.preventDefault(); onPick(); });
    return b;
  }

  function renderHelpers() {
    const box = $('helpers');
    box.replaceChildren();
    if (selected !== 'youtube' && pageIsSelected() && current.channel && inputId() !== current.channel) {
      box.append(helperButton(ICON_PAGE, t('helperUsePage', current.channel), () => { input.value = current.channel; renderHistoryList(); updateGo(); }));
    }
    box.append(helperButton(ICON_FIND, discoverLabel(), () => { closeHistPop(); input.blur(); discover(); }));
    if (SCAN_SUPPORTED.has(selected) && selected !== 'youtube') { // YouTube VODs open on youtube.com itself
      box.append(helperButton(ICON_LINK, t('menuOpenUrl'), () => { closeHistPop(); input.blur(); showOpenUrl(); }));
    }
    // (1.2.5.59: the Kick-only "find channels by keyword" chip is now the find chip itself — discoverLabel())
  }

  function renderHistoryList() {
    const list = $('recentList');
    list.replaceChildren();
    activeIndex = -1;
    renderHelpers();
    const all = historyEntries();
    // Filter while typing (not on YouTube, where the input holds the page's locked channel).
    const q = inputId();
    const sourceId = (input.dataset.source || '').split('|')[1]?.replace(/^@/, '').toLowerCase() || '';
    const filtering = q && q !== sourceId;
    const shown = filtering ? all.filter((e) => e.id.toLowerCase().includes(q) || String(e.name).toLowerCase().includes(q) || String(e.h.memo || '').toLowerCase().includes(q)) : all;

    $('histCount').textContent = all.length ? formatNumber(shown.length) + (filtering ? ' / ' + formatNumber(all.length) : '') : '';
    $('recentEmpty').hidden = shown.length > 0;
    { // 1.2.5.59: bottom line — not in the history? find new ones
      const hf = $('histFind');
      hf.innerHTML = ICON_FIND;
      const l = document.createElement('span'); l.textContent = t('histFindMore', discoverLabel());
      const a = document.createElement('span'); a.className = 'hf-arrow'; a.textContent = '→';
      hf.append(l, a);
      hf.onmousedown = (ev) => ev.preventDefault();
      hf.onclick = () => { closeHistPop(); input.blur(); discover(); };
    }

    for (const { id, h, name, at } of shown) {
      const hits = Number(h.matchedCount ?? h.matchedLines ?? 0) || 0;
      const li = document.createElement('li');
      li.className = 'hrow' + (h.favorite ? ' fav' : '');
      li.dataset.id = id.toLowerCase();
      li.setAttribute('role', 'presentation');
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'row';
      btn.setAttribute('role', 'option');
      btn.dataset.id = id.toLowerCase();
      btn.setAttribute('aria-label', t('useChannel', name));
      btn.tabIndex = -1;

      const text = document.createElement('span');
      text.className = 'r-text';
      const n = document.createElement('span');
      n.className = 'r-name';
      n.textContent = name;
      // ★ favorite toggle next to the ID (kept on top of the list)
      const star = document.createElement('span');
      star.className = 'r-star' + (h.favorite ? ' on' : '');
      star.setAttribute('role', 'button');
      star.setAttribute('aria-pressed', h.favorite ? 'true' : 'false');
      star.title = t(h.favorite ? 'favRemove' : 'favAdd');
      star.setAttribute('aria-label', star.title);
      star.textContent = h.favorite ? '★' : '☆';
      star.addEventListener('mousedown', (ev) => {
        ev.preventDefault(); ev.stopPropagation(); holdPop = true;
        writeHistory((hh) => { const cur = hh[id] || {}; if (cur.favorite) { const { favorite, ...rest } = cur; hh[id] = rest; } else hh[id] = { ...cur, favorite: true }; });
      });
      const nameLine = document.createElement('span');
      nameLine.className = 'r-nameline';
      nameLine.append(n, star);
      if (h.partial) nameLine.insertBefore(partialMark(h), star);
      const sub = document.createElement('span');
      sub.className = 'r-sub';
      sub.textContent = t('histHits', formatNumber(hits));
      // memo as its own tinted pill (and an accent edge on the row) so memo'd IDs stand out when scrolling
      const memoText = String(h.memo || '').trim();
      if (memoText) {
        const sep = document.createElement('span'); sep.className = 'r-sep'; sep.textContent = ' · ';
        const memo = document.createElement('span'); memo.className = 'r-memo'; memo.textContent = t('histMemo', memoText); memo.title = memoText;
        sub.append(sep, memo);
        li.classList.add('has-memo');
      }
      text.append(nameLine, sub);
      btn.append(text);
      // mousedown (not click) so the input does not blur and close the list first
      btn.addEventListener('mousedown', (e) => { e.preventDefault(); pickHistory(id); });
      li.append(btn);
      // 1.2.4 history window tools: edit memo · delete (asks first)
      const tools = document.createElement('span');
      tools.className = 'h-tools';
      tools.append(
        rowTool(ICON_MEMO, t('histEditMemo'), () => editMemo(id, name)),
        rowTool(ICON_DEL, t('histDelete'), () => deleteEntry(id, name)));
      li.append(tools);

      if (at || h.addedFrom) {
        const days = at ? Math.floor((Date.now() - new Date(at).getTime()) / 86400000) : 0;
        // The date badge scans right away (1.2.4 behavior) with the default period / rescan choice.
        const badge = document.createElement(SCAN_SUPPORTED.has(selected) ? 'button' : 'span');
        // ≤1 day green, older than the red threshold (settings, default 14 as in 1.2.4) red, otherwise amber.
        badge.className = 'badge ' + (!at ? 'n' : days <= 1 ? 'g' : days > redDays ? 'r' : 'a');
        badge.textContent = at ? daysAgoLabel(at) : t('histNotSearched'); // 1.2.5.36: added (ranking) but never searched
        const live = hub[selected + ':' + id.toLowerCase()];
        if (live && (live.status === 'running' || live.status === 'queued')) {
          badge.className = 'badge live' + (live.status === 'queued' ? ' wait' : '');
          badge.textContent = live.status === 'queued' ? '•••' : scanPct(live) + '%';
          badge.style.setProperty('--p', (live.status === 'queued' ? 0 : Math.max(4, scanPct(live))) + '%');
        }
        if (badge.tagName === 'BUTTON') {
          badge.type = 'button';
          badge.tabIndex = -1;
          badge.setAttribute('aria-label', t('histRescanLabel', at ? daysAgoLabel(at) : t('histNotSearched')) + ' · ' + name);
          badge.addEventListener('mousedown', (e) => {
            e.preventDefault();
            // YouTube scans from the channel's Live tab: another channel opens it with autoscan (1.2.4).
            holdPop = true;
            startScanFlow(id, { badge: true }).finally(() => {
              if ($('dlgHost').hidden) { holdPop = false; input.focus({ preventScroll: true }); }
            });
          });
        }
        li.append(badge);
      }
      list.append(li);
    }
    markCurrentRow();
  }

  // No page change: like the 1.2.4 history, picking puts the channel into the input.
  // YouTube can only scan from that channel's Live tab, so (as in 1.2.4) a different channel
  // opens its Live tab in a new tab with ?kws_autoscan=1, which starts the scan there.
  // ── history management (memo / delete / clear all), as in the 1.2.4 history window ──
  const ICON_MEMO = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/></svg>';
  const ICON_DEL = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>';
  function rowTool(icon, label, onPick) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'h-tool';
    b.tabIndex = -1;
    b.innerHTML = icon;
    b.title = label;
    b.setAttribute('aria-label', label);
    b.addEventListener('mousedown', (e) => { e.preventDefault(); e.stopPropagation(); holdPop = true; onPick(); });
    return b;
  }
  async function writeHistory(mutate) {
    const key = P.HISTORY_KEYS[selected];
    const d = await chrome.storage.local.get(key);
    const hist = d[key] || {};
    mutate(hist);
    await chrome.storage.local.set({ [key]: hist });
  }
  function editMemo(id, name) {
    const cur = String((currentHistory[id] && currentHistory[id].memo) || '');
    openDialog((dlg, close) => {
      const field = document.createElement('input');
      field.type = 'text';
      field.value = cur;
      field.placeholder = t('histMemoPlaceholder');
      field.setAttribute('aria-label', t('histEditMemo'));
      const save = dlgOpt(t('dataNoteSave'), '', true, async () => {
        const v = field.value.trim();
        close();
        await writeHistory((h) => { h[id] = { ...(h[id] || {}), memo: v }; });
      });
      field.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); save.click(); } });
      dlg.append(dlgTitle(t('histEditMemo') + ' · ' + name), field, save, dlgOpt(t('cancel'), '', false, close));
      setTimeout(() => { field.focus(); field.select(); }, 0);
    });
  }
  function deleteEntry(id, name, after) {
    openDialog((dlg, close) => {
      dlg.append(dlgTitle(t('histDeleteConfirm', name)),
        dlgOpt(t('histDelete'), '', false, async () => { close(); await writeHistory((h) => { delete h[id]; }); if (after) after(); }),
        dlgOpt(t('cancel'), '', true, close));
    });
  }
  // Clears this platform's channel records; keyword/profile entries (keys starting with "_") stay.
  $('histClearBtn').addEventListener('mousedown', (ev) => {
    ev.preventDefault();
    if (!historyEntries().length) return;
    holdPop = true;
    openDialog((dlg, close) => {
      dlg.append(dlgTitle(t('histClearConfirm')),
        dlgOpt(t('histClearAll'), P.PLATFORM_NAMES ? (P.PLATFORM_NAMES[selected] || selected) : selected, false, async () => {
          close();
          await writeHistory((h) => { for (const k of Object.keys(h)) if (!k.startsWith('_')) delete h[k]; });
        }),
        dlgOpt(t('cancel'), '', true, close));
    });
  });

  function pickHistory(id) {
    input.value = id;
    closeHistPop();
    updateHistoryHint();
    updateGo();
  }

  function markCurrentRow() {
    const id = inputId();
    const rows = [...document.querySelectorAll('#recentList .hrow')];
    rows.forEach((li, i) => {
      li.classList.toggle('is-current', !!id && li.dataset.id === id);
      li.classList.toggle('is-active', i === activeIndex);
      li.querySelector('.row').setAttribute('aria-selected', i === activeIndex ? 'true' : 'false');
    });
    if (activeIndex >= 0 && rows[activeIndex]) rows[activeIndex].scrollIntoView({ block: 'nearest' });
  }

  function openHistPop() {
    renderHistoryList();
    histPop.hidden = false;
    syncScrim();
    $('histHint').hidden = true;
    input.setAttribute('aria-expanded', 'true');
  }
  // While the history / scan-options list is open, the page behind it (home card, results) fades
  // back so the list never blends into what is under it.
  function syncScrim() {
    root.classList.toggle('pop-open', !$('histPop').hidden || !$('optPop').hidden);
    // let the list grow up to just under the header (the panel's whole height above the footer)
    // …but always stop at the same line: under the result-tab area at its full height (the tab strip
    // never grows past 30vh), so the list has one fixed size and the tabs behind it stay in sight
    const hdrBottom = document.querySelector('.hdr')?.getBoundingClientRect().bottom || 0;
    const above = hdrBottom + Math.round(window.innerHeight * 0.30) + 12;
    const room = Math.max(220, Math.round($('footer').getBoundingClientRect().top - above - 8));
    $('histPop').style.maxHeight = room + 'px';
    $('histPop').style.height = room + 'px'; // one fixed size, however many entries
    $('optPop').style.maxHeight = room + 'px';
  }
  function closeHistPop() {
    histPop.hidden = true;
    syncScrim();
    input.setAttribute('aria-expanded', 'false');
    activeIndex = -1;
    markCurrentRow();
    updateHistoryHint();
  }

  input.addEventListener('focus', openHistPop);
  input.addEventListener('click', () => { if (histPop.hidden) openHistPop(); });
  // holdPop: a history badge started a scan (maybe with a dialog on top) — keep the list open so
  // several badges can be clicked in a row (multi-scan, as in 1.2.4).
  let holdPop = false;
  input.addEventListener('blur', () => { if (!holdPop) closeHistPop(); });
  input.addEventListener('input', () => {
    if (histPop.hidden) openHistPop();
    else renderHistoryList();
    updateGo();
  });
  input.addEventListener('keydown', (e) => {
    const rows = document.querySelectorAll('#recentList .hrow');
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      if (histPop.hidden) openHistPop();
      if (!rows.length) return;
      e.preventDefault();
      activeIndex = e.key === 'ArrowDown' ? Math.min(activeIndex + 1, rows.length - 1) : Math.max(activeIndex - 1, 0);
      markCurrentRow();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (!histPop.hidden && activeIndex >= 0 && rows[activeIndex]) { pickHistory(rows[activeIndex].dataset.id); return; }
      if (!$('goBtn').disabled) { closeHistPop(); startScanFlow(inputId()); }
    } else if (e.key === 'Escape') {
      if (!histPop.hidden) { e.preventDefault(); closeHistPop(); }
    }
  });

  // Same idea as renderHistoryHint() in the 1.2.4 panels: when the channel in the input is in
  // history, show when it was last scanned, with which keywords, and how many hits.
  function updateHistoryHint() {
    const el = $('histHint');
    if (!histPop.hidden) { el.hidden = true; return; }
    const id = inputId();
    const h = id && currentHistory[id];
    if (!h || typeof h !== 'object') { el.hidden = true; return; }
    let date = '';
    if (h.lastDate && /^\d{4}-\d{2}-\d{2}$/.test(h.lastDate)) date = formatDate(new Date(h.lastDate + 'T00:00:00'));
    else if (h.searchedAt || h.savedAt) date = formatDate(h.searchedAt || h.savedAt);
    const words = (Array.isArray(h.keywords) ? h.keywords : h.keywords ? [h.keywords] : [])
      .map((k) => (typeof k === 'string' ? k : (k && k.word) || '')).filter((k) => !k.startsWith('-')).map((k) => k.replace(/^~+/, '')).filter(Boolean);
    const kw = words.length ? words.slice(0, 3).join(', ') + (words.length > 3 ? ' +' + formatNumber(words.length - 3) : '') : '—';
    const hits = Number(h.matchedCount ?? h.matchedLines ?? 0) || 0;
    el.textContent = t('histHint', date || '—', kw, formatNumber(hits));
    el.title = el.textContent;
    el.hidden = false;
  }

  // ───────────────────────── keyword editor ─────────────────────────
  // Text-first: one word per line, "~word" = contains, "-word" = exclude (same notation as the
  // 1.2.4 keyword string). Saves through the 1.2.4 shared module, so the on-page panels and every
  // platform pick up the change exactly as before.
  const KW = KWSKeywords;
  const findText = $('findText');
  const exText = $('exText');
  let baseline = '';

  function defaultLists() {
    const ed = window.KWSSharedKeywordEditor;
    if (!ed || !Array.isArray(ed.GROUPS)) return { plus: [], minus: [] };
    const plus = ed.GROUPS.flatMap((g) => g.kws.map((w) => (g.sub ? '~' : '') + w));
    const r = KW.parseKeywordText(plus.join('\n'), (ed.EXCLUDES || []).join('\n'));
    return { plus: r.plus, minus: r.minus };
  }
  const canon = (r) => JSON.stringify([r.plus, r.minus]);
  const parseBoxes = () => KW.parseKeywordText(findText.value, exText.value);
  const isDirty = () => canon(parseBoxes()) !== baseline;

  function setStatus(key, ok) {
    const el = $('kwStatus');
    el.textContent = t(key);
    el.classList.toggle('ok', !!ok);
  }

  function updateEditorMeta() {
    const r = parseBoxes();
    $('findMeta').textContent = r.plus.length ? t('kwCounts', formatNumber(r.plus.length), formatNumber(r.exact), formatNumber(r.contains)) : '';
    $('chipMeta').textContent = $('findMeta').textContent;
    $('exMeta').textContent = r.minus.length ? formatNumber(r.minus.length) : '';
    $('kwSaveBtn').disabled = r.plus.length === 0;
    if (!r.plus.length) setStatus('kwNeedOne', false);
    else if (!$('kwStatus').classList.contains('ok') || isDirty()) setStatus('kwSavedAll', false);
  }

  // Rewrite both boxes in clean form (after paste / on leaving a box) and say what was tidied.
  function tidy() {
    const r = parseBoxes();
    const f = KW.plusToText(r.plus);
    const e = KW.minusToText(r.minus);
    const norm = (s) => s.replace(/\r\n?/g, '\n').trim();
    if (norm(findText.value) !== f) findText.value = f;
    if (norm(exText.value) !== e) exText.value = e;
    const notes = [];
    if (r.duplicates) notes.push(t('kwDupes', formatNumber(r.duplicates)));
    if (r.movedToExclude) notes.push(t('kwMoved', formatNumber(r.movedToExclude)));
    $('tidyNote').textContent = notes.join(' · ');
    $('tidyNote').hidden = notes.length === 0;
    updateEditorMeta();
  }

  async function openEditor() {
    closeHistPop();
    let data = {};
    try { data = await chrome.storage.local.get([KEYWORD_PROFILE_KEY, 'kwsKeyword']); } catch (_) {}
    const lists = KW.fromStored(data[KEYWORD_PROFILE_KEY], data.kwsKeyword) || defaultLists();
    findText.value = KW.plusToText(lists.plus);
    exText.value = KW.minusToText(lists.minus);
    baseline = canon(parseBoxes());
    $('tidyNote').hidden = true;
    $('unsavedBar').hidden = true;
    setStatus('kwSavedAll', false);
    $('viewKwEdit').hidden = false;
    let view = 'chips';
    try { view = (await chrome.storage.local.get(KW_VIEW_KEY))[KW_VIEW_KEY] || 'chips'; } catch (_) {}
    setKwView(view === 'text' ? 'text' : 'chips', false);
    updateEditorMeta();
  }

  function closeEditor() {
    $('viewKwEdit').hidden = true;
    $('unsavedBar').hidden = true;
    $('openKwEditor').focus();
  }

  // ── chip view (like the 1.2.4 editor): tap =/≈ to switch, × to remove, add box below.
  // The text box stays the single source of truth; chips just edit its lines.
  const KW_VIEW_KEY = 'kwsSpKwView';
  let kwView = 'chips';

  function setKwView(v, remember = true) {
    if (kwView === 'text' && v === 'chips') tidy();
    kwView = v;
    for (const b of document.querySelectorAll('#kwViewSeg button')) b.setAttribute('aria-selected', b.dataset.v === v ? 'true' : 'false');
    $('chipView').hidden = v !== 'chips';
    $('textView').hidden = v !== 'text';
    $('kwTextHelp').hidden = v !== 'text';
    if (v === 'chips') { renderChips(); $('kwAddInput').focus(); }
    else { findText.focus(); findText.setSelectionRange(0, 0); findText.scrollTop = 0; }
    if (remember) chrome.storage.local.set({ [KW_VIEW_KEY]: v }).catch(() => {});
  }
  for (const b of document.querySelectorAll('#kwViewSeg button')) b.addEventListener('click', () => setKwView(b.dataset.v));

  function setPlus(plus) {
    findText.value = KW.plusToText(plus);
    $('unsavedBar').hidden = true;
    updateEditorMeta();
    renderChips();
  }

  function renderChips() {
    const area = $('chipArea');
    const keepScroll = area.scrollTop;
    area.replaceChildren();
    const plus = parseBoxes().plus;
    plus.forEach((raw, i) => {
      const contains = raw.startsWith('~');
      const word = raw.replace(/^~+/, '');
      const chip = document.createElement('span');
      chip.className = 'echip' + (contains ? ' contains' : '');
      const m = document.createElement('button');
      m.type = 'button';
      m.className = 'm';
      m.textContent = contains ? '≈' : '=';
      m.setAttribute('aria-label', word + ' · ' + t(contains ? 'kwModeContains' : 'kwModeExact'));
      m.addEventListener('click', () => {
        const next = parseBoxes().plus.slice();
        next[i] = contains ? word : '~' + word;
        setPlus(next);
      });
      const w = document.createElement('span');
      w.className = 'w';
      w.textContent = word;
      const x = document.createElement('button');
      x.type = 'button';
      x.className = 'x';
      x.setAttribute('aria-label', t('removeWord', word));
      x.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M7 7l10 10M17 7L7 17"/></svg>';
      x.addEventListener('click', () => {
        const next = parseBoxes().plus.slice();
        next.splice(i, 1);
        setPlus(next);
      });
      chip.append(m, w, x);
      area.append(chip);
    });
    area.scrollTop = keepScroll;
  }

  // Add one or many words (typed or pasted). forceContains: the ≈ button.
  function addWords(text, forceContains) {
    const r = KW.parseKeywordText(text, '');
    if (!r.plus.length && !r.minus.length) return;
    const add = r.plus.map((w) => (forceContains && !w.startsWith('~') ? '~' + w : w));
    findText.value = [findText.value, ...add].filter(Boolean).join('\n');
    if (r.minus.length) exText.value = [exText.value, ...r.minus].filter(Boolean).join('\n');
    tidy();
    renderChips();
    const area = $('chipArea');
    area.scrollTop = area.scrollHeight;
  }
  const addInput = $('kwAddInput');
  addInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); addWords(addInput.value, false); addInput.value = ''; }
  });
  // A one-line input drops line breaks from pasted text, so read the clipboard ourselves:
  // a pasted Notepad list (or "a, ~b, -c") is added as separate words straight away.
  addInput.addEventListener('paste', (e) => {
    const text = e.clipboardData ? e.clipboardData.getData('text') : '';
    if (!/[\r\n,\t;，、；]/.test(text)) return; // a single word: let it paste normally
    e.preventDefault();
    addWords(addInput.value + '\n' + text, false);
    addInput.value = '';
  });
  $('kwAddExactBtn').addEventListener('click', () => { addWords(addInput.value, false); addInput.value = ''; addInput.focus(); });
  $('kwAddContainsBtn').addEventListener('click', () => { addWords(addInput.value, true); addInput.value = ''; addInput.focus(); });

  function tryClose() {
    if (isDirty()) { $('unsavedBar').hidden = false; return; }
    closeEditor();
  }

  async function saveKeywords() {
    tidy();
    const r = parseBoxes();
    if (!r.plus.length) return false;
    const ed = window.KWSSharedKeywordEditor;
    const val = KW.toKeywordString(r.plus, r.minus);
    const profile = { keyword: val, plus: r.plus, minus: r.minus, savedAt: new Date().toISOString() };
    try {
      await ed.saveToAllPlatforms(val, profile);
    } catch (e) {
      console.error('[KWS SP] keyword save failed', e);
      return false;
    }
    baseline = canon(r);
    $('unsavedBar').hidden = true;
    setStatus('kwSaved', true);
    return true;
  }

  async function copyAll() {
    const r = parseBoxes();
    const text = KW.toCopyText(r.plus, r.minus);
    try {
      await navigator.clipboard.writeText(text);
    } catch (_) {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.append(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    }
    const label = $('kwCopyBtn').querySelector('span');
    label.textContent = t('kwCopied');
    clearTimeout(copyAll.timer);
    copyAll.timer = setTimeout(() => { label.textContent = t('kwCopyAll'); }, 1600);
  }

  $('openKwEditor').addEventListener('click', openEditor);
  $('kwBackBtn').addEventListener('click', tryClose);
  $('discardBtn').addEventListener('click', closeEditor);
  $('unsavedSaveBtn').addEventListener('click', async () => { if (await saveKeywords()) closeEditor(); });
  $('kwSaveBtn').addEventListener('click', saveKeywords);
  $('kwCopyBtn').addEventListener('click', copyAll);
  $('kwResetBtn').addEventListener('click', () => {
    const d = defaultLists();
    findText.value = KW.plusToText(d.plus);
    exText.value = KW.minusToText(d.minus);
    $('tidyNote').hidden = true;
    updateEditorMeta();
    if (kwView === 'chips') renderChips();
  });
  for (const box of [findText, exText]) {
    box.addEventListener('input', () => { $('unsavedBar').hidden = true; updateEditorMeta(); });
    box.addEventListener('paste', () => setTimeout(tidy, 0));
    box.addEventListener('blur', tidy);
  }
  $('viewKwEdit').addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); tryClose(); }
    if (e.key === 's' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); saveKeywords(); }
  });


  // ───────────────────────── settings ─────────────────────────
  // Writes the same storage keys the 1.2.4 panels read, so both stay in sync during the move.
  // Red badge threshold (1.2.5): history badges turn red after this many days without a search.
  // (Scans themselves now cover every VOD the platform still has; "new VODs only" is the popup's job.)
  const RANGE_KEY = 'kwsSpBadgeRedDays';
  const RANGE_OPTIONS = [7, 14, 30, 60, 90];
  const RANGE_DEFAULT = 14; // 1.2.4
  // 1.2.5.20: two modes only (Native-only / Zonian-only dropped; old picks map to fast / accurate)
  const LOG_SOURCES = [
    ['combined_fast', 'Combined (Fast)', 'srcCombinedFastDesc'],
    ['combined', 'Combined (Accurate)', 'srcCombinedDesc'],
  ];
  const twitchSourceOf = (v) => (v === 'combined' || v === 'twitch' ? 'combined' : 'combined_fast');
  // Kick: the same two modes (engine: background.js kick_getLogSource)
  const KICK_SOURCE_KEY = 'kwsKickLogSource';
  const KICK_LOG_SOURCES = [
    ['combined_fast', 'Combined (Fast)', 'kickSrcFastDesc'],
    ['combined', 'Combined (Accurate)', 'kickSrcAccurateDesc'],
  ];
  const kickSourceOf = (v) => (v === 'combined_fast' || v === 'kicklogz' ? 'combined_fast' : 'combined');
  const SOOP_MODES = [['api', 'Native API', 'soopNativeDesc'], ['tab', null, 'soopLegacyDesc']];
  const AUTO_CLOSE_KEYS = ['kwsAutoCloseNoResult', 'kickKwsAutoCloseNoResult', 'soopAutoCloseNoResult'];
  const TRANSLATE_KEY = 'kwsSpTranslateLang'; // 1.2.4 kept this per site in page localStorage
  const TRANSLATE_LANGS = [['en', 'English'], ['ko', '한국어'], ['ja', '日本語'], ['zh-CN', '中文'], ['es', 'Español'], ['ru', 'Русский'], ['de', 'Deutsch'], ['fr', 'Français'], ['pt', 'Português'], ['id', 'Bahasa Indonesia'], ['th', 'ไทย'], ['vi', 'Tiếng Việt']];

  function defaultTranslateLang() {
    const l = String(KWSi18n.uiLang || 'en').toLowerCase();
    if (l.startsWith('zh')) return 'zh-CN';
    const two = l.slice(0, 2);
    return TRANSLATE_LANGS.some(([v]) => v === two) ? two : 'en';
  }

  function radioRow(name, value, title, desc, checked, onPick) {
    const row = document.createElement('label');
    row.className = 'srow';
    const main = document.createElement('span');
    main.className = 'srow-main';
    const tt = document.createElement('span');
    tt.className = 'srow-title';
    tt.textContent = title;
    const sub = document.createElement('span');
    sub.className = 'srow-sub';
    sub.textContent = desc;
    main.append(tt, sub);
    const r = document.createElement('input');
    r.type = 'radio';
    r.name = name;
    r.value = value;
    r.checked = checked;
    r.addEventListener('change', () => { if (r.checked) onPick(value); });
    row.append(main, r);
    return row;
  }

  function setDataStatus(text, kind) {
    const el = $('dataStatus');
    el.textContent = text || '';
    el.classList.toggle('ok', kind === 'ok');
    el.classList.toggle('err', kind === 'err');
  }

  // ── 1.2.5.20 overnight mode (engine: overnight_bg.js) ──
  const OV_KEY = 'kwsOvernight';
  const OV_PREFS_KEY = 'kwsOvPrefs';
  const OV_NAMES = { kick: 'Kick', twitch: 'Twitch', soop: 'SOOP', youtube: 'YouTube', chzzk: 'CHZZK' };
  const OV_DAYS = [0, 7, 14, 30];
  let ovState = null;
  let ovReleasing = false;
  let ovReleaseProg = null; // { phase, done, total } from overnight_bg.js (session kwsOvRelease)
  function ovSettingsInit(d) {
    const prefs = d[OV_PREFS_KEY] || {};
    const red = Number.isFinite(d[RANGE_KEY]) ? d[RANGE_KEY] : 14;
    const days = OV_DAYS.includes(prefs.days) ? prefs.days : (OV_DAYS.includes(red) ? red : 14);
    $('ovPlatform').value = OV_NAMES[prefs.platform] ? prefs.platform : (OV_NAMES[selected] ? selected : 'kick');
    $('ovTarget').replaceChildren(...OV_DAYS.map((n) => new Option(n ? t('ovTargetDays', formatNumber(n)) : t('ovTargetAll'), String(n))));
    $('ovTarget').value = String(days);
    $('ovMode').replaceChildren(new Option(t('ovModeNew'), 'new'), new Option(t('ovModeFull'), 'full'));
    $('ovMode').value = prefs.mode === 'full' ? 'full' : 'new';
    ovUpdateCount();
  }
  function ovPrefs() { return { platform: $('ovPlatform').value, days: Number($('ovTarget').value) || 0, mode: $('ovMode').value === 'full' ? 'full' : 'new' }; }
  let ovCountSeq = 0;
  async function ovUpdateCount() {
    const p = ovPrefs();
    const seq = ++ovCountSeq;
    const r = await send({ type: 'KWS_OV_COUNT', platform: p.platform, olderThanDays: p.days });
    if (seq !== ovCountSeq) return;
    if (!r || !r.ok) { // say why instead of a silent "0 channels"
      $('ovCount').textContent = t('scanError', (r && (r.error || r.reason)) || '?');
      $('ovStartBtn').disabled = true;
      return;
    }
    const n = r.count || 0;
    $('ovCount').textContent = t('ovCount', formatNumber(n));
    $('ovStartBtn').disabled = !n;
  }
  function renderOvernight() {
    const veil = $('ovVeil');
    const st = ovState;
    if (!st || !st.active) { veil.hidden = true; return; }
    veil.hidden = false;
    veil.dataset.platform = st.platform;
    if (ovReleasing || st.releasing) { // stopping the running channels and writing the history can take a moment
      const rp = ovReleaseProg || {};
      $('ovVeilTitle').textContent = t('ovReleasing');
      $('ovVeilProg').textContent = rp.total ? t('ovReleasingProg', formatNumber(rp.done || 0), formatNumber(rp.total)) : t('ovReleasingDesc');
      $('ovVeilProg').title = '';
      $('ovVeilFill').style.width = (rp.total ? Math.min(100, Math.round((rp.done || 0) / rp.total * 100)) : 0) + '%';
      $('ovVeilCur').textContent = rp.total ? t('ovReleasingDesc') : '';
      $('ovReleaseBtn').textContent = t('ovReleasing');
      $('ovReleaseBtn').disabled = true;
      return;
    }
    $('ovReleaseBtn').disabled = false;
    const res = Object.values(st.results || {});
    const done = res.length;
    // finished channels + the ones still scanning (live, from the scan hub)
    const hits = res.reduce((n, r) => n + (r.matchedLines || 0), 0)
      + (st.running || []).reduce((n, ch) => { const e = hub[st.platform + ':' + ch]; return n + ((e && e.matchedLines) || 0); }, 0);
    const errs = res.filter((r) => r.status === 'error').length;
    $('ovVeilTitle').textContent = (st.finished ? t('ovDone') : t('ovRunning')) + ' · ' + (OV_NAMES[st.platform] || st.platform)
      + ' · ' + (st.mode === 'full' ? t('ovModeFull') : t('ovModeNew'));
    $('ovVeilProg').textContent = t('ovProgress', formatNumber(done), formatNumber(st.total || 0), formatNumber(hits)) + (errs ? ' · ' + t('ovErrors', formatNumber(errs)) : '');
    // why they failed (hover): "ID not found ×9 · …" — same wording as a failed normal scan
    const why = {};
    res.forEach((r) => { if (r.status === 'error' || r.status === 'skipped') { const k = errorText(r.error); why[k] = (why[k] || 0) + 1; } });
    $('ovVeilProg').title = Object.entries(why).sort((x, y) => y[1] - x[1]).map(([k, n]) => k + ' ×' + formatNumber(n)).join('\n');
    $('ovVeilFill').style.width = (st.total ? Math.min(100, Math.round(done / st.total * 100)) : 0) + '%';
    const cur = (st.running || []).map((ch) => {
      const e = hub[st.platform + ':' + ch];
      const pct = e && e.total ? Math.min(100, Math.round((e.done || 0) / e.total * 100)) : 0;
      return ch + ' ' + pct + '%';
    });
    $('ovVeilCur').textContent = !st.finished && cur.length ? t('ovCurrent', cur.join(' · ')) : '';
    $('ovReleaseBtn').textContent = st.finished ? t('ovReleaseDone') : t('ovRelease');
  }
  async function ovDoRelease() {
    if (ovReleasing) return;
    ovReleasing = true;
    renderOvernight();
    const r = await send({ type: 'KWS_OV_RELEASE' });
    ovReleasing = false;
    if (!r || !r.ok) { renderOvernight(); toast(t('scanError', (r && (r.error || r.reason)) || '?')); return; }
    ovState = null;
    renderOvernight();
    if (r.platform && r.platform !== selected) { selectPlatform(r.platform); render(++renderSeq); }
    toast(t('ovReleased', formatNumber(r.shown || 0)));
  }
  $('ovReleaseBtn').addEventListener('click', () => {
    if (ovState && !ovState.finished) {
      // mid-run: the channels still scanning are dropped (their history stays, so they come up again)
      openDialog((dlg, close) => {
        dlg.append(dlgTitle(t('ovRelease')), dlgText(t('ovReleaseAsk')),
          dlgOpt(t('ovRelease'), '', true, () => { close(); ovDoRelease(); }),
          dlgOpt(t('cancel'), '', false, close));
      });
      return;
    }
    ovDoRelease();
  });
  ['ovPlatform', 'ovTarget', 'ovMode'].forEach((id) => $(id).addEventListener('change', () => {
    chrome.storage.local.set({ [OV_PREFS_KEY]: ovPrefs() }).catch(() => {});
    ovUpdateCount();
  }));
  $('ovStartBtn').addEventListener('click', async () => {
    const p = ovPrefs();
    if (p.platform === 'kick' && !(await klGate())) return;
    $('ovStartBtn').disabled = true;
    const r = await send({ type: 'KWS_OV_START', platform: p.platform, olderThanDays: p.days, mode: p.mode });
    $('ovStartBtn').disabled = false;
    if (r && r.ok) { closeSettings(); return; }
    toast(r && r.reason === 'empty' ? t('ovNoTarget') : t('scanError', (r && (r.error || r.reason)) || '?'));
  });
  chrome.storage.onChanged.addListener((c, area) => {
    if (area === 'local' && c[OV_KEY]) { ovState = c[OV_KEY].newValue || null; renderOvernight(); }
    else if (area === 'session' && c.kwsOvRelease) { ovReleaseProg = c.kwsOvRelease.newValue || null; renderOvernight(); }
    else if (area === 'session' && c.kwsSpScans && ovState && ovState.active) setTimeout(renderOvernight, 0);
  });
  chrome.storage.local.get(OV_KEY).then((d) => { ovState = d[OV_KEY] || null; renderOvernight(); }).catch(() => {});

  const KICKLOGZ_KEY = 'kwsKickKicklogz';
  const KICKLOGZ_PLAN_KEY = 'kwsKickKicklogzPlan';
  const KICKLOGZ_ORIGINS = ['https://kicklogz.com/*'];
  async function openSettings() {
    closeHistPop();
    loadDataStatus();
    const keys = [KEYWORD_PROFILE_KEY, RANGE_KEY, BADGE_CLICK_KEY, 'kwsLogSource', 'soopFetchMode', 'soopSearchSubtitles', KICKLOGZ_KEY, KICK_SOURCE_KEY, KICKLOGZ_PLAN_KEY, OV_PREFS_KEY, TRANSLATE_KEY, ...AUTO_CLOSE_KEYS];
    let d = {};
    try { d = await chrome.storage.local.get(keys); } catch (_) {}

    renderKeywords(d[KEYWORD_PROFILE_KEY]);

    const range = Number.isFinite(d[RANGE_KEY]) ? d[RANGE_KEY] : RANGE_DEFAULT;
    const curTheme = root.dataset.skin || root.dataset.theme || 'system';
    const tseg = $('themeSeg');
    // 1.2.5.58: swatch cards (background · accent bar · two text lines), 3 per row
    const SW = {
      system: ['linear-gradient(135deg,#FFFFFF 50%,#131314 50%)', '#80868B', '#9AA0A6'],
      light: ['#FFFFFF', '#2563EB', '#1F1F1F'],
      dark: ['#131314', '#60A5FA', '#E3E3E3'],
      paper: ['#F6EFDF', '#A0522D', '#3B2F22'],
      midnight: ['#0F1A2E', '#8AB4F8', '#DCE6F5'],
      hacker: ['#000000', '#00E5FF', '#00E5FF'],
    };
    tseg.replaceChildren(...THEMES.map((v) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'theme-sw';
      b.setAttribute('role', 'radio');
      b.setAttribute('aria-checked', v === curTheme ? 'true' : 'false');
      b.dataset.v = v;
      const [bg, ac, tx] = SW[v];
      const pv = document.createElement('span');
      pv.className = 'sw-prev';
      pv.style.background = bg;
      pv.innerHTML = `<i style="background:${ac}"></i><b style="background:${tx}"></b><b style="background:${tx};width:38%"></b>`;
      const nm = document.createElement('span');
      nm.className = 'sw-name';
      nm.textContent = t('theme_' + v);
      b.append(pv, nm);
      b.addEventListener('click', () => {
        for (const o of tseg.children) o.setAttribute('aria-checked', o === b ? 'true' : 'false');
        applyTheme(v);
        chrome.storage.local.set({ [THEME_KEY]: v }).catch(() => {});
      });
      return b;
    }));

    const seg = $('rangeSeg');
    seg.replaceChildren();
    for (const v of RANGE_OPTIONS) {
      const b = document.createElement('button');
      b.type = 'button';
      b.setAttribute('role', 'radio');
      b.setAttribute('aria-checked', v === range ? 'true' : 'false');
      b.dataset.v = String(v);
      b.textContent = t('rangeDays', formatNumber(v));
      b.addEventListener('click', () => {
        for (const o of seg.children) o.setAttribute('aria-checked', o === b ? 'true' : 'false');
        redDays = v;
        chrome.storage.local.set({ [RANGE_KEY]: v }).catch(() => {});
      });
      seg.append(b);
    }

    // default quality of the inline players (quality.js reads it on every site)
    const QUALITY_KEY = 'kwsSpDefaultQuality';
    let qcur = 'last';
    try { qcur = (await chrome.storage.local.get(QUALITY_KEY))[QUALITY_KEY] || 'last'; } catch (_) {}
    const qseg = $('qualitySeg');
    qseg.replaceChildren(...['last', 'max', '1080', '720', '480'].map((v) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.setAttribute('role', 'radio');
      b.setAttribute('aria-checked', v === qcur ? 'true' : 'false');
      b.dataset.v = v;
      b.textContent = /^\d+$/.test(v) ? v + 'p' : t('quality_' + v);
      b.addEventListener('click', () => {
        for (const o of qseg.children) o.setAttribute('aria-checked', o === b ? 'true' : 'false');
        chrome.storage.local.set({ [QUALITY_KEY]: v }).catch(() => {});
      });
      return b;
    }));

    if (['ask', 'new', 'full'].includes(d[BADGE_CLICK_KEY])) badgeClick = d[BADGE_CLICK_KEY];
    const bseg = $('badgeClickSeg');
    bseg.replaceChildren(...['ask', 'new', 'full'].map((v) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.setAttribute('role', 'radio');
      b.setAttribute('aria-checked', v === badgeClick ? 'true' : 'false');
      b.dataset.v = v;
      b.textContent = t('badgeClick_' + v);
      b.addEventListener('click', () => {
        for (const o of bseg.children) o.setAttribute('aria-checked', o === b ? 'true' : 'false');
        badgeClick = v;
        chrome.storage.local.set({ [BADGE_CLICK_KEY]: v }).catch(() => {});
      });
      return b;
    }));


    const sm = d.soopFetchMode === 'tab' ? 'tab' : 'api';
    $('soopModeGroup').replaceChildren(...SOOP_MODES.map(([v, name, descKey]) =>
      radioRow('soopmode', v, name || t('soopLegacy'), t(descKey), v === sm, (val) => chrome.storage.local.set({ soopFetchMode: val }).catch(() => {}))));

    $('soopSubtitles').checked = !!d.soopSearchSubtitles;
    // 1.2.6.0: connected services (traffic lights) instead of log-source options
    $('srUse').checked = srUse;
    $('srTwAlways').checked = srTwAlways;
    $('klUse').checked = d[KICKLOGZ_KEY] !== false;
    srAcctShow(false);
    klAcctShow(true, false);
    $('autoClose').checked = AUTO_CLOSE_KEYS.some((k) => d[k]);

    const sel = $('translateLang');
    sel.replaceChildren(...TRANSLATE_LANGS.map(([v, label]) => new Option(label, v)));
    sel.value = d[TRANSLATE_KEY] || defaultTranslateLang();

    ovSettingsInit(d);
    setDataStatus('');
    $('versionLine').textContent = t('version', chrome.runtime.getManifest().version);
    $('updCheckState').textContent = '';
    $('viewSettings').hidden = false;
    $('setBackBtn').focus();
  }

  function closeSettings() {
    $('viewSettings').hidden = true;
    $('settingsBtn').focus();
  }

  $('settingsBtn').addEventListener('click', openSettings);
  $('setBackBtn').addEventListener('click', closeSettings);
  $('viewSettings').addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && $('viewKwEdit').hidden) { e.preventDefault(); closeSettings(); }
  });
  $('soopSubtitles').addEventListener('change', (e) => chrome.storage.local.set({ soopSearchSubtitles: e.target.checked }).catch(() => {}));
  $('srUse').addEventListener('change', (e) => { chrome.storage.local.set({ [SR_USE_KEY]: e.target.checked }).catch(() => {}); srAcctShow(false); });
  $('srTwAlways').addEventListener('change', (e) => chrome.storage.local.set({ [SR_TW_KEY]: e.target.checked }).catch(() => {}));
  $('klUse').addEventListener('change', (e) => { chrome.storage.local.set({ [KICKLOGZ_KEY]: e.target.checked }).catch(() => {}); klAcctShow(true, false); });
  $('srAcctRefresh').addEventListener('click', async () => {
    const b = $('srAcctRefresh');
    if (b.disabled) return;
    b.disabled = true; b.classList.add('spin');
    try { await srAcctShow(true); } finally { b.disabled = false; b.classList.remove('spin'); }
  });
  function svcPaint(prefix, state, statusText, desc, action) {
    $(prefix + 'Dot').className = 'svc-dot ' + state;      // ok · warn · err · off · unknown
    const st = $(prefix === 'kl' ? 'kickKlAcct' : 'srAcct');
    st.className = 'srow-sub ' + (state === 'ok' ? 'ok' : state === 'warn' ? 'warn' : state === 'err' ? 'err' : '');
    st.textContent = statusText;
    $(prefix + 'Desc').textContent = desc || '';
    const row = $(prefix + 'ActRow'), btn = $(prefix + 'Act');
    row.hidden = !action;
    if (action) { btn.textContent = action.label; btn.onclick = action.run; }
  }
  // StreamRecorder: logged in? Premium? targets used/max (sr_bg.js reads it in a streamrecorder.io tab)
  async function srAcctShow(force) {
    const on = $('srUse').checked;
    $('srTwRow').hidden = !on;
    if (!on) { svcPaint('sr', 'off', t('svcOff'), t('svcSrPitch'), null); return null; }
    svcPaint('sr', 'unknown', t('klAcctChecking'), '', null);
    const r = await Promise.race([send({ type: 'KWS_SR_ACCOUNT', force: !!force }), new Promise((res) => setTimeout(() => res({ error: 'timeout' }), 55000))]);
    srAcct = r;
    if (r && !r.error) chrome.storage.local.set({ kwsSrAcctSeen: { loggedIn: r.loggedIn, premium: r.premium } }).catch(() => {});
    const login = { label: t('svcLogin'), run: () => chrome.tabs.create({ url: 'https://streamrecorder.io/login', active: true }).catch(() => {}) };
    if (!r || r.error || r.loggedIn == null) svcPaint('sr', 'unknown', t('svcUnknown') + (r && r.error ? ' (' + r.error + ')' : ''), t('svcSrPitch'), login);
    else if (!r.loggedIn) svcPaint('sr', 'err', t('svcLoggedOut'), t('svcSrPitch'), login);
    else if (!r.premium) svcPaint('sr', 'warn', t('svcSrFree', formatNumber(r.used || 0), formatNumber(r.max || 3)), t('svcSrFreeDesc'),
      { label: t('svcUpgrade'), run: () => chrome.tabs.create({ url: 'https://streamrecorder.io/purchase/plan', active: true }).catch(() => {}) });
    else svcPaint('sr', 'ok', t('svcSrPremium', formatNumber(r.used || 0), formatNumber(r.max || 0)), t('svcSrOkDesc'), null);
    return r;
  }
  // 1.2.5.20: Kick subscriber-only VODs from KickLogz — optional kicklogz.com permission, asked right from this click
  // KickLogz needs the optional kicklogz.com permission; asked from the service row's button
  async function klAllow() {
    let ok = false;
    try { ok = await chrome.permissions.request({ origins: KICKLOGZ_ORIGINS }); } catch (_) {}
    if (!ok) { toast(t('kickKicklogzDenied')); return; }
    chrome.storage.local.set({ [KICKLOGZ_KEY]: true }).catch(() => {});
    $('klUse').checked = true;
    klAcctShow(true, true);
  }
  // 1.2.5.26: KickLogz account line under the plan (logged in? Pro?) + the "log in first" popup
  $('kickKlAcctRefresh').addEventListener('click', async () => {
    const b = $('kickKlAcctRefresh');
    if (b.disabled) return;
    b.disabled = true; b.classList.add('spin');
    try { await klAcctShow(true, true); } finally { b.disabled = false; b.classList.remove('spin'); }
  });
  // 1.2.6.0: KickLogz service row (traffic light) — the Free/Pro choice follows the account itself
  async function klAcctShow(on, force) {
    if (!$('klUse').checked) { svcPaint('kl', 'off', t('svcOff'), t('svcKlPitch'), null); return null; }
    let perm = false;
    try { perm = await chrome.permissions.contains({ origins: KICKLOGZ_ORIGINS }); } catch (_) {}
    if (!perm) { svcPaint('kl', 'off', t('svcKlNoPerm'), t('svcKlPitch'), { label: t('kickKlAllow'), run: klAllow }); return { noPerm: true }; }
    svcPaint('kl', 'unknown', t('klAcctChecking'), '', null);
    const r = await klAccount(force);
    const login = { label: t('svcLogin'), run: () => chrome.tabs.create({ url: 'https://kicklogz.com/login', active: true }).catch(() => {}) };
    if (!r || r.error || r.noPerm || r.loggedIn == null) { svcPaint('kl', 'unknown', t('svcUnknown') + (r && r.error ? ' (' + r.error + ')' : ''), t('svcKlPitch'), login); return r; }
    if (r.plan === 'pro' || r.plan === 'free') { klPlanSeen = r.plan; chrome.storage.local.set({ [KICKLOGZ_PLAN_KEY]: r.plan }).catch(() => {}); }
    if (!r.loggedIn) { svcPaint('kl', 'err', t('svcLoggedOut'), t('svcKlPitch'), login); return r; }
    if (r.plan === 'free') { svcPaint('kl', 'warn', t('svcKlFree'), t('svcKlFreeDesc'), { label: t('svcUpgrade'), run: () => chrome.tabs.create({ url: 'https://kicklogz.com/pricing', active: true }).catch(() => {}) }); return r; }
    svcPaint('kl', 'ok', r.plan === 'pro' ? t('svcKlPro') : t('klAcctOk'), t('svcKlOkDesc'), null);
    return r;
  }
  // the background check, but never waiting more than 45 s for it
  function klAccount(force) {
    return Promise.race([
      send({ type: 'KWS_KL_ACCOUNT', force: !!force }),
      new Promise((r) => setTimeout(() => r({ error: 'timeout' }), 45000)),
    ]);
  }
  // resolves true = go on (as Free if they skip), false = stop. `askSkip` false → just an info popup.
  // `unknown` → the check itself failed, so the text says "couldn't confirm" instead of "not logged in".
  function klLoginDialog(askSkip, unknown) {
    return new Promise((resolve) => {
      let done = false;
      const fin = (v) => { if (!done) { done = true; resolve(v); } };
      const close = openDialog((dlg, closeDlg) => {
        dlg.append(dlgTitle(t('klLoginTitle')), dlgText(t(unknown ? 'klLoginUnknownText' : 'klLoginText')),
          dlgOpt(t('klLoginGo'), t('klLoginGoDesc'), true, () => {
            closeDlg(); fin(false);
            chrome.tabs.create({ url: 'https://kicklogz.com/login', active: true }).catch(() => {});
          }));
        if (askSkip) dlg.append(dlgOpt(t('klLoginSkip'), t('klLoginSkipDesc'), false, () => { klSkipUntil = Date.now() + 20000; closeDlg(); fin(true); }));
        dlg.append(dlgOpt(t('cancel'), '', false, () => { closeDlg(); fin(false); }));
      });
      // closed some other way (Esc / outside click / replaced) → stop
      const host = $('dlgHost');
      const mo = new MutationObserver(() => { if (host.hidden || !host.children.length) { mo.disconnect(); fin(false); } });
      mo.observe(host, { childList: true, attributes: true, attributeFilter: ['hidden'] });
      void close;
    });
  }
  // Before a Kick search with the Pro plan: logged out → popup. One check / popup shared by every
  // start in the same moment (🎲 +10 starts ten at once); "search anyway" is remembered for 10 min.
  let klSkipUntil = 0, klGatePending = null;
  // 1.2.5.41: every start checks afresh (no 5-min cache) — only the starts of the same moment
  // (🎲 +10, overnight…) share one check, for 20 s.
  let klPassUntil = 0;
  async function klGate() {
    if (Date.now() < klSkipUntil || Date.now() < klPassUntil) return true;
    if (klGatePending) return klGatePending;
    klGatePending = (async () => {
      const d = await chrome.storage.local.get(KICKLOGZ_PLAN_KEY).catch(() => ({}));
      if (d[KICKLOGZ_PLAN_KEY] !== 'pro') return true;
      const r = await klAccount(true);
      if (r && r.noPerm) return true;           // KickLogz isn't allowed at all → Kick API only, nothing to log in to
      if (r && r.loggedIn === true) { klPassUntil = Date.now() + 20000; return true; }
      // logged out — or the check failed: ask rather than silently going on without Pro
      return klLoginDialog(true, !(r && r.loggedIn === false));
    })().finally(() => { setTimeout(() => { klGatePending = null; }, 0); });
    return klGatePending;
  }
  $('autoClose').addEventListener('change', (e) => {
    const v = e.target.checked;
    chrome.storage.local.set(Object.fromEntries(AUTO_CLOSE_KEYS.map((k) => [k, v]))).catch(() => {});
  });
  $('translateLang').addEventListener('change', (e) => chrome.storage.local.set({ [TRANSLATE_KEY]: e.target.value }).catch(() => {}));

  // History import/export — same file format as 1.2.4 (vod-kws-history.v2), via its own module.
  $('histImportBtn').addEventListener('click', () => { $('histFile').value = ''; $('histFile').click(); });
  $('histFile').addEventListener('change', async (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      let total;
      if (data && data.schema === KWSDataFolder.SCHEMA) {
        total = await KWSDataFolder.restore(data, 'merge'); // a kws-data.json (1.2.5 data folder file)
      } else {
        const counts = await window.KWSUnifiedHistory.importToAll(data);
        total = Object.values(counts || {}).reduce((a, n) => a + (Number(n) || 0), 0);
      }
      setDataStatus(t('histImported', formatNumber(total)), 'ok');
      askChzzkIfNeeded();
      toast(t('histImported', formatNumber(total)));
    } catch (err) {
      console.error('[KWS SP] history import failed', err);
      setDataStatus(t('histImportFailed', err && err.message ? err.message : String(err)), 'err');
    }
  });
  $('histExportBtn').addEventListener('click', async () => {
    try {
      const u = await window.KWSUnifiedHistory.exportAll();
      const d = new Date();
      const stamp = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
      window.KWSUnifiedHistory.download(u, 'kws-history-' + stamp + '.json');
    } catch (err) {
      console.error('[KWS SP] history export failed', err);
      setDataStatus(String(err && err.message ? err.message : err), 'err');
    }
  });

  // ───────────────────────── scans & results ─────────────────────────
  // Scans run in the background hub (scan_hub.js), which keeps their state in
  // chrome.storage.session["kwsSpScans"]. The panel only renders that state and sends commands,
  // so it can be closed and reopened mid-scan.
  const SCAN_SUPPORTED = new Set(['kick', 'twitch', 'soop', 'youtube', 'chzzk']); // grows as each platform moves into the panel
  const SCANS_KEY = 'kwsSpScans';
  const CLUSTER_GAP_SEC = 180;              // same rule as the 1.2.4 panels: 2+ hits < 3 min apart
  const activeScan = {};                    // platform → id of the result tab shown
  let bodyVer = 0;                          // bumped when history (visited marks) or translations change
  let lastBodySig = '';

  const send = (msg) => chrome.runtime.sendMessage(msg).catch((e) => ({ ok: false, error: String(e && e.message || e) }));

  async function loadHub() {
    try { hub = (await chrome.storage.session.get(SCANS_KEY))[SCANS_KEY] || {}; } catch (_) { hub = {}; }
  }

  function scansFor(p) {
    return Object.values(hub).filter((e) => e && e.platform === p).sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
  }
  function shownScan() {
    const list = scansFor(selected);
    if (!list.length) return null;
    return list.find((e) => e.id === activeScan[selected]) || list[list.length - 1];
  }
  const hitCount = (e) => (e.groups || []).reduce((n, g) => n + ((g.messages || []).length), 0);

  function canScan() {
    if (!SCAN_SUPPORTED.has(selected)) return false;
    return !!inputId();
  }
  function updateGo() {
    $('goBtn').disabled = !canScan();
    const hint = $('devHint');
    if (SCAN_SUPPORTED.has(selected)) { hint.hidden = true; }
    else { hint.textContent = t('scanUnsupportedYet'); hint.hidden = false; }
  }

  $('goBtn').addEventListener('click', () => {
    if ($('goBtn').disabled) return;
    closeHistPop();
    startScanFlow(inputId());
  });

  // ── bottom-sheet dialogs ──
  let dlgClose = null;
  function openDialog(build) {
    const host = $('dlgHost');
    host.replaceChildren();
    const dlg = document.createElement('div');
    dlg.className = 'dlg';
    dlg.setAttribute('role', 'dialog');
    dlg.setAttribute('aria-modal', 'true');
    const grip = document.createElement('div');
    grip.className = 'dlg-grip';
    dlg.append(grip);
    const close = () => {
      host.hidden = true; host.replaceChildren(); dlgClose = null;
      root.classList.remove('dlg-open');
      if (holdPop) { holdPop = false; if (!histPop.hidden) input.focus({ preventScroll: true }); }
    };
    dlgClose = close;
    build(dlg, close);
    host.append(dlg);
    host.hidden = false;
    root.classList.add('dlg-open'); // same faded, blurred page as behind an open list
    const f = dlg.querySelector('input, .opt.primary, button');
    if (f) f.focus();
    return close;
  }
  $('dlgHost').addEventListener('mousedown', (e) => { if (e.target === $('dlgHost') && dlgClose) dlgClose(); });
  $('dlgHost').addEventListener('keydown', (e) => { if (e.key === 'Escape' && dlgClose) { e.preventDefault(); dlgClose(); } });

  function dlgTitle(text) { const h = document.createElement('h2'); h.className = 'dlg-title'; h.textContent = text; return h; }
  function dlgText(text) { const p = document.createElement('p'); p.className = 'dlg-text'; p.textContent = text; return p; }
  function dlgOpt(title, desc, primary, onPick) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'opt' + (primary ? ' primary' : '');
    const a = document.createElement('span'); a.className = 'opt-title'; a.textContent = title;
    b.append(a);
    if (desc) { const d = document.createElement('span'); d.className = 'opt-desc'; d.textContent = desc; b.append(d); }
    b.addEventListener('click', onPick);
    return b;
  }

  let toastTimer = null;
  function toast(text) {
    let el = document.querySelector('.toast');
    if (!el) { el = document.createElement('div'); el.className = 'toast'; el.setAttribute('role', 'status'); document.querySelector('.panel').append(el); }
    el.textContent = text;
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.hidden = true; }, 2600);
  }

  // ── start flow: "already scanning?" → "rescan everything / only new VODs?" → start ──
  // ── scan options (composer chip): keywords = saved / custom, period = default / N days / all ──
  const SCAN_OPTS_KEY = 'kwsSpScanOpts';
  const RANGE_CHOICES = ['auto', 7, 30, 60, 90, 'all'];
  let scanOpts = { kw: 'saved', customKw: '', range: 'auto' };
  const optKeyword = () => (scanOpts.kw === 'custom' ? String(scanOpts.customKw || '').split(',').map((x) => x.trim()).filter(Boolean).join(', ') : '');
  function setScanOpts(patch) {
    scanOpts = { ...scanOpts, ...patch };
    chrome.storage.local.set({ [SCAN_OPTS_KEY]: scanOpts }).catch(() => {});
    renderOptChip();
  }
  function renderOptChip() {
    const parts = [];
    const kw = optKeyword();
    parts.push(kw ? t('optChipCustom', kw) : t('optKwSaved'));
    if (scanOpts.range !== 'auto') parts.push(scanOpts.range === 'all' ? t('optRangeAll') : t('rangeDays', formatNumber(scanOpts.range)));
    $('optLabel').textContent = parts.join(' · ');
    $('optBtn').classList.toggle('custom', !!kw || scanOpts.range !== 'auto');
    $('optBtn').title = t('scanOptions');
  }
  function renderOptPop() {
    const kseg = $('optKwSeg');
    kseg.replaceChildren(...['saved', 'custom'].map((v) => {
      const b = document.createElement('button');
      b.type = 'button'; b.setAttribute('role', 'radio'); b.dataset.v = v;
      b.setAttribute('aria-checked', scanOpts.kw === v ? 'true' : 'false');
      b.textContent = t(v === 'saved' ? 'optKwSaved' : 'optKwCustom');
      b.addEventListener('click', () => { setScanOpts({ kw: v }); renderOptPop(); if (v === 'custom') $('optKwInput').focus(); });
      return b;
    }));
    const inp = $('optKwInput');
    inp.hidden = scanOpts.kw !== 'custom';
    $('optKwHelp').hidden = inp.hidden;
    if (document.activeElement !== inp) inp.value = scanOpts.customKw || '';
    inp.placeholder = t('customKwPlaceholder');
    inp.setAttribute('aria-label', t('optKwCustom'));
    const rseg = $('optRangeSeg');
    rseg.replaceChildren(...RANGE_CHOICES.map((v) => {
      const b = document.createElement('button');
      b.type = 'button'; b.setAttribute('role', 'radio'); b.dataset.v = String(v);
      b.setAttribute('aria-checked', scanOpts.range === v ? 'true' : 'false');
      b.textContent = v === 'auto' ? t('optRangeAuto') : v === 'all' ? t('optRangeAll') : t('rangeDays', formatNumber(v));
      b.addEventListener('click', () => { setScanOpts({ range: v }); renderOptPop(); });
      return b;
    }));
  }
  $('optKwInput').addEventListener('input', (ev) => setScanOpts({ customKw: ev.target.value }));
  $('optKwInput').addEventListener('keydown', (ev) => { if (ev.key === 'Enter' || ev.key === 'Escape') { ev.preventDefault(); closeOptPop(); input.focus(); } });
  function openOptPop() { closeHistPop(); renderOptPop(); $('optPop').hidden = false; $('optBtn').setAttribute('aria-expanded', 'true'); syncScrim(); }
  function closeOptPop() { $('optPop').hidden = true; $('optBtn').setAttribute('aria-expanded', 'false'); syncScrim(); }
  $('optBtn').addEventListener('click', () => ($('optPop').hidden ? openOptPop() : closeOptPop()));
  document.addEventListener('mousedown', (ev) => { if (!$('optPop').hidden && !$('optPop').contains(ev.target) && !$('optBtn').contains(ev.target)) closeOptPop(); });
  $('optPop').addEventListener('keydown', (ev) => { if (ev.key === 'Escape') { ev.preventDefault(); closeOptPop(); } });
  try {
    chrome.storage.local.get(SCAN_OPTS_KEY).then((d) => {
      const o = d[SCAN_OPTS_KEY];
      if (o && typeof o === 'object') scanOpts = { kw: o.kw === 'custom' ? 'custom' : 'saved', customKw: String(o.customKw || ''), range: RANGE_CHOICES.includes(o.range) ? o.range : 'auto' };
      renderOptChip();
    });
  } catch (_) {}
  renderOptChip();

  // After restoring history that has CHZZK channels: offer the CHZZK permission straight away
  // (a dialog button, since the file pick's click is long gone) so badges and scans just work.
  async function askChzzkIfNeeded() {
    try {
      const d = await chrome.storage.local.get('chzzkKwsHistory');
      const has = Object.keys(d.chzzkKwsHistory || {}).some((k) => !k.startsWith('_'));
      if (!has || await chrome.permissions.contains({ origins: ['https://api.chzzk.naver.com/*', 'https://chzzk.naver.com/*'] })) return;
      openDialog((dlg, close) => {
        dlg.append(dlgTitle('CHZZK'), dlgText(t('errChzzkPermission')),
          dlgOpt(t('chzzkAllow'), '', true, async () => { try { await chrome.permissions.request({ origins: ['https://api.chzzk.naver.com/*', 'https://chzzk.naver.com/*'] }); } catch (_) {} close(); }),
          dlgOpt(t('cancel'), '', false, close));
      });
    } catch (_) {}
  }
  // CHZZK history saved without a channel name (old builds, failed scans): fill names in quietly.
  const chzzkNameTried = new Set();
  async function backfillChzzkNames() {
    if (selected !== 'chzzk') return;
    const missing = Object.keys(currentHistory).filter((k) => /^[0-9a-f]{32}$/.test(k) && !(currentHistory[k] && currentHistory[k].nickname) && !chzzkNameTried.has(k)).slice(0, 8);
    if (!missing.length) return;
    try { if (!(await chrome.permissions.contains({ origins: ['https://api.chzzk.naver.com/*'] }))) return; } catch (_) { return; }
    const names = {};
    await Promise.all(missing.map(async (k) => {
      chzzkNameTried.add(k);
      try { const r = await fetch('https://api.chzzk.naver.com/service/v1/channels/' + k, { credentials: 'include' }); const c = r.ok ? (await r.json()).content : null; if (c && c.channelName) names[k] = c.channelName; } catch (_) {}
    }));
    if (Object.keys(names).length) await writeHistory((h) => { for (const [k, n] of Object.entries(names)) if (h[k]) h[k] = { ...h[k], nickname: n }; });
  }

  // CHZZK needs one optional permission (api.chzzk.naver.com); asked on the first CHZZK scan.
  const CHZZK_ORIGINS = ['https://api.chzzk.naver.com/*', 'https://chzzk.naver.com/*'];
  async function ensureChzzkPermission() {
    // request() first, straight from the click (it answers true at once when already granted)
    try { return await chrome.permissions.request({ origins: CHZZK_ORIGINS }); } catch (_) {}
    try { return await chrome.permissions.contains({ origins: CHZZK_ORIGINS }); } catch (_) { return false; }
  }
  // CHZZK input → channel ID: a 32-hex ID / channel URL as is, a replay URL or number via the
  // video API, anything else as a channel name via the channel search.
  async function resolveChzzk(raw) {
    const v = String(raw || '').trim();
    const hex = /[0-9a-f]{32}/i.exec(v);
    if (hex) return { id: hex[0].toLowerCase() };
    const api = 'https://api.chzzk.naver.com';
    const get = async (u) => { try { const r = await fetch(u, { credentials: 'include' }); return r.ok ? (await r.json()).content : null; } catch (_) { return null; } };
    const vno = /video\/(\d+)/.exec(v) || /^(\d{5,})$/.exec(v);
    if (vno) {
      const c = await get(`${api}/service/v3/videos/${vno[1]}`);
      const ch = c && c.channel;
      return ch && ch.channelId ? { id: ch.channelId.toLowerCase(), name: ch.channelName } : null;
    }
    if (!v) return null;
    const c = await get(`${api}/service/v1/search/channels?keyword=${encodeURIComponent(v)}&offset=0&size=10`);
    const list = ((c && c.data) || []).map((x) => x.channel || x).filter((x) => x && x.channelId);
    const exact = list.find((x) => String(x.channelName || '').toLowerCase() === v.toLowerCase());
    const hit = exact || list[0];
    return hit ? { id: hit.channelId.toLowerCase(), name: hit.channelName } : null;
  }
  async function startScanFlow(rawCh, opts) {
    const fromBadge = !!(opts && opts.badge);
    if (selected === 'chzzk') {
      if (!(await ensureChzzkPermission())) {
        // no click to ask from (e.g. a badge on another site): ask with a button here
        openDialog((dlg, close) => {
          dlg.append(dlgTitle('CHZZK'), dlgText(t('errChzzkPermission')),
            dlgOpt(t('chzzkAllow'), '', true, async () => {
              let ok = false;
              try { ok = await chrome.permissions.request({ origins: CHZZK_ORIGINS }); } catch (_) {}
              close();
              if (ok) startScanFlow(rawCh, opts); else toast(t('errChzzkPermission'));
            }),
            dlgOpt(t('cancel'), '', false, close));
        });
        return;
      }
      const raw = String(rawCh || '').trim() || input.value;
      const r = /^[0-9a-f]{32}$/i.test(raw) ? { id: raw.toLowerCase() } : await resolveChzzk(fromBadge ? raw : (input.value.trim() || raw));
      if (!r) { toast(t('errChzzkNotFound')); return; }
      rawCh = r.id;
    }
    const ch = String(rawCh || '').trim().replace(/^@/, '').toLowerCase();
    if (!ch || !SCAN_SUPPORTED.has(selected)) return;
    const platform = selected;
    const id = platform + ':' + ch;
    const running = hub[id] && (hub[id].status === 'running' || hub[id].status === 'queued');
    if (running) {
      openDialog((dlg, close) => {
        dlg.append(dlgTitle(t('alreadyTitle', hub[id] ? scanLabel(hub[id]) : ch)), dlgText(t('alreadyDesc')),
          dlgOpt(t('alreadyRestart'), '', true, async () => { close(); await restartScan(platform, ch, id); }),
          dlgOpt(t('alreadyKeep'), '', false, () => { close(); showScan(platform, id); }));
      });
      return;
    }
    // scan options (composer): custom keywords and/or a fixed period; badges keep their own rule
    const kw = !fromBadge && !(opts && opts.saved) ? optKeyword() : '';
    const rng = !fromBadge && !(opts && opts.saved) ? scanOpts.range : 'auto';
    // scan options are for one search: back to saved keywords + default period right after
    // (the custom keyword text is kept for next time)
    if (kw || rng !== 'auto') setScanOpts({ kw: 'saved', range: 'auto' });
    if (rng === 'all') { doStart(platform, ch, 'full', kw); return; }
    if (typeof rng === 'number') { doStart(platform, ch, 'full', kw, rng); return; }
    const h = currentHistory[ch];
    const lastRaw = h ? (h.lastDate || String(h.searchedAt || h.savedAt || '').slice(0, 10)) : '';
    const last = /^\d{4}-\d{2}-\d{2}$/.test(lastRaw) ? lastRaw : ''; // 1.2.4 Kick history has no lastDate
    if (last && fromBadge && badgeClick !== 'ask') { doStart(platform, ch, badgeClick); return; } // settings: no popup
    if (last) {
      const date = formatDate(new Date(last + 'T00:00:00'));
      openDialog((dlg, close) => {
        dlg.append(dlgTitle(scanLabel({ platform, channel: ch, nickname: h && (h.nickname || h.displayName) })), dlgText(t('rescanLast', date)),
          dlgOpt(t('rescanNew'), t('rescanNewDesc', date), true, () => { close(); doStart(platform, ch, 'new', kw); }),
          dlgOpt(t('rescanFull'), t('rescanFullDesc'), false, () => { close(); doStart(platform, ch, 'full', kw); }));
      });
      return;
    }
    doStart(platform, ch, 'full', kw);
  }

  async function doStart(platform, ch, mode, keyword, rangeDays) {
    if (platform === 'kick' && !(await klGate())) return;
    const r = await send({ type: 'KWS_SP_SCAN_START', platform, channel: ch, mode, ...(keyword ? { keyword } : {}), ...(rangeDays ? { rangeDays } : {}) });
    if (r && r.ok) { showScan(platform, r.id); return; }
    if (r && r.reason === 'running') { showScan(platform, r.id); return; }
    toast(t('scanError', (r && (r.error || r.reason)) || '?'));
  }

  // Stop, wait until the hub has really stopped it, then start again from scratch.
  async function restartScan(platform, ch, id) {
    await send({ type: 'KWS_SP_SCAN_STOP', id });
    const t0 = Date.now();
    while (Date.now() - t0 < 15000) {
      await loadHub();
      const e = hub[id];
      if (!e || (e.status !== 'running' && e.status !== 'queued')) break;
      await new Promise((r) => setTimeout(r, 250));
    }
    doStart(platform, ch, 'full');
  }

  function showScan(platform, id) {
    activeScan[platform] = id;
    if (platform === selected) renderResults();
  }

  // ── "open a VOD by URL or ID" helper ──
  function showOpenUrl() {
    openDialog((dlg, close) => {
      const field = document.createElement('input');
      field.type = 'text';
      field.placeholder = t('urlPromptPlaceholder');
      field.setAttribute('aria-label', t('urlPromptTitle'));
      field.spellcheck = false;
      const go = dlgOpt(t('openUrlGo'), '', true, async () => {
        const raw = field.value.trim();
        if (!raw) { field.focus(); return; }
        close();
        const r = await send({ type: 'KWS_SP_OPEN_URL', platform: selected, raw, channel: inputId() || (pageIsSelected() ? current.channel : ''), windowId });
        if (!r || !r.ok) toast(t('openVodFailed'));
      });
      field.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); go.click(); } });
      dlg.append(dlgTitle(t('urlPromptTitle')), field, go);
    });
  }

  // ── 1.2.5.20: "find channels by keyword" (Kick, KickLogz — engine: kickfind_bg.js) ──
  const KF_PREFS_KEY = 'kwsKfPrefs';
  // "Find streamers": StreamRecorder's latest list — for SOOP (1.2.5.34) also SOOP's own ranking
  // (토크/캠방, the only board split by 여자/남자), whose streamers go straight into the history.
  // 1.2.5.59: say what "find" does on this platform (Kick: keyword · SOOP: ranking · others: StreamRecorder)
  function discoverLabel() { return selected === 'kick' ? t('discoverKick') : selected === 'soop' ? t('discoverSoop') : t('menuDiscover'); }
  function discoverDirect() { // the platform's own way, skipping the chooser
    if (selected === 'kick') showKickFind();
    else if (selected === 'soop') showSoopRank();
    else chrome.tabs.create({ url: DISCOVER_URL[selected], windowId: windowId ?? undefined, active: true });
  }
  function discover() {
    const openSR = () => chrome.tabs.create({ url: DISCOVER_URL[selected], windowId: windowId ?? undefined, active: true });
    if (selected === 'kick') { // 1.2.5.35: KickLogz keyword search (Pro) · StreamRecorder
      openDialog((dlg, close) => {
        dlg.append(dlgTitle(t('menuDiscover')),
          dlgOpt(t('kfMenu') + ' (KickLogz Pro)', t('kfMenuDesc'), true, () => { close(); showKickFind(); }),
          dlgOpt('StreamRecorder', t('rankSrDesc'), false, () => { close(); openSR(); }),
          dlgOpt(t('cancel'), '', false, close));
      });
      return;
    }
    if (selected !== 'soop') { openSR(); return; }
    openDialog((dlg, close) => {
      dlg.append(dlgTitle(t('menuDiscover')),
        dlgOpt(t('rankMenu'), t('rankMenuDesc'), true, () => { close(); showSoopRank(); }),
        dlgOpt('StreamRecorder', t('rankSrDesc'), false, () => { close(); openSR(); }),
        dlgOpt(t('cancel'), '', false, close));
    });
  }
  const RANK_PREFS_KEY = 'kwsSoopRankPrefs';
  const RANK_API = 'https://afevent2.sooplive.com/app/rank/api.php';
  async function showSoopRank() {
    let prefs = {};
    try { prefs = (await chrome.storage.local.get(RANK_PREFS_KEY))[RANK_PREFS_KEY] || {}; } catch (_) {}
    openDialog((dlg, close) => {
      const mkRow = (title, ctl) => {
        const row = document.createElement('label');
        row.className = 'srow';
        row.innerHTML = '<span class="srow-main"><span class="srow-title"></span></span>';
        row.querySelector('.srow-title').textContent = title;
        row.append(ctl);
        return row;
      };
      const gender = document.createElement('select');
      gender.className = 'sselect';
      [['F', t('rankFemale')], ['M', t('rankMale')]].forEach(([v, l]) => gender.append(new Option(l, v)));
      gender.value = prefs.gender === 'M' ? 'M' : 'F';
      const line = dlgText(t('rankHelp'));
      const go = dlgOpt(t('rankGo'), '', true, async () => {
        const p = { gender: gender.value, count: 0 }; // 1.2.5.36: always the whole ranking — only IDs not in the history are added
        chrome.storage.local.set({ [RANK_PREFS_KEY]: p }).catch(() => {});
        go.disabled = true; gender.disabled = true;
        try {
          const r = await soopRankImport(p, (n) => { line.textContent = t('rankLoading', formatNumber(n)); });
          close();
          toast(t('rankDone', formatNumber(r.added), formatNumber(r.already)));
        } catch (e) {
          go.disabled = false; gender.disabled = false;
          line.textContent = t('rankError', String((e && e.message) || e));
        }
      });
      dlg.append(dlgTitle(t('rankMenu')), line, mkRow(t('rankGender'), gender), go, dlgOpt(t('cancel'), '', false, close));
    });
  }
  // Ranking pages (100 each) → new history entries for streamers not in it yet. They have no search
  // date, so they count as "never searched": first in line for 🎲 and overnight mode, and every SOOP
  // page shows their KWS badge. Entries already in the history are left as they are.
  async function soopRankImport({ gender, count }, onProgress) {
    const list = [];
    const seen = new Set();
    for (let page = 1; page <= 60; page++) {
      const r = await fetch(RANK_API, {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `szWhich=talkcam&nPage=${page}&szSearch=&szGender=${encodeURIComponent(gender)}`,
      });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const j = await r.json();
      const rows = Array.isArray(j && j.ALL_RANK) ? j.ALL_RANK : [];
      for (const x of rows) {
        const id = String(x.bj_id || '').trim().toLowerCase();
        if (!id || seen.has(id)) continue;
        seen.add(id);
        list.push({ id, nick: String(x.bj_nick || '').trim() });
      }
      onProgress && onProgress(list.length);
      if (!rows.length || (count && list.length >= count)) break;
    }
    const pick = count ? list.slice(0, count) : list;
    if (!pick.length) throw new Error(t('rankEmpty'));
    let added = 0, already = 0;
    const now = new Date().toISOString();
    await writeHistory((hist) => {
      const have = new Set(Object.keys(hist).map((k) => k.toLowerCase()));
      for (const { id, nick } of pick) {
        if (have.has(id)) { already++; continue; }
        hist[id] = { nickname: nick || id, gender, addedFrom: 'soop-rank', addedAt: now };
        added++;
      }
    });
    return { added, already };
  }

  // 1.2.5.50: keywords searched before (newest first, max 20) — listed under the field, each with ✕
  const KF_KW_HIST_KEY = 'kwsKfKeywordHistory';
  async function kfKwHistory() { try { const v = (await chrome.storage.local.get(KF_KW_HIST_KEY))[KF_KW_HIST_KEY]; return Array.isArray(v) ? v : []; } catch (_) { return []; } }
  async function kfKwRemember(text) {
    const v = String(text || '').split(',').map((x) => x.trim()).filter(Boolean).join(', ');
    if (!v) return;
    const list = (await kfKwHistory()).filter((x) => x.toLowerCase() !== v.toLowerCase());
    list.unshift(v);
    chrome.storage.local.set({ [KF_KW_HIST_KEY]: list.slice(0, 20) }).catch(() => {});
  }
  async function showKickFind() {
    let prefs = {};
    try { prefs = (await chrome.storage.local.get(KF_PREFS_KEY))[KF_PREFS_KEY] || {}; } catch (_) {}
    let kwHist = await kfKwHistory();
    openDialog((dlg, close) => {
      const field = document.createElement('input');
      field.type = 'text';
      field.placeholder = t('kfKeywordsPh');
      field.setAttribute('aria-label', t('kfKeywordsPh'));
      field.spellcheck = false;
      field.value = prefs.keywords || '';
      // recent keywords: shown while the field has focus; click = use it, ✕ = forget it
      const recent = document.createElement('div');
      recent.className = 'kf-recent';
      recent.hidden = true;
      const renderRecent = (filter) => {
        const q = filter === true ? field.value.trim().toLowerCase() : '';
        const items = kwHist.filter((x) => !q || x.toLowerCase().includes(q) || x.toLowerCase() === q);
        recent.replaceChildren();
        if (!items.length) { recent.hidden = true; return; }
        const head = document.createElement('div'); head.className = 'kf-recent-head'; head.textContent = t('kfRecent');
        recent.append(head);
        for (const kw of items) {
          const row = document.createElement('div'); row.className = 'kf-recent-row';
          const pick = document.createElement('button'); pick.type = 'button'; pick.className = 'kf-recent-kw'; pick.textContent = kw; pick.title = kw;
          pick.addEventListener('mousedown', (ev) => { ev.preventDefault(); field.value = kw; recent.hidden = true; field.focus(); });
          const del = document.createElement('button'); del.type = 'button'; del.className = 'kf-recent-del'; del.textContent = '✕';
          del.title = t('histDelete'); del.setAttribute('aria-label', t('histDelete') + ' · ' + kw);
          del.addEventListener('mousedown', (ev) => {
            ev.preventDefault();
            kwHist = kwHist.filter((x) => x !== kw);
            chrome.storage.local.set({ [KF_KW_HIST_KEY]: kwHist }).catch(() => {});
            renderRecent(false);
          });
          row.append(pick, del);
          recent.append(row);
        }
        recent.hidden = false;
      };
      // a click on the field lists them all; typing narrows the list (not on the dialog's own auto-focus)
      field.addEventListener('click', () => renderRecent(false));
      field.addEventListener('input', () => renderRecent(true));
      field.addEventListener('keydown', (ev) => { if (ev.key === 'ArrowDown' && recent.hidden) renderRecent(false); });
      field.addEventListener('blur', () => { setTimeout(() => { recent.hidden = true; }, 120); });
      field.addEventListener('keydown', (ev) => { if (ev.key === 'Escape' && !recent.hidden) { ev.preventDefault(); ev.stopPropagation(); recent.hidden = true; } }, true);
      const days = document.createElement('select');
      days.className = 'sselect';
      days.setAttribute('aria-label', t('kfDays'));
      [1, 2, 3, 7, 14, 30].forEach((n) => days.append(new Option(t('kfDaysOpt', formatNumber(n)), String(n))));
      days.value = String([1, 2, 3, 7, 14, 30].includes(prefs.days) ? prefs.days : 7);
      const daysRow = document.createElement('label');
      daysRow.className = 'srow';
      daysRow.innerHTML = '<span class="srow-main"><span class="srow-title"></span></span>';
      daysRow.querySelector('.srow-title').textContent = t('kfDays');
      daysRow.append(days);
      const newRow = document.createElement('label');
      newRow.className = 'srow';
      newRow.innerHTML = '<span class="srow-main"><span class="srow-title"></span></span>';
      newRow.querySelector('.srow-title').textContent = t('kfIncludeNew');
      const inc = document.createElement('input');
      inc.type = 'checkbox';
      inc.className = 'switch';
      inc.checked = !!prefs.includeNew;
      newRow.append(inc);
      const go = dlgOpt(t('kfGo'), '', true, async () => {
        const kws = field.value.split(',').map((x) => x.trim()).filter(Boolean);
        if (!kws.length) { field.focus(); return; }
        let ok = false;
        try { ok = await chrome.permissions.request({ origins: KICKLOGZ_ORIGINS }); } catch (_) {}
        if (!ok) { toast(t('kickKicklogzDenied')); return; }
        const p = { keywords: field.value, days: Number(days.value), includeNew: inc.checked };
        chrome.storage.local.set({ [KF_PREFS_KEY]: p }).catch(() => {});
        kfKwRemember(kws.slice(0, 5).join(', '));
        // 1.2.5.47: Pro plan → a fresh login check every time (it used the 5-min cached answer before)
        if ((await chrome.storage.local.get(KICKLOGZ_PLAN_KEY).catch(() => ({})))[KICKLOGZ_PLAN_KEY] === 'pro') {
          const g = await klAccount(true);
          if (!(g && (g.loggedIn === true || g.noPerm))) {
            if (!(await klLoginDialog(true, !(g && g.loggedIn === false)))) return; // login / cancel
            openDialog((d2, c2) => runKickFind(d2, c2, kws.slice(0, 5), p.days, p.includeNew)); // "search anyway"
            return;
          }
        }
        runKickFind(dlg, close, kws.slice(0, 5), p.days, p.includeNew);
      });
      field.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); go.click(); } });
      const fieldWrap = document.createElement('div');
      fieldWrap.className = 'kf-field-wrap';
      fieldWrap.append(field, recent);
      dlg.append(dlgTitle(t('kfMenu')), dlgText(t('kfHelp')), fieldWrap, daysRow, newRow, go);
    });
  }
  async function runKickFind(dlg, close, kws, days, includeNew) {
    // the dialog turns into a live progress view with a stop button
    [...dlg.children].forEach((n) => { if (!n.classList.contains('dlg-grip')) n.remove(); });
    const line = dlgText(t('kfStarting'));
    const stop = dlgOpt(t('stop'), '', false, () => { send({ type: 'KWS_KF_STOP' }); stop.disabled = true; });
    dlg.append(dlgTitle(t('kfMenu') + ' · ' + kws.join(', ')), line, stop);
    const onChange = (c, area) => {
      if (area !== 'session' || !c.kwsKickFind) return;
      const st = c.kwsKickFind.newValue;
      if (!st) return;
      line.textContent = st.phase === 'vods' ? t('kfVods', formatNumber(st.channels || 0))
        : t('kfRunning', formatNumber((st.kwIndex || 0) + 1), formatNumber(kws.length), formatNumber(st.pages || 0), formatNumber(st.hits || 0), formatNumber(st.channels || 0));
    };
    chrome.storage.onChanged.addListener(onChange);
    const r = await send({ type: 'KWS_KF_RUN', keywords: kws, days, includeNew });
    chrome.storage.onChanged.removeListener(onChange);
    close();
    if (!r || !r.ok) { toast(r && r.reason === 'permission' ? t('kickKicklogzDenied') : t('scanError', (r && (r.error || r.reason)) || '?')); return; }
    if (!r.channels) { toast(r.limited ? t('kfLimited') : t('kfNone')); return; }
    if (selected !== 'kick') { selectPlatform('kick'); await render(++renderSeq); }
    showScan('kick', r.firstId);
    toast(t('kfDone', formatNumber(r.channels), formatNumber(r.hits)));
  }

  // ── progress row + top bar ──
  // Twitch scans count days (Zonian dates / VOD days) rather than VODs.
  const byDays = (e) => e.platform === 'twitch';
  // Hub error codes → words (the rest is shown as the engine reported it).
  function errorText(err) {
    const m = String(err || '');
    if (m === 'tab closed') return t('errTabClosed');
    if (m === 'tab reloaded') return t('errTabReloaded');
    if (/did not respond/.test(m)) return t('errPageNoAnswer');
    if (m === 'KWS_ID_NOT_FOUND') return t('errIdNotFound');
    if (m === 'KWS_CHZZK_PERMISSION') return t('errChzzkPermission');
    if (m === 'KWS_CHZZK_BAD_ID') return t('errChzzkBadId');
    if (m === 'KWS_KICK_BLOCKED') return t('errKickBlocked');
    return m || '?';
  }
  function renderProgress(e) {
    const row = $('progRow');
    const fill = $('progFill');
    const top = document.querySelector('.topbar-fill');
    if (!e) { row.hidden = true; top.style.width = '0'; return; }
    row.hidden = false;
    const hits = formatNumber(e.matchedLines || hitCount(e));
    const pct = e.total ? Math.min(100, Math.round((e.done || 0) / e.total * 100)) : 0;
    let text = '';
    let live = false;
    if (e.status === 'running' && e.stopRequested) text = t('scanStopped');
    else if (e.status === 'running') { text = e.total ? t('progressGeneric', formatNumber(e.done || 0), formatNumber(e.total), hits) : t('scanStarting'); live = true; }
    else if (e.status === 'queued') { text = t('scanQueued'); live = true; }
    else if (e.status === 'done') text = byDays(e)
      ? t('doneSummaryDays', formatNumber(e.matchedDays || 0), hits)
      : t('doneSummary', formatNumber(e.totalSessions ?? e.matchedDays ?? 0), hits);
    else if (e.status === 'error') text = t('scanError', errorText(e.error));
    else text = e.interrupted ? t('scanInterrupted') : t('scanStopped');
    $('progText').textContent = scanLabel(e) + ' · ' + text;
    $('progText').title = $('progText').textContent;
    $('progBar').hidden = !live;
    fill.style.width = (e.status === 'running' ? pct : 0) + '%';
    top.style.width = (e.status === 'running' ? pct : 0) + '%';
    $('stopBtn').hidden = !live || !!e.stopRequested;
    // a scan that failed, was stopped/interrupted, or left parts unfetched can be run again right here
    $('retryBtn').hidden = live || !(e.status === 'error' || e.status === 'stopped' || e.failedChunks);
    // a failed scan of an ID that is in the history can drop it from there right here (asks first)
    const hkey = Object.keys(currentHistory).find((k) => k.toLowerCase() === e.channel);
    $('delIdBtn').hidden = live || e.status !== 'error' || !hkey || e.platform !== selected;
    const note = $('progNote');
    const notes = [];
    if (e.customKeyword) notes.push(t('customKwTag', e.customKeyword));
    // KickLogz keyword search result (not a scan of the channel's VODs)
    if (e.kwFind) notes.push(t('kfNote', (e.kwFind.keywords || []).join(', '), formatNumber(e.kwFind.days || 7)) + (e.kwFind.inHistory ? '' : ' · ' + t('kfNewChannel')));
    if (e.platform === 'soop' && e.subOnly) notes.push(t('soopSubOnlyNote', formatNumber(e.subOnly)));
    if (e.platform === 'kick' && e.kicklogzVods) notes.push(t('kickKicklogzNote', formatNumber(e.kicklogzVods)));
    if (e.platform === 'kick' && e.archiveVods) notes.push(t('kickArchiveNote', formatNumber(e.archiveVods)));
    if (e.platform === 'kick' && e.subOnly) notes.push(t(e.kicklogzOn ? 'kickSubOnlyMissed' : 'kickSubOnlyOff', formatNumber(e.subOnly)));
    // 1.2.6.0: what a Pro / Premium account would have added — with the real number, only when it matters
    if (!live && e.platform === 'kick' && e.subOnly && klPlanSeen !== 'pro') notes.push(t('nudgeKlPro'));
    if (!live && e.platform === 'twitch' && !(srUse && srAcct && srAcct.premium)) {
      let n = 0;
      for (const gg of e.groups || []) for (const mm of gg.messages || []) if (mm.playback_ts == null && !mm.sr_rec) n++;
      if (n) notes.push(t('nudgeSr', formatNumber(n)));
    }
    note.hidden = !notes.length;
    if (!note.hidden) note.textContent = notes.join(' · ');
    const warn = $('progWarn');
    warn.hidden = !e.failedChunks;
    if (e.failedChunks) warn.textContent = t(e.rateLimited ? 'scanFailedDaysRl' : byDays(e) ? 'scanFailedDays' : e.platform === 'soop' ? 'scanFailedVods' : 'scanFailedChunks', formatNumber(e.failedChunks));
    if (e.failedChunks && e.failReason) warn.textContent += ' (' + e.failReason + ')'; // 1.2.5.37 SOOP diagnosis
  }
  $('retryBtn').addEventListener('click', () => {
    const e = shownScan();
    if (!e) return;
    $('retryBtn').hidden = true;
    doStart(e.platform, e.channel, e.mode === 'new' ? 'new' : 'full', e.customKeyword, e.rangeDays);
  });
  $('delIdBtn').addEventListener('click', () => {
    const e = shownScan();
    if (!e) return;
    const hkey = Object.keys(currentHistory).find((k) => k.toLowerCase() === e.channel);
    if (hkey) deleteEntry(hkey, scanLabel(e));
  });
  $('progWarn').addEventListener('click', () => { if (!$('retryBtn').hidden) $('retryBtn').click(); });
  $('stopBtn').addEventListener('click', () => {
    const e = shownScan();
    if (e) send({ type: 'KWS_SP_SCAN_STOP', id: e.id });
  });

  // ── result tabs + body ──
  const ICON_X = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  const ICON_TR = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 5h9M8.5 3v2M6 5c.5 3 2.5 6 6 8M11 5c-.5 3-3 7-7 9"/><path d="M13 21l4-9 4 9M14.5 18h5"/></svg>';

  // A running tab fills with the theme colour like a charging battery (and breathes a little);
  // nodes are kept between renders so the fill glides instead of jumping.
  // SOOP IDs are hard to read: in the Korean UI show the streamer's nickname when known.
  const KO_UI = /^ko/i.test(KWSi18n.uiLang || '');
  function scanLabel(e) {
    if (e.platform === 'chzzk') { const hc = (e.platform === selected && currentHistory[e.channel]) || null; return e.nickname || (hc && hc.nickname) || e.channel.slice(0, 8) + '…'; } // CHZZK IDs are hashes
    if (e.platform !== 'soop' || !KO_UI) return e.channel;
    const h = (e.platform === selected && currentHistory[e.channel]) || null;
    return e.nickname || (h && h.nickname) || e.channel;
  }
  const scanPct = (e) => (e.total ? Math.min(100, Math.round((e.done || 0) / e.total * 100)) : 0);
  function renderTabs(list, shown) {
    const box = $('rtabs');
    const old = new Map([...box.querySelectorAll('.rtab')].map((n) => [n.dataset.id, n]));
    const nodes = [];
    for (const e of list) {
      let tab = old.get(e.id);
      if (!tab) {
        tab = document.createElement('div');
        tab.className = 'rtab';
        tab.dataset.id = e.id;
        const main = document.createElement('button');
        main.type = 'button';
        main.className = 'rtab-main';
        main.setAttribute('role', 'tab');
        const name = document.createElement('span');
        name.className = 'rtab-name';
        const count = document.createElement('span');
        count.className = 'rtab-count';
        main.append(name, count);
        // click a tab to show it; click the tab that is already shown (finished) → its menu
        main.addEventListener('click', () => {
          const cur = hub[tab.dataset.id];
          if (cur && tab.getAttribute('aria-selected') === 'true' && !isLive(cur)) tabMenu(cur);
          else showScan(selected, tab.dataset.id);
        });
        main.addEventListener('contextmenu', (ev) => { const cur = hub[tab.dataset.id]; if (cur) { ev.preventDefault(); showScan(selected, cur.id); tabMenu(cur); } });
        const x = document.createElement('button');
        x.type = 'button';
        x.className = 'rtab-x';
        x.innerHTML = ICON_X;
        x.addEventListener('click', () => { const cur = hub[tab.dataset.id]; if (cur) confirmClose(cur); });
        tab.append(main, x);
      }
      old.delete(e.id);
      const on = e === shown;
      tab.setAttribute('aria-selected', on ? 'true' : 'false');
      tab.querySelector('.rtab-main').setAttribute('aria-selected', on ? 'true' : 'false');
      tab.classList.toggle('running', e.status === 'running' && !e.stopRequested);
      tab.classList.toggle('queued', e.status === 'queued');
      tab.classList.toggle('done', e.status === 'done');
      tab.style.setProperty('--p', (e.status === 'running' ? Math.max(4, scanPct(e)) : 0) + '%');
      // keyword-search tabs get a magnifier: blue = channel in the history, orange = new channel
      const nameEl = tab.querySelector('.rtab-name');
      nameEl.textContent = scanLabel(e) + (e.customKeyword ? ' ✦' : '');
      if (e.kwFind) {
        const ic = document.createElement('span');
        ic.className = 'rtab-kw' + (e.kwFind.inHistory ? '' : ' new');
        ic.innerHTML = ICON_KWTAB;
        ic.title = e.kwFind.inHistory ? t('kfMenu') : t('kfMenu') + ' · ' + t('kfNewChannel');
        nameEl.prepend(ic);
      }
      tab.querySelector('.rtab-count').textContent = formatNumber(e.matchedLines || hitCount(e));
      const full = scanLabel(e) === e.channel ? e.channel : scanLabel(e) + ' (' + e.channel + ')';
      tab.title = (e.status === 'running' ? full + ' · ' + scanPct(e) + '%' : full) + (e.customKeyword ? '\n' + t('customKwTag', e.customKeyword) : '') + (isLive(e) ? '' : '\n' + t('tabMenuHint'));
      const x = tab.querySelector('.rtab-x');
      x.setAttribute('aria-label', t('closeResult', scanLabel(e)));
      x.title = t('closeResult', scanLabel(e));
      nodes.push(tab);
    }
    let clr = box.querySelector('.rtab-clear');
    if (list.length > 1) {
      if (!clr) {
        clr = document.createElement('button');
        clr.type = 'button';
        clr.className = 'rtab-clear';
        clr.addEventListener('click', () => { const l = scansFor(selected); confirmClearAll(l, shownScan()); });
      }
      clr.textContent = t('clearAll');
      nodes.push(clr);
    }
    let rnd = box.querySelector('.rtab-rand');
    if (list.length && SCAN_SUPPORTED.has(selected)) {
      if (!rnd) {
        rnd = document.createElement('button');
        rnd.type = 'button';
        rnd.className = 'rtab-rand';
        rnd.addEventListener('click', () => randomScan());
      }
      rnd.textContent = '🎲 +' + RANDOM_N;
      rnd.title = t('rndTip', formatNumber(RANDOM_N));
      rnd.setAttribute('aria-label', rnd.title);
      nodes.push(rnd);
    }
    // put them in order (moves existing nodes, keeps their running animation)
    nodes.forEach((n, i) => { if (box.children[i] !== n) box.insertBefore(n, box.children[i] || null); });
    while (box.children.length > nodes.length) box.lastChild.remove();
    // Bring the selected tab into view only when the selection changes (not on every progress
    // update), and only inside the tab strip — scrollIntoView also scrolled the panel itself.
    const sel = box.querySelector('.rtab[aria-selected="true"]');
    const selId = sel ? sel.dataset.id : '';
    if (sel && selId !== lastSelTab) {
      const top = sel.offsetTop, bottom = top + sel.offsetHeight;
      if (top < box.scrollTop) box.scrollTop = top - 4;
      else if (bottom > box.scrollTop + box.clientHeight) box.scrollTop = bottom - box.clientHeight + 4;
    }
    lastSelTab = selId;
  }
  let lastSelTab = '';

  // Same warnings as 1.2.4: closing a tab that is scanning or has results asks first;
  // "close all" asks current-only / all and names the channels still scanning.
  const isLive = (e) => e.status === 'running' || e.status === 'queued';
  // Menu of a finished result tab (click it again, or right-click any tab).
  function tabMenu(e) {
    const others = scansFor(e.platform).filter((x) => x.id !== e.id);
    openDialog((dlg, close) => {
      dlg.append(dlgTitle(scanLabel(e)));
      if (!isLive(e)) {
        dlg.append(dlgOpt(t('tabRescan'), t('tabRescanDesc'), true, () => { close(); startScanFlow(e.channel, { saved: true }); }));
        dlg.append(dlgOpt(t('tabCustomKw'), t('tabCustomKwDesc'), false, () => { close(); customKeywordScan(e); }));
      }
      dlg.append(dlgOpt(t('tabOpenChannel'), '', false, () => {
        close();
        chrome.tabs.create({ url: P.channelUrl(e.platform, e.channel), windowId: windowId ?? undefined, active: true });
      }));
      const hk = Object.keys(currentHistory).find((k) => k.toLowerCase() === e.channel) || e.channel;
      const memoNow = String((currentHistory[hk] && currentHistory[hk].memo) || '').trim();
      dlg.append(dlgOpt(memoNow ? t('histEditMemo') : t('tabAddMemo'), memoNow, false, () => { close(); editMemo(hk, scanLabel(e)); }));
      // 1.2.5.31: stuck / stopped part-way → keep what's been searched, close the tab
      const partial = e.status === 'running' || ((e.status === 'stopped' || e.status === 'error') && (e.done > 0 || e.matchedLines > 0));
      if (partial && !e.customKeyword) {
        const desc = e.safeThrough ? t('tabSavePartialDesc', e.safeThrough) : t('tabSavePartialNoDate');
        dlg.append(dlgOpt(t('tabSavePartial'), desc, false, async () => {
          close();
          const r = await send({ type: 'KWS_SP_SCAN_SAVE_PARTIAL', id: e.id });
          if (r && r.ok) { toast(r.through ? t('tabSavedPartial', r.through) : t('tabSavedPartialNoDate')); }
          else toast(t('scanError', (r && (r.error || r.reason)) || '?'));
        }));
      }
      const danger = (b) => { b.classList.add('danger'); return b; };
      if (others.length) dlg.append(danger(dlgOpt(t('tabCloseOthers'), t('tabCloseOthersDesc', formatNumber(others.length)), false, () => { close(); closeOthers(e, others); })));
      // chosen from the menu: closes right away, no second question
      dlg.append(danger(dlgOpt(t('tabClose'), '', false, () => { close(); send({ type: 'KWS_SP_SCAN_REMOVE', id: e.id }); })));
      // 1.2.6.0: removing the ID from history also closes its tab
      if (currentHistory[hk]) dlg.append(danger(dlgOpt(t('tabDeleteHistory'), t('tabDeleteHistoryDesc'), false, () => { close(); deleteEntry(hk, scanLabel(e), () => send({ type: 'KWS_SP_SCAN_REMOVE', id: e.id })); })));
      dlg.append(dlgOpt(t('cancel'), '', false, close));
    });
  }
  function closeOthers(keep, others) {
    const go = () => others.forEach((x) => send({ type: 'KWS_SP_SCAN_REMOVE', id: x.id }));
    const running = others.filter(isLive).map((x) => scanLabel(x));
    if (!running.length) { go(); return; }
    openDialog((dlg, close) => {
      const w = dlgText(t('clearRunning', running.join(', ')));
      w.classList.add('warn');
      dlg.append(dlgTitle(t('tabCloseOthers')), w,
        dlgOpt(t('closeAnyway'), '', false, () => { close(); go(); }),
        dlgOpt(t('cancel'), '', true, close));
    });
  }
  // Search this channel again with other keywords only (comma-separated, same ~ / - notation),
  // from the start; the saved keywords and the history stay as they are.
  function customKeywordScan(e) {
    openDialog((dlg, close) => {
      const field = document.createElement('input');
      field.type = 'text';
      field.value = e.customKeyword || '';
      field.placeholder = t('customKwPlaceholder');
      field.setAttribute('aria-label', t('tabCustomKw'));
      const go = dlgOpt(t('customKwGo'), '', true, () => {
        const v = field.value.split(',').map((x) => x.trim()).filter(Boolean).join(', ');
        if (!v) { field.focus(); return; }
        close();
        doStart(e.platform, e.channel, 'full', v);
      });
      field.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') { ev.preventDefault(); go.click(); } });
      dlg.append(dlgTitle(t('tabCustomKw') + ' · ' + scanLabel(e)), dlgText(t('customKwDesc')), field, go, dlgOpt(t('cancel'), '', false, close));
      setTimeout(() => { field.focus(); field.select(); }, 0);
    });
  }
  function confirmClose(e) {
    const hits = e.matchedLines || hitCount(e);
    if (!isLive(e) && !hits) { send({ type: 'KWS_SP_SCAN_REMOVE', id: e.id }); return; }
    openDialog((dlg, close) => {
      dlg.append(
        dlgTitle(isLive(e) ? t('closeRunningTitle', scanLabel(e)) : t('closeResultsTitle', scanLabel(e), formatNumber(hits))),
        dlgText(isLive(e) ? t('closeRunningDesc') : t('closeResultsDesc')),
        dlgOpt(t('closeAnyway'), '', false, () => { close(); send({ type: 'KWS_SP_SCAN_REMOVE', id: e.id }); }),
        dlgOpt(t('cancel'), '', true, close));
    });
  }
  function confirmClearAll(list, shown) {
    const running = list.filter(isLive).map((e) => scanLabel(e));
    openDialog((dlg, close) => {
      dlg.append(dlgTitle(t('clearTitle')));
      if (running.length) {
        const w = dlgText(t('clearRunning', running.join(', ')));
        w.classList.add('warn');
        dlg.append(w);
      }
      dlg.append(dlgText(t('clearAsk')));
      if (shown) dlg.append(dlgOpt(t('clearCurrent', scanLabel(shown)), '', false, () => { close(); send({ type: 'KWS_SP_SCAN_REMOVE', id: shown.id }); }));
      dlg.append(
        dlgOpt(t('clearAllTabs', formatNumber(list.length)), running.length ? t('clearAllDesc') : '', false, () => { close(); send({ type: 'KWS_SP_SCAN_CLEAR', platform: selected }); }),
        dlgOpt(t('cancel'), '', true, close));
    });
  }

  // ── home (nothing open): channels with a memo that haven't been searched for a while ──
  const HOME_MIN_DAYS = 7;
  const HOME_MAX = 4;
  // Channels not searched for a while: the ones with a memo first, then the rest — oldest first in
  // each — so once every memo'd channel is up to date the others keep being suggested.
  function homePicks() {
    const now = Date.now();
    const old = historyEntries()
      .filter(({ at }) => at && (now - new Date(at).getTime()) / 86400000 >= HOME_MIN_DAYS)
      .filter(({ id }) => !hub[selected + ':' + id.toLowerCase()])
      .sort((a, b) => (a.at < b.at ? -1 : a.at > b.at ? 1 : 0)); // longest unseen first
    const hasMemo = ({ h }) => !!String(h.memo || '').trim();
    return old.filter(hasMemo).concat(old.filter((x) => !hasMemo(x))).slice(0, HOME_MAX);
  }
  // 1.2.5.21: "🎲 +10" — 10 history channels at random, weighted toward the longest unseen. Skips
  // channels with a tab (running / queued / shown) and ones searched within the red-badge days.
  const RANDOM_N = 10;
  function randomPicks(n) {
    const now = Date.now();
    const minDays = Number.isFinite(redDays) ? redDays : 14;
    const all = historyEntries()
      .filter(({ id }) => !hub[selected + ':' + id.toLowerCase()])
      .map((x) => ({ ...x, age: x.at ? (now - new Date(x.at).getTime()) / 86400000 : 3650 }));
    let pool = all.filter((x) => x.age >= minDays);
    // 1.2.5.25: everything was searched recently (e.g. right after an overnight run) → don't go
    // empty; top up with the longest-unseen of the rest instead.
    if (pool.length < n) pool = pool.concat(all.filter((x) => x.age < minDays).sort((x, y) => y.age - x.age).slice(0, n - pool.length));
    const out = [];
    while (out.length < n && pool.length) {
      const w = pool.map((x) => Math.sqrt(Math.max(1, x.age)));      // older → a bit likelier
      let r = Math.random() * w.reduce((a, b) => a + b, 0);
      let i = 0;
      while (i < pool.length - 1 && (r -= w[i]) > 0) i++;
      out.push(pool[i].id);
      pool = pool.filter((_, k) => k !== i);
    }
    return out;
  }
  async function randomScan() {
    const ids = randomPicks(RANDOM_N);
    if (!ids.length) { toast(t('rndNone')); return; }
    if (selected === 'kick' && !(await klGate())) return; // 1.2.5.41: KickLogz Pro login asked first, once
    ids.forEach((id) => homeScan(id));
    toast(t('rndStarted', formatNumber(ids.length)));
  }
  function homeScan(id) {
    const ch = id.toLowerCase();
    const h = currentHistory[id] || currentHistory[ch];
    const last = h ? (h.lastDate || String(h.searchedAt || h.savedAt || '').slice(0, 10)) : '';
    doStart(selected, ch, /^\d{4}-\d{2}-\d{2}$/.test(last) ? 'new' : 'full');
  }
  // Nothing saved at all (fresh install / reinstall) → offer to bring the old history back.
  let noData = false;
  async function checkNoData() {
    let empty = false;
    try { empty = await KWSDataFolder.isEmpty(); } catch (_) {}
    if (empty !== noData) { noData = empty; if (!shownScan()) renderHome(); }
  }
  $('homeImportFile').addEventListener('click', () => { $('histFile').value = ''; $('histFile').click(); });
  $('homeImportFolder').addEventListener('click', () => pickFolder());
  function renderTips() {
    const lines = String(t('tips_' + selected) || '').split('\n').map((x) => x.trim()).filter(Boolean);
    $('homeTips').hidden = !lines.length;
    $('tipsList').replaceChildren(...lines.map((x) => { const li = document.createElement('li'); li.textContent = x; return li; }));
  }
  function renderHome() {
    renderTips();
    const box = $('home');
    const picks = SCAN_SUPPORTED.has(selected) ? homePicks() : [];
    $('homeImport').hidden = !noData;
    $('homeHead').hidden = !picks.length;
    $('homeList').hidden = !picks.length;
    { // 1.2.5.59: find-new-streamers card
      const main = $('discoverMain');
      main.innerHTML = ICON_FIND;
      const ml = document.createElement('span'); ml.textContent = discoverLabel(); main.append(ml);
      main.onclick = () => discoverDirect();
      $('discoverDesc').textContent = t(selected === 'kick' ? 'discoverDescKick' : selected === 'soop' ? 'discoverDescSoop' : 'discoverDescOther');
      const sr = $('discoverSr');
      sr.hidden = selected !== 'kick' && selected !== 'soop';
      sr.onclick = () => chrome.tabs.create({ url: DISCOVER_URL[selected], windowId: windowId ?? undefined, active: true });
    }
    const quiet = picks.length > 0 || noData;
    document.querySelector('#viewConnected .empty-text').hidden = quiet;
    document.querySelector('#viewConnected .empty-icon').hidden = quiet;
    const rndBtn = $('homeRandom');
    rndBtn.hidden = !SCAN_SUPPORTED.has(selected) || !randomPicks(1).length;
    rndBtn.textContent = '🎲 ' + t('rndHome', formatNumber(RANDOM_N));
    rndBtn.onclick = () => { rndBtn.disabled = true; randomScan(); setTimeout(() => { rndBtn.disabled = false; }, 1500); };
    box.hidden = !picks.length && rndBtn.hidden; // the find button moved to its own card (1.2.5.59)
    if (!picks.length) { $('homeAll').hidden = true; return; }
    $('homeList').replaceChildren(...picks.map(({ id, h, name, at }) => {
      const li = document.createElement('li');
      li.className = 'home-item';
      const text = document.createElement('div');
      text.className = 'home-text';
      const n = document.createElement('span'); n.className = 'home-name'; n.textContent = name;
      if (h.partial) n.append(partialMark(h));
      const memo = document.createElement('span'); memo.className = 'home-memo'; memo.textContent = h.memo || ''; memo.title = h.memo || ''; memo.hidden = !String(h.memo || '').trim();
      const when = document.createElement('span'); when.className = 'home-when'; when.textContent = t('homeWhen', daysAgoLabel(at));
      text.append(n, memo, when);
      const go = document.createElement('button');
      go.type = 'button'; go.className = 'home-go'; go.textContent = t('homeScan');
      go.addEventListener('click', () => { go.disabled = true; homeScan(id); });
      li.append(text, go);
      return li;
    }));
    const all = $('homeAll');
    all.hidden = picks.length < 2;
    all.textContent = t('homeScanAll', formatNumber(picks.length));
    all.onclick = () => { all.disabled = true; picks.forEach(({ id }) => homeScan(id)); setTimeout(() => { all.disabled = false; }, 1500); };
  }


  // ── 1.2.5.53: update check (GitHub Releases of HLGX/KWS) ──
  // The latest release's tag (v1.2.5.54…) is compared with this build's version. Checked when the
  // panel opens, at most every 6 h (cached); "✕" hides the banner until an even newer one comes out.
  // api.github.com answers any origin (CORS *), so no extra permission is needed.
  const UPD_KEY = 'kwsUpdateCheck', UPD_SKIP_KEY = 'kwsUpdateSkip';
  const UPD_API = 'https://api.github.com/repos/HLGX/KWS/releases/latest';
  const UPD_ZIP = 'https://github.com/HLGX/KWS/releases/latest/download/KWS.zip';
  const verParts = (v) => String(v || '').replace(/^v/i, '').split('.').map((x) => parseInt(x, 10) || 0);
  const verNewer = (a, b) => { const x = verParts(a), y = verParts(b); for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d > 0; } return false; };
  async function updFetch(force) {
    let c = null;
    try { c = (await chrome.storage.local.get(UPD_KEY))[UPD_KEY] || null; } catch (_) {}
    if (!force && c && Date.now() - c.at < 6 * 3600000) return c;
    const r = await fetch(UPD_API, { headers: { Accept: 'application/vnd.github+json' }, cache: 'no-store' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const j = await r.json();
    c = { at: Date.now(), tag: String(j.tag_name || '').replace(/^v/i, ''), url: j.html_url || 'https://github.com/HLGX/KWS/releases/latest' };
    try { await chrome.storage.local.set({ [UPD_KEY]: c }); } catch (_) {}
    return c;
  }
  async function updShow(c, fromButton) {
    const mine = chrome.runtime.getManifest().version;
    const newer = c && c.tag && verNewer(c.tag, mine);
    let skip = '';
    try { skip = (await chrome.storage.local.get(UPD_SKIP_KEY))[UPD_SKIP_KEY] || ''; } catch (_) {}
    const ban = $('updBanner');
    if (newer && (fromButton || skip !== c.tag)) {
      $('updText').textContent = t('updAvailable', c.tag);
      $('updGo').href = UPD_ZIP;
      $('updNotes').href = c.url;
      ban.hidden = false;
      $('updLater').onclick = () => { ban.hidden = true; chrome.storage.local.set({ [UPD_SKIP_KEY]: c.tag }).catch(() => {}); };
      $('updGoSet').href = UPD_ZIP;
      $('updGoSet').hidden = false;
      if (!$('updCheckState').textContent) $('updCheckState').textContent = t('updAvailable', c.tag);
    } else ban.hidden = true;
    return newer;
  }
  async function updCheck(force, fromButton) {
    try { const c = await updFetch(force); return { c, newer: await updShow(c, fromButton) }; }
    catch (e) { return { error: String((e && e.message) || e) }; }
  }
  // 1.2.5.57: the one-click self-update (1.2.5.54–56) is gone — Windows Defender flagged the file
  // that downloads + unzips + writes the extension's own files as a trojan (heuristic false positive).
  // Updates are a download link again (banner + Settings).
  $('updCheckBtn').addEventListener('click', async () => {
    const st = $('updCheckState');
    st.textContent = t('updChecking');
    const r = await updCheck(true, true);
    st.textContent = r.error ? t('updFailed', r.error) : r.newer ? t('updAvailable', r.c.tag) : t('updLatest');
    if (r.newer) $('updGoSet').href = UPD_ZIP;
    $('updGoSet').hidden = !r.newer;
  });
  setTimeout(() => updCheck(false, false), 1500);

  // ── log-source activity bar (bottom): which sources are working right now ──
  const API_SOURCES = {
    twitch: [['twitch', 'Native API'], ['zonian', 'Zonian API']],
    kick: [['native', 'Native API'], ['kicklogz', 'KickLogz', 'warn']],
    soop: [['api', 'Native API'], ['vodcore', 'Manual', 'warn'], ['thumb', 'Subs', 'warn']],
    youtube: [['native', 'Native API']],
    chzzk: [['native', 'Native API']],
  };
  function activeSources(platform) {
    const on = {};
    // 1.2.5.20: with a channel tab open, the dots show THAT scan's sources (home screen: all scans)
    const shown = shownScan();
    const pool = shown && shown.platform === platform ? [shown] : Object.values(hub);
    const running = pool.filter((e) => e && e.platform === platform && e.status === 'running' && !e.stopRequested);
    for (const e of running) {
      if (platform === 'twitch') {
        if (e.net && (e.net.zonian !== undefined || e.net.twitch !== undefined)) { on.zonian = on.zonian || !!e.net.zonian; on.twitch = on.twitch || !!e.net.twitch; }
        else if (e.logSource === 'zonian') on.zonian = true;
        else if (e.logSource === 'twitch') on.twitch = true;
        else { on.zonian = true; on.twitch = true; }
        if (e.srBusy) on.sr = true;
      } else if (platform === 'soop') {
        if (e.net) { on.api = on.api || !!e.net.api; on.vodcore = on.vodcore || !!e.net.vodcore; on.thumb = on.thumb || !!e.net.thumb; }
        else on.api = true;
      } else if (platform === 'kick' && e.net) {
        on.native = on.native || !!e.net.native;
        on.kicklogz = on.kicklogz || !!e.net.kicklogz;
      } else on.native = true;
    }
    return { on, count: running.length };
  }
  function renderApiBar() {
    const bar = $('apiBar');
    let srcs = API_SOURCES[selected] || [];
    if (selected === 'twitch' && srUse) srcs = [...srcs, ['sr', 'StreamRecorder']]; // 1.2.6.1: SR chat (dual source)
    const { on, count } = activeSources(selected);
    const TIP = { vodcore: 'Manual Scraping', thumb: 'Subscriber / fan-only VOD being checked', kicklogz: 'Subscriber-only VODs (kicklogz.com)' };
    bar.replaceChildren(...srcs.map(([k, label, kind]) => {
      const it = document.createElement('span');
      it.className = 'api-item' + (on[k] ? ' on' : '') + (kind ? ' ' + kind : '');
      if (TIP[k]) it.title = TIP[k];
      const dot = document.createElement('span'); dot.className = 'api-dot';
      const l = document.createElement('span'); l.textContent = label;
      it.append(dot, l);
      return it;
    }));
    const shown = shownScan();
    const mine = shown && shown.platform === selected ? shown : null;
    if (mine && mine.status === 'running' && !mine.stopRequested) {
      // selected channel tab: its own progress instead of the platform-wide count
      const c = document.createElement('span');
      c.className = 'api-count';
      c.textContent = mine.channel + ' · ' + (mine.total ? Math.min(100, Math.round((mine.done || 0) / mine.total * 100)) + '%' : '…');
      bar.append(c);
    } else if (!mine && count) {
      const c = document.createElement('span');
      c.className = 'api-count';
      c.textContent = t('apiRunning', formatNumber(count));
      bar.append(c);
    }
  }

  function renderResults() {
    const list = scansFor(selected);
    const shown = shownScan();
    renderApiBar();
    $('viewConnected').hidden = !!shown;
    $('viewResults').hidden = !shown;
    if (!shown) { if ($('home').parentNode !== $('viewConnected')) $('viewConnected').append($('home')); renderHome(); }
    renderProgress(shown);
    if (!shown) { lastBodySig = ''; $('rtabs').replaceChildren(); $('rbody').replaceChildren(); return; }
    renderTabs(list, shown);
    const sig = [shown.id, shown.createdAt, shown.status, shown.matchedLines, hitCount(shown), shown.trimmed ? 1 : 0, bodyVer].join('|');
    if (sig === lastBodySig) { placeHomeInResults(shown); return; }
    const sameScan = lastBodySig.split('|').slice(0, 2).join('|') === shown.id + '|' + shown.createdAt;
    lastBodySig = sig;
    const body = $('rbody');
    const keep = sameScan ? body.scrollTop : 0;
    if ($('home').parentNode === body) $('viewConnected').append($('home')); // keep it in the document
    body.replaceChildren(buildBody(shown));
    body.scrollTop = keep;
    placeHomeInResults(shown);
  }
  // A scan with no chat found (yet) shows the suggestions under its status line, too.
  function placeHomeInResults(shown) {
    const noHits = !(shown.groups || []).some((g) => g && (g.messages || []).length);
    const home = $('home');
    if (!noHits) { if (home.parentNode === $('rbody')) $('viewConnected').append(home); return; }
    if (home.parentNode !== $('rbody')) $('rbody').append(home);
    renderHome();
  }

  function stateLine(text) { const d = document.createElement('div'); d.className = 'rstate'; d.textContent = text; return d; }

  function buildBody(e) {
    const frag = document.createDocumentFragment();
    const groups = (e.groups || []).filter((g) => g && (g.messages || []).length);
    if (!groups.length) {
      let text = t('noMatches');
      if (e.status === 'queued') text = t('scanQueued');
      else if (e.status === 'running') text = e.total ? t('noHitsYet') : t('scanStarting');
      else if (e.status === 'error') text = t('scanError', errorText(e.error));
      else if (e.status === 'stopped') text = e.interrupted ? t('scanInterrupted') : t('scanStopped');
      frag.append(stateLine(text));
      return frag;
    }
    const visited = (currentHistory[e.channel] && currentHistory[e.channel].clickedTimes) || {};
    // newest first: YouTube keeps the site's list order (its dates are relative text), others by date
    const sorted = [...groups].sort((a, b) => (typeof a.order === 'number' && typeof b.order === 'number') ? a.order - b.order
      : (a.date < b.date ? 1 : a.date > b.date ? -1 : String(b.key || '').localeCompare(String(a.key || ''))));
    for (const g of sorted) frag.append(buildGroup(e, g, visited));
    return frag;
  }

  // Seconds used to group hits "less than 3 min apart". Twitch hits carry the real chat time
  // (rawTs, an ISO string or ms) — and only some of them a VOD offset (none once the VOD is gone),
  // so the real time comes first; the others (SOOP / YouTube / Kick) use the VOD offset.
  const realSec = (v) => {
    if (v == null || v === '') return NaN;
    const n = typeof v === 'number' ? v : /^\d+$/.test(String(v)) ? Number(v) : Date.parse(v);
    return Number.isFinite(n) ? Math.floor((n < 1e12 ? n * 1000 : n) / 1000) : NaN;
  };
  const secOf = (m) => {
    const r = realSec(m.rawTs);
    if (Number.isFinite(r)) return r;
    const o = Number(m.playback_offset);
    return Number.isFinite(o) ? o : 0;
  };
  // SOOP keeps clicked seconds per VOD ({ titleNo: [seconds] }); the others key by timestamp.
  const isVisited = (e, m, visited) => (e.platform === 'soop'
    ? Array.isArray(visited[m.vod_id]) && visited[m.vod_id].includes(m.playback_offset)
    : e.platform === 'youtube' || e.platform === 'chzzk' ? !!visited[m.vod_id + '_' + m.playback_offset]
    : !!visited[visitedKey(m)]);
  const visitedKey = (m) => m.ts || m.playback_ts || String(m.rawTs ?? m.playback_offset ?? ''); // = kwsVisitedTsKey (1.2.4)

  // Log source names, as in the settings (Twitch: Native API / Zonian, SOOP: Native API / Legacy / Partial).
  const SOURCE_NAMES = { 'kick-native': 'Native API', kicklogz: 'KickLogz', twitch: 'Native API', zonian: 'External (Zonian)', 'soop-api': 'Native API', 'soop-legacy': 'Legacy', 'soop-thumb': 'Partial (thumbnail)', streamrecorder: 'StreamRecorder' };
  const sourceText = (g) => (Array.isArray(g.sourceServices) ? g.sourceServices : []).map((x) => SOURCE_NAMES[x] || x).filter(Boolean).join(' + ');
  const ICON_SRC = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><ellipse cx="12" cy="5.5" rx="7.5" ry="2.8"/><path d="M4.5 5.5v6c0 1.5 3.4 2.8 7.5 2.8s7.5-1.3 7.5-2.8v-6M4.5 11.5v6c0 1.5 3.4 2.8 7.5 2.8s7.5-1.3 7.5-2.8v-6"/></svg>';
  const realTimeFmt = new Intl.DateTimeFormat(KWSi18n.uiLang, { year: 'numeric', month: 'short', day: 'numeric', weekday: 'short', hour: '2-digit', minute: '2-digit', second: '2-digit' });
  function realTime(m) {
    const v = m.rawTs;
    let ms = null;
    if (typeof v === 'number') ms = v > 1e12 ? v : v > 1e9 ? v * 1000 : null;
    else if (v) { const p = new Date(v).getTime(); ms = Number.isNaN(p) ? null : p; }
    return ms ? realTimeFmt.format(new Date(ms)) : '';
  }

  function buildGroup(e, g, visited) {
    const sec = document.createElement('section');
    sec.className = 'rgroup';
    const gkey = e.id + '|' + (g.key || g.date);
    const msgs = g.messages.slice().sort((a, b) => secOf(a) - secOf(b));

    const head = document.createElement('div');
    head.className = 'rg-head';
    const title = document.createElement('div');
    title.className = 'rg-title';
    const date = document.createElement('span');
    date.className = 'rg-date';
    const d = /^\d{4}-\d{2}-\d{2}$/.test(g.displayDate || g.date || '') ? formatDate(new Date((g.displayDate || g.date) + 'T00:00:00')) : (g.displayDate || g.date || '');
    date.textContent = d + ' ';
    const n = document.createElement('span');
    n.className = 'n';
    n.textContent = t('groupHits', formatNumber(msgs.length));
    date.append(n);
    title.append(date);
    const src = sourceText(g);
    if (src) {
      const ic = document.createElement('span');
      ic.className = 'rg-src';
      ic.innerHTML = ICON_SRC;
      ic.title = t('logSourceTip', src) + (g.partial ? '\n' + t('partialTip') : '');
      ic.setAttribute('aria-label', ic.title);
      date.append(ic);
      head.title = ic.title;
    }
    const vods = [...new Set(msgs.map((m) => m.vod_title).filter((x) => x && x !== '(CDN recovered)'))];
    if (vods.length) {
      const v = document.createElement('span');
      v.className = 'rg-vod';
      v.textContent = vods.join(' · ');
      v.title = vods.join('\n');
      title.append(v);
    }
    const tr = document.createElement('button');
    tr.type = 'button';
    tr.className = 'rg-tr';
    tr.innerHTML = ICON_TR;
    const trLabel = document.createElement('span');
    trLabel.textContent = trShown.has(gkey) ? t('translateHide') : trBusy.has(gkey) ? t('translating') : t('translate');
    tr.append(trLabel);
    tr.title = t('translateGroup');
    tr.addEventListener('click', () => toggleTranslate(gkey, msgs));
    head.append(title, tr);
    sec.append(head);

    // clusters: runs of 2+ hits less than 3 minutes apart
    let i = 0;
    while (i < msgs.length) {
      let j = i + 1;
      while (j < msgs.length && secOf(msgs[j]) - secOf(msgs[j - 1]) < CLUSTER_GAP_SEC) j++;
      if (j - i >= 2) {
        const box = document.createElement('div');
        box.className = 'rcluster';
        const lab = document.createElement('div');
        lab.className = 'rcluster-label';
        const mins = Math.max(1, Math.ceil((secOf(msgs[j - 1]) - secOf(msgs[i])) / 60));
        lab.textContent = t('cluster', formatNumber(j - i), formatNumber(mins));
        box.append(lab);
        for (let k = i; k < j; k++) box.append(buildHit(e, msgs[k], visited, gkey, g));
        sec.append(box);
      } else {
        sec.append(buildHit(e, msgs[i], visited, gkey, g));
      }
      i = j;
    }
    return sec;
  }

  function escapeRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
  function highlight(el, text, words) {
    const ws = (words || []).map((w) => String(w).replace(/^~/, '')).filter((w) => w && w !== 'regex').sort((a, b) => b.length - a.length);
    if (!ws.length) { el.textContent = text; return; }
    const re = new RegExp('(' + ws.map(escapeRe).join('|') + ')', 'gi');
    let last = 0;
    for (const m of text.matchAll(re)) {
      if (m.index > last) el.append(text.slice(last, m.index));
      const mark = document.createElement('mark');
      mark.textContent = m[0];
      el.append(mark);
      last = m.index + m[0].length;
    }
    if (last < text.length) el.append(text.slice(last));
  }

  // 1.2.5.44: store a hit as clicked from the panel itself (same keys as the pages: isVisited above).
  // Only for a channel already in the history — never creates an entry.
  async function rememberVisited(e, m) {
    const key = P.HISTORY_KEYS[e.platform];
    if (!key) return;
    try {
      const d = await chrome.storage.local.get(key);
      const hist = d[key] || {};
      const k = Object.keys(hist).find((x) => x.toLowerCase() === e.channel);
      if (!k || !hist[k] || typeof hist[k] !== 'object') return;
      const ct = { ...(hist[k].clickedTimes || {}) };
      if (e.platform === 'soop') {
        const arr = Array.isArray(ct[m.vod_id]) ? ct[m.vod_id].slice() : [];
        if (!arr.includes(m.playback_offset)) arr.push(m.playback_offset);
        ct[m.vod_id] = arr;
      } else if (e.platform === 'youtube' || e.platform === 'chzzk') ct[m.vod_id + '_' + m.playback_offset] = true;
      else { const vk = visitedKey(m); if (!vk) return; ct[vk] = true; }
      hist[k] = { ...hist[k], clickedTimes: ct };
      await chrome.storage.local.set({ [key]: hist });
    } catch (_) {}
  }
  function srRequest(e, m, st) {
    if (!srUse || !['twitch', 'kick', 'soop', 'chzzk'].includes(e.platform)) return null;
    const ts = srMs(m);
    const base = { platform: e.platform, channel: e.channel, title: m.vod_title || '' };
    if (m.sr_rec) return { ...base, recId: m.sr_rec, recOff: m.sr_off || 0, ts };
    if (e.platform === 'twitch' && (st.noOffset || srTwAlways) && ts) return { ...base, ts };
    if (e.platform === 'kick' && (st.kickNoVod || st.kickSubOnly) && (ts || m.playback_offset != null)) return { ...base, ts, date: m._date || '', off: m.playback_offset };
    return null;
  }
  function srMs(m) {
    const v = m.rawTs;
    if (typeof v === 'number') return v > 1e12 ? v : v > 1e9 ? v * 1000 : 0;
    const p = v ? Date.parse(v) : NaN;
    return Number.isNaN(p) ? 0 : p;
  }
  // a hit that opens in the StreamRecorder player (one popup window, reused)
  function buildSrHit(e, m, visited, g, req) {
    const row = document.createElement('div');
    row.className = 'hit';
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'hit-time sr';
    btn.textContent = m.playback_ts || (m.sr_rec ? fmtSec(m.sr_off || 0) : (m.ts || '?'));
    const rt = realTime(m);
    const src = g ? sourceText(g) : '';
    btn.title = [t('srOpenTip'), m.vod_title, rt ? t('realTimeTip', rt) : '', src ? t('logSourceTip', src) : ''].filter(Boolean).join('\n');
    if (isVisited(e, m, visited)) btn.classList.add('visited');
    btn.addEventListener('click', async () => {
      btn.classList.add('visited');
      rememberVisited(e, m);
      // logged out of StreamRecorder (last check) → say so first, like KickLogz
      if (srAcct && srAcct.loggedIn === false) {
        const fresh = await send({ type: 'KWS_SR_ACCOUNT', force: true });
        if (fresh && !fresh.error) srAcct = fresh;
        if (srAcct && srAcct.loggedIn === false) {
          openDialog((dlg, close) => dlg.append(dlgTitle(t('srLoginTitle')), dlgText(t('srLoginText')),
            dlgOpt(t('svcLogin'), '', true, () => { close(); chrome.tabs.create({ url: 'https://streamrecorder.io/login', active: true }).catch(() => {}); }),
            dlgOpt(t('cancel'), '', false, close)));
          return;
        }
      }
      const r = await send({ type: 'KWS_SR_OPEN', req });
      if (!(r && r.ok)) toast(t('srFailed', (r && r.error) || '?'));
    });
    const text = document.createElement('div');
    text.className = 'hit-text';
    const nick = document.createElement('span');
    nick.className = 'hit-nick';
    nick.textContent = m.username || '?';
    const msg = document.createElement('span');
    msg.className = 'hit-msg';
    highlight(msg, String(m.message || ''), m.keywords);
    text.append(nick, msg);
    row.append(btn, text);
    return row;
  }
  function fmtSec(s) { s = Math.max(0, Math.floor(s)); return [Math.floor(s / 3600), Math.floor((s % 3600) / 60), s % 60].map((v) => String(v).padStart(2, '0')).join(':'); }
  function buildHit(e, m, visited, gkey, g) {
    const row = document.createElement('div');
    row.className = 'hit';
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'hit-time';
    // Twitch without a VOD offset: 1.2.4 showed "⚠ Time error" / "⚠ VOD expired", not the
    // broadcast clock (which looked like a VOD time). The real time stays in the tooltip.
    const noOffset = e.platform === 'twitch' && m.playback_ts == null;
    // Kick (KickLogz Pro): a past broadcast whose VOD is gone — same look as Twitch's "VOD expired"
    const kickNoVod = e.platform === 'kick' && m.vod_state === 'expired' && m.vod_id == null && !m.vod_source;
    // 1.2.5.21: Kick subscriber-only VOD — can't be played; say so instead of loading something else
    const kickSubOnly = e.platform === 'kick' && m.vod_state === 'subonly';
    // 1.2.6.0: StreamRecorder takes the hits KWS can't play (VOD gone / sub-only / no VOD offset /
    // found in StreamRecorder chat) — and every Twitch hit when "always" is on (Korea)
    const srReq = srRequest(e, m, { noOffset: e.platform === 'twitch' && m.playback_ts == null, kickNoVod: e.platform === 'kick' && m.vod_state === 'expired' && m.vod_id == null && !m.vod_source, kickSubOnly });
    if (srReq) return buildSrHit(e, m, visited, g, srReq);
    btn.textContent = kickSubOnly ? t('timeSubOnly') : (noOffset || kickNoVod) ? (m.vod_state === 'expired' ? t('timeExpired') : t('timeError')) : (m.playback_ts || m.ts || '?');
    if (noOffset || kickNoVod || kickSubOnly) btn.classList.add('err');
    // Twitch hits without a resolved VOD can still be tried (1.2.4 looked the VOD up on click).
    const playable = !kickSubOnly && (m.vod_id != null || !!m.vod_source || (e.platform === 'twitch' && m.rawTs != null));
    const errBtn = noOffset || kickNoVod || kickSubOnly;
    btn.disabled = !playable && !errBtn; // 1.2.5.44: ⚠ buttons can be clicked just to mark them as seen
    if (!playable) {
      const rt = realTime(m);
      const src = (kickNoVod || kickSubOnly) && g ? sourceText(g) : '';
      btn.title = (kickNoVod || kickSubOnly)
        ? [t(kickSubOnly ? 'kickSubOnlyTip' : 'kickNoVodTip'), m.vod_title, m.playback_ts ? t('vodOffsetTip', m.playback_ts) : '', rt ? t('realTimeTip', rt) : '', src ? t('logSourceTip', src) : ''].filter(Boolean).join('\n')
        : (rt ? t('realTimeTip', rt) : '');
      if (errBtn) {
        if (isVisited(e, m, visited)) btn.classList.add('visited');
        btn.addEventListener('click', () => { btn.classList.add('visited'); rememberVisited(e, m); });
      }
    }
    if (playable) {
      const rt = realTime(m);
      const src = g ? sourceText(g) : '';
      btn.title = [noOffset ? (m.vod_state === 'expired' ? t('timeExpiredTip') : t('timeErrorTip')) : t('openAtMoment'), m.vod_title, m.playback_ts ? t('vodOffsetTip', m.playback_ts) : '', rt ? t('realTimeTip', rt) : '', src ? t('logSourceTip', src) : ''].filter(Boolean).join('\n');
      if (isVisited(e, m, visited)) btn.classList.add('visited');
      btn.addEventListener('click', async () => {
        if (btn.classList.contains('busy')) return;
        btn.classList.add('busy');
        if (errBtn) { btn.classList.add('visited'); rememberVisited(e, m); } // ⚠ time error etc.: remembered even if it can't open
        const r = await openHit(e, m);
        btn.classList.remove('busy');
        if (r && r.ok) btn.classList.add('visited');
        else toast(r && r.error ? r.error : t('openVodFailed'));
      });
    }
    const text = document.createElement('div');
    text.className = 'hit-text';
    const nick = document.createElement('span');
    nick.className = 'hit-nick';
    nick.textContent = m.username || '?';
    const msg = document.createElement('span');
    msg.className = 'hit-msg';
    highlight(msg, String(m.message || ''), m.keywords);
    text.append(nick, msg);
    if (trShown.has(gkey)) {
      const tx = trCache.get(trLang() + '|' + (m.message || ''));
      if (tx != null && tx !== m.message) {
        const tr = document.createElement('span');
        tr.className = 'hit-tr';
        tr.textContent = tx;
        text.append(tr);
      } else if (tx === undefined && trFailed.has(gkey)) {
        const er = document.createElement('span');
        er.className = 'hit-err';
        er.textContent = t('translateFailed');
        text.append(er);
      }
    }
    row.append(btn, text);
    return row;
  }

  // ── per-date translation (Google Translate, same endpoint as 1.2.4) ──
  const trCache = new Map();   // "<lang>|<text>" → translation
  const trShown = new Set();   // group keys showing translations
  const trBusy = new Set();
  const trFailed = new Set();
  let trLangValue = null;
  const trLang = () => trLangValue || defaultTranslateLang();
  async function loadTrLang() {
    try { trLangValue = (await chrome.storage.local.get(TRANSLATE_KEY))[TRANSLATE_KEY] || null; } catch (_) {}
  }
  async function translateOne(text, lang) {
    const key = lang + '|' + text;
    if (trCache.has(key)) return trCache.get(key);
    const data = await globalThis.KWSGTranslate(text, lang); // 1.2.5.46: rotates gtx / dict-chrome-ex / at (platform.js)
    const out = ((data && data[0]) || []).map((x) => (x && x[0]) || '').join('').trim();
    if (!out) throw new Error('empty translation');
    trCache.set(key, out);
    return out;
  }
  async function toggleTranslate(gkey, msgs) {
    if (trShown.has(gkey)) { trShown.delete(gkey); bodyVer++; renderResults(); return; }
    if (trBusy.has(gkey)) return;
    trBusy.add(gkey);
    trFailed.delete(gkey);
    bodyVer++; renderResults();
    await loadTrLang();
    const lang = trLang();
    const texts = [...new Set(msgs.map((m) => String(m.message || '')).filter(Boolean))];
    let failed = 0;
    let next = 0;
    const worker = async () => {
      while (next < texts.length) {
        const s = texts[next++];
        try { await translateOne(s, lang); } catch (_) { failed++; }
      }
    };
    await Promise.all(Array.from({ length: Math.min(6, texts.length) }, worker));
    trBusy.delete(gkey);
    if (failed) trFailed.add(gkey);
    if (failed === texts.length && texts.length) toast(t('translateFailed'));
    trShown.add(gkey);
    bodyVer++; renderResults();
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && KWSDataFolder.HISTORY_KEYS.concat(['twitchKwsKeywordProfile']).some((k) => changes[k])) checkNoData();
  });
  checkNoData();
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'session' && changes[SCANS_KEY]) {
      hub = changes[SCANS_KEY].newValue || {};
      renderResults();
      if (!histPop.hidden) { const a = activeIndex; renderHistoryList(); activeIndex = a; markCurrentRow(); }
    } else if (area === 'local' && changes[TRANSLATE_KEY]) {
      trLangValue = changes[TRANSLATE_KEY].newValue || null;
    }
  });

  // ───────────────────────── open a hit ─────────────────────────
  // The 1.2.4 inline player opens on the platform's own site: the current tab if it is that site,
  // else another tab of it in this window, else the site's main page in a new tab. The page's KWS
  // saves the visited mark. YouTube opens the watch page (scan_hub.js).
  function openHit(e, m) {
    return send({ type: 'KWS_SP_OPEN_VOD', platform: e.platform, item: m, windowId });
  }

  // ── a KWS badge on another site asked for a scan (scan_hub.js KWS_SP_EXTERNAL_SCAN) ──
  // Ask here (new VODs only / everything) and start, without leaving that site.
  let askBusy = false;
  async function takeAsk(ask) {
    if (!ask || askBusy || Date.now() - (ask.at || 0) > 60000) return;
    if (typeof ask.windowId === 'number' && windowId != null && ask.windowId !== windowId) return;
    askBusy = true;
    try {
      await chrome.storage.session.remove('kwsSpAsk');
      closeHistPop();
      if (selected !== ask.platform) selectPlatform(ask.platform);
      await render(++renderSeq);
      await startScanFlow(ask.channel, { badge: true });
    } finally { askBusy = false; }
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'session' && changes.kwsSpAsk && changes.kwsSpAsk.newValue) takeAsk(changes.kwsSpAsk.newValue);
  });

  // ───────────────────────── data folder (auto-save, see data_folder.js) ─────────────────────────
  // The panel picks the folder (needs a click) and restores from it; the background writes to it.
  const DF = KWSDataFolder;
  const dfSupported = typeof window.showDirectoryPicker === 'function';
  let dfStatus = { state: 'none' };
  let dfDirty = false; // changes the background could not write (no folder access right now)

  const timeLabel = (iso) => {
    try { return new Intl.DateTimeFormat(KWSi18n.uiLang, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }).format(new Date(iso)); } catch (_) { return iso || ''; }
  };
  function renderDataFolder() {
    const st = dfStatus || { state: 'none' };
    const line = $('dataFolderStatus');
    const btn = $('dataFolderBtn');
    line.classList.remove('err');
    if (!dfSupported) { line.textContent = t('dataFolderUnsupported'); btn.hidden = true; $('dataNote').hidden = true; return; }
    btn.hidden = false;
    if (st.state === 'ok') { line.textContent = t('dataFolderStatus', st.name || '', timeLabel(st.savedAt)); btn.textContent = t('dataFolderChange'); }
    else if (st.state === 'needsPermission') { line.textContent = t('dataFolderNeedsPermission', st.name || ''); btn.textContent = t(dfDirty ? 'dataNoteSave' : 'dataFolderAllow'); }
    else if (st.state === 'error') { line.textContent = t('dataFolderError', st.error || '?'); line.classList.add('err'); btn.textContent = t('dataFolderChange'); }
    else { line.textContent = t('dataFolderNone'); btn.textContent = t('dataFolderPick'); }
    // Only worth a notice when something is actually waiting to be written.
    $('dataNote').hidden = !(st.state === 'needsPermission' && dfDirty);
  }
  async function loadDataStatus() {
    try {
      const d = await chrome.storage.local.get([DF.STATUS_KEY, DF.DIRTY_KEY]);
      dfStatus = d[DF.STATUS_KEY] || { state: 'none' };
      dfDirty = !!d[DF.DIRTY_KEY];
    } catch (_) {}
    // The stored status may be stale after a browser restart: ask the handle itself.
    const h = dfSupported ? await DF.getHandle() : null;
    if (!h) dfStatus = { state: 'none' };
    else if (await DF.permission(h) !== 'granted') dfStatus = { ...dfStatus, state: 'needsPermission', name: h.name };
    else if (dfStatus.state === 'needsPermission' || dfStatus.state === 'none') dfStatus = { ...dfStatus, state: 'ok', name: h.name };
    renderDataFolder();
    return h;
  }
  // The panel writes with its own folder grant (the background may not hold one).
  async function saveNow() {
    const h = await DF.getHandle();
    if (!h) return { state: 'none' };
    const st = await DF.save(h);
    if (st.state === 'ok') chrome.storage.local.remove(DF.DIRTY_KEY).catch(() => {});
    return st;
  }
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || msg.type !== 'KWS_SP_DATA_SAVE_REQUEST') return;
    (async () => {
      const h = await DF.getHandle();
      if (!h || await DF.permission(h) !== 'granted') return { state: 'needsPermission' };
      return saveNow();
    })().then(sendResponse, () => sendResponse({ state: 'error' }));
    return true;
  });

  // After a folder is connected (or reconnected): empty here → restore from the file; data on
  // both sides → ask; otherwise just save.
  async function afterConnect(handle, { askOnConflict }) {
    const file = await DF.readFile(handle);
    if (file && await DF.isEmpty()) {
      const n = await DF.restore(file, 'replace');
      toast(t('dataRestored', formatNumber(n)));
      await saveNow();
      return;
    }
    if (file && askOnConflict) {
      const when = file.savedAt ? timeLabel(file.savedAt) : '?';
      openDialog((dlg, close) => {
        dlg.append(dlgTitle(t('dataFolderExistingTitle')), dlgText(t('dataFolderExistingDesc', when, formatNumber(DF.countRecords(file.keys)))),
          dlgOpt(t('dataFolderLoad'), t('dataFolderLoadDesc'), true, async () => {
            close();
            const n = await DF.restore(file, 'merge');
            toast(t('dataRestored', formatNumber(n)));
            await saveNow();
          }),
          dlgOpt(t('dataFolderOverwrite'), t('dataFolderOverwriteDesc'), false, async () => {
            close();
            await DF.backupExisting(handle);
            await saveNow();
            toast(t('dataSavedNow'));
          }));
      });
      return;
    }
    await saveNow();
    toast(t('dataSavedNow'));
  }

  async function pickFolder() {
    let handle;
    try { handle = await window.showDirectoryPicker({ id: 'kws-data', mode: 'readwrite', startIn: 'documents' }); }
    catch (e) { if (e && e.name !== 'AbortError') setDataStatus(String(e.message || e), 'err'); return; }
    await DF.setHandle(handle);
    await afterConnect(handle, { askOnConflict: true });
    loadDataStatus();
  }
  async function reconnect() {
    const h = await DF.getHandle();
    if (!h) return pickFolder();
    let p = 'denied';
    try { p = await h.requestPermission({ mode: 'readwrite' }); } catch (_) {}
    if (p !== 'granted') { loadDataStatus(); return; }
    await afterConnect(h, { askOnConflict: false });
    loadDataStatus();
  }
  $('dataFolderBtn').addEventListener('click', () => (dfStatus.state === 'needsPermission' ? reconnect() : pickFolder()));
  $('dataNoteBtn').addEventListener('click', reconnect);
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[DF.DIRTY_KEY]) { dfDirty = !!changes[DF.DIRTY_KEY].newValue; renderDataFolder(); }
    if (area === 'local' && changes[DF.STATUS_KEY]) { dfStatus = changes[DF.STATUS_KEY].newValue || { state: 'none' }; renderDataFolder(); if (dfStatus.state === 'needsPermission') loadDataStatus(); }
  });

  // Panel opened on an empty install with the folder still connected → restore quietly.
  async function dataFolderStartup() {
    const h = await loadDataStatus();
    if (!h || dfStatus.state !== 'ok') return;
    // changes the background could not write while the panel was closed
    try { if ((await chrome.storage.local.get(DF.DIRTY_KEY))[DF.DIRTY_KEY] && !(await DF.isEmpty())) await saveNow(); } catch (_) {}
    if (!(await DF.isEmpty())) return;
    const file = await DF.readFile(h);
    if (!file || !DF.countRecords(file.keys)) return;
    const n = await DF.restore(file, 'replace');
    toast(t('dataRestored', formatNumber(n)));
  }

  // ───────────────────────── follow this window's active tab ─────────────────────────
  chrome.tabs.onActivated.addListener((info) => {
    if (windowId == null || info.windowId === windowId) sync();
  });
  chrome.tabs.onUpdated.addListener((tabId, change, tab) => {
    if (!tab.active || (windowId != null && tab.windowId !== windowId)) return;
    if (change.url || change.status === 'complete') sync();
  });
  // Keywords or history edited elsewhere (on-page panels, other tabs) → refresh.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (Object.keys(changes).some((k) => WATCHED_KEYS.has(k))) render(++renderSeq);
  });

  await loadHub();
  loadTrLang();
  await sync();
  try { takeAsk((await chrome.storage.session.get('kwsSpAsk')).kwsSpAsk); } catch (_) {}
  dataFolderStartup().catch((e) => console.warn('[KWS SP] data folder', e));
})();
