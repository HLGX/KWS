// KWS 1.2.5 — background side of the data folder (see data_folder.js).
// Whenever a history, keyword or setting changes — from the panel, a scan finishing, or a page —
// the data is written to the chosen folder a few seconds later, whether or not the panel is open.
(function () {
  const DF = self.KWSDataFolder;
  if (!DF) return;
  const WATCH = new Set(DF.DATA_KEYS);
  let timer = null;
  let running = null;
  let again = false;

  async function saveNow() {
    if (running) { again = true; return running; }
    running = (async () => {
      try {
        let st = await DF.save(null, { quiet: true });
        if (st && st.state === 'needsPermission') {
          // Chrome may keep the folder grant only for the side panel page: let an open panel write.
          let r = null;
          try { r = await chrome.runtime.sendMessage({ type: 'KWS_SP_DATA_SAVE_REQUEST' }); } catch (_) {}
          if (r && r.state && r.state !== 'needsPermission') st = r;
          else await chrome.storage.local.set({ [DF.DIRTY_KEY]: true }); // written when the panel opens
        } else if (st && st.state === 'ok') {
          await chrome.storage.local.remove(DF.DIRTY_KEY);
        }
        return st;
      } finally {
        running = null;
        if (again) { again = false; schedule(500); }
      }
    })();
    return running;
  }
  function schedule(ms) {
    clearTimeout(timer);
    timer = setTimeout(saveNow, ms);
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (Object.keys(changes).some((k) => WATCH.has(k))) schedule(3000);
  });

  // On browser start: refresh the status line (a folder whose permission was not kept shows
  // "reconnect" in the panel) and write once, in case something changed while it was closed.
  chrome.runtime.onStartup.addListener(() => schedule(2000));

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || msg.type !== 'KWS_SP_DATA_SAVE_NOW') return;
    clearTimeout(timer);
    saveNow().then((st) => sendResponse(st || { state: 'none' }), (e) => sendResponse({ state: 'error', error: String(e && e.message || e) }));
    return true;
  });
})();
