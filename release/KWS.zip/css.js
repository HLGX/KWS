function getLogoCSS() { return `
      .ll_1_logo_v5{
          transform:translate(-0px,-4px);
      }
      .ll_1_logo_v4{
          transform:translate(-0px,-5.5px);
      }
      .ll_1_logo_v3{
          transform:translate(-0px,-6.5px);
      }
      .ll_1_logo_v2{
          transform:translate(-0px,-7.5px);
      }
      .ll_1_logo_v1{
          transform:translate(-0px,-8.5px);
      }

      .rightlogo_v5{
          transform:translate(-0px,-4.5px);
      }
      .rightlogo_v4{
          transform:translate(-0px,-3px);
      }
      .rightlogo_v3{
          transform:translate(-0px,-2px);
      }
      .rightlogo_v2{
          transform:translate(-0px,-1px);
      }
      .rightlogo_v1{
          transform:translate(-0px,-0px);
      }
      .left_vlogo{
          visibility:hidden;
          transform:translate(-0px,-2px);
      }
      #tvd_clipper_logo:hover .vlogo{
          transition:transform 200ms;
          transform:translate(-0px,0px);
      }
      #tvd_clipper_logo:hover .ll_vlogo{
          visibility:hidden;
      }
      #tvd_clipper_logo:hover .left_vlogo{
          visibility:visible;
      }
      #tvd_clipper_logo:active .left_vlogo{
          transform:rotate(17deg) translate(2.4px,-0.3px);
          visibility:visible;
      }
      .d_vlogo{
          transform:translate(-0px,1.6px);
      }
      #tvd_clipper_logo{
          transition:transform 200ms;
          transform:rotate(-90deg);
      }
      #tvd_clipper_logo:hover{
          transform:rotate(-0deg);
      }
`}
function getMainAppCss(){ return `
  .fill_contrast_icon{
    fill:${main_app_colors()?.contrast_icon};
  }
  .fill_menu_bg{
    fill:${main_app_colors()?.menu_bg};
  }
  .fill_bg{
    fill:${main_app_colors()?.bg};
  }
  .fill_icon_color:{
    fill:${main_app_colors()?.icon_color};
  }
  .stroke_icon_color{
    stroke:${main_app_colors()?.icon_color};
  }
  .whitetext{
    color: #ffffff !important;
  }
  .build_container {
    background:${main_background_gradient() || main_app_colors()?.bg};
    color: ${main_app_colors()?.text};
  }
  .menu_body{
    background:${main_app_colors()?.menu_bg};
    color: ${main_app_colors()?.text};
  }
  .custom_checkbox{
    border-radius: 0.4em;
    border: 1px solid ${main_app_colors()?.contrast_icon};
    appearance: none;
    -webkit-appearance: none;
    outline: none;
    cursor: pointer;
  }

  .custom_checkbox:checked{
    appearance: auto;
    clip-path: xywh(0 0px 100% 100% round 10% 10%);
    background-color: ${main_app_colors()?.contrast_icon};
  }
    .pad8 {
        padding:8px;
    }
    .gen_btn {
      box-shadow: ${main_app_colors()?.input_shadow}28 2px 1px 2px 0px, ${main_app_colors()?.input_inset}80 -3px -2px 3px -1px;
    }
    .gen_btn:hover {
      box-shadow: ${main_app_colors()?.input_shadow}48 3px 2px 3px 0px, ${main_app_colors()?.input_inset}80 -3px -3px 3px -1px;
    }
    .gen_btn:active {
        box-shadow:
        -2px -1px 2px 0px ${main_app_colors()?.input_inset},
        1px 1px 1px 0px ${main_app_colors()?.input_shadow},
        2px 1px 1px 0px ${main_app_colors()?.input_shadow} inset,
        -1px -1px 2px 0px ${main_app_colors()?.input_inset} inset;
    }
    .move_btn {
      box-shadow: ${main_app_colors()?.btn_border}28 2px 1px 2px 0px, ${main_app_colors()?.btn_border}80 -3px -2px 3px -1px;
    }
    .move_btn:hover{
      box-shadow: ${main_app_colors()?.btn_border}48 3px 2px 3px 0px, ${main_app_colors()?.btn_border}80 -3px -3px 3px -1px;
    }
    .move_btn:active {
        background:${main_app_colors()?.btn_border}30;
        box-shadow:
        -2px -1px 2px 0px ${main_app_colors()?.btn_border},
        1px 1px 1px 0px ${main_app_colors()?.btn_border},
        2px 1px 1px 0px ${main_app_colors()?.input_shadow} inset,
        -1px -1px 2px 0px ${main_app_colors()?.input_inset} inset;
    }

    .res_option {
        text-align:center;
        color:${main_app_colors()?.icon_color};
        padding:0px;
        background:${main_app_colors()?.bg}50;
        margin:auto;
        border-radius:0.2em;
        cursor: pointer;
        transition: all 111ms;
    }
    .res_option:hover {
        color:${main_app_colors()?.bg};
        background:${main_app_colors()?.menu_bg};
    }
    .res_option:active {
        color:${main_app_colors()?.bg};
        background:${main_app_colors()?.icon_color};
        box-shadow:-0px -0px 1px 0px ${main_app_colors()?.bg}80,
        2px 1px 2px 0px ${main_app_colors()?.bg},
        2px 1px 1px 0px ${main_app_colors()?.bg_shadow} inset,
        -2px -1px 1px 0px ${main_app_colors()?.bg_highlight}50 inset;
    }
    .res_option.checked {
        color:${main_app_colors()?.bg};
        background:${main_app_colors()?.icon_color};
        box-shadow: rgba(0, 0, 0, 0.1) 1px 2px 3px 1px;
    }
    .hover_btn {
        box-shadow: rgba(0, 0, 0, 0.1) 0px 1px 2px 0px;
        cursor: pointer;
        border-radius: 50%;
        transition: all 111ms;
        user-select: none;
    }
    .hover_btn:hover {
        box-shadow: ${main_app_colors()?.input_shadow}48 4px 2px 4px 0px, ${main_app_colors()?.input_inset}80 -4px -2px 4px -3px;
    }
    .hover_btn:active {
        box-shadow:
        -1px -1px 1px 0px ${main_app_colors()?.input_inset},
        1px 1px 1px 0px ${main_app_colors()?.input_shadow},
        4px 4px 4px 0px ${main_app_colors()?.input_shadow} inset,
        -2px -2px 4px 0px ${main_app_colors()?.input_inset} inset;
    }
    .automargin{
      margin:auto;
    }
    .base_font{
      font-size:1em;
    }
    .textarea {
        autocomplete: off !important;
        outline: none !important;
        border-radius: 0.4em;
        border: 0px;
        background: transparent;
        box-shadow: ${main_app_colors()?.input_shadow} 1px 2px 3px 1px inset, ${main_app_colors()?.input_inset}50 -1px -2px 3px 2px inset;
        color: ${main_app_colors()?.text};
    }
    .textarea:hover {
        box-shadow: ${main_app_colors()?.input_shadow} 2px 3px 4px 1px inset, ${main_app_colors()?.input_inset}50 -2px -2px 4px 2px inset;
    }
    .textarea:focus {
        background: transparent !important;
        box-shadow: ${main_app_colors()?.input_shadow} 3px 5px 4px 1px inset, ${main_app_colors()?.input_inset}50 -2px -2px 4px 2px inset;
    }
    .textarea:active {
        background: transparent !important;
        box-shadow: ${main_app_colors()?.input_shadow} 3px 4px 4px 1px inset, ${main_app_colors()?.input_inset}50 -2px -2px 4px 2px inset;
    }
    .textarea::placeholder {
        color:${main_app_colors()?.placeholder};
        opacity: 1;
    }
    .textarea::-ms-input-placeholder {
        color: ${main_app_colors()?.placeholder};
    }
    .load_box{
        border-radius:2em;
        padding:2px;
        color:transparent;
        background:transparent;
    }
    .preview_img {
        border-radius:0.4em;
        transform:translate(0px,-0px);
        animation: preview_img 33s infinite;
        animation-timing-function: cubic-bezier(0,1.19,.2,1);
    }
    @keyframes preview_img {
        0% {
            transform:translate(0px,-33.8px);
        }
        6% {
            transform:translate(0px,-67.6px);
        }
        12% {
            transform:translate(0px,-101.4px);
        }
        18% {
            transform:translate(0px,-135.2px);
        }
        24% {
            transform:translate(0px,-169px);
        }
        30% {
            transform:translate(0px,-202.8px);
        }
        36% {
            transform:translate(0px,-236.6px);
        }
        42% {
            transform:translate(0px,-270.4px);
        }
        48% {
            transform:translate(0px,-304.2px);
        }
        54% {
            transform:translate(0px,-270.4px);
        }
        60% {
            transform:translate(0px,-236.6px);
        }
        66% {
            transform:translate(0px,-202.8px);
        }
        72% {
            transform:translate(0px,-169px);
        }
        78% {
            transform:translate(0px,-135.2px);
        }
        84% {
            transform:translate(0px,-101.4px);
        }
        90% {
            transform:translate(0px,-67.6px);
        }
        96% {
            transform:translate(0px,-33.8px);
        }
        100% {
            transform:translate(0px,-0px);
        }
    }

    @keyframes loader-animation {
        from {
          transform:translateX(-16px) scale(1.5,1.5);
          background-color: ${main_app_colors()?.bg};
          color:#ffffff;
          box-shadow: ${main_app_colors()?.bg}40 2px 1px 2px 0px, ${main_app_colors()?.bg}80 -1px -2px 1px -1px;
        }
        to {
          transform:translateX(0px) scale(0.9,0.9);
          background-color: ${main_app_colors()?.mid};
          color:${main_app_colors()?.bg};
          box-shadow:
              -0px -0px 1px 0px ${main_app_colors()?.bg}80,
              1px 0px 1px 0px ${main_app_colors()?.bg},
              2px 0px 1px 0px ${main_app_colors()?.mid} inset,
              -2px -1px 1px 0px ${main_app_colors()?.bg}80 inset;
        }
      }

      .resize_svg:hover{
        transition:all 222ms;
        transform:translate(-2px,-2px) scale(1.2,1.2);
      }



      .vid_control_bar{
        border-radius:0.2em;
        padding:0px;
        background:#000000;
        cursor:pointer;
        margin:0px;
      }
      .vid_control_ball.active{
          background: #f69d3c;
          box-shadow:-0px -0px 0px 0px #f5a247;
      }
      .vid_control_ball.active:hover{
          box-shadow:-0px -0px 0px 0px #f5a247;
      }
      .vid_control_ball.active:active{
          background: radial-gradient(transparent 20%, #f69d3c 80%, #f69d3c 100%);
      }
      .vid_control_ball{
        cursor: ew-resize;
        padding:0px;
        margin:0px;
        background:${main_app_colors()?.bg};
        border-radius:0.4em;
        box-shadow:-0px -0px 1px 0px ${main_app_colors()?.bg}80,
        1px 1px 2px 0px ${main_app_colors()?.bg},
        1px 1px 1px 0px ${main_app_colors()?.bg_highlight} inset,
        -1px -1px 1px 0px ${main_app_colors()?.bg_shadow} inset;
      }
      .vid_control_ball:hover{
        box-shadow:-1px -0px 1px 0px ${main_app_colors()?.bg}80,
        2px 1px 2px 0px ${main_app_colors()?.bg},
        1.5px 1px 1px 0px ${main_app_colors()?.bg_highlight} inset,
        -2px -1px 1px 0px ${main_app_colors()?.bg_shadow} inset;
      }
      .vid_control_ball:active {
        cursor:col-resize;
        background: radial-gradient(transparent 20%, #f69d3c 80%, #f69d3c 100%);
        /* background:${main_app_colors()?.bg}50; */
        /* box-shadow:-0px -0px 0px 0px ${main_app_colors()?.bg}80,
        2px 1px 2px 0px ${main_app_colors()?.bg},
        2px 1px 1px 0px ${main_app_colors()?.bg_shadow} inset,
        -2px -1px 1px 0px ${main_app_colors()?.bg_highlight}50 inset; */
    }
    .vid_time_display{
        outline: none !important;
        border-radius: 0.4em;
        border: 0px;
        background: ${main_app_colors()?.bg};
        transition:top 200ms cubic-bezier(.59,-0.54,.49,1.55), left 60ms cubic-bezier(.58,.98,.08,.52);
        box-shadow:-0px -0px 1px 0px ${main_app_colors()?.bg},
        2px 1px 2px 0px ${main_app_colors()?.bg},
        2px 1px 1px 0px ${main_app_colors()?.bg_shadow} inset,
        -2px -1px 1px 0px ${main_app_colors()?.bg_highlight}50 inset;
    }
    #time_preview_cont{
      color:${main_app_colors()?.edge};
    }
    .vod_info_cont{
        visibility:hidden;
        position: absolute;
        width:86%;
        top:16px;
        left:16px;
        color:#ffffff;
        background:${main_app_colors()?.bg}60;
    }
    .vod_info_cont:hover{
        visibility:visible;
    }
    .video_controls_cont{
        background:${main_app_colors()?.bg}60;
        border-radius:0.2em;
        padding:6px;
        width:56px;
        visibility:hidden;
        position: absolute;
        display:grid;
        grid-template-rows:auto;
        row-gap: 2px;
        top:16px;
        right:16px;
    }
    .video_controls_cont:hover{
        visibility:visible;
    }
    .pop_out_video{
        width:100%;
    }

    #tvd_video_viewer:has(.menu_body:hover) .video_controls_cont{
        visibility:visible;
    }
    .speed_cont{
      padding:4px;
    }
    .speed_cont:hover{
      background:#000000;
      border-radius:2em;
    }
    .speed_bar{
      visibility:hidden;
      transform:scale(0.8,0.8);
    }
    .speed_bar:hover{
      visibility:visible;
    }
    .speed_display{
      visibility:hidden;
    }
    .speed_display:hover{
      visibility:visible;
    }

    .custom_video_controls_cont:has(.speed_cont:hover) .speed_display{
        visibility:visible;
    }
    .custom_video_controls_cont:has(.speed_cont:hover) .speed_bar{
        visibility:visible;
    }

    .custom_video_controls_cont{
        visibility:hidden;
    }
    .custom_video_controls_cont:hover{
        visibility:visible;
    }
    .volume_bar{
      transform:scale(0.8,0.8);
      visibility:hidden;
    }
    .volume_bar:hover{
      visibility:visible;
    }
    .volume_cont{
      padding:4px;
    }
    .volume_cont:hover{
      background:#000000;
      border-radius:2em;
    }
    .custom_video_controls_cont:has(.volume_cont:hover) .volume_bar{
        visibility:visible;
    }
    #tvd_video_viewer:has(.menu_body:hover) .custom_video_controls_cont{
        visibility:visible;
    }
    #download_view_holder{
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      padding:18px;
    }
    // #video_progress_controls_cont{
    //   background-color: #fff;
    //   border-radius: 8px;
    //   box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    // }
    #tvd_video_viewer:has(.menu_body:hover) .vod_info_cont{
        visibility:visible;
    }
    .show_title_pop[title]:hover::after {
        content: attr(title);
        position: absolute;
        color:#1c1c1c;
        left: -100%;
        background:#ffffff;
        font-size:0.7em;
        padding:6px;
        border-radius:1em;
        text-align:center;
    }
    .side_vid_controls_btn{
        width:56px;
    }

    .max-height43{
        max-height:43px;
    }

    .title_simple_text{
        border-top-left-radius:1em;
        border-bottom-left-radius:1em;
        border-top-right-radius:0em;
        border-bottom-right-radius:0em;
        color:#ffffff;
        background:${main_app_colors()?.bg_highlight};
        font-size:0.7em;
        padding:6px;
        text-align:center;
        width:fit-content;
        white-space: nowrap;
        word-break: keep-all;
        // box-shadow: rgba(136, 165, 191, 0.48) 10px 2px 10px 0px, rgba(255, 255, 255, 0.8) -2px -2px 1px -1px;
    }
    .title_simple_pointer{
        border-top: 13px solid transparent;
        border-bottom: 13px solid transparent;
        border-left: 13px solid ${main_app_colors()?.bg_highlight};
        width:0px;
        height:0px;
    }
    .show_title_simple_elm{
        text-align:center;
        width:fit-content;
        white-space: nowrap;
        word-break: keep-all;
        background:transparent;
        display:grid;
        grid-template-columns:1fr 26px;
        grid-gap:0px;
        visibility:hidden;
        position:absolute;
        right:42px;
    }
    .show_title_simple_ref:hover .show_title_simple_elm{
        visibility:visible;
    }
    .fitwidth{
        width:fit-width;
    }
    .updates_cont{
      background-color: ${main_app_colors()?.menu_bg};
      color:${main_app_colors()?.text};
      border-radius: 0.8em;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      padding: 18px;
      max-width: 400px;
    }
    .recent_vod_btn{
      display:flex;
      justify-content:end;
      text-align: center;
      border-radius:0.4em;
    }
    .recent_vod_btn:hover .translateYneg20{
      transform:translate(0px,-20px);
    }
    .recent_title_view_cont{
      display:flex;
      width: 200px;
      height:35px;
      text-align:left;
      overflow:clip;
    }
    .align_center {
      display:flex;
      align-items:center;
    }
    .align_top {
      display:flex;
      align-items:start;
    }
    .recent_title_view{
      width: 200px;
      transition: all 1s ease-out;
      text-align:left;
      overflow:clip;
    }
    .control_btn{
      padding:3px;
      border-radius:0.4em;
      display:flex;
      align-items:end;
      cursor:pointer;
    }
    .control_btn:hover{
      background:#ffffff30;
    }

    :root {
        --colr-1:#db1076;
        --colr-2:#d810db98;
        --colr-3:#6516db99;
        --colr-4:#1d56d198;
        --colr-5:#2497d1;
    }
    @property --gradient-angle {
        syntax: "<angle>";
        initial-value: 0deg;
        inherits: false;
    }
    @keyframes arotation{
        0% { --gradient-angle: 0deg; }
        100% { --gradient-angle: 360deg; }
    }
    .bg_glower {
        background: linear-gradient(
            var(--gradient-angle),
            var(--colr-2),
            var(--colr-3),
            var(--colr-4),
            var(--colr-5)
        );
        animation: arotation 15s linear infinite;
    }
    .bg_gradient {
      background:linear-gradient(
      var(--gradient-angle),
      #ee775298, #e73c7e99, #23a6d598, #23a6d598, #23d5ab);
      animation: arotation 15s linear infinite;
    }
    .bg_1c1c1c{
      background:#1c1c1c;
    }
    .bg_52fc18{
      background:#52fc18;
    }
    .bg_9047ff{
      background:#9047ff;
    }
    .bg_f0f0f0{
      background:#f0f0f0;
    }
    .bg_000000{
      background:#000000;
    }
    .disabled {
        pointer-events: none;
        opacity: 0.5;
        cursor: not-allowed;
    }
    @keyframes loader-animation {
        0%, 100% {
          transform: translateY(0px) scale(1, 1);
          background-color: ${main_app_colors()?.menu_bg};
          color: ${main_app_colors()?.text};
          box-shadow: 0 2px 5px ${main_app_colors()?.input_shadow}20;
          opacity: 0.9;
          border-radius: 25%;
        }
        40% {
          transform: translateY(-5px) scale(1.06, 1.06);
          background-color: ${main_app_colors()?.edge};
          color: #ffffff;
          box-shadow: 0 5px 10px ${main_app_colors()?.edge}35;
          opacity: 1;
          border-radius: 30%;
        }
        60% {
          transform: translateY(-5px) scale(1.06, 1.06);
          background-color: ${main_app_colors()?.menu_bg};
          color: ${main_app_colors()?.text};
          box-shadow: 0 5px 10px ${main_app_colors()?.contrast_icon}35;
          opacity: 1;
          border-radius: 30%;
        }
    }



    @keyframes cycle-frames {
      0%    { background-position: 0% 0%; }
      25%   { background-position: 100% 0%; }
      50%   { background-position: 0% 100%; }
      75%   { background-position: 100% 100%; }
      100%  { background-position: 0% 0%; }
    }

    /* VOD KWS 1.1.7: force dark translator dropdowns */
`
}
