// KWS 1.2.6.9 — the Clip Downloader in the user's language (Twitch · Kick · SOOP · CHZZK · StreamRecorder).
// The downloaders build their popups with English text (same markup on every site); instead of
// touching each of them, the text inside a downloader popup is swapped for the _locales string as it
// appears or changes. English UI → nothing to do.
(function () {
  'use strict';
  if (globalThis.__kwsDlI18n) return;
  globalThis.__kwsDlI18n = true;
  const T = (k, ...a) => { try { return chrome.i18n.getMessage(k, a.map(String)) || ''; } catch (_) { return ''; } };
  let lang = '';
  try { lang = chrome.i18n.getUILanguage() || ''; } catch (_) {}
  if (!lang || /^en\b/i.test(lang) || !T('dlTitle')) return;

  const SCOPE = '#kws_clip_downloader, .kws-inline-download-pop, [id^="kws_inline_download_pop_"], #download_view_holder, #soop_dl_pop, #kws-chzzk-clipdl, #kwsSrP .dl, .kws-sr-dl';
  const RULES = [
    [/^Clip Downloader$/i, () => T('dlTitle')],
    [/^Start$/, () => T('dlStart')],
    [/^End$/, () => T('dlEnd')],
    [/^Set to Current$/, () => T('dlSetCurrent')],
    [/^Duration$/, () => T('dlDuration')],
    [/^(Resolution|Quality:?)$/, () => T('dlQuality')],
    [/^(⚠️\s*)?Keep this tab open while downloading( as one file)?\.$/, (m) => (m[1] ? '⚠️ ' : '') + T('dlKeepTab')],
    [/^Keep this tab active — navigating away may interrupt the download\.$/, () => T('dlKeepActive')],
    [/^(⚠️\s*)?Keep this window open while downloading\.$/, (m) => (m[1] ? '⚠️ ' : '') + T('dlKeepWindow')],
    [/^Keep this window open — closing it stops the download\.$/, () => T('dlKeepWindowStops')],
    [/^💾 Download$/, () => '💾 ' + T('dlDownload')],
    [/^⏳ Loading quality\.\.\.$/, () => '⏳ ' + T('dlLoadingQuality')],
    [/^initiating download$/i, () => T('dlInitiating')],
    [/^([\d.]+)% complete$/, (m) => T('dlPct', m[1])],
    [/^Stop and Download Progress$/, () => T('dlStop')],
    [/^Click to Stop and Download Progress$/, () => T('dlStopClick')],
    [/^Current File Size: (.+)$/, (m) => T('dlFileSize', m[1])],
    [/^(?:Current File )?Duration: (.+)$/, (m) => T('dlDurNow', m[1])],
    [/^Current VOD Position: (.+)$/, (m) => T('dlVodPos', m[1])],
    [/^Downloading (\S+) to (\S+)$/, (m) => T('dlRange', m[1], m[2])],
    [/^(.+) · (\S+) to (\S+)$/, (m) => m[1] + ' · ' + T('dlRange', m[2], m[3])],
    [/^(✅ )?Download complete$/i, () => '✅ ' + T('dlComplete')],
    [/^✅ Stopped — progress saved$/, () => '✅ ' + T('dlStopped')],
    [/^⚠️ Incomplete — a segment failed after retries\. File saved up to that point\.$/, () => '⚠️ ' + T('dlIncomplete')],
    [/^⚠️ Incomplete — a segment failed after retries(?: at \S+)?\. File saved up to (\S+)\.$/, (m) => '⚠️ ' + T('dlIncompleteAt', m[1])],
    [/^⚠️ Incomplete — a segment failed after retries \(saved up to (\S+)\)$/, (m) => '⚠️ ' + T('dlIncompleteAt', m[1])],
    [/^⏳ Stopping — saving progress so far\.\.\.$/, () => '⏳ ' + T('dlStopping')],
    [/^Close$/, () => T('dlClose')],
    [/^Failed to load VOD data\.$/, () => T('dlFailedLoad')],
  ];
  function tr(node) {
    const raw = node.nodeValue;
    const s = raw && raw.trim();
    if (!s || s.length > 200) return;
    for (const [re, fn] of RULES) {
      const m = re.exec(s);
      if (!m) continue;
      const out = fn(m);
      if (out && out !== s) node.nodeValue = raw.replace(s, out);
      return;
    }
  }
  function walk(root) {
    if (!root) return;
    if (root.nodeType === 3) { tr(root); return; }
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    for (let n = w.nextNode(); n; n = w.nextNode()) tr(n);
  }
  const pending = new Set();
  let queued = false;
  const flush = () => { queued = false; for (const n of pending) if (n.isConnected) walk(n); pending.clear(); };
  new MutationObserver((list) => {
    for (const m of list) {
      const el = m.target.nodeType === 3 ? m.target.parentElement : m.target;
      const scope = el && el.closest && el.closest(SCOPE);
      if (scope) pending.add(scope);
      else for (const a of m.addedNodes || []) {
        if (a.nodeType !== 1) continue;
        if (a.matches && a.matches(SCOPE)) pending.add(a);
        else if (a.querySelectorAll) a.querySelectorAll(SCOPE).forEach((x) => pending.add(x));
      }
    }
    if (pending.size && !queued) { queued = true; queueMicrotask(flush); }
  }).observe(document.documentElement, { subtree: true, childList: true, characterData: true });
})();
