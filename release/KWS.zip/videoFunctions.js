var hls = new Hls();

// buildVideoSourceFromTSInformation({fragments,total_seconds,head_text,foot_text,url,extendby,extend_frag_dur})
function buildVideoSourceFromTSInformation(params) {
  var {
    fragments,
    total_seconds,
    head_text,
    foot_text,
    source,
    extendby,
    extend_frag_dur,
    url,
    start_offset_seconds,
    is_mp4,
  } = params;
  var force2Point = (n) => /\.\d\d\d/.test(`${n}`)
      ? `${n}`
      : /\.\d\d\b/.test(`${n}`)
        ? `${n}0`
        : /\.\d\b/.test(`${n}`)
          ? `${n}00`
          : `${n}.000`;
  let mid = fragments
    .map((f) => `#EXTINF:${force2Point(f.dur)},\n${source?.replace(/[\w-]+\.m3u8$/, f.path.replace(/unmuted/, "muted"))}\n`,)
    .reduce((a, b) => a + b);
  let extended = extendby && extendby / (extend_frag_dur || 10) > 0
      ? Array(Math.ceil(extendby / (extend_frag_dur || 10)))
          .fill()
          .map((_, i) => `#EXTINF:${extend_frag_dur || 10}.000,\n${(source || url)?.replace(/[\w-]+?\.m3u8$/, `${fragments.length + i}.${is_mp4 ? 'mp4' : 'ts'}`)}\n`,)
          .reduce((a, b) => a + b)
      : "";
  // console.log({ init: `${source?.replace(/[\w-]+\.m3u8$/, '')}init-0.mp4` });
  // console.log(`v2`)
  let head_text_ = is_mp4 ? head_text?.replace(/EXT-X-MAP:URI="init-0.mp4"/,`EXT-X-MAP:URI="${source?.replace(/[\w-]+\.m3u8$/, '')}init-0.mp4"\n`)
    : head_text.replace(/(?<=#EXT-X-MEDIA-SEQUENCE:\d+)\n/, `\n#EXT-X-START:TIME-OFFSET=${start_offset_seconds},PRECISE=YES\n`);
  let playlist_file = `${head_text_?.replace(/(?<=EXT-X-TWITCH-TOTAL-SECS:)[\d\.]+/, total_seconds + (extendby || 0) + '\n')}${mid}${extended}${foot_text || ""}`;
  // console.log(playlist_file );
  return playlist_file;

}



// function buildVideoSourceFromTSInformation(params){
//     var {fragments,total_seconds,head_text,foot_text,url,source,extendby} = params;
//     // console.log(params)
//     var force2Point = (n)=> /\.\d\d\d/.test(`${n}`) ? `${n}` : /\.\d\d\b/.test(`${n}`) ? `${n}0` : /\.\d\b/.test(`${n}`) ? `${n}00` : `${n}.000`;
//     let mid = fragments.map(f=> `#EXTINF:${force2Point(f.s)},\n${source?.replace(/[\w-]+\.m3u8$/, f.path.replace(/unmuted/,'muted'))}\n`).reduce((a,b)=> a+b);
//     let extended = extendby && (extendby/10) > 0 ? Array(Math.ceil(extendby/10)).fill().map((_,i)=> `#EXTINF:10.000,\n${url?.replace(/[\w-]+?\.m3u8$/, `${fragments.length+(i)}.ts`)}\n`).reduce((a,b)=> a+b) : '';
//     return `${head_text}${total_seconds}\n${mid}${extended}${foot_text}`
// }
function getSelectedResolutionName(params) {
  var { options } =
    params; /*getting the element from the global window could be an issue if we decide to let multiple video views run at once. But allowing this would also break all of our HLS stuff, so fuck it.*/
  let resolution = Array.from(cn(document, "res_option checked"))?.[0];
  return options.filter((r) => r.name == resolution)?.[0] || options?.[0];
}

async function getTwitchVODManifestInformation(params) {
  var { vod, video, is_update, cls_btn, is_live, livestream_urls } = params;
  var { src, source } = vod;
  // console.log('getTwitchVODManifestInformation')
  var tokens = getTokensFromCookies();
  var playlist = await requestFromBackground({
    cmd: "getTwitchOrKickManifest",
    params: vod,
  });
  // console.log({playlist})
  if(!playlist?.data?.fragments?.length){
    // console.log('bad playlist endpoint');
  }
  if (is_live) {
    var livestream_urls = await requestFromBackground({
      cmd: "getTwitchLivestreamUrl",
      params: { ...tokens, ...vod },
    });
    // console.log("livestream_url=>", livestream_urls);
    var livestream_url = getSelectedResolutionName({
      options: livestream_urls,
    });
    var livestream_playlist = await requestFromBackground({
      cmd: "getTwitchLivestreamManifest",
      params: {
        ...livestream_urls[0],
        ...{ timestamp: vod?.timestamp },
      },
    });
    // console.log("livestream_playlist", livestream_playlist);
    return { ...params, ...{ playlist, livestream_playlist, livestream_url } };
  } else {
    return { ...params, ...{ playlist } };
  }
}

async function attachTwitchSourceToVideoElm(params) {
  var { vod, video, is_update, cls_btn, is_live, livestream_urls } = params;
  var { src, source } = vod;

  // fragments가 비어있으면 최대 3번 재시도
  var manifest_info = await getTwitchVODManifestInformation(params);
  for (let retry = 0; retry < 3; retry++) {
    if (manifest_info?.playlist?.data?.fragments?.length > 0) break;
    await new Promise(r => setTimeout(r, 1500));
    manifest_info = await getTwitchVODManifestInformation(params);
  }

  var last_time = video.currentTime;
  // 1.2.5.19: what to restore after a resolution switch (the switch reloads the source)
  var keep_rate = video.playbackRate || 1, keep_playing = !video.paused;
  var { playlist, livestream_url, livestream_playlist } = manifest_info;

  // fragments가 없으면 에러 메시지 표시
  if (!playlist?.data?.fragments?.length) {
    // a failed resolution switch keeps the current playback (nothing has been torn down yet)
    if (is_update) { console.warn('[KWS player] resolution switch: no fragments for', vod?.name); return null; }
    const cont = video.parentElement || document.getElementById('tvd_video_viewer');
    if (cont) {
      cont.innerHTML = '';
      cont.style.cssText += 'display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;background:#0a0c12;min-height:200px;';
      const msg = document.createElement('div');
      msg.textContent = '⚠️ Unable to load VOD. The video may have expired or is unavailable.';
      msg.style.cssText = 'color:rgba(255,255,255,0.7);font-size:13px;text-align:center;padding:0 24px;line-height:1.6;';
      const closeBtn = document.createElement('button');
      closeBtn.textContent = 'Close';
      closeBtn.style.cssText = 'display:flex;align-items:center;justify-content:center;padding:10px 32px;border-radius:12px;background:rgba(220,38,38,0.75);color:#fff;border:1px solid rgba(239,68,68,0.5);cursor:pointer;font-size:0.95em;font-weight:800;';
      closeBtn.addEventListener('click', () => document.getElementById('tvd_video_viewer')?.remove());
      cont.appendChild(msg);
      cont.appendChild(closeBtn);
    }
    return;
  }
  // console.log("attachTwitchSourceToVideoElm manifest_info", manifest_info);
  let ninety_nine_hours = 359960;
  let total_seconds = playlist?.data?.fragments?.map((r) => r.dur).reduce((a, b) => a + b, 0) || 0;
  let extendby = manifest_info?.is_live === true ? Math.ceil(ninety_nine_hours-total_seconds) : 0;
  let custom_source_text = buildVideoSourceFromTSInformation({
    start_offset_seconds: manifest_info?.is_live ? Math.floor(total_seconds)-30 : 1,
    fragments: playlist?.data?.fragments,
    total_seconds: Math.ceil(total_seconds + extendby),
    head_text: playlist?.data?.head_text,
    source: source,
    extendby: Math.ceil(extendby),
    extend_frag_dur: 10,
    is_mp4:playlist?.data?.is_mp4,
  });
  video.src = vod.src || vod.source;

  var enc = new TextEncoder("utf-8");
  let objURL = URL.createObjectURL(
    new Blob([enc.encode(custom_source_text)]),
  );
  // Destroy and recreate HLS instance on every load to prevent audio pitch corruption.
  // Reusing a single HLS instance across different VODs leaves stale audio decoder state
  // (sample rate, AAC HE-AAC context) which causes pitch-shifted playback on Twitch VODs.
  hls.destroy();
  hls = new Hls({
    // Disable worker to avoid audio context issues in extension sandbox
    enableWorker: false,
    // Force audio codec to avoid misdetection between AAC-LC and HE-AAC
    audioCodec: undefined,
    // 배속 재생(4x 등) 시 버퍼가 못 따라가서 재생이 잠깐씩 멈추고(=seek바도 같이 멈춤) 하는 것을 줄이기 위해
    // 기본값보다 앞쪽 버퍼를 더 넉넉하게 확보 (VOD 세그먼트는 정적 파일이라 미리 받아둬도 부담 적음)
    maxBufferLength: 120,
    maxMaxBufferLength: 900,
    maxBufferSize: 200 * 1000 * 1000,
  });
  hls.loadSource(objURL);
  // Always attach: the old instance was destroyed above, so a resolution switch (is_update) that
  // skipped this left the video with no source at all — the quality buttons seemed to do nothing.
  hls.attachMedia(video);
  // 치명적 재생 오류가 나면 예전엔 아무 표시 없이 검은 화면만 남았음 — 네트워크/미디어 오류는
  // 몇 번 자동 재시도하고, 그래도 안 되면 원인(HTTP 코드 등)을 화면에 알려줌.
  {
    let _hlsRetries = 0;
    const _hlsInst = hls;
    hls.on(Hls.Events.ERROR, (_ev, d) => {
      if (_hlsInst !== hls) return; // 이미 다른 VOD로 교체된 옛 인스턴스의 오류는 무시
      console.warn('[KWS player] HLS error:', d?.type, d?.details, d?.response?.code, d?.url, d?.fatal ? '(fatal)' : '');
      if (!d?.fatal) return;
      if (d.type === Hls.ErrorTypes.NETWORK_ERROR && _hlsRetries < 3) { _hlsRetries++; setTimeout(() => { try { hls.startLoad(); } catch (e) {} }, 1000 * _hlsRetries); return; }
      if (d.type === Hls.ErrorTypes.MEDIA_ERROR && _hlsRetries < 3) { _hlsRetries++; try { hls.recoverMediaError(); } catch (e) {} return; }
      const host = video.parentElement;
      if (!host) return;
      if (getComputedStyle(host).position === 'static') host.style.position = 'relative';
      host.querySelectorAll('.kws-hls-error').forEach(el => el.remove());
      const note = document.createElement('div');
      note.className = 'kws-hls-error';
      note.style.cssText = 'position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);max-width:80%;padding:12px 18px;border-radius:12px;background:rgba(0,0,0,0.78);border:1px solid rgba(248,113,113,0.5);color:#fca5a5;font-size:13px;line-height:1.6;text-align:center;z-index:5;pointer-events:none;';
      note.textContent = '⚠️ Video failed to load' + (d.response?.code ? ' (HTTP ' + d.response.code + ')' : '') + ' — ' + (d.details || d.type || 'unknown error') + '. The VOD may be expired, blocked in your region, or the network is unstable.';
      host.appendChild(note);
    });
    hls.on(Hls.Events.MANIFEST_PARSED, () => { host_clear(); });
    function host_clear() { video.parentElement?.querySelectorAll('.kws-hls-error').forEach(el => el.remove()); }
  }
  // 재생이 중간에 멈추는 경우(특히 세로 VOD처럼 해상도/세그먼트가 특이한 영상) 대비 워치독:
  // 재생 중인데 4초 넘게 시간이 안 흐르면 로딩 재개 → 그래도 안 되면 위치를 살짝 밀어서 깨움.
  if (video._kwsStallTimer) clearInterval(video._kwsStallTimer);
  {
    let lastT = -1, stuck = 0;
    const _hlsForWatch = hls;
    video._kwsStallTimer = setInterval(() => {
      if (!document.contains(video) || _hlsForWatch !== hls) { clearInterval(video._kwsStallTimer); return; }
      if (video.paused || video.ended || video.seeking) { lastT = video.currentTime; stuck = 0; return; }
      if (Math.abs(video.currentTime - lastT) < 0.05) {
        stuck++;
        if (stuck === 2) { try { hls.startLoad(video.currentTime); } catch (e) {} }
        else if (stuck >= 3) { try { video.currentTime = video.currentTime + 0.1; } catch (e) {} stuck = 1; }
      } else { stuck = 0; }
      lastT = video.currentTime;
    }, 2000);
  }
  hls.on(Hls.Events.MANIFEST_PARSED, () => {
    pauseOtherVideoElms()
    if(last_time){
      video.currentTime = last_time;
    }
  });
  if (is_update) {
    // resolution switch: same place, same speed, same play/pause — and keep the controls that are
    // already there (rebuilding them stacked a second set of listeners on the video: a click then
    // toggled play twice, and the window jumped to 80 % width)
    hls.on(Hls.Events.MANIFEST_PARSED, () => {
      video.playbackRate = keep_rate;
      if (keep_playing) video.play().catch(() => {});
    });
    return manifest_info;
  }
  let tvd_settings_seek_default = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'tvd_settings_seek_default' } });
  var seeker_adjustment = (tvd_settings_seek_default || 30);

  var contolsParams = {
    data_ref: {
      current_time: Math.floor(video.currentTime),
      max: Math.ceil(total_seconds),
      is_live:manifest_info?.is_live === true ? true : false,
      // offset_timestamp: new Date().getTime(),
      duration:Math.ceil(total_seconds + extendby),
      stream_start_timestamp:manifest_info?.vod?.timestamp,
    },
    video:video,
    seeker_adjustment: seeker_adjustment,
    // parent_elm: video,
    parent_elm:document.getElementById('tvd_video_viewer_menu_body') || document.getElementById('tvd_video_viewer_footer'),
    // parent_elm: video?.parentElement
  };
  // console.log('contolsParams', contolsParams);
  var {cont,forward,backward,play_pause,seeker_input,current_seek,volume_bar,volume_btn,speed_step_btns} = await addCustomVideoControls(contolsParams);

  backward.addEventListener('click',async ()=>	{
      let tvd_settings_seek_default = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'tvd_settings_seek_default' } });
      video.currentTime = (parseFloat(video.currentTime)-parseFloat((tvd_settings_seek_default || 30)));
    	seeker_input.value = (parseFloat(video.currentTime)-parseFloat((tvd_settings_seek_default || 30)));
	});
  forward.addEventListener('click',async ()=>	{
    let tvd_settings_seek_default = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'tvd_settings_seek_default' } });
    video.currentTime = (parseInt(video.currentTime)+parseFloat((tvd_settings_seek_default || 30)));
  	seeker_input.value = (parseInt(video.currentTime)+parseFloat((tvd_settings_seek_default || 30)));
  });
  function setSpeed(n) {
    video.playbackRate = n;
    console.log('[KWS player] setSpeed(' + n + ') — video.playbackRate now', video.playbackRate, 'is_live=', manifest_info?.is_live, 'readyState=', video.readyState);
    speed_step_btns.forEach(b => b.classList.toggle('checked', parseInt(b.dataset.speed, 10) === n));
  }
  speed_step_btns.forEach(b => {
    b.addEventListener('click', () => {
      console.log('[KWS player] speed pill clicked:', b.dataset.speed);
      setSpeed(parseInt(b.dataset.speed, 10));
    });
  });
  volume_btn.addEventListener('click', () => {
    if (volume_btn.getElementsByTagName('svg')?.[0]?.id == 'volume_on') {
      volume_btn.innerHTML = svgs()?.muted;
      video.volume = 0;
      volume_bar.value = 0;
    } else {
      volume_btn.innerHTML = svgs()?.volume;
      video.volume = 1;
      volume_bar.value = 100;
    }
  });
  volume_bar.addEventListener('input', () => {
    video.volume = (parseFloat(volume_bar.value) / 100);
    if (parseFloat(volume_bar.value) == 0) { volume_btn.innerHTML = svgs()?.muted; } else { volume_btn.innerHTML = svgs()?.volume; }
  });
  volume_bar.addEventListener('blur', async () => {
    await requestFromBackground({ cmd: 'setLocalStorage', params: { key: 'tvd_settings_volume', data: volume_bar.value } });
  });
  let tvd_settings_volume = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'tvd_settings_volume' } });
  video.volume = tvd_settings_volume ? (parseFloat(tvd_settings_volume) / 100) : 1;
  volume_bar.value = tvd_settings_volume ? parseFloat(tvd_settings_volume) : 100;
  // 예전 레이아웃에서 쓰던 인라인 transform/background 제거됨 — 지금은 kwsEnsureInlineVodHotfixStyle()의
  // CSS(position:absolute + bottom:12px 등)가 위치를 전담함. 인라인 style의 !important는 스타일시트의
  // !important보다 항상 우선이라, 이 한 줄이 지금까지의 모든 위치 수정을 계속 무력화시키고 있었음.

  video.addEventListener('timeupdate', () => {
    //ACCOUNTING FOR WHEN A LIVESTREAM VIEWER IS UP AGAINST THE MAX INPUT WALL => slow playback rate to 1x;
    let speed = video.playbackRate;
    let vod_delay = 32;
    let variable_max = manifest_info?.is_live === true ? Math.floor((new Date().getTime() - manifest_info?.vod?.timestamp) / 1000)-vod_delay : 0;
    if(manifest_info?.is_live === true && speed > 1 && ((video.currentTime+5) >= variable_max)){
      // console.log('playback rate exceeding buffer');
      setSpeed(1);
    }
    updateSeekerDisplay({
      data_ref: {
        current_time: Math.floor(video.currentTime),
        max: Math.ceil(total_seconds),
        is_live:manifest_info?.is_live === true ? true : false,
        // offset_timestamp: new Date().getTime(),
        duration:Math.ceil(total_seconds + extendby),
        stream_start_timestamp:manifest_info?.vod?.timestamp,
      },
      seeker_input: seeker_input,
      current_seek: current_seek
    });
    a(seeker_input, [['value',Math.floor(video.currentTime)]]);
  });
  let viewer_cont_id = video?.parentElement.id?.replace(/_menu_body/, '');
  let viewer_cont = document.getElementById(viewer_cont_id);
  let foot_resizer = document.getElementById(`${viewer_cont_id}_foot_resizer`);
  var parent_dimensions = foot_resizer.getAttribute('data-parent_dimensions') ? atobJSON(foot_resizer.getAttribute('data-parent_dimensions')) : null;
  var resize_elm_ids = foot_resizer.getAttribute('data-resize-id').split(/,/);
  var cbod = document.getElementById(resize_elm_ids[0]);
  var tbod = document.getElementById(resize_elm_ids[1]);
  let new_width = (window.innerWidth * 0.8);
  if((cbod.getBoundingClientRect().width-50) < window.innerWidth){
    inlineStyler(cbod, `{width:${new_width}px;}`);
    if(tbod){
        inlineStyler(tbod,`{width: ${((new_width-((parent_dimensions?.left_panel_width || 0) + (parent_dimensions?.right_panel_width || 0))))}px; opacity: 0.98; transiation: opacity 100ms;}`);
    }
  }
  // refitVideoCont({cont:video?.parentElement});
  return manifest_info;
}



async function attachSourceToVideoElm(params){
  var { vod, video, is_update, cls_btn, is_live, livestream_urls } = params;
  // var { src, source } = vod;
  if(vod){
    let manifest_info = await attachTwitchSourceToVideoElm(params);
    // console.log({manifest_info})
    // console.log('attachSourceToVideoElm', params);
    return manifest_info;
  }else{
    return null;
  }
}
