// ══════════════════════════════════════════════════════════════════════
//  KWS — Twitch Client-Integrity 토큰 채취기 (MAIN world)
//
//  Twitch 페이지 자신이 gql.twitch.tv 로 보내는 실제 요청에는 진짜 브라우저
//  챌린지를 통과한 정품 Client-Integrity 토큰이 붙는다. 우리가 직접 그 토큰을
//  계산하려고 하면 "failed integrity check"로 막히지만, 페이지가 스스로
//  만들어낸 이 토큰을 그대로 빌려쓰면 VOD 채팅(VideoCommentsByOffsetOrCursor)
//  같은 보호된 쿼리도 정상적으로 통과한다 (실제 브라우저에서 확인됨).
//
//  이 스크립트는 MAIN world(페이지 실제 JS 컨텍스트)에 주입되어 window.fetch를
//  가로채고, gql.twitch.tv 요청에서 필요한 헤더 세트를 통째로 캡처한 뒤
//  window.postMessage로 격리된(isolated) content script(twitchIntegrityBridge.js)에
//  전달한다. 거기서 chrome.runtime.sendMessage로 background.js까지 릴레이됨.
// ══════════════════════════════════════════════════════════════════════
(function () {
  if (window.__kwsIntegrityPatched) return;
  window.__kwsIntegrityPatched = true;

  const REQUIRED_HEADERS = ['client-id', 'x-device-id', 'client-version', 'client-session-id', 'client-integrity'];

  function extractHeaders(input, init) {
    const out = {};
    const raw = init?.headers || (typeof input === 'object' && input?.headers);
    if (!raw) return out;
    if (raw instanceof Headers) {
      for (const [k, v] of raw.entries()) out[k.toLowerCase()] = v;
    } else if (typeof raw === 'object') {
      for (const k of Object.keys(raw)) out[k.toLowerCase()] = raw[k];
    }
    return out;
  }

  let __kwsLastBundle = null;

  // 헤더 세트가 다 모였으면 __kwsFetchVodComments가 쓸 __kwsLastBundle에 저장하고,
  // 동시에 (구) postMessage 릴레이 방식과의 호환을 위해 브로드캐스트도 계속 해준다.
  // 중요: 예전엔 이 저장을 fetch 후킹 쪽에서만 했었는데, 실제로는 Twitch 페이지가
  // 이 gql 쿼리를 fetch가 아니라 XHR로 보내는 경우가 있어서(실제 확인됨) 그 경우엔
  // __kwsLastBundle이 끝까지 null로 남아 "아직 캡처된 토큰이 없음" 오류가 났음.
  // 그래서 fetch/XHR 두 경로 모두 이 함수 하나로 통일함.
  function tryEmit(headers) {
    if (REQUIRED_HEADERS.every(h => headers[h])) {
      __kwsLastBundle = {
        clientId: headers['client-id'], deviceId: headers['x-device-id'],
        clientVersion: headers['client-version'], sessionId: headers['client-session-id'],
        integrity: headers['client-integrity'],
      };
      try {
        window.postMessage({
          __kws: true,
          type: 'KWS_INTEGRITY_CAPTURED',
          bundle: { ...__kwsLastBundle, capturedAt: Date.now() },
        }, '*');
      } catch (e) {}
    }
  }

  const origFetch = window.fetch;
  window.fetch = function (input, init) {
    try {
      const url = typeof input === 'string' ? input : input?.url;
      if (url && url.indexOf('gql.twitch.tv') !== -1) {
        tryEmit(extractHeaders(input, init));
      }
    } catch (e) {}
    return origFetch.apply(this, arguments);
  };

  // ── VOD 채팅 조회 진입점 (chrome.scripting.executeScript로 직접 호출됨) ──────
  // background.js(서비스 워커)에서 직접 gql.twitch.tv에 fetch를 쏘면 브라우저가
  // 자동으로 Origin: chrome-extension://... 을 붙이는데(JS로 절대 변경 불가),
  // Twitch가 이걸로 요청을 걸러내는 것으로 보여서 토큰이 진짜여도 매번
  // "failed integrity check"로 막혔음 (실제 테스트로 확인: 같은 토큰을 무관한
  // 사이트의 평범한 페이지에서 쏘면 성공, chrome-extension 컨텍스트에서만 실패).
  // 그래서 실제 GQL 요청 자체를 이 페이지(진짜 https://www.twitch.tv Origin)
  // 안에서 실행함.
  //
  // window.postMessage + content-script 릴레이 방식(예전 시도)은 background가
  // chrome.tabs.sendMessage로 이 탭에 요청을 넣을 때 "Could not establish
  // connection. Receiving end does not exist" 오류가 나서 매번 실패했음 —
  // 그래서 훨씬 더 직접적인 chrome.scripting.executeScript({world:'MAIN', ...})
  // 방식으로 바꿈: background.js가 이 탭 안에서 아래 함수를 직접 호출하고
  // 반환값(Promise)을 그대로 결과로 받는다. content script 메시지 리스너에
  // 의존하지 않아서 훨씬 안정적.
  window.__kwsFetchVodComments = async function (vodId, cursor, offsetSeconds) {
    try {
      if (!__kwsLastBundle) return { ok: false, error: '아직 캡처된 토큰이 없음' };
      const variables = cursor ? { videoID: String(vodId), cursor } : { videoID: String(vodId), contentOffsetSeconds: offsetSeconds || 0 };
      const res = await origFetch.call(window, 'https://gql.twitch.tv/gql', {
        method: 'POST',
        headers: {
          'Client-Id': __kwsLastBundle.clientId,
          'X-Device-Id': __kwsLastBundle.deviceId,
          'Client-Version': __kwsLastBundle.clientVersion,
          'Client-Session-Id': __kwsLastBundle.sessionId,
          'Client-Integrity': __kwsLastBundle.integrity,
          'Content-Type': 'text/plain;charset=UTF-8',
        },
        body: JSON.stringify([{
          operationName: 'VideoCommentsByOffsetOrCursor',
          variables,
          extensions: { persistedQuery: { version: 1, sha256Hash: 'b70a3591ff0f4e0313d126c6a1502d79a1c02baebb288227c582044aa76adf6a' } },
        }]),
      });
      if (!res.ok) return { ok: false, error: `HTTP ${res.status}` };
      const json = await res.json();
      return { ok: true, data: json };
    } catch (e) {
      return { ok: false, error: String(e?.message || e) };
    }
  };

  // 일부 경로는 fetch 대신 XHR을 쓸 수도 있어서 같이 후킹
  const origOpen = XMLHttpRequest.prototype.open;
  const origSetHeader = XMLHttpRequest.prototype.setRequestHeader;
  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url) {
    this.__kwsUrl = url;
    this.__kwsHeaders = {};
    return origOpen.apply(this, arguments);
  };
  XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
    if (this.__kwsHeaders) this.__kwsHeaders[String(name).toLowerCase()] = value;
    return origSetHeader.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function () {
    try {
      if (this.__kwsUrl && String(this.__kwsUrl).indexOf('gql.twitch.tv') !== -1) {
        tryEmit(this.__kwsHeaders || {});
      }
    } catch (e) {}
    return origSend.apply(this, arguments);
  };
})();
