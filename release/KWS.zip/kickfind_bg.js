// KWS 1.2.5.20 — Kick "find channels by keyword" (KickLogz). Loaded into background.js after
// scan_hub.js / overnight_bg.js.
//
// kicklogz.com's search with a keyword and NO channel searches every channel it captured. Each hit
// carries channel_slug + created_at, so we group them per channel (the user's Kick history first;
// channels not in the history only when asked), place every hit on that channel's Kick VOD (so the
// inline player opens it, like a scan hit) and open one result tab per channel, marked 🔎 and kept
// apart from the channel's normal scan tab (id "kick:<channel>#kw").
//
// Checked live 2026-10-17: no OR syntax ("a | b", "a OR b", quotes → 0 hits; "a b" needs both), so
// several keywords = one search each. kicklogz also stems ("hiccups" finds "hiccup"), so every hit
// is re-checked with KWS's own whole-word matching. "total" in its answer is not reliable; we page
// with nextCursor up to KF_MAX_PAGES per keyword (50 hits per page, newest first).
const KF_STATE_KEY = 'kwsKickFind';   // chrome.storage.session — progress for the panel
const KF_MAX_KEYWORDS = 5;
const KF_MAX_PAGES = 40;              // per keyword → up to 2,000 hits
const KF_MAX_VOD_CHANNELS = 40;       // channels whose Kick VOD list is looked up (others: real time only)
let kfRunning = null;                 // { stop: bool }

async function kfSetState(st) { try { await chrome.storage.session.set({ [KF_STATE_KEY]: st }); } catch (_) {} }

async function kfFindOnePage(tabRef, args) {
  let r = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    const used = tabRef.id;
    try { r = await kicklogz_searchPage(used, args); } catch (e) { r = { error: e?.message || 'script' }; }
    if (r.hits || r.rateLimited) return r;
    if (kicklogz_isTabGone(r.error)) {
      tabRef.revived = (tabRef.revived || 0) + 1;
      if (tabRef.revived > 5) return r;
      try { if (tabRef.id === used) tabRef.id = await kicklogz_reviveTab(); } catch (_) {}
      attempt--;
    } else if (r.error === 'no-csrf') {
      try { await chrome.tabs.reload(tabRef.id); await kicklogz_waitComplete(tabRef.id); } catch (_) {}
    } else {
      await kws_sleep(1500 * (attempt + 1));
    }
  }
  return r;
}

function kfMatcher(kw) {
  const sub = kw.startsWith('~');
  const word = (sub ? kw.slice(1) : kw).toLowerCase();
  return (text) => { const l = String(text || '').toLowerCase(); return sub ? l.includes(word) : kws_matchesWholeWord(l, word); };
}

async function kfRun({ keywords, days, includeNew }) {
  if (kfRunning) return { ok: false, reason: 'running' };
  try { if (!(await chrome.permissions.contains({ origins: KICKLOGZ_ORIGINS }))) return { ok: false, reason: 'permission' }; } catch (_) { return { ok: false, reason: 'permission' }; }
  const kws = [...new Set((keywords || []).map((k) => String(k).trim()).filter(Boolean))].slice(0, KF_MAX_KEYWORDS);
  if (!kws.length) return { ok: false, reason: 'empty' };
  const nDays = [1, 2, 3, 7, 14, 30].includes(Number(days)) ? Number(days) : 7;
  const run = { stop: false };
  kfRunning = run;
  const toMs = Date.now();
  const fromMs = toMs - nDays * 86400000;
  const from = new Date(fromMs).toISOString();
  const to = new Date(toMs).toISOString();
  let hist = {};
  try { hist = (await chrome.storage.local.get('kickKwsHistory')).kickKwsHistory || {}; } catch (_) {}
  const histSet = new Set(Object.keys(hist).filter((k) => !k.startsWith('_')).map((k) => kws_normalizeChannel(k)));
  const st = { running: true, keywords: kws, days: nDays, kwIndex: 0, pages: 0, hits: 0, channels: 0, startedAt: Date.now() };
  await kfSetState(st);

  const byChannel = new Map(); // channel → [{ h, kw }]
  const seen = new Set();
  let limited = false;
  let tabId = null;
  try { tabId = await kicklogz_acquireTab(); } catch (_) {}
  if (tabId == null) { kfRunning = null; await kfSetState(null); return { ok: false, reason: 'tab' }; }
  const tabRef = { id: tabId };
  try {
    for (let i = 0; i < kws.length && !run.stop && !limited; i++) {
      const kw = kws[i];
      const match = kfMatcher(kw);
      st.kwIndex = i;
      let cursor = null;
      for (let page = 0; page < KF_MAX_PAGES && !run.stop; page++) {
        const r = await kfFindOnePage(tabRef, { query: kw.replace(/^~/, ''), channel: '', from, to, cursor });
        if (r.rateLimited) { limited = true; break; }
        if (!r.hits) { console.warn('[KWS KF] search failed for', kw, r.error); break; }
        st.pages++;
        for (const h of r.hits) {
          if (!h || !h.content || !match(h.content)) continue; // kicklogz stems words — keep KWS's own rule
          const ch = kws_normalizeChannel(h.channel_slug || '');
          if (!ch || (!includeNew && !histSet.has(ch))) continue;
          const key = h.id != null ? 'id:' + h.id : ch + '|' + h.created_at + '|' + h.username + '|' + h.content;
          if (seen.has(key)) continue;
          seen.add(key);
          if (!byChannel.has(ch)) byChannel.set(ch, []);
          byChannel.get(ch).push({ h, kw });
          st.hits++;
        }
        st.channels = byChannel.size;
        await kfSetState(st);
        if (!r.nextCursor || !r.hits.length) break;
        cursor = r.nextCursor;
      }
    }
  } finally {
    kicklogz_releaseTab();
  }

  // history channels first, then by hit count
  const channels = [...byChannel.keys()].sort((a, b) => (histSet.has(b) - histSet.has(a)) || (byChannel.get(b).length - byChannel.get(a).length));
  st.phase = 'vods';
  await kfSetState(st);
  await spEnsureLoaded();
  const startDate = kws_format(new Date(fromMs - 86400000));
  const endDate = kws_format(new Date(toMs + 86400000));
  let firstId = null;
  for (let ci = 0; ci < channels.length; ci++) {
    const ch = channels[ci];
    let vods = [];
    if (ci < KF_MAX_VOD_CHANNELS && !run.stop) {
      try { vods = await kick_getVodSessions(ch, startDate, endDate); } catch (_) { vods = []; }
    }
    const groups = {};
    for (const { h, kw } of byChannel.get(ch)) {
      const tsMs = Date.parse(h.created_at);
      const vod = Number.isFinite(tsMs) ? vods.find((v) => tsMs >= v.startMs && tsMs <= v.endMs) : null;
      const offsetSec = vod ? Math.max(0, Math.round((tsMs - vod.startMs) / 1000)) : null;
      const localDate = String(h.created_at || '').slice(0, 10) || startDate;
      const item = {
        ts: Number.isFinite(tsMs) ? new Date(tsMs).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }) : '?',
        rawTs: Number.isFinite(tsMs) ? tsMs : null,
        localDate, keywords: [kw.replace(/^~/, '')], username: h.username || '?', message: h.content,
        playback_offset: offsetSec, playback_ts: offsetSec != null ? kws_formatPlayback(offsetSec) : null,
        vod_id: vod?.vodId || null, vod_slug: vod?.vodSlug || null, vod_source: vod && !vod.subOnly ? (vod.vodSource || null) : null,
        ...(vod && vod.subOnly ? { vod_state: 'subonly' } : {}), // subscriber-only VOD: not playable
        vod_channel: ch, vod_title: vod?.title || null, vod_timestamp: vod?.startMs || null,
        log_source: 'kicklogz',
        ...(vod ? {} : { vod_state: 'expired' }), // no Kick VOD (gone, or not looked up) — shown like Twitch's "VOD expired"
      };
      if (!groups[localDate]) groups[localDate] = { date: localDate, displayDate: localDate, sourceDate: localDate, messages: [], channel: ch, sourceServices: ['kicklogz'] };
      groups[localDate].messages.push(item);
    }
    const glist = Object.values(groups).sort((a, b) => (a.date < b.date ? -1 : 1));
    glist.forEach((g) => g.messages.sort((a, b) => (a.rawTs || 0) - (b.rawTs || 0)));
    const n = glist.reduce((x, g) => x + g.messages.length, 0);
    const id = 'kick:' + ch + '#kw';
    spScans[id] = {
      id, platform: 'kick', channel: ch, status: 'done', mode: 'full',
      params: { keyword: kws.join(', '), startDate, endDate },
      createdAt: Date.now() + ci, startedAt: st.startedAt, finishedAt: Date.now(),
      done: 1, total: 1, matchedLines: n, matchedDays: glist.length, failedChunks: 0, groups: glist, keywords: kws,
      totalSessions: vods.length,
      kwFind: { keywords: kws, days: nDays, inHistory: histSet.has(ch), vodsChecked: ci < KF_MAX_VOD_CHANNELS },
    };
    if (!firstId) firstId = id;
  }
  await spPersist(true);
  kfRunning = null;
  await kfSetState(null);
  return { ok: true, channels: channels.length, hits: st.hits, firstId, limited, stopped: run.stop };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.type !== 'string' || !msg.type.startsWith('KWS_KF_')) return;
  if (msg.type === 'KWS_KF_STOP') { if (kfRunning) kfRunning.stop = true; sendResponse({ ok: true }); return; }
  if (msg.type === 'KWS_KF_RUN') {
    kfRun(msg).then(sendResponse, (e) => { kfRunning = null; kfSetState(null); sendResponse({ ok: false, error: String(e && e.message || e) }); });
    return true;
  }
});
