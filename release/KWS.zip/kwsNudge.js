// KWS 1.2.6.9 — instant feedback for a site badge click ("Search ▶" on Twitch / Kick / SOOP).
// On a slow computer the background could take a few seconds to answer, so nothing seemed to
// happen and people clicked again and again; and when it answered too late Chrome no longer let it
// open the side panel (that needs a fresh click). Now a small KWS note shows at once, says when
// it's just slow (no need to click again), and says when the panel couldn't be opened.
(function () {
  'use strict';
  if (globalThis.kwsBadgeSend) return;
  const T = (k, ...a) => { try { return chrome.i18n.getMessage(k, a.map(String)) || ''; } catch (_) { return ''; } };
  let box = null, hideT = 0;
  function note(text, kind) {
    if (!box || !document.contains(box)) {
      box = document.createElement('div');
      box.setAttribute('role', 'status');
      box.style.cssText = 'position:fixed;z-index:2147483647;right:18px;bottom:18px;max-width:340px;padding:10px 14px;border-radius:14px;background:rgba(15,17,23,.94);color:#e5e7eb;font:600 13px/1.45 -apple-system,"Segoe UI","Malgun Gothic",sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.45);border:1px solid rgba(255,255,255,.12);pointer-events:none;transition:opacity .2s';
      (document.body || document.documentElement).appendChild(box);
    }
    box.textContent = text;
    box.style.borderColor = kind === 'warn' ? 'rgba(251,191,36,.55)' : 'rgba(255,255,255,.12)';
    box.style.opacity = '1';
    clearTimeout(hideT);
    hideT = setTimeout(() => { if (box) box.style.opacity = '0'; }, kind === 'warn' ? 6000 : 2200);
  }
  const pending = new Map(); // channel → since (ignore repeat clicks while one is on its way)
  globalThis.kwsBadgeSend = function (msg) {
    const key = msg.platform + ':' + msg.channel;
    const since = pending.get(key);
    if (since && Date.now() - since < 8000) { note(T('nudgeWait') || 'KWS…', 'warn'); return; }
    pending.set(key, Date.now());
    if (msg.openPanel) note(T('nudgeStarting', msg.channel) || 'KWS…');
    const slow = setTimeout(() => note(T('nudgeSlow') || 'KWS…', 'warn'), 2500);
    let p;
    try { p = chrome.runtime.sendMessage(msg); } catch (_) { p = Promise.reject(); }
    Promise.resolve(p).then((r) => {
      clearTimeout(slow);
      pending.delete(key);
      if (!msg.openPanel) return;
      if (r && r.panel === 'fail') note(T('nudgePanel') || 'KWS', 'warn');
      else if (box) box.style.opacity = '0';
    }, () => { clearTimeout(slow); pending.delete(key); });
  };
})();
