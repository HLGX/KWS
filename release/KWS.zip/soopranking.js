// VOD KWS — SOOP Ranking page badge injector (afevent2.sooplive.com)
(async function() {
  'use strict';

  const STORAGE_KEY = 'soopSearchHistory';
  const SCAN_CACHE = {}; // streamerId → { state: 'running'|'queued', percent }
  const LOCAL_SET_AT = {}; // streamerId → timestamp of last local (optimistic) write
  const LOCAL_GRACE_MS = 6000; // 이 시간 동안은 서버 폴링이 로컬에서 방금 세팅한 값을 못 지움

  async function loadHistory() {
    try {
      const r = await chrome.storage.local.get(STORAGE_KEY);
      return r[STORAGE_KEY] || {};
    } catch { return {}; }
  }

  function setLocal(id, entry) {
    SCAN_CACHE[id] = entry;
    LOCAL_SET_AT[id] = Date.now();
  }

  async function fetchScanState() {
    try {
      const res = await chrome.runtime.sendMessage({ type: 'KWS_SOOP_GET_STATUS' });
      if (!res) return;
      const now = Date.now();
      const fresh = {};
      if (res.activeStreamerId) fresh[res.activeStreamerId.toLowerCase()] = { state: 'running', percent: res.percent || 0 };
      for (const q of (res.queue || [])) {
        const id = (q.streamerId || '').toLowerCase();
        if (id && !fresh[id]) fresh[id] = { state: 'queued', percent: 0 };
      }
      // 서버 스냅샷으로 교체하되, 방금(LOCAL_GRACE_MS 이내) 로컬에서 낙관적으로 세팅한 항목은
      // 서버가 아직 못 따라왔을 수 있으니 그대로 유지
      for (const id of Object.keys(SCAN_CACHE)) {
        if (!fresh[id] && LOCAL_SET_AT[id] && (now - LOCAL_SET_AT[id] < LOCAL_GRACE_MS)) {
          fresh[id] = SCAN_CACHE[id];
        }
      }
      for (const k of Object.keys(SCAN_CACHE)) delete SCAN_CACHE[k];
      Object.assign(SCAN_CACHE, fresh);
    } catch {}
  }

  let HISTORY = await loadHistory();
  await fetchScanState();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes[STORAGE_KEY]) return;
    HISTORY = changes[STORAGE_KEY].newValue || {};
    scheduleInject();
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'KWS_SOOP_STATE' && msg.streamerId) {
      const id = msg.streamerId.toLowerCase();
      if (msg.state === 'done') { delete SCAN_CACHE[id]; delete LOCAL_SET_AT[id]; }
      else setLocal(id, { state: msg.state, percent: msg.percent || 0 });
      scheduleInject();
    }
  });

  if (!document.getElementById('kws-soop-rank-style')) {
    const s = document.createElement('style');
    s.id = 'kws-soop-rank-style';
    s.textContent = `.kws-soop-rank-badge{display:inline-flex;align-items:center;padding:1px 7px;border-radius:99px;font-size:10px;font-weight:700;white-space:nowrap;vertical-align:middle;margin-left:6px;cursor:pointer;font-family:-apple-system,sans-serif;line-height:1.6;letter-spacing:0.01em;transition:all 0.15s;}`;
    document.head.appendChild(s);
  }

  const SKIP = new Set(['vod','live','search','explore','main','station','replay','highlight','undefined','null']);

  function makeBadge(id) {
    const h = HISTORY[id];
    const sc = SCAN_CACHE[id];
    const badge = document.createElement('span');
    badge.className = 'kws-soop-rank-badge';
    badge.dataset.kwsStreamerId = id;

    if (sc?.state === 'running') {
      badge.textContent = `⏳ ${sc.percent || 0}%`;
      badge.style.cssText = 'background:rgba(251,146,60,0.15);border:1px solid rgba(251,146,60,0.4);color:#fb923c;cursor:default;';
      badge.title = `Scanning ${id}...`;
    } else if (sc?.state === 'queued') {
      badge.textContent = 'queued';
      badge.style.cssText = 'background:rgba(6,182,212,0.12);border:1px solid rgba(6,182,212,0.35);color:#22d3ee;cursor:default;';
      badge.title = 'Queued — waiting for slot';
    } else if (!h) {
      badge.textContent = 'KWS ▶';
      badge.style.cssText = 'background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.3);color:#f87171;';
      badge.title = `Search ${id} on SOOP KWS`;
      badge.addEventListener('mouseenter', () => badge.style.background = 'rgba(239,68,68,0.22)');
      badge.addEventListener('mouseleave', () => badge.style.background = 'rgba(239,68,68,0.12)');
      badge.addEventListener('click', e => {
        e.preventDefault(); e.stopPropagation();
        setLocal(id, { state: 'queued', percent: 0 });
        badge.textContent = 'queued';
        badge.style.cssText = 'background:rgba(6,182,212,0.12);border:1px solid rgba(6,182,212,0.35);color:#22d3ee;cursor:default;';
        badge.title = 'Queued — waiting for slot';
        chrome.runtime.sendMessage({ type: 'KWS_SP_EXTERNAL_SCAN', platform: 'soop', channel: id });
      });
    } else {
      const when = h.searchedAt || h.savedAt || null;
      const daysAgo = when ? Math.floor((Date.now() - new Date(when)) / 86400000) : null;
      const isRecent = daysAgo !== null && daysAgo <= 1;
      const isStale = daysAgo !== null && daysAgo > 14;
      const label = daysAgo === 0 ? 'Today ↺' : daysAgo === 1 ? 'Yesterday ↺' : daysAgo !== null ? `${daysAgo}d ago ↺` : 'Not searched ▶';
      // 1.2.5.36: in the history but never searched (e.g. added from the ranking) → blue
      const col = daysAgo === null ? { bg: 'rgba(56,189,248,0.12)', bdr: 'rgba(56,189,248,0.35)', txt: '#38bdf8', hov: 'rgba(56,189,248,0.22)' } : isStale
        ? { bg: 'rgba(239,68,68,0.1)',  bdr: 'rgba(239,68,68,0.3)',  txt: '#f87171', hov: 'rgba(239,68,68,0.2)' }
        : isRecent
          ? { bg: 'rgba(34,197,94,0.12)', bdr: 'rgba(34,197,94,0.35)', txt: '#4ade80', hov: 'rgba(34,197,94,0.22)' }
          : { bg: 'rgba(234,179,8,0.12)',  bdr: 'rgba(234,179,8,0.35)',  txt: '#fbbf24', hov: 'rgba(234,179,8,0.22)' };
      badge.textContent = label;
      badge.style.cssText = `background:${col.bg};border:1px solid ${col.bdr};color:${col.txt};`;
      badge.title = `${h.matchedCount || 0} hits · Click to re-scan`;
      if (h.memo) {
        const short = h.memo.length > 15 ? h.memo.slice(0, 15) + '…' : h.memo;
        const t1 = document.createElement('span'); t1.textContent = label; badge.textContent = '';
        badge.appendChild(t1);
        const t2 = document.createElement('span'); t2.textContent = ' · ' + short; t2.style.cssText = 'color:#f87171;font-weight:800;';
        badge.appendChild(t2);
        badge.title += '\n📝 ' + h.memo;
      }
      badge.addEventListener('mouseenter', () => badge.style.background = col.hov);
      badge.addEventListener('mouseleave', () => badge.style.background = col.bg);
      badge.addEventListener('click', e => {
        e.preventDefault(); e.stopPropagation();
        setLocal(id, { state: 'queued', percent: 0 });
        badge.textContent = 'queued';
        badge.style.cssText = 'background:rgba(6,182,212,0.12);border:1px solid rgba(6,182,212,0.35);color:#22d3ee;cursor:default;';
        badge.title = 'Queued — waiting for slot';
        chrome.runtime.sendMessage({ type: 'KWS_SP_EXTERNAL_SCAN', platform: 'soop', channel: id }); // 외부 사이트에서는 confirm() 팝업이 백그라운드 탭에서 무시될 수 있어서 무조건 풀스캔
      });
    }

    return badge;
  }

  function injectBadges() {
    document.querySelectorAll('.kws-soop-rank-badge').forEach(el => el.remove());

    const seen = new Set();

    function tryInject(el) {
      if (seen.has(el)) return; seen.add(el);
      const href = el.getAttribute('href') || '';
      // /station/ID 또는 bjid=ID 패턴 (SOOP 프로필/랭킹 페이지 공통)
      const stationMatch = href.match(/\/station\/([^/?#"'\s]+)/);
      const bjidMatch = href.match(/(?:bjid|bj_id|user_id)=([^&"'\s]+)/i);
      let id = null;
      if (stationMatch) id = decodeURIComponent(stationMatch[1]).toLowerCase().replace(/\/$/, '');
      else if (bjidMatch) id = decodeURIComponent(bjidMatch[1]).toLowerCase();
      if (!id) {
        const raw = el.dataset.bjid || el.dataset.userid || el.dataset.bjId || el.dataset.userId || '';
        if (raw) id = raw.toLowerCase().trim();
      }
      if (!id || id.length < 2 || SKIP.has(id) || /^\d+$/.test(id)) return;
      if (el.nextElementSibling?.classList?.contains('kws-soop-rank-badge')) return;
      el.insertAdjacentElement('afterend', makeBadge(id));
    }

    // 랭킹 표 안의 스트리머 링크들
    document.querySelectorAll('a[href*="/station/"], a[href*="bjid="], a[href*="bj_id="], [data-bjid], [data-userid]').forEach(tryInject);
  }

  let _timer;
  function scheduleInject() { clearTimeout(_timer); _timer = setTimeout(injectBadges, 400); }

  [0, 500, 1000, 2000].forEach(d => setTimeout(injectBadges, d));
  new MutationObserver(scheduleInject).observe(document.body, { childList: true, subtree: true });

  setInterval(async () => {
    await fetchScanState();
    scheduleInject();
  }, 3000);

})();
