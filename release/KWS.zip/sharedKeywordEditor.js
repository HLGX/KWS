(function(){
  'use strict';
  if (window.KWSSharedKeywordEditor) return;

  // 저장된 키워드 profile을 메모리에 캐시
  let _cachedProfile = null;
  chrome.storage.local.get('twitchKwsKeywordProfile').then(r => {
    if (r.twitchKwsKeywordProfile?.keyword) {
      _cachedProfile = r.twitchKwsKeywordProfile;
    }
  }).catch(()=>{});

  const GROUPS = [
    {sub:false,kws:['hiccup','hiccups','hicup','hicups','hickup','hickups','hiccuping','hiccupped','hiccupp','hiccoughs','hiccough']},
    {sub:true, kws:['딸꾹','딸국','딱꾹','딱국','꾹질','국질','딸꾹질','딸국질','딸꾸기','딸꾹이','딱꾹질']},
    {sub:false,kws:['икота','икотка','икоту','икоты','икнул','икнула','икает','икаю','икотта']},
    {sub:false,kws:['гикавка','гикає','гикнув','гикнула','гикаю','гикати']},
    {sub:false,kws:['гіканне','гікаць','гікае']},
    {sub:true, kws:['しゃっくり','シャックリ','しゃくり','しゃっく','吃逆']},
    {sub:true, kws:['打嗝','打咯','嗝','呃逆','打格','打隔']},
    {sub:true, kws:['hipo','hipos','hipó','hipando','hipar']},
    {sub:false,kws:['schluckauf','schluckaif','schluckof','schluck auf','hickser']},
    {sub:false,kws:['czkawka','czkafka','czkawke','czkawki','czakwka','czkawką','czkawkę']},
    {sub:false,kws:['škytavka','škytavku','škytám','škytá','škytat','skytavka']},
    {sub:false,kws:['čkanie','čká','čkam','čkať']},
    {sub:false,kws:['csuklás','csuklok','csuklik','csuklást']},
    {sub:false,kws:['štucanje','štuca','štucan','štucam','stucanje','stuca']},
    {sub:false,kws:['хълцане','хълца','хълцам']},
    {sub:false,kws:['штуцање','штуца','штуцам']},
    {sub:false,kws:['kolcanje','kolca','kolcam','kolcat']},
    {sub:false,kws:['sughiț','sughit','sughitul','sughite','sughita','sugit','am sughițuri']},
    {sub:true, kws:['สะอึก']},
    {sub:false,kws:['nấc','nấc cụt','nac cut']},
    {sub:false,kws:['cegukan','ceguken']},
    {sub:false,kws:['sedu','sedu sedan']},
    {sub:false,kws:['hoquet','hoquets','hoqueter']},
    {sub:false,kws:['singhiozzo','singhiozzi','singhiozzare']},
    {sub:false,kws:['soluço','soluços','soluco','solucos','soluçar']},
    {sub:false,kws:['hıçkırık','hickirik','hıçkırıklar']},
    {sub:true, kws:['فواق','حازوقة','هيكاب']},
    {sub:true, kws:['हिचकी','हिचकियाँ']},
    {sub:false,kws:['hik','hikken','de hik','gehik']},
    {sub:false,kws:['hicka','hickan','hickade']},
    {sub:false,kws:['hikke','hikker','hikkende']},
    {sub:false,kws:['hikka','hikkaa','hikkailen']},
    {sub:false,kws:['hicksti','histi','hista']},
    {sub:false,kws:['λόξιγκας','loxigas','λοξυγμός','loxygmos']},
    {sub:false,kws:['שיהוק','שיהוקים']},
    {sub:false,kws:['lemzë','lemza']},
    {sub:true, kws:['ხვრინვა','ხვრინი']},
    {sub:true, kws:['կըտկըտոց','կըտկըտալ']},
    {sub:false,kws:['hıçqırıq','hicqirig']},
    {sub:true, kws:['விக்கல்']},
    {sub:true, kws:['হেঁচকি','হেচকি']},
    {sub:true, kws:['ہچکی']},
    {sub:true, kws:['سکسکه','هیکاپ']},
    {sub:false,kws:['òsúkèsúkè']},
    {sub:false,kws:['ingwici']},
    {sub:false,kws:['kwikwi']},
    {sub:false,kws:['singlot','singlots','singlotar']},
    {sub:false,kws:['soluzo','soluzos']},
  ];
  const EXCLUDES = ['chipotle','chipo','chipotles','chipotle sauce','chipotle chicken','chipotle bowl','chipotle order','chick','chicks','chicken','chickens','chicky','chickie','chickpea','chickpeas','chickadee','chickadees','chick-fil-a','chickfila','chick fil a','chic','chico','chica','chicas','chicle','hiccup sauce','hiccup drink','hiccup song','hiccup meme','hiccupcup','hiccupcupcup','hippo','hippos','hippopotamus','hippopotamuses','hipoteca','hipotecas','hipódromo','hipodromo','hipopótamo','hipopotamo','hipócrita','hipocrita','hipocondria','hipoglucemia','hipnosis','hipnotizar','hiper','hipster','hipsters','hoquetage','hickory','hickman','hickok','hicksville','hicks','しゃくり上げる','しゃくりあげる','икотник','สะอื้น'];
  const defaultItems = () => GROUPS.flatMap(g => g.kws.map(word => ({word, substring:g.sub})));
  const defaultValue = () => {
    if (_cachedProfile?.keyword) return _cachedProfile.keyword;
    return defaultItems().map(i => (i.substring?'~':'')+i.word).concat(EXCLUDES.map(x=>'-'+x)).join(', ');
  };
  const esc = s => String(s||'').replace(/[&<>\"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  function splitWords(s){ return String(s||'').split(/[\n,]/).map(x=>x.trim()).filter(Boolean); }
  function parseValue(v){
    const parts = splitWords(v);
    if (!parts.length) return { include: defaultItems(), exclude: [...EXCLUDES], isDefault:true };
    return { include: parts.filter(p=>!p.startsWith('-')).map(p=>({word:p.replace(/^[~+]+/,''), substring:p.startsWith('~')})), exclude: parts.filter(p=>p.startsWith('-')).map(p=>p.replace(/^-+/,'')), isDefault:false };
  }
  function updatePreview(inputId, previewId){
    const el = document.getElementById(inputId), pr = document.getElementById(previewId); if(!el||!pr) return;
    const val = (el.value||'').trim();
    if(!val){ pr.textContent='⚠ No keywords set — click to set'; pr.style.color='rgba(251,191,36,0.85)'; return; }
    const p = splitWords(val), inc=p.filter(x=>!x.startsWith('-')), exc=p.filter(x=>x.startsWith('-'));
    const sub=inc.filter(x=>x.startsWith('~')).length; const exact=inc.length-sub;
    pr.textContent = (inc.length?('+'+inc.length+' words'):'Default +') + (sub?` (= ${exact} · ≈ ${sub})`:'') + (exc.length?' · -'+exc.length+' words':'') + ' — click to edit';
  }
  async function open(opts){
    const {modalId,inputId,previewId,accent='rgba(124,58,237,.9)',storageKey,historyKey,onSaved} = opts;
    // 이미 모달이 열려있으면 닫고 재열기 방지 (중복 방지)
    if (document.getElementById(modalId)) return;
    const input = document.getElementById(inputId); if(!input) return;
    // storage에서 저장된 프로필 우선 읽기 (DOM value보다 정확)
    let include, exclude;
    try {
      const sd = await chrome.storage.local.get(['twitchKwsKeywordProfile', storageKey]).catch(()=>({}));
      const profile = sd['twitchKwsKeywordProfile'] || null;
      console.log('[KWS] open() profile from storage:', profile?.plus?.length, 'keywords'); if (profile?.plus?.length) {
        include = profile.plus.map(p => ({ word: p.replace(/^[~]+/,''), substring: p.startsWith('~') }));
        exclude = profile.minus || [];
        // input DOM도 동기화
        if (input.value !== profile.keyword) input.value = profile.keyword;
      } else {
        const parsed = parseValue(profile?.keyword || input.value);
        include = parsed.include; exclude = parsed.exclude;
      }
    } catch {
      const parsed = parseValue(input.value);
      include = parsed.include; exclude = parsed.exclude;
    }
    const m=document.createElement('div'); m.id=modalId;
    if (!document.getElementById('kws-keyword-editor-scrollbar-style')) {
      const scrollStyle = document.createElement('style');
      scrollStyle.id = 'kws-keyword-editor-scrollbar-style';
      scrollStyle.textContent = `
        #${modalId} ::-webkit-scrollbar { width:8px; }
        #${modalId} ::-webkit-scrollbar-track { background:transparent; }
        #${modalId} ::-webkit-scrollbar-thumb { background:rgba(255,255,255,0.15);border-radius:99px; }
      `;
      document.head.appendChild(scrollStyle);
    }
    m.style.cssText='position:fixed;z-index:2147483647;right:16px;top:18px;width:460px;max-width:calc(100vw - 20px);max-height:calc(100vh - 20px);overflow:auto;border-radius:18px;border:1px solid rgba(255,255,255,.18);background:rgba(10,12,18,.92);box-shadow:0 26px 70px rgba(0,0,0,.75),inset 0 1px 0 rgba(255,255,255,.1);backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px);color:#e5e7eb;font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:12px;';
    m.innerHTML=`<div id="${modalId}-hdr" style="display:flex;align-items:center;justify-content:space-between;padding:14px 16px 10px;border-bottom:1px solid rgba(255,255,255,.07);cursor:move;background:rgba(255,255,255,.02);border-radius:18px 18px 0 0;"><b style="color:#fff;font-size:13px;">✏️ Keyword Editor</b><button id="${modalId}-close" style="width:26px;height:26px;border:0;border-radius:8px;background:rgba(255,255,255,.08);color:rgba(255,255,255,.6);cursor:pointer;font-size:15px;display:flex;align-items:center;justify-content:center;line-height:1;flex-shrink:0;">×</button></div><div style="padding:14px 16px"><div style="padding:9px 10px;border-radius:11px;background:rgba(99,102,241,.08);border:1px solid rgba(99,102,241,.18);color:rgba(255,255,255,.58);font-size:10.5px;line-height:1.5;margin-bottom:12px"><b style="color:#a5b4fc">= Exact</b> — whole-word match only &nbsp;|&nbsp; <b style="color:#fb923c">≈ Contains</b> — matches anywhere in the word<br><span style="color:rgba(255,255,255,.38)">Click the mode button on each tag to toggle.</span></div><div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px"><div style="font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:#a5b4fc">+ Keywords</div><div style="display:flex;gap:5px"><button id="${modalId}-exact" style="height:22px;padding:0 8px;border-radius:6px;cursor:pointer;border:1px solid rgba(99,102,241,.4);background:rgba(99,102,241,.12);color:#a5b4fc;font-size:10px;font-weight:700">All = Exact</button><button id="${modalId}-sub" style="height:22px;padding:0 8px;border-radius:6px;cursor:pointer;border:1px solid rgba(251,146,60,.4);background:rgba(251,146,60,.1);color:#fb923c;font-size:10px;font-weight:700">All ≈ Contains</button></div></div><div id="${modalId}-tags" style="min-height:120px;max-height:260px;overflow-y:auto;padding:10px;border-radius:11px;border:1px solid rgba(99,102,241,.3);background:rgba(99,102,241,.05);display:flex;flex-wrap:wrap;gap:5px;align-content:flex-start"></div><div style="display:flex;gap:5px;margin-top:7px"><input id="${modalId}-add" placeholder="Add a word, then press Enter…" style="flex:1;height:34px;padding:0 12px;border-radius:8px;border:1px solid rgba(99,102,241,.28);background:rgba(99,102,241,.06);color:#e2e8f0;font-size:11px;outline:none"><button id="${modalId}-add-exact" style="height:34px;padding:0 11px;border-radius:8px;cursor:pointer;border:1px solid rgba(99,102,241,.4);background:rgba(99,102,241,.14);color:#a5b4fc;font-weight:800">=</button><button id="${modalId}-add-sub" style="height:34px;padding:0 11px;border-radius:8px;cursor:pointer;border:1px solid rgba(251,146,60,.4);background:rgba(251,146,60,.1);color:#fb923c;font-weight:800">≈</button></div><div style="font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:rgba(248,113,113,.85);margin:12px 0 6px">- Exclude</div><textarea id="${modalId}-minus" style="width:100%;height:84px;padding:11px 13px;border-radius:10px;border:1px solid rgba(248,113,113,.28);background:rgba(248,113,113,.06);color:#fecaca;font-size:11px;outline:none;resize:vertical;line-height:1.5;box-sizing:border-box"></textarea><div style="margin-top:7px;font-size:10px;line-height:1.45;color:rgba(255,255,255,.28)">Words to block — one per line or comma-separated.</div><div style="display:flex;gap:7px;margin-top:12px"><button id="${modalId}-reset" style="height:38px;padding:0 14px;display:flex;align-items:center;justify-content:center;text-align:center;border-radius:10px;cursor:pointer;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.05);color:rgba(255,255,255,.65);font-weight:700">Reset default</button><button id="${modalId}-save" style="flex:1;height:38px;border:0;border-radius:11px;cursor:pointer;background:${accent};color:#fff;font-weight:800;display:flex;align-items:center;justify-content:center;text-align:center;padding:0 14px;">✓ Apply & Save</button></div></div>`;
    document.body.appendChild(m);
    (function(){
      const hdr = m.querySelector(`#${modalId}-hdr`);
      if (!hdr) return;
      let dragging=false, ox=0, oy=0;
      hdr.addEventListener('mousedown', function(e){
        if (e.target.closest('button,input,textarea,select,label')) return;
        dragging=true;
        const r=m.getBoundingClientRect();
        ox=e.clientX-r.left; oy=e.clientY-r.top;
        m.style.left=r.left+'px'; m.style.top=r.top+'px'; m.style.right='auto'; m.style.bottom='auto';
        document.body.style.userSelect='none';
      });
      window.addEventListener('mousemove', function(e){
        if (!dragging) return;
        const left=Math.min(Math.max(8, e.clientX-ox), Math.max(8, window.innerWidth-m.offsetWidth-8));
        const top=Math.min(Math.max(8, e.clientY-oy), Math.max(8, window.innerHeight-m.offsetHeight-8));
        m.style.left=left+'px'; m.style.top=top+'px';
      });
      window.addEventListener('mouseup', function(){ if(!dragging) return; dragging=false; document.body.style.userSelect=''; });
    })();
    const tags=m.querySelector(`#${modalId}-tags`), minus=m.querySelector(`#${modalId}-minus`), add=m.querySelector(`#${modalId}-add`);
    minus.value = exclude.join('\n');
    function render(){ tags.innerHTML=''; include.forEach((it,i)=>{ const sub=it.substring; const t=document.createElement('div'); t.style.cssText=`display:inline-flex;align-items:center;gap:3px;padding:3px 4px 3px 8px;border-radius:8px;border:1px solid ${sub?'rgba(251,146,60,.42)':'rgba(99,102,241,.45)'};background:${sub?'rgba(251,146,60,.12)':'rgba(99,102,241,.16)'};color:#e5e7eb;font-size:11px;`; t.innerHTML=`<button data-mode="${i}" style="width:22px;height:20px;border:0;border-radius:5px;background:${sub?'rgba(251,146,60,.22)':'rgba(99,102,241,.25)'};color:${sub?'#fb923c':'#a5b4fc'};cursor:pointer;font-weight:900">${sub?'≈':'='}</button><span>${esc(it.word)}</span><button data-del="${i}" style="border:0;background:transparent;color:rgba(255,255,255,.45);cursor:pointer;font-size:14px">×</button>`; tags.appendChild(t); }); }
    tags.onclick=e=>{ const mi=e.target.getAttribute('data-mode'), di=e.target.getAttribute('data-del'); if(mi!=null){include[+mi].substring=!include[+mi].substring;render();} if(di!=null){include.splice(+di,1);render();} };
    function addWord(sub){ const w=add.value.trim(); if(!w) return; include.push({word:w.replace(/^[~+]+/,''), substring:sub}); add.value=''; render(); }
    m.querySelector(`#${modalId}-close`).onclick=()=>m.remove();
    m.querySelector(`#${modalId}-exact`).onclick=()=>{include=include.map(x=>({...x,substring:false}));render();};
    m.querySelector(`#${modalId}-sub`).onclick=()=>{include=include.map(x=>({...x,substring:true}));render();};
    m.querySelector(`#${modalId}-add-exact`).onclick=()=>addWord(false);
    m.querySelector(`#${modalId}-add-sub`).onclick=()=>addWord(true);
    add.onkeydown=e=>{ if(e.key==='Enter'){e.preventDefault();addWord(false);} };
    m.querySelector(`#${modalId}-reset`).onclick=()=>{include=defaultItems(); exclude=[...EXCLUDES]; minus.value=exclude.join('\n'); render();};
    m.querySelector(`#${modalId}-save`).onclick=async()=>{
      // 입력창에 내용이 남아있으면 Exact로 자동 추가
      const pendingAdd = add.value.trim();
      if (pendingAdd) {
        splitWords(pendingAdd).forEach(w => {
          const word = w.replace(/^[~+=\-]+/,'');
          if (word && !include.find(i => i.word === word.toLowerCase()))
            include.push({ word: word.toLowerCase(), substring: false });
        });
        add.value = '';
      }
      const plus=include.map(it=>(it.substring?'~':'')+it.word);
      const ex=splitWords(minus.value).map(x=>x.replace(/^-+/,''));
      const val=plus.concat(ex.map(x=>'-'+x)).join(', ');
      input.value=val;
      updatePreview(inputId,previewId);
      const profile={keyword:val,plus,minus:ex,savedAt:new Date().toISOString()};
      try{
        await KWSSharedKeywordEditor.saveToAllPlatforms(val, profile);
        // 저장 후 즉시 검증: storage에서 다시 읽어서 plus가 맞는지 확인
        const verify = await chrome.storage.local.get(['twitchKwsKeywordProfile']);
        const saved = verify.twitchKwsKeywordProfile;
        if (!saved || !saved.plus || saved.plus.length !== plus.length) {
          console.error('[KWS] Profile save mismatch!', { expected: plus.length, got: saved?.plus?.length, saved });
        } else {
          console.log('[KWS] Profile saved OK:', saved.plus.length, 'keywords');
        }
      }catch(e){ console.error('[KWS] saveToAllPlatforms error:', e); }
      if(onSaved) onSaved(val,profile);
      m.remove();
    };
    render();
  }
  async function saveToAllPlatforms(val, profile) {
    // 3개 플랫폼 동시 저장
    const setObj = {};
    // Twitch
    setObj['twitchKwsKeywordProfile'] = profile;
    _cachedProfile = profile;
    setObj['kwsKeyword'] = val;
    // SOOP
    setObj['soopKeyword'] = val;
    // Kick (kickKwsSettings 객체 병합)
    const kickData = await chrome.storage.local.get(['kickKwsSettings']).catch(()=>({}));
    const kickSettings = Object.assign({}, kickData.kickKwsSettings || {}, { keyword: val, savedAt: profile.savedAt });
    setObj['kickKwsSettings'] = kickSettings;
    // 각 플랫폼 history에도 keyword_profile 업데이트
    const histData = await chrome.storage.local.get(['twitchKwsHistory','soopSearchHistory','kickKwsHistory']).catch(()=>({}));
    const twitchH = histData.twitchKwsHistory || {};
    twitchH.__keyword_profile__ = profile;
    setObj['twitchKwsHistory'] = twitchH;
    const soopH = histData.soopSearchHistory || {};
    soopH._globalKeyword = val;
    setObj['soopSearchHistory'] = soopH;
    const kickH = histData.kickKwsHistory || {};
    kickH.__keyword_profile__ = profile;
    setObj['kickKwsHistory'] = kickH;
    await chrome.storage.local.set(setObj);
    // 현재 탭에 다른 플랫폼 searcher에 키워드 변경 알림 (같은 페이지에 로드된 경우)
    window.dispatchEvent(new CustomEvent('kws-keyword-synced', { detail: { val, profile } }));
  }
  const _updateCache = (profile) => { _cachedProfile = profile; };
  window.KWSSharedKeywordEditor = { open, updatePreview, defaultValue, saveToAllPlatforms, EXCLUDES, GROUPS, _updateCache };
  // 초기화 완료 알림
  window.dispatchEvent(new CustomEvent('kws-shared-editor-ready'));
})();
