// KWS 1.2.6.9 — ★ favourites, checked by themselves once a day (loaded after overnight_bg.js).
//
// While "★ check favourites daily" is on (home card), an hourly alarm looks whether the last check
// is 20 h+ old; if so — and overnight mode isn't running — every ★ channel of every platform gets a
// normal "new VODs only" scan through the scan hub (so it shows up as a tab and writes its history
// like any scan). Channels with no hits close by themselves; the rest add up to a number on the
// toolbar icon until the user looks (home card → "show").
const FAV_KEY = 'kwsFavAuto';          // { on }
const FAV_STATE_KEY = 'kwsFavAutoState'; // { lastRun, running: [id], found: { id: hits }, seen }
const FAV_ALARM = 'kwsFavAuto';
const FAV_EVERY_MS = 20 * 3600 * 1000;

async function favGet() {
  const d = await chrome.storage.local.get([FAV_KEY, FAV_STATE_KEY]).catch(() => ({}));
  return { on: !!(d[FAV_KEY] && d[FAV_KEY].on), st: d[FAV_STATE_KEY] || { lastRun: 0, running: [], found: {}, seen: true } };
}
async function favSaveState(st) { try { await chrome.storage.local.set({ [FAV_STATE_KEY]: st }); } catch (_) {} }

async function favChannels() {
  const out = [];
  const d = await chrome.storage.local.get(Object.values(SP_HISTORY_KEYS)).catch(() => ({}));
  for (const [platform, key] of Object.entries(SP_HISTORY_KEYS)) {
    for (const [id, h] of Object.entries(d[key] || {})) {
      if (!id || id.startsWith('_') || !h || typeof h !== 'object' || !h.favorite) continue;
      out.push({ platform, channel: kws_normalizeChannel(id).replace(/^@/, '') });
    }
  }
  return out;
}

function favBadge(st) {
  try {
    const n = Object.values(st.found || {}).reduce((a, b) => a + (Number(b) || 0), 0);
    chrome.action.setBadgeBackgroundColor({ color: '#F59E0B' });
    chrome.action.setBadgeText({ text: !st.seen && n ? (n > 999 ? '999+' : String(n)) : '' });
    chrome.action.setTitle({ title: !st.seen && n ? 'KWS · ★ ' + n : 'KWS' });
  } catch (_) {}
}

let favBusy = false;
async function favRun(force) {
  if (favBusy) return { ok: false, reason: 'busy' };
  favBusy = true;
  try {
    const { on, st } = await favGet();
    if (!force && !on) return { ok: false, reason: 'off' };
    if (!force && Date.now() - (st.lastRun || 0) < FAV_EVERY_MS) return { ok: false, reason: 'recent' };
    if (typeof ovLoad === 'function') { const ov = await ovLoad(); if (ov && ov.active) return { ok: false, reason: 'overnight' }; }
    const list = await favChannels();
    if (!list.length) { st.lastRun = Date.now(); await favSaveState(st); return { ok: false, reason: 'empty' }; }
    const next = { lastRun: Date.now(), running: [], found: {}, seen: true, total: list.length };
    for (const { platform, channel } of list) {
      let r = null;
      try { r = await spStart({ platform, channel, mode: 'new', origin: 'fav' }); } catch (_) {}
      if (r && r.ok) next.running.push(r.id);
    }
    await favSaveState(next);
    favBadge(next);
    return { ok: true, started: next.running.length, total: list.length };
  } finally { favBusy = false; }
}

// scan_hub.js spRun → here when a scan started by favRun ends
async function favScanEnded(e) {
  const { st } = await favGet();
  st.running = (st.running || []).filter((x) => x !== e.id);
  st.found = st.found || {};
  if (e.status === 'done' && e.matchedLines > 0) { st.found[e.id] = e.matchedLines; st.seen = false; }
  else if (e.status === 'done' && spScans && spScans[e.id] === e && !(e.platform === 'kick' && e.subOnly)) { delete spScans[e.id]; await spPersist(true); } // nothing new: no tab
  await favSaveState(st);
  favBadge(st);
}

async function favEnsureAlarm() {
  const { on } = await favGet();
  try {
    if (on) { if (!(await chrome.alarms.get(FAV_ALARM))) chrome.alarms.create(FAV_ALARM, { delayInMinutes: 1, periodInMinutes: 60 }); }
    else chrome.alarms.clear(FAV_ALARM);
  } catch (_) {}
}

chrome.alarms.onAlarm.addListener((a) => { if (a && a.name === FAV_ALARM) favRun(false); });
chrome.runtime.onStartup.addListener(() => { favEnsureAlarm(); favGet().then(({ st }) => favBadge(st)); });
chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && c[FAV_KEY]) favEnsureAlarm(); });
setTimeout(() => { favEnsureAlarm(); }, 2000);

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.type !== 'string' || !msg.type.startsWith('KWS_FAV_')) return;
  (async () => {
    if (msg.type === 'KWS_FAV_STATE') { const { on, st } = await favGet(); return { ok: true, on, st, favCount: (await favChannels()).length }; }
    if (msg.type === 'KWS_FAV_RUN') return favRun(true);
    if (msg.type === 'KWS_FAV_SEEN') { const { st } = await favGet(); st.seen = true; await favSaveState(st); favBadge(st); return { ok: true }; }
    return { ok: false, reason: 'unknown' };
  })().then(sendResponse, (e) => sendResponse({ ok: false, error: String(e && e.message || e) }));
  return true;
});
