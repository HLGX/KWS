// VOD KWS — Shared rescan confirmation popup
// Used by keywordSearcher.js (Twitch), soopSearcher.js (SOOP), kickSearcher.js (Kick)
(function () {
  if (window.showRescanPopup) return;

  // 예전엔 브라우저 네이티브 confirm()을 썼는데, 탭이 포커스 안 돼있거나 백그라운드
  // 상태면 크롬이 조용히 무시/자동취소해버리는 경우가 있어서 "OK 눌러도 무시됨" 버그가 있었음.
  // 그냥 평범한 DOM 오버레이라 그런 문제가 없는 커스텀 팝업으로 교체.
  function showRescanPopup(streamerId, kw, nick, lastDate, onConfirmFull, onConfirmIncremental) {
    const name = nick || streamerId;
    const overlayId = 'kws-rescan-overlay-' + Date.now();

    document.querySelectorAll('[id^="kws-rescan-overlay-"]').forEach(el => el.remove());

    const overlay = document.createElement('div');
    overlay.id = overlayId;
    overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,0.55);display:flex;align-items:center;justify-content:center;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;';
    overlay.innerHTML = `
      <div style="width:min(360px, calc(100vw - 40px));border-radius:18px;background:#12141c;border:1px solid rgba(255,255,255,0.14);box-shadow:0 28px 90px rgba(0,0,0,0.6);padding:20px;color:#e5e7eb;">
        <div style="font-size:14px;font-weight:800;color:#fff;margin-bottom:8px;">${escapeHtml(name)}</div>
        <div style="font-size:12.5px;line-height:1.6;color:rgba(255,255,255,0.7);margin-bottom:18px;">Last scanned up to <b style="color:#fff;">${escapeHtml(lastDate)}</b>.</div>
        <div style="display:flex;flex-direction:column;gap:8px;">
          <button data-act="full" style="padding:11px 14px;border-radius:12px;border:1px solid rgba(96,165,250,0.5);background:rgba(96,165,250,0.18);color:#bfdbfe;font-size:13px;font-weight:700;cursor:pointer;text-align:left;">
            Full rescan <span style="opacity:0.6;font-weight:500;">— all VODs from the beginning</span>
          </button>
          <button data-act="incremental" style="padding:11px 14px;border-radius:12px;border:1px solid rgba(255,255,255,0.14);background:rgba(255,255,255,0.05);color:#e5e7eb;font-size:13px;font-weight:700;cursor:pointer;text-align:left;">
            New VODs only <span style="opacity:0.6;font-weight:500;">— since ${escapeHtml(lastDate)}</span>
          </button>
          <button data-act="cancel" style="padding:8px 14px;border-radius:12px;border:none;background:transparent;color:rgba(255,255,255,0.45);font-size:12px;cursor:pointer;">Cancel</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);

    const close = () => overlay.remove();
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
    overlay.querySelector('[data-act="full"]').addEventListener('click', () => { close(); onConfirmFull(); });
    overlay.querySelector('[data-act="incremental"]').addEventListener('click', () => { close(); onConfirmIncremental(); });
    overlay.querySelector('[data-act="cancel"]').addEventListener('click', close);
  }

  function escapeHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  // "Play VOD by URL/ID" 버튼용 — 플랫폼 공용 텍스트 입력 프롬프트 (native prompt() 대신,
  // 백그라운드 탭에서 무시될 수 있는 문제를 피하려고 커스텀 오버레이로 만듦)
  function showKwsUrlPrompt({ title, placeholder, onSubmit }) {
    const overlayId = 'kws-url-prompt-overlay-' + Date.now();
    document.querySelectorAll('[id^="kws-url-prompt-overlay-"]').forEach(el => el.remove());

    const overlay = document.createElement('div');
    overlay.id = overlayId;
    overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,0.55);display:flex;align-items:center;justify-content:center;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;';
    overlay.innerHTML = `
      <div style="width:min(360px, calc(100vw - 40px));border-radius:18px;background:#12141c;border:1px solid rgba(255,255,255,0.14);box-shadow:0 28px 90px rgba(0,0,0,0.6);padding:20px;color:#e5e7eb;">
        <div style="font-size:14px;font-weight:800;color:#fff;margin-bottom:8px;">${escapeHtml(title)}</div>
        <input id="${overlayId}_input" type="text" placeholder="${escapeHtml(placeholder)}" style="width:100%;box-sizing:border-box;height:38px;border-radius:10px;border:1px solid rgba(96,165,250,0.35);background:#0e0f17;color:#fff;font-size:13px;padding:0 12px;outline:none;font-family:inherit;">
        <div style="display:flex;flex-direction:column;gap:8px;margin-top:16px;">
          <button data-act="submit" style="padding:11px 14px;border-radius:12px;border:1px solid rgba(96,165,250,0.5);background:rgba(96,165,250,0.18);color:#bfdbfe;font-size:13px;font-weight:700;cursor:pointer;text-align:left;">Play</button>
          <button data-act="cancel" style="padding:8px 14px;border-radius:12px;border:none;background:transparent;color:rgba(255,255,255,0.45);font-size:12px;cursor:pointer;">Cancel</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);

    const input = overlay.querySelector(`#${overlayId}_input`);
    setTimeout(() => input?.focus(), 50);
    const close = () => overlay.remove();
    const submit = () => { const val = input?.value?.trim(); if (!val) return; close(); onSubmit(val); };
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
    overlay.querySelector('[data-act="submit"]').addEventListener('click', submit);
    overlay.querySelector('[data-act="cancel"]').addEventListener('click', close);
    input?.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); if (e.key === 'Escape') close(); });
  }

  // 🔍(Discover) 버튼 공용 팝업 — 4개 KWS 모두 이 팝업 하나를 씀. 플랫폼별 streamrecorder.io 링크 버튼만 다름.
  function showKwsDiscoverPopup() {
    const host = location.hostname;
    const current = /youtube\.com$/.test(host) ? 'yt' : /kick\.com$/.test(host) ? 'kick' : /sooplive\./.test(host) ? 'soop' : 'twitch';
    const items = [
      { id: 'twitch', label: 'Twitch', url: 'https://streamrecorder.io/latest/twitch', path: 'latest/twitch', c: '145,71,255', fg: '#c4b5fd' },
      { id: 'kick',   label: 'Kick',   url: 'https://streamrecorder.io/latest/kick', path: 'latest/kick',   c: '83,185,69',  fg: '#86efac' },
      { id: 'soop',   label: 'SOOP',   url: 'https://streamrecorder.io/latest/afreecatv', path: 'latest/afreecatv', c: '56,150,240', fg: '#7dd3fc' },
      { id: 'yt',     label: 'YouTube', url: 'https://streamrecorder.io/latest/yt', path: 'latest/yt',    c: '239,68,68',  fg: '#fca5a5' },
    ];
    document.querySelectorAll('[id^="kws-info-popup-overlay-"]').forEach(el => el.remove());
    const overlay = document.createElement('div');
    overlay.id = 'kws-info-popup-overlay-' + Date.now();
    overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,0.55);display:flex;align-items:center;justify-content:center;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;';
    overlay.innerHTML = `
      <div style="width:min(360px, calc(100vw - 40px));border-radius:18px;background:#12141c;border:1px solid rgba(255,255,255,0.14);box-shadow:0 28px 90px rgba(0,0,0,0.6);padding:20px;color:#e5e7eb;">
        <div style="font-size:14px;font-weight:800;color:#fff;margin-bottom:8px;">Find more streamers</div>
        <div style="font-size:12.5px;line-height:1.6;color:rgba(255,255,255,0.7);margin-bottom:16px;">Browse <b style="color:#fff;">streamrecorder.io</b> for more streamers. Each one gets a KWS badge — click it to start scanning their VODs.</div>
        <div style="display:flex;flex-direction:column;gap:8px;">
          ${items.map(it => `<button data-url="${it.url}" style="padding:11px 14px;border-radius:12px;border:1px solid rgba(${it.c},${it.id === current ? '0.75' : '0.4'});background:rgba(${it.c},${it.id === current ? '0.26' : '0.14'});color:${it.fg};font-size:13px;font-weight:700;cursor:pointer;text-align:left;font-family:inherit;">${it.label} <span style="opacity:0.6;font-weight:500;">— ${it.path}</span></button>`).join('')}
          <button data-act="close" style="padding:8px 14px;border-radius:12px;border:none;background:transparent;color:rgba(255,255,255,0.45);font-size:12px;cursor:pointer;">Close</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    const close = () => overlay.remove();
    overlay.addEventListener('click', e => { if (e.target === overlay) close(); });
    overlay.querySelector('[data-act="close"]').addEventListener('click', close);
    overlay.querySelectorAll('[data-url]').forEach(b => b.addEventListener('click', () => { window.open(b.dataset.url, '_blank'); close(); }));
  }

  window.showRescanPopup = showRescanPopup;
  window.showKwsDiscoverPopup = showKwsDiscoverPopup;
  window.showKwsUrlPrompt = showKwsUrlPrompt;
})();
