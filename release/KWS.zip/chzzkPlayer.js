// KWS 1.2.5.18 — CHZZK inline VOD player + Clip Downloader (runs on chzzk.naver.com), in the same UI as the Twitch / Kick / SOOP inline players.
//
// What CHZZK serves for a replay (checked on a real VOD):
//   GET api.chzzk.naver.com/service/v3/videos/{no}                → videoId, inKey, title, channel
//   GET apis.naver.com/neonplayer/vodplay/v1/playback/{videoId}?key={inKey}&env=real
//       → DASH MPD (no DRM) with
//         • video/mp4  AdaptationSet: progressive MP4 per quality (video + audio together, Range OK)
//         • video/mp2t AdaptationSet: the same qualities as numbered .ts segments (SegmentTimeline)
//         • audio/mp4  AdaptationSet: audio only
// The player plays the progressive MP4 (a plain <video>, seeking by Range); the Clip Downloader
// (the same popup as on Twitch / Kick) writes the .ts segments of the chosen range into one file. Live-rewind replays without an MPD play their HLS with hls.js.
// Registered by the background once the optional CHZZK permission is granted.
(function () {
  'use strict';
  if (window.__kwsChzzkPlayer) return;
  window.__kwsChzzkPlayer = true;

  const API = 'https://api.chzzk.naver.com';
  const POP_ID = 'kws-chzzk-player';
  const fmt = (s) => { s = Math.max(0, Math.floor(s)); return [Math.floor(s / 3600), Math.floor((s % 3600) / 60), s % 60].map((v) => String(v).padStart(2, '0')).join(':'); };
  const parseT = (s) => { const p = String(s).trim().split(':').map(Number); return p.length === 3 ? p[0] * 3600 + p[1] * 60 + p[2] : p.length === 2 ? p[0] * 60 + p[1] : (parseFloat(s) || 0); };
  const sleep = (ms) => (globalThis.KWSDl ? KWSDl.sleep(ms) : new Promise((r) => setTimeout(r, ms)));
  const esc = (s) => String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  async function getJson(url) {
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  }

  // MPD → { mp4: [{id,height,url}], ts: [{id,height,segs:[{n,t,d,url}]}] }
  function parseMpd(xml, mpdUrl) {
    const doc = new DOMParser().parseFromString(xml, 'application/xml');
    const out = { mp4: [], ts: [] };
    const abs = (u, base) => { try { return new URL(u, base).href; } catch (_) { return u; } };
    const mpdBase = abs(doc.querySelector('MPD > BaseURL')?.textContent || '', mpdUrl) || mpdUrl;
    for (const set of doc.querySelectorAll('AdaptationSet')) {
      const mime = set.getAttribute('mimeType') || set.querySelector('Representation')?.getAttribute('mimeType') || '';
      const setBase = abs(set.querySelector(':scope > BaseURL')?.textContent || '', mpdBase);
      if (mime === 'video/mp4' && !set.querySelector('SegmentTemplate')) {
        for (const rep of set.querySelectorAll('Representation')) {
          const b = rep.querySelector('BaseURL')?.textContent;
          if (b) out.mp4.push({ id: rep.getAttribute('id'), height: Number(rep.getAttribute('height')) || 0, url: abs(b, setBase) });
        }
      } else if (mime === 'video/mp2t') {
        const tmplEl = set.querySelector(':scope > SegmentTemplate');
        for (const rep of set.querySelectorAll('Representation')) {
          const tmpl = rep.querySelector('SegmentTemplate') || tmplEl;
          if (!tmpl) continue;
          const repBase = abs(rep.querySelector('BaseURL')?.textContent || '', setBase);
          const media = tmpl.getAttribute('media') || '';
          const ts = Number(tmpl.getAttribute('timescale')) || 1;
          let n = Number(tmpl.getAttribute('startNumber') || 1);
          const pto = Number(tmpl.getAttribute('presentationTimeOffset')) || 0;
          const id = rep.getAttribute('id');
          const segs = [];
          let t = 0;
          for (const s of tmpl.querySelectorAll('SegmentTimeline > S')) {
            if (s.hasAttribute('t')) t = Number(s.getAttribute('t'));
            const d = Number(s.getAttribute('d')) || 0;
            const r = Number(s.getAttribute('r') || 0);
            for (let k = 0; k <= Math.max(0, r); k++) {
              const name = media.replace(/\$RepresentationID\$/g, id)
                .replace(/\$Number(?:%0(\d+)d)?\$/g, (_, w) => String(n).padStart(Number(w) || 0, '0'))
                .replace(/\$Time\$/g, String(t));
              segs.push({ n, t: (t - pto) / ts, d: d / ts, url: abs(name, repBase) });
              t += d; n++;
            }
          }
          if (segs.length) out.ts.push({ id, height: Number(rep.getAttribute('height')) || 0, segs });
        }
      }
    }
    out.mp4.sort((a, b) => b.height - a.height);
    out.ts.sort((a, b) => b.height - a.height);
    return out;
  }

  // HLS master → [{id,height,playlist,segs:null}] (segments are read when a download starts)
  async function hlsRenditions(masterUrl) {
    const r = await fetch(masterUrl, { credentials: 'omit' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const txt = await r.text();
    const lines = txt.split(/\r?\n/);
    const out = [];
    if (!/#EXT-X-STREAM-INF/.test(txt)) return [{ id: 'source', height: 0, playlist: r.url, segs: null }]; // already a media playlist
    for (let i = 0; i < lines.length; i++) {
      if (!lines[i].startsWith('#EXT-X-STREAM-INF')) continue;
      const u = (lines[i + 1] || '').trim();
      if (!u || u.startsWith('#')) continue;
      const res = /RESOLUTION=\d+x(\d+)/.exec(lines[i]);
      const name = /NAME="([^"]+)"/.exec(lines[i]);
      out.push({ id: name ? name[1] : (res ? res[1] + 'p' : 'v' + out.length), height: res ? Number(res[1]) : 0, playlist: new URL(u, r.url).href, segs: null });
    }
    out.sort((a, b) => b.height - a.height);
    return out;
  }
  // HLS media playlist → segments [{n,t,d,url}] (+ the fMP4 init segment, if any)
  async function hlsSegments(rep) {
    if (rep.segs) return rep.segs;
    const r = await fetch(rep.playlist, { credentials: 'omit' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const lines = (await r.text()).split(/\r?\n/);
    const segs = [];
    let t = 0, d = 0, n = 0;
    for (const raw of lines) {
      const l = raw.trim();
      if (!l) continue;
      if (l.startsWith('#EXT-X-MAP')) { const m = /URI="([^"]+)"/.exec(l); if (m) rep.init = new URL(m[1], r.url).href; }
      else if (l.startsWith('#EXTINF:')) d = parseFloat(l.slice(8)) || 0;
      else if (!l.startsWith('#')) { segs.push({ n: n++, t, d, url: new URL(l, r.url).href }); t += d; d = 0; }
    }
    rep.segs = segs;
    return segs;
  }

  async function loadVideo(no) {
    const meta = (await getJson(`${API}/service/v3/videos/${no}`)).content || {};
    const info = { no: String(no), title: meta.videoTitle || '', channel: meta.channel?.channelName || '', channelId: meta.channel?.channelId || '', date: (meta.liveOpenDate || meta.publishDate || '').slice(0, 10), startMs: (() => { const v = meta.liveOpenDate || meta.publishDate; const t = v ? new Date(String(v).replace(' ', 'T')).getTime() : NaN; return isFinite(t) ? t : null; })(), duration: meta.duration || 0, mp4: [], ts: [], hls: '' };
    if (meta.adult && meta.userAdultStatus && meta.userAdultStatus !== 'ADULT') info.adultBlocked = true;
    if (meta.videoId && meta.inKey) {
      const url = `https://apis.naver.com/neonplayer/vodplay/v1/playback/${meta.videoId}?key=${encodeURIComponent(meta.inKey)}&env=real&lc=ko_KR&cpl=ko_KR`;
      try {
        const r = await fetch(url, { credentials: 'include', headers: { Accept: 'application/dash+xml' } });
        if (r.ok) Object.assign(info, parseMpd(await r.text(), r.url));
      } catch (e) { console.warn('[KWS CHZZK] playback', e); }
    }
    if (!info.mp4.length && meta.liveRewindPlaybackJson) {
      // recent replays are served from the live-rewind HLS for a while (no MPD yet); prefer plain HLS over LL-HLS
      try { const media = (JSON.parse(meta.liveRewindPlaybackJson).media || []).filter((m) => m.path); info.hls = (media.find((m) => /^HLS$/i.test(m.mediaId || m.protocol || '')) || media[0])?.path || ''; } catch (_) {}
      if (info.hls) { try { info.ts = await hlsRenditions(info.hls); } catch (e) { console.warn('[KWS CHZZK] hls master', e); } }
    }
    return info;
  }

  // ── inline player: the same shell, glass bar, controls and Clip Downloader as the Twitch / Kick /
  //    SOOP inline players (ui.js buildVideoViewer · soopSearcher.js openSoopInlinePlayer) ──
  const DL_ID = 'kws-chzzk-clipdl';
  const RANGE_ID = 'kws-chzzk-range-overlay';
  const SVG = {
    pause: '<svg id="pause_svg" xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 16 16"><path fill="white" d="M2 2h4v12h-4v-4z"/><path fill="white" d="M8 2h4v12h-4v-4z"/></svg>',
    play: '<svg id="play_svg" xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 16 16"><path fill="white" d="M2 1v14l12-7z"/></svg>',
    back: '<svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 16 16"><text fill="white" x="4" y="11" font-size="8">30</text><path fill="white" d="M8 0c-3 0-5.6 1.6-6.9 4.1l-1.1-1.1v4h4l-1.5-1.5c1-2 3.1-3.5 5.5-3.5 3.3 0 6 2.7 6 6s-2.7 6-6 6c-1.8 0-3.4-0.8-4.5-2.1l-1.5 1.3c1.4 1.7 3.6 2.8 6 2.8 4.4 0 8-3.6 8-8s-3.6-8-8-8z"/></svg>',
    fwd: '<svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 16 16"><text fill="white" x="4" y="11" font-size="8">30</text><path fill="white" d="M16 7v-4l-1.1 1.1c-1.3-2.5-3.9-4.1-6.9-4.1-4.4 0-8 3.6-8 8s3.6 8 8 8c2.4 0 4.6-1.1 6-2.8l-1.5-1.3c-1.1 1.3-2.7 2.1-4.5 2.1-3.3 0-6-2.7-6-6s2.7-6 6-6c2.4 0 4.5 1.5 5.5 3.5l-1.5 1.5h4z"/></svg>',
    vol: '<svg xmlns="http://www.w3.org/2000/svg" fill="white" height="20px" width="20px" viewBox="0 0 24 24"><path d="M13,23.1L5.6,17H0V7h5.6L13,0.9C13,0.9,13,23.1,13,23.1z M2,15h4.4l4.6,3.9V5.1L6.4,9H2V15z M15,21v-2c3.9,0,7-3.1,7-7s-3.1-7-7-7V3c5,0,9,4,9,9S20,21,15,21z M15,17v-2c1.7,0,3-1.3,3-3s-1.3-3-3-3V7c2.8,0,5,2.2,5,5S17.8,17,15,17z"/></svg>',
    mute: '<svg xmlns="http://www.w3.org/2000/svg" fill="white" height="20px" width="20px" viewBox="0 0 24 24"><path d="M13,23.1L5.6,17H0V7h5.6L13,0.9C13,0.9,13,23.1,13,23.1z M2,15h4.4l4.6,3.9V5.1L6.4,9H2V15z"/><path d="M16 8l6 8M22 8l-6 8" stroke="white" stroke-width="2"/></svg>',
  };

  function ensureStyle() {
    if (document.getElementById(POP_ID + '-style')) return;
    const P = '#' + POP_ID;
    const st = document.createElement('style');
    st.id = POP_ID + '-style';
    st.textContent = `
      ${P} { box-sizing:border-box; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Malgun Gothic",sans-serif; color:#e2e8f0; }
      ${P} *, ${P} *::before, ${P} *::after { box-sizing:border-box; }
      ${P} video { width:100%; height:100%; display:block; object-fit:contain; background:#000; cursor:pointer; }
      ${P} .kws-vod-glassbar { position:absolute; left:12px; right:12px; top:12px; z-index:7; display:flex; align-items:center; justify-content:space-between; gap:10px; padding:9px 10px; border-radius:18px; background:rgba(20,24,34,.58); border:1px solid rgba(255,255,255,.14); backdrop-filter:blur(18px); -webkit-backdrop-filter:blur(18px); opacity:0; transform:translateY(-6px); transition:opacity .16s ease, transform .16s ease; pointer-events:none; }
      ${P}:hover .kws-vod-glassbar { opacity:1; transform:translateY(0); pointer-events:auto; }
      ${P} .kws-vod-title { min-width:0; color:#fff; font:800 12px/1.25 -apple-system,"Malgun Gothic",sans-serif; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      ${P} .kws-vod-subtitle { color:rgba(255,255,255,.52); font:600 10px/1.2 -apple-system,"Malgun Gothic",sans-serif; margin-top:2px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      ${P} .kws-vod-actions { display:flex; align-items:center; gap:6px; flex-wrap:wrap; justify-content:flex-end; }
      ${P} .kws-vod-pill, ${P} .kws-vod-iconbtn { border:1px solid rgba(255,255,255,.16); background:rgba(255,255,255,.10); color:rgba(255,255,255,.86); border-radius:999px; min-height:28px; padding:0 10px; font:800 11px/1 -apple-system,sans-serif; cursor:pointer; display:inline-flex; align-items:center; justify-content:center; gap:5px; box-shadow:inset 0 1px 0 rgba(255,255,255,.08); margin:0; }
      ${P} .kws-vod-pill:hover, ${P} .kws-vod-iconbtn:hover { background:rgba(255,255,255,.20); color:#fff; border-color:rgba(255,255,255,.30); }
      ${P} .kws-vod-pill.checked { background:rgba(250,204,21,.22) !important; color:#facc15 !important; border-color:rgba(250,204,21,.5) !important; }
      ${P} .kws-vod-iconbtn { width:30px; padding:0; font-size:13px; }
      ${P} .kws-vod-iconbtn:disabled { opacity:.35; cursor:not-allowed; filter:grayscale(1); }
      ${P} .kws-vod-res-group { display:flex; gap:5px; align-items:center; max-width:42vw; overflow:auto; scrollbar-width:none; }
      ${P} .kws-vod-res-group::-webkit-scrollbar { display:none; }
      ${P} .kws-unified-close, #${DL_ID} .kws-unified-close { width:30px; height:30px; border-radius:999px; background:linear-gradient(135deg,rgba(255,255,255,.18),rgba(255,255,255,.07)); border:1px solid rgba(255,255,255,.18); box-shadow:0 8px 18px rgba(0,0,0,.35),inset 0 1px 0 rgba(255,255,255,.18); display:flex; align-items:center; justify-content:center; font-size:15px; color:#fff; cursor:pointer; transition:transform .14s,background .14s,border-color .14s; padding:0; flex-shrink:0; }
      ${P} .kws-unified-close:hover, #${DL_ID} .kws-unified-close:hover { background:linear-gradient(135deg,rgba(248,113,113,.95),rgba(220,38,38,.88)); border-color:rgba(255,255,255,.28); transform:scale(1.06); }
      ${P} .custom_video_controls_cont { height:auto; display:flex; flex-direction:column; gap:6px; opacity:0; background:rgba(12,15,23,.66); border:1px solid rgba(255,255,255,.12); border-radius:18px; padding:7px 10px; backdrop-filter:blur(14px); -webkit-backdrop-filter:blur(14px); transform:translateY(6px); transition:opacity .16s ease, transform .16s ease; pointer-events:none; }
      ${P}:hover .custom_video_controls_cont, ${P}.kws-cz-dl-open .custom_video_controls_cont { opacity:1; transform:translateY(0); pointer-events:auto; }
      ${P} .custom_video_controls_cont > div:first-child { display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:nowrap; }
      ${P} .speed_cont, ${P} .volume_cont { background:rgba(255,255,255,.07); border-radius:999px; padding:3px 8px; height:32px; display:flex; align-items:center; gap:4px; }
      ${P} .volume_bar { width:86px; accent-color:#facc15; margin:0; }
      ${P} .kws-cz-seeker { width:100%; accent-color:#a78bfa; margin:0; display:block; }
      ${P} .kws-cz-msg { position:absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:12px; color:#94a3b8; font-size:13px; font-weight:700; background:rgba(5,7,11,.85); z-index:5; text-align:center; padding:20px; }
      ${P} .kws-cz-msg.err { color:#fca5a5; }
      .kws-inline-download-pop.kws-cz-dl { position:fixed; z-index:2147483000; right:24px; bottom:24px; width:min(760px, calc(100vw - 48px)); max-height:min(78vh,720px); overflow:hidden; border-radius:24px; background:rgba(9,11,18,.94); border:1px solid rgba(255,255,255,.16); box-shadow:0 28px 90px rgba(0,0,0,.62), inset 0 1px 0 rgba(255,255,255,.10); color:#e5e7eb; backdrop-filter:blur(22px) saturate(150%); -webkit-backdrop-filter:blur(22px) saturate(150%); font-size:13px; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Malgun Gothic",sans-serif; }
      .kws-cz-dl .kws-inline-download-head { display:flex; align-items:center; justify-content:space-between; gap:10px; padding:12px 14px; background:rgba(14,17,27,.88); border-bottom:1px solid rgba(255,255,255,.10); cursor:grab; user-select:none; }
      .kws-cz-dl .kws-inline-download-title { font:900 13px/1.2 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; color:#fff; }
      .kws-cz-dl .kws-inline-download-close { border:1px solid rgba(255,255,255,.18); background:linear-gradient(135deg,rgba(255,255,255,.18),rgba(255,255,255,.07)); color:#fff; width:30px; height:30px; border-radius:999px; cursor:pointer; font-size:15px; line-height:1; display:flex; align-items:center; justify-content:center; box-shadow:0 8px 18px rgba(0,0,0,.35), inset 0 1px 0 rgba(255,255,255,.18); flex-shrink:0; padding:0; }
      .kws-cz-dl .kws-inline-download-close:hover { background:linear-gradient(135deg,rgba(248,113,113,.95),rgba(220,38,38,.88)); }
    `;
    document.head.appendChild(st);
  }

  // Undo a page zoom so the popups match the other KWS sites and follow the mouse 1:1.
  function zoomFix(el) {
    let z = 1;
    for (const e of [document.documentElement, document.body]) { const v = parseFloat(getComputedStyle(e).zoom); if (v > 0) z *= v; }
    if (Math.abs(z - 1) > 0.01) el.style.zoom = String(1 / z);
  }

  // Move `el` with the mouse from `handle`. The popup is switched from its centred transform to
  // plain left/top first, so it no longer jumps away from the cursor. A small threshold keeps a
  // plain click (play / pause on the video) a click.
  function dragBy(handle, el, threshold = 0) {
    let on = false, moved = false, sx = 0, sy = 0, ox = 0, oy = 0;
    handle.addEventListener('mousedown', (e) => {
      if (e.button !== 0 || e.target.closest('button,select,input')) return;
      const r = el.getBoundingClientRect();
      el.style.transform = 'none'; el.style.right = 'auto'; el.style.bottom = 'auto';
      el.style.left = r.left + 'px'; el.style.top = r.top + 'px';
      on = true; moved = threshold === 0; sx = e.clientX; sy = e.clientY; ox = r.left; oy = r.top;
      document.body.style.userSelect = 'none';
      if (threshold === 0) e.preventDefault();
    });
    window.addEventListener('mousemove', (e) => {
      if (!on) return;
      const dx = e.clientX - sx, dy = e.clientY - sy;
      if (!moved && Math.hypot(dx, dy) > threshold) moved = true;
      if (!moved) return;
      const r = el.getBoundingClientRect();
      el.style.left = Math.min(Math.max(8 - r.width + 60, ox + dx), window.innerWidth - 60) + 'px';
      el.style.top = Math.min(Math.max(8, oy + dy), window.innerHeight - 40) + 'px';
    });
    window.addEventListener('mouseup', () => {
      if (on && moved && threshold) handle._kwsSuppressNextClick = true;
      on = false; document.body.style.userSelect = '';
    });
  }

  // Default quality (KWS settings → "Default quality"): 'last' = the height picked last time on CHZZK
  // (720p the first time), else the best one at or below the chosen height.
  async function preferredHeight() {
    const pref = globalThis.KWSQuality ? await KWSQuality.pref() : 'last';
    if (pref !== 'last') return pref;
    try { const d = await chrome.storage.local.get('chzzkLastQuality'); return d.chzzkLastQuality ? String(d.chzzkLastQuality) : '720'; } catch (_) { return '720'; }
  }
  function pickByHeight(list, pref) {
    if (!list.length) return null;
    if (globalThis.KWSQuality) return KWSQuality.pick(list, (r) => r.height || Infinity, pref) || list[0];
    return list.find((r) => String(r.height) === String(pref)) || list[0];
  }
  const rememberHeight = (h) => { try { if (h) chrome.storage.local.set({ chzzkLastQuality: h }); } catch (_) {} };

  let current = null; // { no, info, video, hls, cont, seekCont, total, seekTo }

  function close() {
    if (current?.hls) { try { current.hls.destroy(); } catch (_) {} }
    const cont = document.getElementById(POP_ID);
    if (cont) { cont.querySelector('video')?.pause(); cont.remove(); }
    document.getElementById(DL_ID)?.remove();
    current = null;
  }

  async function open(no, sec) {
    ensureStyle();
    const startAt = Math.max(0, Number(sec) || 0);
    // the same replay again: only move to the new time
    if (current && current.no === String(no) && document.body.contains(current.cont) && current.seekTo) { current.seekTo(startAt); return; }
    close();

    const initW = Math.min(900, Math.max(520, Math.round(window.innerWidth * 0.52)));
    const cont = document.createElement('div');
    cont.id = POP_ID;
    cont.dataset.no = String(no);
    cont.style.cssText = `position:fixed;top:22px;left:${Math.max(18, Math.round(window.innerWidth * 0.30))}px;width:${initW}px;z-index:2147482000;background:rgba(10,12,18,.88);border:3px solid rgba(255,255,255,.22);border-radius:24px;box-shadow:0 22px 70px rgba(0,0,0,.55),inset 0 1px 0 rgba(255,255,255,.14);backdrop-filter:blur(22px) saturate(150%);-webkit-backdrop-filter:blur(22px) saturate(150%);min-width:420px;overflow:hidden;display:flex;flex-direction:column;`;
    zoomFix(cont);
    document.body.appendChild(cont);
    current = { no: String(no), cont };

    const dragHead = document.createElement('div');
    dragHead.style.cssText = 'height:18px;cursor:grab;flex-shrink:0;';
    cont.appendChild(dragHead);
    dragBy(dragHead, cont);

    let ratio = 9 / 16;
    const body = document.createElement('div');
    body.style.cssText = `position:relative;background:#05070b;margin:0 18px 18px 18px;border-radius:16px;overflow:hidden;height:${Math.round((initW - 42) * ratio)}px;flex-shrink:0;`;
    cont.appendChild(body);
    const fit = () => { const w = cont.getBoundingClientRect().width - 42; if (w > 0) body.style.height = Math.round(Math.min(w * ratio, window.innerHeight - 80)) + 'px'; };
    if (window.ResizeObserver) new ResizeObserver(fit).observe(cont);

    // ◢ resize (keeps the aspect ratio, like the Twitch player)
    const grip = document.createElement('div');
    grip.textContent = '◢';
    grip.title = 'Resize';
    grip.style.cssText = 'position:absolute;right:10px;bottom:10px;width:16px;height:16px;cursor:nwse-resize;z-index:9;color:rgba(255,255,255,.42);display:flex;align-items:flex-end;justify-content:flex-end;font:900 15px/1 -apple-system,sans-serif;text-shadow:0 1px 8px rgba(0,0,0,.8);';
    cont.appendChild(grip);
    {
      let on = false, sx = 0, sw = 0;
      grip.addEventListener('mousedown', (e) => { on = true; sx = e.clientX; sw = cont.getBoundingClientRect().width; document.body.style.userSelect = 'none'; e.preventDefault(); e.stopPropagation(); });
      window.addEventListener('mousemove', (e) => { if (on) cont.style.width = Math.max(420, Math.min(window.innerWidth - 16, sw + e.clientX - sx)) + 'px'; });
      window.addEventListener('mouseup', () => { on = false; document.body.style.userSelect = ''; });
    }

    const video = document.createElement('video');
    video.className = 'pop_out_video';
    video.autoplay = true; video.playsInline = true;
    body.appendChild(video);
    dragBy(video, cont, 6); // drag anywhere on the picture to move the window; a short click still plays / pauses

    const msg = document.createElement('div');
    msg.className = 'kws-cz-msg';
    msg.textContent = '⏳ Loading VOD info...';
    body.appendChild(msg);

    // glass bar (on hover): title · channel · date | quality pills · 🔗 · ⬇ · ⛶ · ✕
    const bar = document.createElement('div'); bar.className = 'kws-vod-glassbar';
    const meta = document.createElement('div'); meta.style.cssText = 'min-width:0;flex:1;cursor:move;';
    dragBy(meta, cont);
    const titleEl = document.createElement('div'); titleEl.className = 'kws-vod-title'; titleEl.textContent = 'CHZZK';
    const subEl = document.createElement('div'); subEl.className = 'kws-vod-subtitle';
    meta.append(titleEl, subEl);
    const actions = document.createElement('div'); actions.className = 'kws-vod-actions';
    const resGroup = document.createElement('div'); resGroup.className = 'kws-vod-res-group';
    const mkBtn = (txt, title, cls = 'kws-vod-iconbtn') => { const b = document.createElement('button'); b.type = 'button'; b.className = cls; b.textContent = txt; b.title = title; return b; };
    const linkBtn = mkBtn('🔗', 'Open original VOD on CHZZK (new tab)');
    const dlBtn = mkBtn('⬇', 'Download'); dlBtn.disabled = true;
    const fsBtn = mkBtn('⛶', 'Fullscreen');
    const closeBtn = mkBtn('✕', 'Close', 'kws-unified-close');
    actions.append(resGroup, linkBtn, dlBtn, fsBtn, closeBtn);
    bar.append(meta, actions);
    body.appendChild(bar);
    closeBtn.addEventListener('click', close);
    fsBtn.addEventListener('click', () => { try { video.requestFullscreen(); } catch (_) {} });
    // dbl-click left/right = -/+10 s (1.2.5.45); `seekBy` is defined with the controls below
    try { globalThis.KWSDblSeek && globalThis.KWSDblSeek(video, { seek: (d) => current && current.seekBy && current.seekBy(d) }); } catch (_) {}
    video.addEventListener('dblclick', () => { try { video.requestFullscreen(); } catch (_) {} });
    linkBtn.addEventListener('click', () => window.open(`https://chzzk.naver.com/video/${no}?currentTime=${Math.floor(video.currentTime || 0)}`, '_blank', 'noopener'));

    // controls (on hover): ▶ ⟲30 ⟳30 time | 1x 2x 3x 4x · volume, then the seek bar
    const ctrlWrap = document.createElement('div');
    ctrlWrap.style.cssText = 'position:absolute;left:12px;right:12px;bottom:12px;z-index:7;';
    const ctrl = document.createElement('div'); ctrl.className = 'custom_video_controls_cont';
    const row = document.createElement('div');
    const left = document.createElement('div'); left.style.cssText = 'display:grid;grid-template-columns:20px 20px 20px 150px;grid-gap:4px;place-items:center start;';
    const right = document.createElement('div'); right.style.cssText = 'margin:auto;display:flex;flex-wrap:wrap;gap:4px;align-items:center;';
    const icon = (html) => { const d = document.createElement('div'); d.style.cssText = 'cursor:pointer;display:flex;align-items:center;'; d.innerHTML = html; return d; };
    const playEl = icon(SVG.pause), backEl = icon(SVG.back), fwdEl = icon(SVG.fwd);
    backEl.title = '-30s'; fwdEl.title = '+30s';
    const timeEl = document.createElement('div');
    timeEl.style.cssText = 'width:fit-content;color:#fff;font-size:11px;font-weight:700;font-variant-numeric:tabular-nums;white-space:nowrap;';
    timeEl.textContent = '00:00:00 / --:--:--';
    left.append(playEl, backEl, fwdEl, timeEl);
    const speedCont = document.createElement('div'); speedCont.className = 'speed_cont';
    const speedBtns = [1, 2, 3, 4].map((n) => { const b = mkBtn(n + 'x', n + 'x speed', 'kws-vod-pill kws-vod-speed-pill' + (n === 1 ? ' checked' : '')); b.dataset.speed = String(n); speedCont.appendChild(b); return b; });
    const volCont = document.createElement('div'); volCont.className = 'volume_cont';
    const volIcon = icon(SVG.vol);
    const volBar = document.createElement('input'); volBar.type = 'range'; volBar.className = 'volume_bar'; volBar.min = '0'; volBar.max = '100'; volBar.value = '100';
    volCont.append(volIcon, volBar);
    right.append(speedCont, volCont);
    row.append(left, right);
    const seekCont = document.createElement('div'); seekCont.style.cssText = 'position:relative;';
    const seeker = document.createElement('input'); seeker.type = 'range'; seeker.className = 'kws-cz-seeker'; seeker.id = 'kws_cz_seeker'; seeker.min = '0'; seeker.max = '1'; seeker.value = '0';
    seekCont.appendChild(seeker);
    ctrl.append(row, seekCont);
    ctrlWrap.appendChild(ctrl);
    body.appendChild(ctrlWrap);
    Object.assign(current, { video, seekCont });

    // controls behaviour
    const toggle = () => { if (video.paused) video.play().catch(() => {}); else video.pause(); };
    playEl.addEventListener('click', toggle);
    video.addEventListener('click', () => { if (video._kwsSuppressNextClick) { video._kwsSuppressNextClick = false; return; } toggle(); });
    video.addEventListener('play', () => { playEl.innerHTML = SVG.pause; });
    video.addEventListener('pause', () => { playEl.innerHTML = SVG.play; });
    // 1.2.5.45: seeks sometimes snapped back to the old spot and kept replaying it (most likely
    // hls.js still loading the old position, or a seek landing mid-load). Every seek now goes
    // through one function: it tells hls.js where to load from, and if playback shows up far from
    // the target within a few seconds it seeks there again (up to 3 times).
    let want = null, wantUntil = 0, fixes = 0;
    const isBuffered = (t) => { const b = video.buffered; for (let i = 0; i < b.length; i++) if (t >= b.start(i) && t <= b.end(i) - 0.3) return true; return false; };
    const seekAbs = (t) => {
      const dur = total();
      const T = Math.max(0, Math.min(dur ? dur - 0.5 : Infinity, t));
      want = T; wantUntil = Date.now() + 6000; fixes = 0;
      const h = current && current.hls;
      if (h && !isBuffered(T)) { try { h.stopLoad(); h.startLoad(T); } catch (_) {} }
      video.currentTime = T;
      paint();
    };
    const seekBy = (d) => seekAbs((want != null && video.seeking ? want : (video.currentTime || 0)) + d);
    current.seekBy = seekBy;
    current.seekAbs = seekAbs;
    const guard = () => {
      if (want == null) return;
      if (Date.now() > wantUntil) { want = null; return; }
      if (video.seeking) return;
      const off = (video.currentTime || 0) - want;
      if (off >= -1.5 && off <= 3) { want = null; return; }          // landed (playing on from there)
      if (fixes < 3) { fixes++; const h = current && current.hls; if (h && !isBuffered(want)) { try { h.startLoad(want); } catch (_) {} } video.currentTime = want; }
      else want = null;
    };
    video.addEventListener('seeked', guard);
    video.addEventListener('timeupdate', guard);
    backEl.addEventListener('click', () => seekBy(-30));
    fwdEl.addEventListener('click', () => seekBy(30));
    const setSpeed = (n) => { video.playbackRate = n; speedBtns.forEach((b) => b.classList.toggle('checked', Number(b.dataset.speed) === n)); };
    speedBtns.forEach((b) => b.addEventListener('click', () => setSpeed(Number(b.dataset.speed))));
    const volIconUpd = () => { volIcon.innerHTML = (video.muted || Number(volBar.value) === 0) ? SVG.mute : SVG.vol; };
    try { const sv = await chrome.storage.local.get('chzzkPlayerVolume'); if (sv && sv.chzzkPlayerVolume != null) volBar.value = String(sv.chzzkPlayerVolume); } catch (_) {}
    video.volume = Number(volBar.value) / 100; volIconUpd();
    volBar.addEventListener('input', () => { video.volume = Number(volBar.value) / 100; video.muted = false; volIconUpd(); try { chrome.storage.local.set({ chzzkPlayerVolume: Number(volBar.value) }); } catch (_) {} });
    volIcon.addEventListener('click', () => { video.muted = !video.muted; volBar.value = video.muted ? '0' : String(Math.round(video.volume * 100)); volIconUpd(); });
    let info = null;
    const total = () => (isFinite(video.duration) && video.duration > 0 ? video.duration : (info?.duration || 0));
    current.total = total;
    const paint = () => {
      const t = total();
      timeEl.innerHTML = `<span>${fmt(video.currentTime || 0)} / </span><span>${t ? fmt(t) : '--:--:--'}</span>`;
      if (t) seeker.max = String(Math.floor(t));
      if (!seeker._drag) seeker.value = String(Math.floor(video.currentTime || 0));
    };
    video.addEventListener('timeupdate', paint);
    video.addEventListener('loadedmetadata', () => { paint(); if (video.videoWidth && video.videoHeight) { ratio = video.videoHeight / video.videoWidth; fit(); } });
    seeker.addEventListener('pointerdown', () => { seeker._drag = true; });
    seeker.addEventListener('input', () => {
      const t = Number(seeker.value);
      if (!seeker._drag) { seekAbs(t); return; } // keyboard on the bar
      const tt = total();
      timeEl.innerHTML = `<span>${fmt(t)} / </span><span>${tt ? fmt(tt) : '--:--:--'}</span>`;
    });
    seeker.addEventListener('change', () => { seeker._drag = false; seekAbs(Number(seeker.value)); });
    window.addEventListener('pointerup', () => { if (seeker._drag) { seeker._drag = false; seekAbs(Number(seeker.value)); } });
    const onKey = (e) => {
      if (!document.body.contains(cont)) { window.removeEventListener('keydown', onKey, true); return; }
      if (e.key === 'Escape') { close(); return; }
      if (document.getElementById(DL_ID) || !cont.matches(':hover')) return;
      const tag = document.activeElement?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
      if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') { seekBy(e.key === 'ArrowLeft' ? -5 : 5); e.preventDefault(); e.stopPropagation(); }
      else if (e.key === ' ') { toggle(); e.preventDefault(); e.stopPropagation(); }
    };
    window.addEventListener('keydown', onKey, true);

    // load the replay
    try { info = await loadVideo(no); }
    catch (e) { msg.classList.add('err'); msg.textContent = `❌ Could not load this replay (${e.message})`; return; }
    if (!document.body.contains(cont)) return;
    current.info = info;
    titleEl.textContent = info.title || 'CHZZK';
    subEl.textContent = [info.channel, info.date].filter(Boolean).join(' · ');
    if (info.adultBlocked) { msg.classList.add('err'); msg.textContent = '🔞 Log in to CHZZK with an age-verified account to watch this replay.'; return; }
    if (!info.mp4.length && !info.hls) { msg.classList.add('err'); msg.textContent = '❌ No playable stream for this replay.'; return; }
    msg.remove();
    const qPref = await preferredHeight();

    const seekTo = (t) => {
      const go = () => { seekAbs(Math.max(0, t)); video.play().catch(() => {}); };
      if (video.readyState >= 1) go(); else video.addEventListener('loadedmetadata', go, { once: true });
    };
    current.seekTo = seekTo;
    if (info.mp4.length) {
      let sel = Math.max(0, info.mp4.indexOf(pickByHeight(info.mp4, qPref)));
      const setSrc = (i, t, playing) => {
        sel = i;
        resGroup.querySelectorAll('.kws-vod-pill').forEach((b) => b.classList.toggle('checked', Number(b.dataset.i) === i));
        const rate = video.playbackRate;
        video.src = info.mp4[i].url;
        video.addEventListener('loadedmetadata', () => { video.currentTime = t; video.playbackRate = rate; if (playing) video.play().catch(() => {}); }, { once: true });
      };
      info.mp4.forEach((m, i) => {
        const b = mkBtn(m.height ? m.height + 'p' : m.id, `Switch to ${m.height ? m.height + 'p' : m.id}`, 'kws-vod-pill' + (i === sel ? ' checked' : ''));
        b.dataset.i = String(i);
        b.addEventListener('click', () => { if (i !== sel) { rememberHeight(m.height); setSrc(i, video.currentTime || 0, !video.paused); } });
        resGroup.appendChild(b);
      });
      setSrc(sel, startAt, true);
    } else {
      // HLS (recent replays): quality pills from the master playlist, 720p first like the MP4 replays.
      // hls.js when this page has it, else Chrome's own HLS playback of the chosen rendition.
      const useHls = !!(window.Hls && window.Hls.isSupported());
      const pick = pickByHeight(info.ts, qPref);
      let hls = null;
      const levelOf = (h) => (hls && hls.levels ? hls.levels.findIndex((l) => (l.height || 0) === h) : -1);
      const nativeSrc = (rep, t, playing) => {
        const rate = video.playbackRate;
        video.src = rep ? rep.playlist : info.hls;
        video.addEventListener('loadedmetadata', () => { video.currentTime = t; video.playbackRate = rate; if (playing) video.play().catch(() => {}); }, { once: true });
      };
      info.ts.forEach((r) => {
        const label = r.height ? r.height + 'p' : 'Source';
        const b = mkBtn(label, `Switch to ${label}`, 'kws-vod-pill' + (r === pick ? ' checked' : ''));
        b.addEventListener('click', () => {
          if (b.classList.contains('checked')) return;
          resGroup.querySelectorAll('.kws-vod-pill').forEach((x) => x.classList.toggle('checked', x === b));
          rememberHeight(r.height);
          if (hls) { const i = levelOf(r.height); if (i >= 0) hls.currentLevel = i; }
          else nativeSrc(r, video.currentTime || 0, !video.paused);
        });
        resGroup.appendChild(b);
      });
      if (useHls) {
        hls = new window.Hls({ startPosition: startAt }); current.hls = hls;
        hls.loadSource(info.hls); hls.attachMedia(video);
        hls.on(window.Hls.Events.MANIFEST_PARSED, () => { const i = levelOf(pick && pick.height); if (i >= 0) hls.currentLevel = i; video.play().catch(() => {}); });
      } else nativeSrc(pick, startAt, true);
    }
    if (info.ts.length) { dlBtn.disabled = false; dlBtn.addEventListener('click', () => openClipDownloader(info, video)); }
    else dlBtn.title = 'No downloadable segments for this replay';
  }

  // ── the download range on the seek bar (Start = yellow, End = blue; drag the handles) — the same
  //    design as updateRangeOverlay in ui.js ──
  let rangeCb = null;
  function rangeOverlay(startSec, endSec, cb) {
    let ov = document.getElementById(RANGE_ID);
    if (cb !== undefined) rangeCb = cb;
    if (startSec == null) { ov?.remove(); rangeCb = null; current?.cont?.classList.remove('kws-cz-dl-open'); return; }
    const parent = current?.seekCont;
    const total = current?.total?.() || 0;
    if (!parent || !total) return;
    current.cont.classList.add('kws-cz-dl-open'); // keep the controls (and the range) in view while choosing
    const render = (s, en) => {
      ov.dataset.s = s; ov.dataset.e = en;
      const sp = Math.max(0, Math.min(100, (s / total) * 100));
      const ep = Math.max(0, Math.min(100, (en / total) * 100));
      const stripe = ov.querySelector('.kws-range-stripe');
      stripe.style.left = sp + '%'; stripe.style.width = Math.max(0, ep - sp) + '%';
      const hs = ov.querySelector('.kws-range-handle-start'), he = ov.querySelector('.kws-range-handle-end');
      hs.style.left = 'calc(' + sp + '% - 8px)'; he.style.left = 'calc(' + ep + '% - 8px)';
      hs.querySelector('.kws-range-label').textContent = fmt(s);
      he.querySelector('.kws-range-label').textContent = fmt(en);
    };
    if (!ov) {
      ov = document.createElement('div');
      ov.id = RANGE_ID;
      ov.style.cssText = 'position:absolute;top:-8px;bottom:-8px;left:0;right:0;pointer-events:none;z-index:6;';
      parent.appendChild(ov);
      const stripe = document.createElement('div');
      stripe.className = 'kws-range-stripe';
      stripe.style.cssText = 'position:absolute;top:-2px;bottom:-2px;left:0;width:0;border-radius:3px;pointer-events:none;' +
        'background:repeating-linear-gradient(135deg,rgba(255,255,255,0.12) 0px 6px,transparent 6px 12px),linear-gradient(90deg,rgba(250,204,21,0.42),rgba(96,165,250,0.42));' +
        'border-top:1px solid rgba(255,255,255,0.28);border-bottom:1px solid rgba(255,255,255,0.28);';
      ov.appendChild(stripe);
      const mk = (side, color) => {
        const h = document.createElement('div');
        h.className = 'kws-range-handle kws-range-handle-' + side;
        h.style.cssText = 'position:absolute;top:-16px;height:16px;width:16px;cursor:ew-resize;pointer-events:auto;display:flex;align-items:center;justify-content:center;z-index:2;';
        const line = document.createElement('div');
        line.style.cssText = 'position:absolute;top:16px;bottom:-2px;left:50%;width:3px;margin-left:-1.5px;border-radius:2px;pointer-events:none;background:' + color + ';box-shadow:0 0 5px ' + color + ',0 0 0 1px rgba(0,0,0,0.5);';
        const tri = document.createElement('div');
        tri.style.cssText = 'position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:0;height:0;pointer-events:none;border-style:solid;' +
          (side === 'start' ? 'border-width:5px 0 5px 7px;border-color:transparent transparent transparent ' + color + ';' : 'border-width:5px 7px 5px 0;border-color:transparent ' + color + ' transparent transparent;') +
          'filter:drop-shadow(0 1px 2px rgba(0,0,0,0.6));';
        const label = document.createElement('div');
        label.className = 'kws-range-label';
        label.style.cssText = 'position:absolute;bottom:100%;left:50%;transform:translateX(-50%);margin-bottom:6px;pointer-events:none;padding:3px 7px;border-radius:6px;background:rgba(12,8,22,0.94);border:1px solid ' + color + '88;color:' + color + ';font-size:10px;font-weight:700;font-family:monospace;white-space:nowrap;';
        h.append(line, tri, label);
        ov.appendChild(h);
        return h;
      };
      const hs = mk('start', '#facc15'), he = mk('end', '#60a5fa');
      let mode = null;
      const secAt = (x) => { const r = parent.getBoundingClientRect(); return Math.max(0, Math.min(1, (x - r.left) / r.width)) * total; };
      const begin = (m) => (e) => { e.preventDefault(); e.stopPropagation(); mode = m; document.body.style.userSelect = 'none'; };
      hs.addEventListener('mousedown', begin('start'));
      he.addEventListener('mousedown', begin('end'));
      document.addEventListener('mousemove', (e) => {
        if (!mode || !document.getElementById(RANGE_ID)) return;
        let s = Number(ov.dataset.s), en = Number(ov.dataset.e);
        if (mode === 'start') s = Math.max(0, Math.min(secAt(e.clientX), en - 1));
        else en = Math.min(Math.max(secAt(e.clientX), s + 1), total);
        render(Math.round(s), Math.round(en));
        if (rangeCb) rangeCb(Math.round(s), Math.round(en));
      });
      document.addEventListener('mouseup', () => { if (mode) { mode = null; document.body.style.userSelect = ''; } });
    }
    render(startSec, endSec);
  }

  // ── Clip Downloader: the same popup as on Twitch / Kick (ui.js kwsOpenClipDownloader) ──
  function openClipDownloader(info, video) {
    if (document.getElementById(DL_ID)) { document.getElementById(DL_ID).remove(); rangeOverlay(null); return; }
    const total = current?.total?.() || info.duration || 0;
    let cs = Math.floor(video.currentTime || 0);
    let ce = Math.min(cs + 300, Math.floor(total || cs + 300));
    const pop = document.createElement('div');
    pop.id = DL_ID;
    pop.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:2147483001;width:340px;background:rgba(8,10,16,0.88);backdrop-filter:blur(20px) saturate(1.6);-webkit-backdrop-filter:blur(20px) saturate(1.6);border:1px solid rgba(255,255,255,0.14);border-radius:18px;box-shadow:0 16px 50px rgba(0,0,0,0.6);font-family:-apple-system,BlinkMacSystemFont,"Malgun Gothic",sans-serif;color:#e2e8f0;font-size:12px;display:flex;flex-direction:column;overflow:hidden;box-sizing:border-box;';
    const lab = (t, c) => `<div style="font-size:9px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:${c};margin-bottom:4px;">${t}</div>`;
    const box = (cls, label, c, val) => {
      const [r, g, b] = c;
      const txt = cls === 'st' ? '#facc15' : '#60a5fa', btx = cls === 'st' ? '#fde68a' : '#93c5fd';
      return `<div style="background:rgba(${r},${g},${b},0.07);border:1px solid rgba(${r},${g},${b},0.2);border-radius:10px;padding:8px 10px;">${lab(label, `rgba(${r},${g},${b},0.6)`)}` +
        `<input class="${cls}" type="text" value="${val}" style="width:100%;box-sizing:border-box;background:transparent;border:none;outline:none;font-size:13px;font-weight:800;color:${txt};margin:0 0 6px;padding:0;font-family:inherit;"/>` +
        `<button class="${cls}-set" style="width:100%;padding:4px;border-radius:7px;font-size:10px;font-weight:800;background:rgba(${r},${g},${b},0.25);border:1px solid rgba(${r},${g},${b},0.4);color:${btx};cursor:pointer;">Set to Current</button></div>`;
    };
    pop.innerHTML =
      `<div class="hd" style="display:flex;align-items:center;justify-content:space-between;padding:11px 14px 9px;border-bottom:1px solid rgba(255,255,255,0.07);cursor:move;background:rgba(255,255,255,0.04);"><span style="font-size:11px;font-weight:800;letter-spacing:0.05em;color:rgba(255,255,255,0.55);text-transform:uppercase;">Clip Downloader</span><button class="cl kws-unified-close" style="width:22px;height:22px;font-size:12px;">✕</button></div>` +
      `<div style="padding:12px 14px;display:flex;flex-direction:column;gap:10px;">` +
        `<div>${lab('Resolution', 'rgba(255,255,255,0.35)')}<select class="res" style="width:100%;box-sizing:border-box;background:rgba(20,20,30,0.95);border:1px solid rgba(255,255,255,0.14);border-radius:9px;color:#fff;font-size:11px;padding:5px 9px;outline:none;font-family:inherit;cursor:pointer;">${info.ts.map((r, i) => `<option value="${i}">${r.height ? r.height + 'p' : esc(r.id)}</option>`).join('')}</select></div>` +
        `<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">${box('st', 'Start', [250, 204, 21], fmt(cs))}${box('en', 'End', [96, 165, 250], fmt(ce))}</div>` +
        `<div style="display:flex;align-items:center;justify-content:space-between;padding:6px 10px;border-radius:9px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07);"><span style="font-size:9px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:rgba(255,255,255,0.3);">Duration</span><span class="du" style="font-size:13px;font-weight:800;color:rgba(255,255,255,0.75);"></span></div>` +
        `<div style="display:flex;align-items:center;gap:5px;padding:6px 9px;border-radius:9px;background:rgba(251,191,36,0.08);border:1px solid rgba(251,191,36,0.22);color:#fde68a;font-size:10px;font-weight:600;"><span>⚠️</span><span>Keep this tab open while downloading.</span></div>` +
        `<button class="go" style="width:100%;padding:9px;border-radius:11px;font-size:12px;font-weight:800;background:linear-gradient(135deg,rgba(37,99,235,0.7),rgba(59,130,246,0.7));color:#fff;border:1px solid rgba(99,137,255,0.4);cursor:pointer;box-shadow:inset 0 1px 0 rgba(255,255,255,0.12);">💾 Download</button>` +
      `</div>`;
    zoomFix(pop);
    document.body.appendChild(pop);
    const $ = (sel) => pop.querySelector(sel);
    dragBy($('.hd'), pop);
    $('.cl').addEventListener('click', () => { pop.remove(); rangeOverlay(null); });
    $('.res').value = '0'; // downloads always start on the best quality (info.ts is sorted best first)
    const upd = (skipOverlay) => {
      $('.st').value = fmt(cs); $('.en').value = fmt(ce);
      $('.du').textContent = fmt(Math.max(0, ce - cs));
      if (!skipOverlay) rangeOverlay(cs, ce, (s, e) => { cs = s; ce = e; upd(true); });
    };
    $('.st').addEventListener('change', () => { cs = parseT($('.st').value); upd(); });
    $('.en').addEventListener('change', () => { ce = parseT($('.en').value); upd(); });
    $('.st-set').addEventListener('click', () => { cs = Math.floor(video.currentTime || 0); if (ce <= cs) ce = Math.min(cs + 300, Math.floor(total || cs + 300)); upd(); });
    $('.en-set').addEventListener('click', () => { ce = Math.floor(video.currentTime || 0); if (ce <= cs) ce = cs + 1; upd(); });
    $('.go').addEventListener('click', async () => {
      const rep = info.ts[Number($('.res').value || 0)] || info.ts[0];
      const fail = (m) => { $('.go').textContent = m; setTimeout(() => { if ($('.go')) $('.go').textContent = '💾 Download'; }, 2500); };
      if (!rep) return fail('❌ No downloadable segments');
      if (!(ce > cs)) return fail('❌ End must be after Start');
      if (!rep.segs) {
        $('.go').textContent = '⏳ Loading segments...';
        try { await hlsSegments(rep); } catch (e) { return fail('❌ ' + e.message); }
        $('.go').textContent = '💾 Download';
      }
      const segs = rep.segs.filter((sg) => sg.t + sg.d > cs && sg.t < ce);
      if (!segs.length) return fail('❌ No segments in this range');
      startDownload(info, rep, segs, cs, ce);
      // the time picker stays open (as on Twitch / Kick) so a wrong range can be fixed and run again
    });
    upd();
  }

  // File name like the Twitch / Kick downloader (largeDownload.js buildFilenameFromSettings):
  //   start-end-channel-date-resolution  →  "01h12m10s-01h17m10s-한세라-7 Oct 2026-1080p"
  // The channel is the CHZZK channel *name* (the 32-character channel ID is too long). A file-name
  // layout saved in the Twitch / Kick downloader settings (tvd_file_format_setting) is followed too.
  const hms = (s) => { s = Math.max(0, Math.floor(s)); const p = (n) => String(n).padStart(2, '0'); return p(Math.floor(s / 3600)) + 'h' + p(Math.floor((s % 3600) / 60)) + 'm' + p(s % 60) + 's'; };
  const friendly = (ms) => { if (!ms) return ''; const d = new Date(ms); return d.getDate() + ' ' + ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getMonth()] + ' ' + d.getFullYear(); };
  const awsDT = (ms) => (ms ? new Date(ms).toISOString().replace(/\.\d+?(?=Z)/, '').replace(/\W+/g, '') : '');
  async function clipFileName(info, rep, cs, ce) {
    const vals = {
      start_time: hms(cs), end_time: hms(ce), channel_login: info.channel || 'chzzk',
      timestamp: friendly(info.startMs) || info.date, dateString: awsDT(info.startMs),
      resolution: rep.height ? rep.height + 'p' : (rep.id || ''),
    };
    let layout = null;
    try {
      let saved = (await chrome.storage.local.get('tvd_file_format_setting')).tvd_file_format_setting;
      if (typeof saved === 'string') saved = JSON.parse(saved);
      if (Array.isArray(saved) && saved.some((r) => r && r.include && r.key && r.key !== 'spacer')) layout = saved.filter((r) => r && r.include);
    } catch (_) {}
    if (!layout) layout = [{ key: 'start_time' }, { separator: '-' }, { key: 'end_time' }, { separator: '-' }, { key: 'channel_login' }, { separator: '-' }, { key: 'timestamp' }, { separator: '-' }, { key: 'resolution' }];
    const name = layout.map((r) => (r.separator ? r.separator : (vals[r.key] ?? ''))).join('');
    return name.replace(/[\\/:*?"<>|]+/g, '_').replace(/^-+|-+$/g, '').trim() || 'chzzk clip';
  }

  // The download runs in its own progress popup (Twitch / Kick / SOOP: .kws-inline-download-pop).
  async function startDownload(info, rep, segs, cs, ce) {
    const isMp4 = !!rep.init || /\.(m4s|mp4|m4v)(\?|$)/i.test(segs[0].url); // fMP4 HLS → init + fragments = one .mp4
    const name = (await clipFileName(info, rep, cs, ce)) + (isMp4 ? '.mp4' : '.ts');
    let fh;
    try { fh = await window.showSaveFilePicker({ suggestedName: name, startIn: 'downloads', types: [isMp4 ? { description: 'MP4 video', accept: { 'video/mp4': ['.mp4'] } } : { description: 'mpeg transport stream', accept: { 'video/mp2t': ['.ts'] } }] }); }
    catch (e) { if (e.name !== 'AbortError') alert('KWS: ' + e.message); return; }
    const ws = await fh.createWritable();
    const id = 'kws_cz_dl_' + Date.now();
    const pop = document.createElement('div');
    pop.id = id;
    pop.className = 'kws-inline-download-pop kws-cz-dl';
    pop.innerHTML = `
      <div class="kws-inline-download-head"><div class="kws-inline-download-title">Clip Downloader</div><button type="button" class="kws-inline-download-close">×</button></div>
      <div class="bd" style="display:grid;grid-gap:10px;padding:14px 16px;color:#e5e7eb;">
        <div style="display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:12px;background:rgba(251,191,36,0.10);border:1px solid rgba(251,191,36,0.28);color:#fde68a;font-size:0.85em;font-weight:600;"><span style="font-size:1.1em;">⚠️</span><span>Keep this tab active — navigating away may interrupt the download.</span></div>
        <div style="display:grid;gap:8px;">
          <div class="sec" style="font-size:0.82em;color:rgba(255,255,255,0.52);font-weight:600;">Downloading ${fmt(cs)} to ${fmt(ce)}</div>
          <div class="sb" style="border-radius:10px;padding:8px 12px;font-size:0.9em;font-weight:700;color:#fff;border:1px solid rgba(37,99,235,0.45);background:linear-gradient(90deg, rgba(2,52,181,0.9) 0%, rgba(2,52,181,0.5) 0.5%, rgba(2,52,181,0.04) 1%, rgba(2,52,181,0.04) 100%);">initiating download</div>
        </div>
        <div style="display:grid;gap:6px;">
          <div style="display:grid;gap:3px;font-size:0.82em;color:rgba(255,255,255,0.65);font-weight:600;"><div class="fs"></div><div class="du"></div><div class="po"></div></div>
          <button class="stop" style="width:100%;text-align:center;color:#fff;cursor:pointer;background:rgba(37,99,235,0.55);border:1px solid rgba(99,137,255,0.35);padding:9px 12px;border-radius:12px;font-size:0.9em;font-weight:700;box-shadow:inset 0 1px 0 rgba(255,255,255,0.10);">Stop and Download Progress</button>
        </div>
      </div>`;
    zoomFix(pop);
    document.body.appendChild(pop);
    { const n = document.querySelectorAll('.kws-cz-dl').length - 1; if (n > 0) { pop.style.right = (24 + n * 22) + 'px'; pop.style.bottom = (24 + n * 22) + 'px'; } }
    const $ = (s) => pop.querySelector(s);
    dragBy($('.kws-inline-download-head'), pop);
    let stop = false;
    $('.kws-inline-download-close').addEventListener('click', () => { stop = true; pop.remove(); });
    $('.stop').addEventListener('click', () => { stop = true; $('.stop').remove(); $('.sb').textContent = '⏳ Stopping — saving progress so far...'; });
    if (globalThis.KWSDl) KWSDl.begin(); // keep the tab alive while this runs
    let done = 0, bytes = 0, dur = 0, failed = false;
    try {
      if (rep.init) { try { const r = await fetch(rep.init); if (r.ok) { const b = await r.arrayBuffer(); await ws.write(b); bytes += b.byteLength; } else failed = true; } catch (_) { failed = true; } }
      for (const sg of (failed ? [] : segs)) {
        if (stop) break;
        let buf = null;
        for (let a = 0; a < 6 && !buf; a++) {
          try { const r = await fetch(sg.url); if (r.ok) buf = await r.arrayBuffer(); } catch (_) {}
          if (!buf) await sleep(500 * (a + 1));
        }
        if (!buf) { failed = true; break; }
        await ws.write(buf); bytes += buf.byteLength; dur += sg.d; done++;
        if (!document.body.contains(pop)) continue;
        const pct = Math.round(done / segs.length * 10000) / 100;
        const sb = $('.sb');
        sb.textContent = `${pct}% complete`;
        sb.style.background = `linear-gradient(90deg, #00237d ${pct - 0.5}%, #0234b5 ${pct + 1}%, #0234b501 ${pct + 1.5}%, #0234b501 100%)`;
        const st = $('.stop'); if (st && st.textContent === 'Stop and Download Progress') st.textContent = 'Click to Stop and Download Progress';
        $('.fs').textContent = `Current File Size: ${bytes >= 1e9 ? (bytes / 1e9).toFixed(3) + 'gb' : (bytes / 1e6).toFixed(2) + 'mb'}`;
        $('.du').textContent = `Duration: ${fmt(dur)}`;
        $('.po').textContent = `Current VOD Position: ${fmt(sg.t)}`;
      }
    } finally {
      await ws.close().catch(() => {});
      if (globalThis.KWSDl) KWSDl.end();
    }
    if (!document.body.contains(pop)) return;
    const bd = $('.bd');
    bd.innerHTML = '';
    bd.style.cssText += 'display:flex;align-items:center;justify-content:center;flex-direction:column;gap:12px;padding:24px;';
    const m = document.createElement('div');
    m.textContent = failed ? '⚠️ Incomplete — a segment failed after retries. File saved up to that point.' : stop ? '✅ Stopped — progress saved' : '✅ Download Complete';
    m.style.cssText = failed ? 'font-size:0.95em;font-weight:800;color:#fca5a5;text-align:center;' : 'font-size:1em;font-weight:800;color:#86efac;';
    const btn = document.createElement('button');
    btn.textContent = 'Close';
    btn.style.cssText = 'padding:10px 32px;border-radius:12px;background:rgba(220,38,38,0.75);color:#fff;border:1px solid rgba(239,68,68,0.5);cursor:pointer;font-size:0.95em;font-weight:800;box-shadow:inset 0 1px 0 rgba(255,255,255,0.15);';
    btn.addEventListener('click', () => pop.remove());
    bd.append(m, btn);
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || msg.platform !== 'chzzk') return;
    if (msg.type === 'KWS_SP_OPEN_VOD' && msg.item) {
      open(msg.item.vod_id, Math.max(0, (Number(msg.item.playback_offset) || 0) - 30)); // 30 s before the line, like Twitch / Kick / YouTube
      sendResponse({ ok: true });
    } else if (msg.type === 'KWS_SP_OPEN_URL') {
      const raw = String(msg.raw || '');
      const m = /video\/(\d+)/.exec(raw) || /^\s*(\d{4,})\s*$/.exec(raw);
      const t = /[?&](?:currentTime|t)=(\d+)/.exec(raw);
      if (m) { open(m[1], t ? Number(t[1]) : 0); sendResponse({ ok: true }); } else sendResponse({ ok: false });
    }
  });
})();
