// KWS 1.2.5 — side panel wiring (loaded from background.js via importScripts).
//
// - Toolbar icon opens the side panel (window-wide panel, follows the user across tabs).
// - Floating button on supported sites asks to open it (KWS_SP_OPEN).
// - The panel keeps a port open while it is visible; we track which windows have it open
//   and tell that window's tabs, so their floating buttons hide while the panel is open.

const KWS_SP_PORT = 'kws-sidepanel';
const kwsSpOpenWindows = new Set();

chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((e) => {
  console.warn('[KWS SP] setPanelBehavior failed', e);
});

// Self-heal (1.2.5.15): when the extension reloads or updates while the panel is open, Chrome can
// leave the panel on its own "ERR_FILE_NOT_FOUND" page (the panel asked for its page while the
// extension was not ready). That page is not an extension page, so nothing of ours runs in it.
// If no live panel page exists, we point the panel at its page again under a fresh URL; Chrome
// then navigates every open panel to it, and an error page turns back into KWS. (A closed panel
// just keeps the new default path.)
async function kwsSpHeal(delayMs = 1500) {
  await new Promise((r) => setTimeout(r, delayMs));
  try {
    const live = chrome.runtime.getContexts ? await chrome.runtime.getContexts({ contextTypes: ['SIDE_PANEL'] }) : [];
    if (live && live.length) return false; // a real panel is running: leave it alone
    await chrome.sidePanel.setOptions({ path: 'sidepanel/sidepanel.html?r=' + Date.now().toString(36), enabled: true });
    return true;
  } catch (e) { console.warn('[KWS SP] heal', e); return false; }
}
chrome.runtime.onInstalled.addListener(() => { kwsSpHeal(1500); kwsSpHeal(5000); });
chrome.runtime.onStartup.addListener(() => { kwsSpHeal(2000); kwsSpHeal(6000); });
// and a slow check, for a panel that broke while nothing else happened
try {
  chrome.alarms.create('kws-sp-heal', { periodInMinutes: 1 });
  chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'kws-sp-heal') kwsSpHeal(0); });
} catch (_) {}

async function kwsSpBroadcast(windowId, open) {
  try {
    const tabs = await chrome.tabs.query({ windowId });
    for (const tab of tabs) {
      chrome.tabs.sendMessage(tab.id, { type: 'KWS_SP_STATE', open }).catch(() => {});
    }
  } catch (e) {}
}

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== KWS_SP_PORT) return;
  let windowId = null;
  port.onMessage.addListener((msg) => {
    if (msg && msg.type === 'hello' && typeof msg.windowId === 'number') {
      windowId = msg.windowId;
      kwsSpOpenWindows.add(windowId);
      kwsSpBroadcast(windowId, true);
    }
  });
  port.onDisconnect.addListener(() => {
    if (windowId == null) return;
    kwsSpOpenWindows.delete(windowId);
    kwsSpBroadcast(windowId, false);
  });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.type !== 'string' || !msg.type.startsWith('KWS_SP_')) return;

  if (msg.type === 'KWS_SP_OPEN') {
    // Must run synchronously inside the click's user-gesture window: no await before open().
    const windowId = sender?.tab?.windowId;
    if (windowId != null) {
      chrome.sidePanel.open({ windowId }).catch((e) => console.warn('[KWS SP] open failed', e));
      kwsSpHeal(2500); // if it opened on an error page, bring KWS back
    }
    sendResponse({ ok: true });
    return;
  }

  if (msg.type === 'KWS_SP_GET_STATE') {
    const windowId = sender?.tab?.windowId;
    sendResponse({ open: windowId != null && kwsSpOpenWindows.has(windowId) });
    return;
  }
});
