// KWS 1.2.5 — scan hub (loaded into background.js via importScripts).
//
// One place that runs channel scans for the side panel and keeps their state:
//   chrome.storage.session["kwsSpScans"] = { "<platform>:<channel>": entry, ... }
// The panel renders from that key (storage.onChanged), so it can be closed and reopened
// mid-scan without losing anything, and the page scripts read it for their site badges.
// Session storage = same lifetime as the 1.2.4 result tabs (kept until the browser closes).
//
// The scan engines themselves are the 1.2.4 ones, unchanged (kick_scanChannelRange, ...).

const SP_SCANS_KEY = 'kwsSpScans';
const SP_RANGE_KEY = 'kwsSpDefaultRange';
const SP_RANGE_DEFAULT_DAYS = 60;
const SP_MAX_CONCURRENT = { kick: 4, twitch: 4, soop: 4, youtube: 4, chzzk: 4 }; // 1.2.5.49: YouTube 2 → 4 like the others
const SP_HISTORY_KEYS = { kick: 'kickKwsHistory', twitch: 'twitchKwsHistory', soop: 'soopSearchHistory', youtube: 'ytKwsHistory', chzzk: 'chzzkKwsHistory' };
const SP_AUTO_CLOSE_KEYS = { kick: 'kickKwsAutoCloseNoResult', twitch: 'kwsAutoCloseNoResult', soop: 'soopAutoCloseNoResult', youtube: 'kwsAutoCloseNoResult', chzzk: 'kwsAutoCloseNoResult' };
const SP_SITE_PATTERNS = {
  kick: ['https://kick.com/*', 'https://www.kick.com/*'],
  twitch: ['https://www.twitch.tv/*'],
  soop: ['https://www.sooplive.com/*'],
  youtube: ['https://www.youtube.com/*'],
  chzzk: ['https://chzzk.naver.com/*'],
};
const SP_CHANNEL_URL = {
  kick: (c) => 'https://kick.com/' + encodeURIComponent(c),
  twitch: (c) => 'https://www.twitch.tv/' + encodeURIComponent(c),
  soop: (c) => 'https://www.sooplive.com/station/' + encodeURIComponent(c),
  youtube: (c) => 'https://www.youtube.com/@' + encodeURIComponent(c) + '/streams',
  chzzk: (c) => 'https://chzzk.naver.com/' + encodeURIComponent(c),
};

const SP_MAIN_URL = { kick: 'https://kick.com/', twitch: 'https://www.twitch.tv/', soop: 'https://www.sooplive.com/', youtube: 'https://www.youtube.com/', chzzk: 'https://chzzk.naver.com/' };

// Page scripts (site badges) read the scan state too.
try { chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' }).catch(() => {}); } catch (_) {}

// Per-platform engines: run(entry, hooks) → { failedChunks }, stop(entry).
const SP_RUNNERS = {
  kick: {
    run: (e, h) => kick_scanChannelRange({
      channel: e.channel, keyword: e.params.keyword, startDate: e.params.startDate, endDate: e.params.endDate,
      onStart: h.onStart, onProgress: h.onProgress,
    }),
    stop: (e) => { kws_kickStopFlags.add(e.channel); },
  },
  // Twitch: the 1.2.4 dispatcher (Zonian / Native / Combined fast / Combined accurate, from the
  // kwsLogSource setting). Progress sends new groups (or a full snapshot with replaceGroups);
  // the final result carries the authoritative list (incl. CDN-recovered VODs).
  twitch: {
    run: async (e, h) => {
      const d = await chrome.storage.local.get('kwsLogSource');
      // 1.2.5.20: two modes only — an old Native-only pick runs as Accurate, Zonian-only (and unset) as Fast
      const logSource = (d.kwsLogSource === 'combined' || d.kwsLogSource === 'twitch') ? 'combined' : 'combined_fast';
      e.logSource = logSource;
      if (e.params.allApi && logSource !== 'twitch') {
        // Zonian keeps logs for days whose VOD is gone — start at the oldest VOD Twitch still has.
        let vods = [];
        try { vods = await kws_fetchVodScheduleByType(e.channel, 'ARCHIVE', 0); } catch (_) {}
        const oldest = (vods || []).reduce((m, v) => (v && v.startMs && v.startMs < m ? v.startMs : m), Infinity);
        e.params.startDate = Number.isFinite(oldest) ? kws_format(new Date(oldest)) : spDaysAgo(SP_RANGE_DEFAULT_DAYS); // no VODs at all → 1.2.4's 60 days
      }
      const token = { cancelled: false };
      spTwitchTokens.set(e.id, token);
      const byDate = new Map();
      const put = (groups, replace) => {
        if (replace) byDate.clear();
        for (const g of groups || []) {
          const key = g.date || g.displayDate || g.sourceDate;
          if (!key || (!replace && byDate.has(key))) continue;
          byDate.set(key, spTwitchGroup(g, e.channel));
        }
        return [...byDate.values()].sort((a, b) => (a.date < b.date ? -1 : 1));
      };
      try {
        const r = await kws_scanChannelRangeDispatch({
          channel: e.channel, keyword: e.params.keyword, startDate: e.params.startDate, endDate: e.params.endDate,
          pageDate: '', logSource, twitchTokens: null, cancelToken: token,
          onStart: h.onStart,
          onProgress: (p) => {
            // which log sources are working right now (combined modes report both)
            const busy = (x) => !!x && (x.total ? (x.done || 0) < x.total : true);
            if (p.zonianStatus || p.twitchStatus) e.net = { zonian: busy(p.zonianStatus), twitch: busy(p.twitchStatus) };
            const groups = (p.replaceGroups || (p.newGroups && p.newGroups.length)) ? put(p.newGroups, !!p.replaceGroups) : null;
            h.onProgress({ ...p, matchedGroups: groups || undefined, failedChunks: p.failedDays || 0 });
          },
        });
        const groups = Array.isArray(r && r.matchedGroups) ? put(r.matchedGroups, true) : [...byDate.values()];
        h.onProgress({ done: r.total || e.total, total: r.total || e.total, matchedLines: r.matchedLines || 0, matchedDays: r.matchedDays || 0, matchedGroups: groups, failedChunks: r.failedDays || 0 });
        if (r && r.resolvedEndDate) e.params.endDate = r.resolvedEndDate;
        return { failedChunks: (r && r.failedDays) || 0 };
      } catch (err) {
        if (token.cancelled) return { failedChunks: e.failedChunks || 0 }; // stopped: keep what was found
        throw err;
      } finally {
        spTwitchTokens.delete(e.id);
      }
    },
    stop: (e) => { const t = spTwitchTokens.get(e.id); if (t) t.cancelled = true; },
  },
};
const spTwitchTokens = new Map();
// CHZZK: the API answers the extension directly (optional host permission), so it runs here.
SP_RUNNERS.chzzk = {
  run: async (e, h) => {
    const token = { cancelled: false };
    spTwitchTokens.set(e.id, token);
    try {
      const r = await chzzk_scanChannelRange({
        channel: e.channel, keyword: e.params.keyword, startDate: e.params.startDate, endDate: e.params.endDate, token,
        onStart: (p) => { if (p.channelName) { e.nickname = p.channelName; e.historyPatch = { nickname: p.channelName }; } h.onStart(p); },
        onProgress: h.onProgress,
      });
      return r;
    } finally { spTwitchTokens.delete(e.id); }
  },
  stop: (e) => { const t = spTwitchTokens.get(e.id); if (t) t.cancelled = true; },
};

// SOOP and YouTube: their chat logs only answer requests made from the site's own page (SOOP's
// ChatLoadSplit.php; YouTube's live_chat replay with the page's cookies), so the 1.2.4 engines keep
// running in a site tab (soopSearcher.js / youtubeSearcher.js). The hub picks that tab, asks it to
// run the scan (KWS_SP_PAGE_RUN) and relays its events (KWS_SP_PAGE_EVENT). Closing or reloading
// that tab ends the scan, as in 1.2.4.
const spPageRuns = new Map(); // scan id → { tabId, h, resolve, reject, e }
const SP_TAB_TEST = {
  soop: (url) => /^https:\/\/www\.sooplive\.com\//.test(url || ''),
  // YouTube scans read the channel's own Live tab (the VOD list comes from that page).
  youtube: (url, ch) => {
    const m = /^https:\/\/www\.youtube\.com\/(?:@([^/?#]+)|channel\/([^/?#]+))\/streams/.exec(url || '');
    if (!m) return false;
    let h = m[1] || m[2];
    try { h = decodeURIComponent(h); } catch (_) {}
    return h.toLowerCase() === String(ch || '').toLowerCase();
  },
};
// Where a SOOP / YouTube scan runs (1.2.4 way, dev24): in the user's own site tab when one is
// open — the tab that asked, then this window's tab, then any — so no extra tab appears. Only when
// there is none does the hub open one (a normal tab) and close it when the scans are done.
// Closing the tab a scan runs in ends that scan, as in 1.2.4 (the panel offers "scan again").
// One SOOP tab runs every SOOP scan (the engine handles up to 4 at once); YouTube needs the
// channel's own Live tab.
const spWorkers = new Map(); // tabId → { platform, runs: Set<scan id> } — only tabs the hub opened
// 1.2.5.20: tabs whose KWS page script never answered — almost always a page that was open
// before the extension was reloaded/updated (its old script is cut off until the page reloads).
// Skipped from then on, so the next scan opens a fresh worker tab instead of failing again.
const spStaleTabs = new Set();
chrome.tabs.onUpdated.addListener((tabId, info) => { if (info.status === 'loading') spStaleTabs.delete(tabId); }); // reloaded → fresh script
chrome.tabs.onRemoved.addListener((tabId) => spStaleTabs.delete(tabId));
async function spUserTab(platform, e) {
  const ok = (t) => t && !t.discarded && !spStaleTabs.has(t.id) && SP_TAB_TEST[platform](t.url || t.pendingUrl, e.channel);
  if (e.origin && typeof e.origin.tabId === 'number') {
    try { const t = await chrome.tabs.get(e.origin.tabId); if (ok(t)) return t; } catch (_) {}
  }
  let tabs = [];
  try { tabs = await chrome.tabs.query({}); } catch (_) {}
  const winId = e.origin && typeof e.origin.windowId === 'number' ? e.origin.windowId : null;
  const cands = tabs.filter(ok);
  return cands.find((t) => t.windowId === winId && t.active) || cands.find((t) => t.windowId === winId)
    || cands.find((t) => t.active) || cands[0] || null;
}
// SOOP: one decision at a time, so scans started together all end up in the same tab.
let spSoopPick = Promise.resolve();
function spWorkerTab(platform, e) {
  if (platform !== 'soop') return spUserTab(platform, e).then((own) => own || spMakeWorkerTab(platform, e));
  const next = spSoopPick.then(() => spPickSoopTab(e));
  spSoopPick = next.catch(() => {});
  return next;
}
async function spPickSoopTab(e) {
  // a SOOP tab the hub opened earlier and is still using comes first (keeps scans together)
  for (const [tabId, w] of spWorkers) {
    if (w.platform !== 'soop' || spStaleTabs.has(tabId)) continue;
    try { await chrome.tabs.get(tabId); clearTimeout(w.closeTimer); return { id: tabId }; } catch (_) { spWorkers.delete(tabId); }
  }
  return (await spUserTab('soop', e)) || spMakeWorkerTab('soop', e);
}
async function spMakeWorkerTab(platform, e) {
  const url = platform === 'soop' ? SP_MAIN_URL.soop : SP_CHANNEL_URL[platform](e.channel);
  const winQ = e.origin && typeof e.origin.windowId === 'number' ? { windowId: e.origin.windowId } : {};
  const tab = await chrome.tabs.create({ ...winQ, url, active: false });
  try { await chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch (_) {}
  spWorkers.set(tab.id, { platform, runs: new Set() });
  return tab;
}
function spWorkerDone(tabId, scanId) {
  const w = spWorkers.get(tabId);
  if (!w) return;
  w.runs.delete(scanId);
  if (w.runs.size) return;
  clearTimeout(w.closeTimer);
  w.closeTimer = setTimeout(() => {
    const cur = spWorkers.get(tabId);
    if (!cur || cur.runs.size) return;
    spWorkers.delete(tabId);
    chrome.tabs.remove(tabId).catch(() => {});
  }, platform_closeDelay(w.platform));
}
const platform_closeDelay = (p) => (p === 'soop' ? 15000 : 1500); // a SOOP tab may be reused by the next scan
chrome.tabs.onRemoved.addListener((tabId) => spWorkers.delete(tabId));

function spPageRunner(platform) {
  return {
    run: async (e, h) => {
      try { return await spPageRunOnce(platform, e, h); }
      catch (err) {
        // the page never answered: mark that tab stale and retry once in a fresh hub-made tab
        if (!(err && err.kwsNoAnswer)) throw err;
        spStaleTabs.add(err.kwsTabId);
        console.warn('[KWS SP]', platform, 'tab', err.kwsTabId, 'did not answer (stale page script?) — retrying in a new worker tab');
        return spPageRunOnce(platform, e, h, { fresh: true });
      }
    },
    stop: (e) => {
      const run = spPageRuns.get(e.id);
      if (run) chrome.tabs.sendMessage(run.tabId, { type: 'KWS_SP_PAGE_STOP', platform, id: e.id }).catch(() => {});
    },
  };
}
async function spPageRunOnce(platform, e, h, { fresh = false } = {}) {
  {
    {
      const tab = fresh ? await spMakeWorkerTab(platform, e) : await spWorkerTab(platform, e);
      const w = spWorkers.get(tab.id);
      if (w) w.runs.add(e.id);
      await spWaitTabComplete(tab.id);
      const done = new Promise((resolve, reject) => spPageRuns.set(e.id, { tabId: tab.id, h, resolve, reject, e }))
        .finally(() => spWorkerDone(tab.id, e.id));
      let ok = false;
      for (let i = 0; i < 20 && !ok; i++) {
        try {
          const r = await chrome.tabs.sendMessage(tab.id, { type: 'KWS_SP_PAGE_RUN', platform, id: e.id, channel: e.channel, mode: e.mode, params: e.params,
            // a hub-made tab (no tab group: Chrome syncs groups and asks "delete group?" when the last
            // tab closes, which kept the tab open) — the page marks its own title instead
            worker: spWorkers.has(tab.id) ? (chrome.i18n.getMessage('workerTabGroup') || 'KWS') : '' });
          ok = !!(r && r.ok);
          if (r && r.busy) { spPageRuns.delete(e.id); spWorkerDone(tab.id, e.id); throw new Error('busy'); }
        } catch (err) { if (err && err.message === 'busy') throw new Error('This tab is already scanning'); }
        if (!ok) await kws_sleep(400);
      }
      if (!ok) {
        spPageRuns.delete(e.id); spWorkerDone(tab.id, e.id);
        const err = new Error('The ' + platform + ' page did not respond — reload it and try again');
        if (!fresh) { err.kwsNoAnswer = true; err.kwsTabId = tab.id; }
        throw err;
      }
      return done;
    }
  }
}
SP_RUNNERS.soop = spPageRunner('soop');
SP_RUNNERS.youtube = spPageRunner('youtube');

function spPageEvent(msg) {
  const run = spPageRuns.get(msg.id);
  if (!run) return;
  const { h, e } = run;
  if (msg.kind === 'start') { h.onStart({ totalDates: 0, keywords: msg.keywords || [] }); return; }
  if (typeof msg.totalSessions === 'number') e.totalSessions = msg.totalSessions;
  if (msg.nickname) e.nickname = msg.nickname;
  if (typeof msg.subOnly === 'number') e.subOnly = msg.subOnly;
  if (typeof msg.failReason === 'string') e.failReason = msg.failReason; // 1.2.5.37 SOOP: why VODs failed
  if (msg.net) e.net = msg.net; // SOOP live network activity (API / VOD tab / thumbnail) // SOOP streamer nickname (shown instead of the ID in Korean UI)
  h.onProgress({
    done: msg.done || 0, total: msg.total || 0, matchedLines: msg.matchedLines || 0, matchedDays: msg.matchedDays || 0,
    matchedGroups: Array.isArray(msg.groups) ? msg.groups : undefined, failedChunks: msg.failed || 0,
  });
  if (msg.kind === 'progress') return;
  spPageRuns.delete(msg.id);
  e.historyPatch = Object.assign({}, msg.historyPatch || {});
  if (msg.kind === 'done' || msg.stopped) run.resolve({ failedChunks: msg.failed || 0 });
  else run.reject(new Error(msg.error || 'scan failed'));
}
// The page that runs a scan is gone (closed, reloaded, or navigated away — YouTube navigates
// in-page, so a 'loading' tab is asked whether it is still running the scan first).
function spPageGone(tabId, why) {
  for (const [id, run] of spPageRuns) {
    if (run.tabId !== tabId) continue;
    spPageRuns.delete(id);
    run.reject(new Error(why));
  }
}
chrome.tabs.onRemoved.addListener((tabId) => spPageGone(tabId, 'tab closed'));
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status !== 'loading') return;
  if (![...spPageRuns.values()].some((r) => r.tabId === tabId)) return;
  setTimeout(async () => {
    let alive = [];
    try { alive = ((await chrome.tabs.sendMessage(tabId, { type: 'KWS_SP_PAGE_PING' })) || {}).running || []; } catch (_) {}
    for (const [id, run] of spPageRuns) {
      if (run.tabId === tabId && !alive.includes(id)) { spPageRuns.delete(id); run.reject(new Error('tab reloaded')); }
    }
  }, 1500);
});
// 1.2.4 Twitch group {date, displayDate, sourceDate, lines, rawMessages} → panel group {date, displayDate, messages}.
// Each message gets its channel and date so the page can open it without the group.
function spTwitchGroup(g, channel) {
  const date = g.displayDate || g.date;
  const messages = (g.rawMessages || g.messages || []).map((m) => ({ ...m, vod_channel: channel, _date: date, _sourceDate: g.sourceDate || g.date }));
  const sourceServices = Array.isArray(g.sourceServices) && g.sourceServices.length ? g.sourceServices : [g.source === 'internal' ? 'twitch' : 'zonian'];
  return { date: g.date || date, displayDate: date, sourceDate: g.sourceDate || g.date, sourceServices, messages };
}

let spScans = null;
let spLoading = null;
async function spEnsureLoaded() {
  if (spScans) return;
  if (!spLoading) {
    spLoading = (async () => {
      let d = {};
      try { d = await chrome.storage.session.get(SP_SCANS_KEY); } catch (_) {}
      spScans = d[SP_SCANS_KEY] || {};
      // The service worker was restarted while these were in flight: they are not running any more.
      for (const e of Object.values(spScans)) {
        if (e.status === 'running' || e.status === 'queued') { e.status = 'stopped'; e.interrupted = true; }
      }
    })();
  }
  await spLoading;
}

let spWriteTimer = null;
function spPersist(now) {
  if (now) {
    clearTimeout(spWriteTimer);
    spWriteTimer = null;
    return spFlush();
  }
  if (!spWriteTimer) spWriteTimer = setTimeout(() => { spWriteTimer = null; spFlush(); }, 700);
}
async function spFlush() {
  try {
    await chrome.storage.session.set({ [SP_SCANS_KEY]: spScans });
  } catch (e) {
    // Over the session quota: keep the newest 300 hits per scan in storage (all stay in memory).
    console.warn('[KWS SP] scan state write failed, trimming', e && e.message);
    const slim = {};
    for (const [id, en] of Object.entries(spScans)) {
      let left = 300;
      const groups = [];
      for (const g of [...(en.groups || [])].reverse()) {
        if (left <= 0) break;
        const msgs = (g.messages || []).slice(-left);
        left -= msgs.length;
        groups.unshift({ ...g, messages: msgs });
      }
      slim[id] = { ...en, groups, trimmed: true };
    }
    try { await chrome.storage.session.set({ [SP_SCANS_KEY]: slim }); } catch (_) {}
  }
}

const spId = (platform, channel) => platform + ':' + channel;
const spRunning = (platform) => Object.values(spScans).filter((e) => e.platform === platform && e.status === 'running').length;

function spDaysAgo(days) {
  return kws_format(new Date(Date.now() - days * 86400000));
}

// Keyword string + dates exactly as the 1.2.4 panels built them.
// Full scan = every VOD the platform still has (Kick / Twitch / SOOP APIs, YouTube's list).
// For Twitch with Zonian in the log source, Zonian also has days whose VOD is gone; those are
// left out by starting at the oldest VOD Twitch still lists (resolved in the Twitch runner).
// "New VODs only" (the popup) starts from the last search instead.
async function spBuildParams(platform, channel, mode) {
  const d = await chrome.storage.local.get(['twitchKwsKeywordProfile', 'kwsKeyword', SP_HISTORY_KEYS[platform]]);
  const keyword = (d.twitchKwsKeywordProfile && d.twitchKwsKeywordProfile.keyword) || d.kwsKeyword || ''; // empty → engine defaults
  const hist = (d[SP_HISTORY_KEYS[platform]] || {})[channel];
  const last = hist ? (hist.lastDate || String(hist.searchedAt || hist.savedAt || '').slice(0, 10)) : '';
  const newOnly = mode === 'new' && /^\d{4}-\d{2}-\d{2}$/.test(last);
  const startDate = newOnly ? last : '2015-01-01';
  // YouTube (1.2.4): "full rescan" ignores the chat cache, "new only" skips cached VODs.
  const fresh = mode !== 'new' && !!last;
  return { keyword, startDate, endDate: kws_format(new Date()), fresh, newOnly: mode === 'new', allApi: !newOnly };
}

async function spStart({ platform, channel, mode, params, origin, keyword, rangeDays, overnight }) {
  await spEnsureLoaded();
  if (!SP_RUNNERS[platform]) return { ok: false, reason: 'unsupported' };
  const ch = kws_normalizeChannel(channel).replace(/^@/, '');
  if (!ch) return { ok: false, reason: 'empty' };
  const id = spId(platform, ch);
  const prev = spScans[id];
  if (prev && prev.status === 'running') return { ok: false, reason: 'running', id };
  const p = params || await spBuildParams(platform, ch, mode);
  // A one-off keyword for this channel only (tab menu): replaces the saved keywords for this scan
  // and is not written to the history, so the next normal "new VODs" scan is unaffected.
  const custom = typeof keyword === 'string' && keyword.trim() ? keyword.trim() : '';
  if (custom) p.keyword = custom;
  // A chosen period (scan options): the last N days only, no "new VODs" logic.
  const days = Number(rangeDays);
  if (Number.isFinite(days) && days > 0) {
    p.startDate = kws_format(new Date(Date.now() - days * 86400000));
    p.newOnly = false; p.allApi = false;
  }
  spScans[id] = {
    id, platform, channel: ch, status: 'queued', mode: mode || 'full', params: p,
    createdAt: Date.now(), done: 0, total: 0, matchedLines: 0, matchedDays: 0, failedChunks: 0,
    groups: [], keywords: [], origin: origin || null, customKeyword: custom || undefined, overnight: overnight ? true : undefined, rangeDays: Number.isFinite(days) && days > 0 ? days : undefined,
  };
  await spPersist(true);
  spPump(platform);
  return { ok: true, id };
}

function spPump(platform) {
  const max = SP_MAX_CONCURRENT[platform] || 1;
  const queued = Object.values(spScans).filter((e) => e.platform === platform && e.status === 'queued').sort((a, b) => a.createdAt - b.createdAt);
  for (const e of queued) {
    if (spRunning(platform) >= max) break;
    spRun(e);
  }
}

async function spRun(e) {
  e.status = 'running';
  e.startedAt = Date.now();
  spPersist(true);
  const alive = () => spScans[e.id] === e;
  const hooks = {
    onStart: (p) => {
      if (!alive()) return;
      e.total = p.totalDates || p.total || 0;
      e.keywords = p.keywords || [];
      if (typeof p.totalSessions === 'number') e.totalSessions = p.totalSessions;
      spPersist();
    },
    onProgress: (p) => {
      if (!alive()) return;
      e.done = p.done || 0;
      e.total = p.total || e.total;
      e.matchedLines = p.matchedLines || 0;
      e.matchedDays = p.matchedDays || 0;
      e.failedChunks = p.failedChunks || 0;
      // 1.2.5.20 Kick: subscriber-only VODs (left unchecked / filled in from KickLogz) + which source is busy
      if (e.platform === 'kick') {
        if (typeof p.subOnly === 'number') e.subOnly = p.subOnly;
        if (typeof p.kicklogzVods === 'number') e.kicklogzVods = p.kicklogzVods;
        if (typeof p.archiveVods === 'number') e.archiveVods = p.archiveVods;
        if (typeof p.kicklogzOn === 'boolean') e.kicklogzOn = p.kicklogzOn;
        if (p.net) e.net = p.net;
      }
      if (p.safeThrough !== undefined) e.safeThrough = p.safeThrough; // 1.2.5.31: how far it has searched without gaps
      if (Array.isArray(p.matchedGroups)) e.groups = p.matchedGroups;
      if (Array.isArray(p.keywords) && !e.keywords.length) e.keywords = p.keywords;
      spPersist();
    },
  };
  try {
    const r = await SP_RUNNERS[e.platform].run(e, hooks);
    if (!alive()) return;
    e.failedChunks = (r && r.failedChunks) || e.failedChunks || 0;
    e.status = e.stopRequested ? 'stopped' : 'done';
    e.finishedAt = Date.now();
    // 1.2.5.20 overnight mode: no history here — overnight_bg.js keeps the result and writes the
    // history only when the user releases the mode
    // 1.2.5.32: a scan stopped part-way is recorded as such (lastDate only as far as it really got)
    if (!e.overnight) { if (e.status === 'stopped') await spWritePartial(e); else await spSaveHistory(e); }
    // 1.2.5.20: keep a 0-hit Kick scan that skipped / couldn't fetch subscriber-only VODs, so its note stays visible
    if (!e.overnight && e.status === 'done' && !e.matchedLines && !(e.platform === 'kick' && e.subOnly)) {
      const ac = await chrome.storage.local.get(SP_AUTO_CLOSE_KEYS[e.platform]);
      if (ac[SP_AUTO_CLOSE_KEYS[e.platform]]) delete spScans[e.id];
    }
  } catch (err) {
    if (!alive()) return;
    e.status = 'error';
    e.error = (err && err.message) || String(err);
    e.finishedAt = Date.now();
    if (!e.overnight) await spMarkSearched(e).catch(() => {});
    // 1.2.5.49: a YouTube channel without a Live tab (its past streams are removed or hidden after
    // each broadcast) has nothing to search — close its tab instead of leaving an error behind
    if (e.platform === 'youtube' && /no Live tab/i.test(e.error) && !e.overnight) delete spScans[e.id];
  } finally {
    await spPersist(true);
    spPump(e.platform);
    if (e.overnight && typeof ovScanEnded === 'function') ovScanEnded(e);
  }
}

// Same history fields the 1.2.4 panels wrote when a scan finished (merged, never overwritten),
// plus lastDate so "new VODs only" works on every platform.
async function spSaveHistory(e) {
  if (e.customKeyword) return; // one-off keyword search: keep the channel's history as it was
  const key = SP_HISTORY_KEYS[e.platform];
  const d = await chrome.storage.local.get(key);
  const hist = d[key] || {};
  const now = new Date().toISOString();
  const words = (e.keywords || []).map((k) => String(k).replace(/^~/, '')).filter(Boolean);
  const entry = { keywords: words, savedAt: now, searchedAt: now, lastDate: e.params.endDate };
  if (e.platform === 'soop') entry.matchedCount = e.matchedLines;
  else { entry.matchedLines = e.matchedLines; entry.matchedDays = e.matchedDays; }
  if (e.historyPatch) Object.assign(entry, e.historyPatch);
  hist[e.channel] = Object.assign({}, hist[e.channel] || {}, entry);
  if (!entry.partial) delete hist[e.channel].partial; // a full pass: no longer "searched only part-way" (SOOP sets it when VODs failed)
  await chrome.storage.local.set({ [key]: hist });
}

// A scan that failed (e.g. the ID no longer exists) still counts as "searched just now" for an ID
// already in the history, so it is not suggested again right away; nothing else is changed.
async function spMarkSearched(e) {
  if (e.customKeyword) return;
  const key = SP_HISTORY_KEYS[e.platform];
  const d = await chrome.storage.local.get(key);
  const hist = d[key] || {};
  const k = Object.keys(hist).find((x) => x.toLowerCase() === e.channel);
  if (!k || !hist[k] || typeof hist[k] !== 'object') return;
  const now = new Date().toISOString();
  hist[k] = Object.assign({}, hist[k], { searchedAt: now, savedAt: now, lastError: String(e.error || '').slice(0, 120) });
  await chrome.storage.local.set({ [key]: hist });
}

async function spStop(id) {
  await spEnsureLoaded();
  const e = spScans[id];
  if (!e) return;
  if (e.status === 'queued') { e.status = 'stopped'; await spPersist(true); return; }
  if (e.status === 'running') {
    e.stopRequested = true;
    try { SP_RUNNERS[e.platform].stop(e); } catch (_) {}
    await spPersist(true);
  }
}

// 1.2.5.31 tab menu "save what's searched and close": a scan that is stuck or was stopped part-way.
// Stops it, records it in the history — lastDate only moves up to where the platform reports an
// unbroken searched stretch (e.safeThrough), so the next "new VODs" scan picks up there; without
// that, lastDate stays where it was (the next "new VODs" scan redoes this range) — and closes the tab.
async function spSavePartial(id) {
  await spEnsureLoaded();
  const e = spScans[id];
  if (!e) return { ok: false };
  if (e.status === 'running') { e.stopRequested = true; try { SP_RUNNERS[e.platform].stop(e); } catch (_) {} }
  const through = await spWritePartial(e);
  delete spScans[id];
  await spPersist(true);
  spPump(e.platform);
  return { ok: true, through };
}
// History for a scan that searched only part of its range. Marks the entry `partial` (the panel shows
// a "!" on it) until a scan finishes the whole range. Returns the new lastDate, if it moved.
async function spWritePartial(e) {
  let through = null;
  if (!e.customKeyword && !e.overnight) {
    const key = SP_HISTORY_KEYS[e.platform];
    const d = await chrome.storage.local.get(key);
    const hist = d[key] || {};
    const k = Object.keys(hist).find((x) => x.toLowerCase() === e.channel) || e.channel;
    const prev = hist[k] && typeof hist[k] === 'object' ? hist[k] : null;
    const now = new Date().toISOString();
    const words = (e.keywords || []).map((w) => String(w).replace(/^~/, '')).filter(Boolean);
    const entry = { savedAt: now, searchedAt: now };
    if (words.length) entry.keywords = words;
    const prevLast = prev ? String(prev.lastDate || '') : '';
    if (/^\d{4}-\d{2}-\d{2}$/.test(e.safeThrough || '') && (!prevLast || e.safeThrough > prevLast)) { entry.lastDate = e.safeThrough; through = e.safeThrough; }
    if (e.platform === 'soop') entry.matchedCount = e.matchedLines || 0;
    else { entry.matchedLines = e.matchedLines || 0; entry.matchedDays = e.matchedDays || 0; }
    if (e.historyPatch) Object.assign(entry, e.historyPatch);
    // searched to the end after all (stopped on the very last bit) → a normal, complete entry
    const complete = !!through && through >= String((e.params && e.params.endDate) || '9999');
    hist[k] = Object.assign({}, prev || {}, entry);
    if (complete) delete hist[k].partial;
    else hist[k].partial = { through: hist[k].lastDate || null, at: now };
    await chrome.storage.local.set({ [key]: hist });
  }
  return through;
}

async function spRemove(id) {
  await spEnsureLoaded();
  const e = spScans[id];
  if (!e) return;
  if (e.status === 'running') { e.stopRequested = true; try { SP_RUNNERS[e.platform].stop(e); } catch (_) {} }
  delete spScans[id];
  await spPersist(true);
  spPump(e.platform);
}

async function spClear(platform) {
  await spEnsureLoaded();
  for (const e of Object.values(spScans)) {
    if (platform && e.platform !== platform) continue;
    if (e.status === 'running') { e.stopRequested = true; try { SP_RUNNERS[e.platform].stop(e); } catch (_) {} }
    delete spScans[e.id];
  }
  await spPersist(true);
}

function spWaitTabComplete(tabId, timeoutMs = 20000) {
  return new Promise((resolve) => {
    let done = false;
    const finish = () => { if (done) return; done = true; chrome.tabs.onUpdated.removeListener(onUpd); clearTimeout(timer); resolve(); };
    const onUpd = (id, info) => { if (id === tabId && info.status === 'complete') finish(); };
    const timer = setTimeout(finish, timeoutMs);
    chrome.tabs.onUpdated.addListener(onUpd);
    chrome.tabs.get(tabId).then((t) => { if (t.status === 'complete') finish(); }).catch(finish);
  });
}

// Open a hit in the inline player on the platform's own page (the player stays a page feature).
// Uses the active tab if it is on that site, else another tab of that site in the window,
// else opens the channel page.
async function spOpenInPage({ platform, windowId, channel, payload }) {
  const patterns = SP_SITE_PATTERNS[platform];
  if (!patterns) return { ok: false };
  const winQ = typeof windowId === 'number' ? { windowId } : { currentWindow: true };
  const [active] = await chrome.tabs.query({ ...winQ, active: true });
  const matches = await chrome.tabs.query({ ...winQ, url: patterns });
  let tab = (active && matches.find((t) => t.id === active.id)) || matches[0];
  let fresh = false;
  if (!tab) {
    // No tab of that site here: open the site's main page (new tab), whose KWS opens the player.
    tab = await chrome.tabs.create({ ...(typeof windowId === 'number' ? { windowId } : {}), url: SP_MAIN_URL[platform], active: true });
    fresh = true;
  } else if (!tab.active) {
    await chrome.tabs.update(tab.id, { active: true });
  }
  await spWaitTabComplete(tab.id);
  const ask = async (tries) => {
    for (let i = 0; i < tries; i++) {
      try {
        const r = await chrome.tabs.sendMessage(tab.id, { platform, ...payload });
        if (r && r.ok) return true;
      } catch (_) {}
      await kws_sleep(400);
    }
    return false;
  };
  // The page script may still be starting right after a load: retry briefly.
  if (await ask(fresh ? 20 : 6)) return { ok: true, tabId: tab.id };
  // 1.2.5.20: a page that was open before the extension was reloaded/updated keeps a cut-off KWS
  // script that never answers — reload it (the player was going to open there anyway) and ask again.
  if (!fresh) {
    try { await chrome.tabs.reload(tab.id); } catch (_) {}
    await kws_sleep(300);
    await spWaitTabComplete(tab.id);
    if (await ask(20)) return { ok: true, tabId: tab.id, reloaded: true };
  }
  return { ok: false, tabId: tab.id };
}

// YouTube has no inline player: 1.2.4 opened the watch page 30 s before the hit in a new tab and
// saved clickedTimes["<videoId>_<seconds>"].
async function spOpenYoutube({ item, windowId }) {
  const sec = Math.max(0, Number(item.playback_offset) || 0);
  await chrome.tabs.create({ ...(typeof windowId === 'number' ? { windowId } : {}), url: 'https://www.youtube.com/watch?v=' + encodeURIComponent(item.vod_id) + '&t=' + Math.max(0, sec - 30) + 's', active: true });
  const ch = String(item.vod_channel || '').toLowerCase();
  if (ch) {
    const d = await chrome.storage.local.get('ytKwsHistory');
    const hist = d.ytKwsHistory || {};
    const cur = hist[ch] || {};
    hist[ch] = { ...cur, clickedTimes: { ...(cur.clickedTimes || {}), [item.vod_id + '_' + sec]: true } };
    await chrome.storage.local.set({ ytKwsHistory: hist });
  }
  return { ok: true };
}

// A hit → the inline player at that moment.
// CHZZK replays open on chzzk.naver.com in a new tab, a few seconds before the chat line.
async function spOpenChzzk({ item, windowId }) {
  // 1.2.5.9: the KWS player on a chzzk.naver.com tab (like Twitch / Kick / SOOP); if that page
  // script can't be reached (no permission yet), CHZZK's own page at that moment instead.
  const r = (await chzzk_hasPermission()) ? await spOpenInPage({ platform: 'chzzk', windowId, channel: item.vod_channel, payload: { type: 'KWS_SP_OPEN_VOD', item } }).catch(() => ({ ok: false })) : { ok: false };
  if (!r.ok) {
    const sec = Math.max(0, (Number(item.playback_offset) || 0) - 30);
    await chrome.tabs.create({ ...(typeof windowId === 'number' ? { windowId } : {}), url: 'https://chzzk.naver.com/video/' + encodeURIComponent(item.vod_id) + '?currentTime=' + sec, active: true });
  }
  const ch = String(item.vod_channel || '').toLowerCase();
  if (ch) {
    const d = await chrome.storage.local.get('chzzkKwsHistory');
    const hist = d.chzzkKwsHistory || {};
    const cur = hist[ch] || {};
    hist[ch] = { ...cur, clickedTimes: { ...(cur.clickedTimes || {}), [item.vod_id + '_' + item.playback_offset]: true } };
    await chrome.storage.local.set({ chzzkKwsHistory: hist });
  }
  return { ok: true };
}
function spOpenVod({ platform, item, windowId }) {
  if (platform === 'youtube') return spOpenYoutube({ item, windowId });
  if (platform === 'chzzk') return spOpenChzzk({ item, windowId });
  return spOpenInPage({ platform, windowId, channel: item && item.vod_channel, payload: { type: 'KWS_SP_OPEN_VOD', item } });
}
// "Open a VOD by URL or ID" from the panel helper.
function spOpenUrl({ platform, raw, channel, windowId }) {
  if (platform === 'chzzk') { // the KWS player on a CHZZK tab; else CHZZK's own page
    const m = /video\/(\d+)/.exec(String(raw || '')) || /^\s*(\d{4,})\s*$/.exec(String(raw || ''));
    if (!m) return Promise.resolve({ ok: false });
    return spOpenInPage({ platform, windowId, channel, payload: { type: 'KWS_SP_OPEN_URL', raw, channel } }).catch(() => ({ ok: false })).then((r) => r.ok ? r
      : chrome.tabs.create({ ...(typeof windowId === 'number' ? { windowId } : {}), url: 'https://chzzk.naver.com/video/' + m[1], active: true }).then(() => ({ ok: true })));
  }
  return spOpenInPage({ platform, windowId, channel, payload: { type: 'KWS_SP_OPEN_URL', raw, channel } });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.type !== 'string') return;
  if (!(msg.type.startsWith('KWS_SP_SCAN_') || msg.type === 'KWS_SP_OPEN_VOD' || msg.type === 'KWS_SP_OPEN_URL' || msg.type === 'KWS_SP_BADGE_SCAN' || msg.type === 'KWS_SP_EXTERNAL_SCAN' || msg.type === 'KWS_SP_PAGE_EVENT')) {
    // A worker tab's sleep: timers in a background tab are throttled (down to once a minute), the
    // service worker's are not — so the SOOP engine waits here instead of with its own setTimeout.
    if (msg.type === 'KWS_SP_TAB_GUARD') { // a download is running in this tab: don't discard it
      const id = sender && sender.tab && sender.tab.id;
      if (typeof id === 'number') chrome.tabs.update(id, { autoDiscardable: !msg.on }).catch(() => {});
      sendResponse(true); return;
    }
    if (msg.type === 'KWS_SP_SLEEP') { setTimeout(() => sendResponse(true), Math.max(0, Math.min(Number(msg.ms) || 0, 60000))); return true; }
    return;
  }
  (async () => {
    switch (msg.type) {
      case 'KWS_SP_SCAN_START': return spStart({ ...msg, origin: typeof msg.windowId === 'number' ? { windowId: msg.windowId } : null });
      case 'KWS_SP_SCAN_STOP': return spStop(msg.id);
      case 'KWS_SP_SCAN_REMOVE': return spRemove(msg.id);
      case 'KWS_SP_SCAN_SAVE_PARTIAL': return spSavePartial(msg.id);
      case 'KWS_SP_SCAN_CLEAR': return spClear(msg.platform);
      case 'KWS_SP_OPEN_VOD': return spOpenVod(msg);
      case 'KWS_SP_OPEN_URL': return spOpenUrl(msg);
      case 'KWS_SP_PAGE_EVENT': return spPageEvent(msg);
      case 'KWS_SP_EXTERNAL_SCAN': {
        // A KWS badge on another site (streamrecorder.io, TwitchTracker, SOOP ranking): open the
        // side panel and let it ask "new VODs only / everything" and start — no page change.
        const winId = sender && sender.tab ? sender.tab.windowId : undefined;
        if (typeof winId === 'number') { chrome.sidePanel.open({ windowId: winId }).catch(() => {}); if (typeof kwsSpHeal === 'function') kwsSpHeal(2500); } // still inside the click
        if (!SP_RUNNERS[msg.platform]) return { ok: false, reason: 'unsupported' };
        await chrome.storage.session.set({ kwsSpAsk: { platform: msg.platform, channel: String(msg.channel || '').replace(/^@/, '').toLowerCase(), windowId: winId, at: Date.now() } });
        return { ok: true };
      }
      case 'KWS_SP_BADGE_SCAN': {
        // From a site badge / ?kws_autoscan=1 on the page: start in the hub and show the panel.
        if (msg.openPanel && sender && sender.tab) {
          chrome.sidePanel.open({ windowId: sender.tab.windowId }).catch(() => {}); if (typeof kwsSpHeal === 'function') kwsSpHeal(2500);
        }
        return spStart({ platform: msg.platform, channel: msg.channel, mode: msg.mode, origin: sender && sender.tab ? { tabId: sender.tab.id, windowId: sender.tab.windowId } : null });
      }
    }
  })().then((r) => sendResponse(r || { ok: true }), (err) => sendResponse({ ok: false, error: String(err && err.message || err) }));
  return true;
});
