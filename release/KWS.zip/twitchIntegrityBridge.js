// ══════════════════════════════════════════════════════════════════════
//  KWS — Twitch Client-Integrity 토큰 브릿지 (ISOLATED world)
//  MAIN world(twitchIntegrityMain.js)가 window.postMessage로 보낸 캡처된
//  토큰 번들을 받아서 background.js로 릴레이한다.
//
//  (VOD 채팅 조회 자체는 더 이상 이 브릿지를 거치지 않음 — background.js가
//  chrome.scripting.executeScript({world:'MAIN', ...})로 twitchIntegrityMain.js의
//  window.__kwsFetchVodComments를 직접 호출하는 방식으로 바뀜. content-script
//  메시지 리스너(chrome.tabs.sendMessage)에 의존하던 이전 방식은 "Could not
//  establish connection. Receiving end does not exist" 오류로 매번 실패했음.)
// ══════════════════════════════════════════════════════════════════════
window.addEventListener('message', (event) => {
  if (event.source !== window) return;
  const data = event.data;
  if (!data || data.__kws !== true || data.type !== 'KWS_INTEGRITY_CAPTURED') return;
  try {
    chrome.runtime.sendMessage({ type: 'KWS_INTEGRITY_TOKEN', bundle: data.bundle }).catch(() => {});
  } catch (e) {}
});
