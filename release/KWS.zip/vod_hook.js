// vod_hook.js — vod.sooplive.com에 document_start MAIN world로 주입
// URL에 soop_cap 파라미터가 있을 때만 활성화

(function() {
  const params = new URLSearchParams(location.search);
  const captureId = params.get('soop_cap');
  if (!captureId) return;

  const startSec   = parseFloat(params.get('soop_start') || '0');
  const endSec     = parseFloat(params.get('soop_end')   || '0');
  const captureSpeed = parseFloat(params.get('soop_speed') || '4');

  // ── MediaSource 후킹 (document_start이므로 플레이어보다 먼저 실행) ──
  const OrigMS = window.MediaSource;
  function HookedMS() { return Reflect.construct(OrigMS, arguments, HookedMS); }
  HookedMS.prototype = Object.create(OrigMS.prototype);
  HookedMS.prototype.constructor = HookedMS;
  HookedMS.isTypeSupported = OrigMS.isTypeSupported.bind(OrigMS);

  HookedMS.prototype.addSourceBuffer = function(mimeType) {
    const sb = OrigMS.prototype.addSourceBuffer.call(this, mimeType);
    const origAppend = sb.appendBuffer.bind(sb);
    sb.appendBuffer = function(data) {
      try {
        const arr = data instanceof ArrayBuffer
          ? new Uint8Array(data)
          : new Uint8Array(data.buffer || data);
        const CHUNK = 256 * 1024;
        const vid = document.querySelector('video');
        const ct = vid ? vid.currentTime : 0;
        for (let off = 0; off < arr.byteLength; off += CHUNK) {
          const sl = arr.subarray(off, Math.min(off + CHUNK, arr.byteLength));
          let bin = '';
          for (let i = 0; i < sl.byteLength; i++) bin += String.fromCharCode(sl[i]);
          chrome.runtime.sendMessage({
            type: 'MS_CHUNK', captureId,
            data: btoa(bin),
            currentTime: ct
          }).catch(() => {});
        }
      } catch(e) {}
      return origAppend(data);
    };
    return sb;
  };

  Object.defineProperty(window, 'MediaSource', {
    value: HookedMS, writable: true, configurable: true
  });

  // ── 플레이어 준비되면 seek + 배속 재생 ──
  let played = false;
  function tryPlay(attempts) {
    if (played || attempts > 80) return;
    const video = document.querySelector('video');
    if (!video || video.readyState < 2) {
      setTimeout(() => tryPlay(attempts + 1), 500);
      return;
    }
    played = true;
    video.currentTime = startSec;
    video.playbackRate = captureSpeed;
    video.muted = true;
    video.play().catch(() => {});

    // seeked 후 다시 배속 설정
    video.addEventListener('seeked', function onSeeked() {
      video.removeEventListener('seeked', onSeeked);
      video.playbackRate = captureSpeed;
      video.play().catch(() => {});
    }, { once: true });

    // endSec 도달 시 종료
    video.addEventListener('timeupdate', function onTime() {
      if (video.currentTime >= endSec) {
        video.pause();
        video.removeEventListener('timeupdate', onTime);
        chrome.runtime.sendMessage({ type: 'MS_ENDED', captureId }).catch(() => {});
      }
    });
  }

  // vodCore 로드 대기 후 재생
  const waitVodCore = setInterval(() => {
    if (typeof window.vodCore !== 'undefined') {
      clearInterval(waitVodCore);
      setTimeout(() => tryPlay(0), 1500);
    }
  }, 300);

  // 최대 30초 대기
  setTimeout(() => {
    clearInterval(waitVodCore);
    tryPlay(0);
  }, 30000);
})();
