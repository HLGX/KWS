// vod_corewatch.js — vod.sooplive.com/player/*에 document_start, MAIN world로 항상 주입.
//
// 목적: soopSearcher.js의 gap-recovery(긴 VOD/파일 목록 결손 감지 시 탭을 열어 정확한
// vodCore.fileItems를 얻어오는 경로)가, background.js에서 executeScript를 반복 호출해서
// "다 됐나?" 폴링하는 대신, 페이지 스스로 vodCore가 채워지는 그 순간 바로 알려주게 함.
//
// - document_start라서 페이지의 다른 스크립트보다 먼저 실행되고, 그때부터 100ms 간격으로
//   window.vodCore.fileItems를 감시함 (executeScript 왕복 없이 같은 페이지 컨텍스트 안에서
//   도니까 폴링 자체가 훨씬 촘촘하고 즉각적임).
// - 채워지는 즉시 background로 한 번만 메시지를 보내고 끝남 — 다른 기능(예: vod_hook.js의
//   캡처/다운로드 기능)과는 무관하게 항상 동작.
// - background.js는 이 메시지를 못 받는 경우(확장 업데이트 타이밍, 권한 이슈 등)에 대비해
//   기존 executeScript 폴링도 백업으로 계속 돌림 — 이 스크립트는 "더 빠른 지름길"일 뿐,
//   없어도 동작 자체는 되게 되어있음.
(function() {
  let sent = false;
  let timer = null;

  function trySend() {
    if (sent) return;
    try {
      const vc = window.vodCore;
      if (vc && Array.isArray(vc.fileItems) && vc.fileItems.length) {
        sent = true;
        if (timer) clearInterval(timer);
        const fileItems = vc.fileItems.map((f, i) => ({
          file_info_key: f.fileInfoKey || '',
          duration: Math.floor(f.duration || 0),
          file_order: f.fileOrder || (i + 1),
          url: f.url || ''
        }));
        chrome.runtime.sendMessage({ type: 'VOD_CORE_READY', fileItems }).catch(() => {});
      }
    } catch (e) {}
  }

  timer = setInterval(trySend, 100);
  setTimeout(() => { if (timer) clearInterval(timer); }, 30000);
  trySend();
})();
