const cn = (o,s)=>o ? o.getElementsByClassName(s) : null;
const tn = (o,s)=>o ? o.getElementsByTagName(s) : null;
const gi = (o,s)=>o ? o.getElementById(s) : null;
const ele = (t)=> document.createElement(t||'div');
const attr = (o,k,v)=>o ? o.setAttribute(k, v) : false;
const a = (l,r)=>r.forEach(i=>attr(l, i[0], i[1]));
const btoaJSON = (s) => btoa(encodeURIComponent(JSON.stringify(s)));
const atobJSON = (s) => JSON.parse(decodeURIComponent(atob(s)));

function inlineStyler(elm, css) {
    if (elm) {
        Object.entries(JSON.parse(css.replace(/(?<=:)\s*(\b|\B)(?=.+?;)/g, '"').replace(/(?<=:\s*.+?);/g, '",').replace(/[a-zA-Z-]+(?=:)/g, k=>k.replace(/^\b/, '"').replace(/\b$/, '"')).replace(/\s*,\s*}/g, '}'))).forEach(kv=>{
            elm.style.setProperty([kv[0]], kv[1], 'important')
        }
        );
    }
}
var _zIndexCounter = 100000;
function topZIndexer() {
    _zIndexCounter += 1;
    return _zIndexCounter;
}

function topIndexHover() {
    this.style.zIndex = topZIndexer();
}

function appender(params){
    var {cont,parent_elm,attach_method,ref_elm}=params;
    if(parent_elm){
        try{
            if(attach_method) parent_elm[attach_method](cont,(ref_elm))
            else parent_elm.appendChild(cont)
        }catch(err){
            parent_elm.appendChild(cont)
            // console.log(err);
            // console.log(`appended to parent elm instead`);
        }
    }else{
        document.body.appendChild(cont);
    }
}

function addBuffer(params){
    var {parent_elm, height, width} = params;
    let buffer = ele('div');
    parent_elm.appendChild(buffer);
    inlineStyler(buffer,`{${height ? 'height:'+height+'px; ' : ''}${width ? 'width:'+width+'px; ' : ''}}`)
}

function gridCol(arr,gap){return `display:grid; grid-template-columns: ${arr.reduce((a,b)=> a+' '+b)};${gap ? 'grid-gap:'+gap+'px;' : ''}`};



function dragElement() {
    var move_id = this.getAttribute('data-move_id');
    var el = move_id ? document.getElementById(move_id) : this.parentElement.parentElement;
    var pos1 = 0
      , pos2 = 0
      , pos3 = 0
      , pos4 = 0;
    if (document.getElementById(this.id))
        document.getElementById(this.id).onmousedown = dragMouseDown;
    else
        this.onmousedown = dragMouseDown;
    function dragMouseDown(e) {
        // 창 이동 드래그 중 페이지가 파랗게 선택되는 것 방지 (리사이즈와 동일)
        if (!e.target.closest || !e.target.closest('input,textarea,select,button')) e.preventDefault();
        _kwsMoveSelPrev = document.documentElement.style.userSelect;
        document.documentElement.style.userSelect = 'none';
        pos3 = e.clientX;
        pos4 = e.clientY;
        el.style.zIndex = topZIndexer();
        document.onmouseup = closeDragElement;
        document.onmousemove = elementDrag;
    }
    function elementDrag(e) {
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;
        el.style.top = (el.offsetTop - pos2) + "px";
        el.style.left = (el.offsetLeft - pos1) + "px";
        el.style.zIndex = topZIndexer();
    }
    function closeDragElement() {
        document.onmouseup = null;
        document.onmousemove = null;
        document.documentElement.style.userSelect = _kwsMoveSelPrev || '';
        el.style.zIndex = topZIndexer();
        if(el.id){
            let rect = el.getBoundingClientRect()
            requestFromBackground({
                cmd:'setLocalStorage',
                params:{
                    key:el.id,
                    data: rect.bottom < window.innerHeight && rect.left < (window.innerWidth-50) ? rect : {...rect,...{top:5,left:5}}
                }
            })
        }
    }
}


var _kwsResizeSelPrev = '';
var _kwsMoveSelPrev = '';
function adjustElementSize(){
    var parent_dimensions = this.getAttribute('data-parent_dimensions') ? atobJSON(this.getAttribute('data-parent_dimensions')) : null;
    var resize_elm_ids = this.getAttribute('data-resize-id').split(/,/);
    var cbod = document.getElementById(resize_elm_ids[0]);
    var tbod = document.getElementById(resize_elm_ids[1]);

    var vid_elm = tbod?.getElementsByClassName('pop_out_video')?.[0];
    // let tbod_css = atobJSON(tbod.getAttribute('data-css'))
    let tbod_css = tbod.getBoundingClientRect();
    let header_pxs = cbod?.firstChild.style.gridTemplateColumns.split(/\s/).map(r=> /[\d\.]+/.exec(r)?.[0]).filter(r=> r).map(r=> parseFloat(r));
    let min_width = header_pxs?.length ? header_pxs.reduce((a,b)=> a+b)+60 : 120;
    var foot_height = 0;
    var pos1 = 0,    pos2 = 0,    pos3 = 0,    pos4 = 0;
    var width = cbod.getBoundingClientRect().width;
    var height = cbod.getBoundingClientRect().height;

    if (document.getElementById(this.id)) document.getElementById(this.id).onmousedown = dragMouseDown;
    else this.onmousedown = dragMouseDown;
    function dragMouseDown(e) {
        // 리사이즈 드래그 중 페이지 글자/요소가 파랗게 선택되는 것 방지
        e.preventDefault();
        _kwsResizeSelPrev = document.documentElement.style.userSelect;
        document.documentElement.style.userSelect = 'none';
        pos3 = e.clientX;
        pos4 = e.clientY;
        document.onmouseup = closeDragElement;
        document.onmousemove = elementDrag;
    }
    function elementDrag(e) {
        let moved_width = (width - (pos3 - e.clientX))
        let main_width = moved_width < min_width ? min_width : moved_width;
        let main_height = ((height - (pos4 - e.clientY)) - (foot_height));
        // tvd_video_viewer(Twitch)/soop-inline-vod-player(SOOP)는 비율 유지: 너비 기준으로 높이 강제 계산
        const isVodViewer = resize_elm_ids?.[0] === 'tvd_video_viewer' || resize_elm_ids?.[0] === 'soop-inline-vod-player';
        if (isVodViewer) {
            const v = tbod?.querySelector('video.pop_out_video');
            const ratio = (v?.videoWidth && v?.videoHeight) ? v.videoHeight / v.videoWidth : 9/16;
            const bodyW = main_width - ((parent_dimensions?.left_panel_width || 0) + (parent_dimensions?.right_panel_width || 0));
            const bodyH = Math.round(bodyW * ratio);
            main_height = bodyH + ((parent_dimensions?.header_height || 0) + (parent_dimensions?.footer_height || 0));
            inlineStyler(cbod,`{width: ${main_width}px; height: ${main_height}px; z-index: ${topZIndexer()};}`);
            if(tbod){ inlineStyler(tbod,`{width: ${bodyW}px; height: ${bodyH}px; opacity: 0.98;}`); }
            return;
        }
        inlineStyler(cbod,`{width: ${main_width}px;${ moved_width < min_width ? '' : ' height: '+main_height+'px; '}z-index: ${topZIndexer()};}`);
        if(tbod){
            inlineStyler(tbod,`{
                width: ${((main_width-((parent_dimensions?.left_panel_width || 0) + (parent_dimensions?.right_panel_width || 0))))}px;
                height: ${(main_height-((parent_dimensions?.header_height || 0)+(parent_dimensions?.footer_height || 0)))}px;
                opacity: 0.98; transiation: opacity 100ms;}`);
            // if(vid_elm){
            //   inlineStyler(vid_elm,`{
            //     width: ${((main_width-((parent_dimensions?.left_panel_width || 0) + (parent_dimensions?.right_panel_width || 0))))}px;
            //     height: ${(main_height-((parent_dimensions?.header_height || 0)+(parent_dimensions?.footer_height || 0)))-10}px;
            //     opacity: 0.98; transiation: opacity 100ms;}`);
            // }
        }
        // if(resize_elm_ids?.[0] == 'tvd_video_viewer' && vid_elm){
        //   let controls_cont = cbod.getElementsByClassName('custom_video_controls_cont')?.[0];
        //   let controls_rect = controls_cont.getBoundingClientRect();
        //   let vid_rect = vid_elm.getBoundingClientRect();
        //   // let tx = vid_rect.bottom > controls_rect.top ? `-${(controls_rect.top-vid_rect.bottom)}px` : '-100%'
        //   let tx = `-${(controls_rect.top - vid_rect.bottom)}px`;
        //   console.log(`{transform:translate(0px,${tx});}`)
        //   inlineStyler(controls_cont, `{transform:translate(0px,${tx});}`);
        // }
    }
    function closeDragElement() {
        document.onmouseup = null;
        document.onmousemove = null;
        document.documentElement.style.userSelect = _kwsResizeSelPrev || '';
        if(tbod) tbod.style.opacity = '1';
    }
}




// function isValidDateFormatWarning(elm){
//     elm.addEventListener('keyup',validateDateTimeFormat)

// }

function warnMissingInput(elm){
    elm.addEventListener('keydown',()=> {
        if(elm.value?.trim()?.length){
            elm.classList.remove("input-error");
            elm.setCustomValidity("");
        }
    });
    if(!elm.value?.trim()){
        elm.classList.add("input-error");
        elm.setCustomValidity('Required For Requested Action');
        elm.reportValidity();
    }
}
function validateDateTimeFormat(elm){ //returns timestamp or false
    var val = elm.value.trim();
    if(val?.length){
        var date = normalizeDateTimeInput(val);
        // console.log('isValidDateFormatWarning,normalizeDateTimeInput',date);
        let no_time = /00:00:00/.test(date.toString())
        if(!date){
            // set warning, invalid date
            elm.classList.add("input-error");
            elm.setCustomValidity('please enter a valid date and time');
            elm.reportValidity();
            return false;
        }
        if(date && no_time){
            elm.classList.add("input-error");
            elm.setCustomValidity(`add the time, example: ${dateString(date)} 09:23 PM`);
            elm.reportValidity();
            return false;
        }
        if(date && !no_time){
            elm.classList.remove("input-error");
            elm.setCustomValidity("");
            return date.getTime();
        }
    }else{
        elm.classList.remove("input-error");
        elm.setCustomValidity("");
    }
    return false;
}



function setCSS(style_id,css_text){
    if(gi(document,`${style_id}_style`)) gi(document,`${style_id}_style`).remove();
    let csselm = ele('style');
    a(csselm,[['class',`${style_id}_style`]]);
    document.head.appendChild(csselm);
    csselm.innerHTML = css_text;
}



async function keepContInBoundary(params){
    var {cont}=params;
    if(params?.delay){
      await delay(params?.delay);
    }
    var rect = cont.getBoundingClientRect();
    let wh = window.innerHeight;
    let ww = window.innerWidth;
    if(rect.height >= wh){
      inlineStyler(cont,`{top:0px;}`);
    }
    if((rect?.top + rect.height) >= wh){
        inlineStyler(cont,`{top:${wh-rect.height}px;}`);
    }
    if((rect.left+rect.width) > ww){
        let dif = ww - rect.width;
        inlineStyler(cont,`{left:${dif-10}px;}`);
    }
}

function addBtnWithHoverTitle(params){
    var {parent_elm,btn_text,btn_svg,hover_text,copy_text,btn_width} = params;
    let btn_cont = ele();
    parent_elm.appendChild(btn_cont)
    inlineStyler(btn_cont,`{${gridCol([btn_width,'0px'],0)} cursor:pointer; margin:auto;}`);
    // if(r?.source){
    a(btn_cont,[['class','show_title_simple_ref']]);
    if(btn_svg?.length && svgs()[btn_svg] && btn_cont){
        try{
          // console.log('btn_svg',btn_svg);
          btn_cont.innerHTML = svgs()[btn_svg];
        } catch(err){
          // console.log('svgs','btn_svg');
        }
    }
    if(btn_text){ btn_cont.innerHTML = `<div">${btn_text}</div>`; }
    // if(btn_text){ btn_cont.innerHTML = `<div style="color:${main_app_colors()?.text};">${btn_text}</div>`; }

    if(copy_text){
        btn_cont.addEventListener('click',()=>{
            domplate(copy_text);
        });
    }
    let title_pop_cont = ele();
    a(title_pop_cont,[['class','show_title_simple_elm']]);
    btn_cont.appendChild(title_pop_cont);

        let title_simple_text = ele();
        a(title_simple_text,[['class','title_simple_text']]);
        title_pop_cont.appendChild(title_simple_text);
        title_simple_text.textContent = hover_text || '';

        let title_simple_pointer = ele();
        a(title_simple_pointer,[['class','title_simple_pointer']]);
        title_pop_cont.appendChild(title_simple_pointer);
        return btn_cont;
}


function setMainBtnZIndexOnTheaterModeState() {
  var main_btn_cont = document.getElementById('init_tvd_program_btn');
  if (!main_btn_cont) return;
  if (document.querySelector('[data-a-player-state="theatre"]')) {
    main_btn_cont.style.zIndex = 0;
  } else {
    main_btn_cont.style.zIndex = 199999;
  }
}
function removeMainBtnZindex(e) {
  if (['Escape', 'Alt'].some(k => e.key == k)) {
    setMainBtnZIndexOnTheaterModeState()
  }
}

async function resetMainBtnIndexForTheatreMode() {
  await delay(511);
  let btn = document.querySelector(`[aria-label*="Theatre Mode"]`);
  if(btn){
    btn.addEventListener('click', async ()=>{
      // Theatre Mode (alt+t),Exit Theatre Mode (alt+t)
      await delay(500);
      setMainBtnZIndexOnTheaterModeState();
    })
  }
}


// function refitVideoCont(params){
//     var {cont} =params;
//     var min_ratio = 0.573;
//     var rect = cont.firstChild.getBoundingClientRect();
//     var exceeding = rect.bottom > window.innerHeight;
//     if(exceeding){
//         cont.style.width = `${rect.width-100}px`;
//     }
// }
// function refitVideoCont(params){
//     var {cont} =params;
//     var min_ratio = 0.573;
//     var rect = cont.getBoundingClientRect();
//     var cont_ratio = rect.height/rect.width;
//     console.log('refitVideoCont',{min_ratio,cont_ratio})
//     if(cont_ratio < min_ratio){
//       console.log('no fit',{min_ratio,cont_ratio})
//         cont.style.width = `${(rect.width * (1-(min_ratio-cont_ratio)))}px`;
//     }
// }
// function updatePlayerFromUI(){
//     let bar = gi(document,'vid_control_bar_cont');
//     let ball = gi(document,'vid_control_bar_ball');
//     let bar_rect = bar.getBoundingClientRect();
//     let ball_rect = ball.getBoundingClientRect();
//     let offset_allowance = (ball_rect.width/2);
//     let ball_offset = offset_allowance + ball.offsetLeft;
//     let percent = ball_offset/bar_rect.width;
//     let updated_position = (hls_video_fragment_information?.current_max_segment_avail) * percent;

//     console.log({updated_position,percent})
// }

// function dragBall(){
//     let bar = gi(document,'vid_control_bar_cont');
//     let ball = gi(document,'vid_control_bar_ball');
//     let bar_rect = bar.getBoundingClientRect();
//     let ball_rect = ball.getBoundingClientRect();
//     let offset_allowance = ball_rect.width/2;
//     var pos1 = 0, pos2 = 0;
//     ball.onmousedown = dragMouseDown;
//     function dragMouseDown(e) {
//         pos2 = e.clientX;
//         document.onmouseup = closeDragElement;
//         document.onmousemove = elementDrag;
//     }
//     function elementDrag(e) {
//         pos1 = pos2 - e.clientX;
//         pos2 = e.clientX;
//                 let left_pos = (ball.offsetLeft - pos1);
//         let left_in_boundary = (left_pos+(offset_allowance)) >= 0;
//         let right_in_boundary = (left_pos+(offset_allowance)) <= (bar_rect.width+1);
//         if(left_in_boundary && right_in_boundary){
//         ball.style.left = (left_pos) + "px";
//         ball.style.opacity = "0.48";
//         }
//     }
//     function closeDragElement() {
//         updatePlayerFromUI();
//         document.onmouseup = null;
//         document.onmousemove = null;
//         ball.style.opacity = "1";
//     }
// }

// function buildVideoProgressBar(params){
//     var {parent_elm,cont_height,total_segments,current_max_segment_avail,ball_width,ball_height} = params;

//     var bar_translate_y = ((ball_height)/2);
//     var ball_translate_x = (ball_width/2);

//     var bar_cont = ele();
//     a(bar_cont,[['class','vid_control_bar_cont'],['id','vid_control_bar_cont'],['data-move_id','vid_control_bar_ball']]);
//     parent_elm.appendChild(bar_cont);
//     inlineStyler(bar_cont,`{height:${cont_height || 20}px; position:relative; top:${ball_translate_x}px; left:${bar_translate_y}px;}`);
//     //  transform:translate(${ball_translate_x}px,${bar_translate_y}px);
//     //bar_cont.addEventListener('mouseover',dragBall);

//     var ball_cont = ele();
//     bar_cont.appendChild(ball_cont);
//     inlineStyler(ball_cont,`{position:relative; left:-${ball_translate_x}px; top:-${(bar_translate_y-(cont_height/2))}px; width:${ball_width}px;height:${ball_height}px;}`);
//     //transform:translate(-${ball_translate_x}px,-${(bar_translate_y-(cont_height/2))}px);
//     a(ball_cont,[['class','vid_control_bar_ball'],['id','vid_control_bar_ball']]);
//     ball_cont.addEventListener('mouseover',dragBall);

// }

// var hls_video_fragment_information = {
//     total_segments:2080,
//     current_max_segment_avail:676,
// };
// buildVideoProgressBar({
//     parent_elm:document.body,
//     cont_height:5,
//     total_segments:2080,
//     current_max_segment_avail:676,
//     ball_width:30,
//     ball_height:30,
// })
