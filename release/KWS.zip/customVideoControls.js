
async function addCustomVideoControls(params){
	var {data_ref,seeker_adjustment,video} = params;
	if(document.getElementById('custom_video_controls_cont')){document.getElementById('custom_video_controls_cont').remove()}
  let cont = ele();
  a(cont, [['id', 'custom_video_controls_cont'],['class','custom_video_controls_cont']]);
	appender({...{cont:cont},...params});

  // let top_control = ele();
  let info_cont = ele();
  cont.appendChild(info_cont);
  // a(info_cont, [['class', 'custom_controls_info_cont']]);
  inlineStyler(info_cont, `{display:flex; flex-wrap:wrap;}`);

    let left_control = ele();
    info_cont.appendChild(left_control);
    inlineStyler(left_control, `{display:grid; grid-template-columns: 20px 20px 20px 150px; grid-gap:4px; place-items: center start;}`);

    let right_control = ele();
    info_cont.appendChild(right_control);
    inlineStyler(right_control, `{margin:auto; display:flex; flex-wrap:wrap; gap:4px; place-items: end center;}`);

      let play_pause = ele();
      left_control.appendChild(play_pause);
      play_pause.innerHTML = svgs()?.controls_pause;

      let backward = ele();
      a(backward, [['id', 'seek_backward']]);
      left_control.appendChild(backward);
      backward.innerHTML = svgs()?.backward.replace(/\d+(?=<\/text>)/,seeker_adjustment);
      inlineStyler(backward,`{cursor:pointer;}`);

      let forward = ele();
      left_control.appendChild(forward);
      a(forward, [['id', 'seek_forward']]);
      forward.innerHTML = svgs()?.forward.replace(/\d+(?=<\/text>)/,seeker_adjustment);
      inlineStyler(forward,`{cursor:pointer;}`);

      let current_seek = ele();
      left_control.appendChild(current_seek);
      inlineStyler(current_seek,`{width:fit-content; text-align:left; color:${main_app_colors()?.menu_bg};}`);

      let speed_cont = ele();
      a(speed_cont, [['class', 'speed_cont']]);
      right_control.appendChild(speed_cont);
      inlineStyler(speed_cont, `{color:${main_app_colors()?.menu_bg}; display:flex; gap:3px; align-items:center;}`);

        let speed_step_btns = [1,2,3,4].map(n => {
          let b = ele('button');
          a(b, [['type','button'],['data-speed', String(n)],['class','kws-vod-pill kws-vod-speed-pill' + (n===1 ? ' checked' : '')]]);
          b.textContent = n + 'x';
          speed_cont.appendChild(b);
          return b;
        });

        let volume_cont = ele();
        a(volume_cont, [['class', 'volume_cont']]);
        inlineStyler(volume_cont,`{display:grid; grid-template-columns: 20px 120px; grid-gap:4px; place-items: center;}`);
        right_control.appendChild(volume_cont);

          let volume_btn = ele();
          inlineStyler(volume_btn, `{cursor:pointer;transform:translate(3px,3px);}`);
          volume_cont.appendChild(volume_btn);
          volume_btn.innerHTML = svgs()?.volume || '';

          let volume_bar = ele('input');
          a(volume_bar, [['type','range'],['min','0'],['max','100'],['class', 'volume_bar']]);
          volume_cont.appendChild(volume_bar);

          let tvd_settings_volume = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'tvd_settings_volume' } });
          volume_bar.value = (tvd_settings_volume) || 100;

      // let full_screen = ele();
      // right_control.appendChild(full_screen);

      // let three_dot = ele();
      // right_control.appendChild(three_dot);


  let control_cont = ele();
  cont.appendChild(control_cont);
  inlineStyler(control_cont,`{background:transparent; }`);
  // display:grid; grid-template-columns:20px 20px 1fr 20px 20px; grid-gap:0px;

	let seeker_cont = ele();
  control_cont.appendChild(seeker_cont);

  let seeker_input = ele('input');
  a(seeker_input,[['id','seeker_video_input'],['type','range'],['min',(data_ref?.min||0)],['max',(data_ref?.max)],['value',data_ref.current_time]]);
  inlineStyler(seeker_input,`{width:100%;}`);
  seeker_cont.appendChild(seeker_input);


	current_seek.textContent = parseTimeOffset(data_ref.current_time) || '';
	updateSeekerDisplay({data_ref,seeker_input,current_seek})




  let seeker_params = {
  	...{seeker_input,current_seek},
    ...{
      data_ref:{
        ...data_ref,
        ...{current_time:seeker_input.value}
      }
		}
	};
  video.addEventListener('click', () => {
    if (video._kwsSuppressNextClick) { video._kwsSuppressNextClick = false; return; }
    switchPlayPause({ actor: play_pause, video: video });
  });
  play_pause.addEventListener('click', () => {
    switchPlayPause({ actor: play_pause, video: video });
  });
	seeker_input.addEventListener('input',()=>{
	    video.currentTime = parseInt(seeker_input.value);
      updateSeekerDisplay({
      ...{seeker_input,current_seek},
      ...{
        data_ref:{
          ...data_ref,
          ...{current_time:seeker_input.value}
        }
      }
    })
  });
 //  backward.addEventListener('click',()=>	{
 //      video.currentTime = (parseInt(video.currentTime)-(seeker_adjustment));
 //    	seeker_input.value = parseInt(video.currentTime)-(seeker_adjustment);
	// });
 //  forward.addEventListener('click',()=>	{
 //    video.currentTime = (parseInt(video.currentTime)+(seeker_adjustment));
 //  	seeker_input.value = parseInt(video.currentTime)+(seeker_adjustment);
 //  });
  addSeekWithArrowKeys({ video: video });
  return {cont,forward,backward,play_pause,seeker_input,current_seek,volume_bar,volume_btn,speed_step_btns}
}

function switchPlayPause(params){
	var {actor,video} =params;
  var id = actor.getElementsByTagName('svg')?.[0]?.id;
	if(id == 'pause_svg'){
    if (video) { video.pause()}
  	actor.innerHTML = svgs()?.controls_play;
  }else{
    if (video) { video.play()}
  	actor.innerHTML = svgs()?.controls_pause;
    // actor.innerHTML = svgs()?.paws;
  }
}

function updateSeekerDisplay(params){
  var {ref_elm,data_ref,seeker_input,current_seek,seek_time,video} = params;
  // var seek_display_offset_percent = Math.round((((data_ref.current_time)/data_ref.max)*10000))/100;
  var vod_delay = 32; //setting this manually for now. can be a variable in the future.
	inlineStyler(current_seek,`{width:fit-content; color:#ffffff;}`);
  // console.log('data_ref.max,data_ref.duration', data_ref.max, data_ref.duration);
  let variable_max = data_ref.is_live === true ? Math.floor((new Date().getTime() - data_ref.stream_start_timestamp) / 1000)-vod_delay : 0;
  let max = data_ref?.is_live ? variable_max : data_ref.max;
  let max_color = data_ref?.is_live ? (data_ref.current_time >= variable_max ? '#eb4034' : '#59eb31') : '#ffffff';
	current_seek.innerHTML = `<span>${parseTimeOffset(data_ref.current_time) || ''} / </span><span style="color:${max_color};">${parseTimeOffset(max)}</span>`;
	if(data_ref?.max) {a(seeker_input,[['max',(max)]])}
}


async function addSeekWithArrowKeys(params) {
  var { video } = params;
  var arrow_key_seek_setting = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'arrow_key_seek_setting' } });
  window.addEventListener('keyup', (e)=> {
    // VOD 다운로드 팝업이 열려있으면 키보드 seek 비활성화
    if (document.getElementById('kws_clip_downloader') || document.getElementById('kws_inline_download_pop')) return;
    // 입력 필드에 포커스가 있으면 비활성화
    const tag = document.activeElement?.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') return;
    let seek = e.key == 'ArrowLeft' ? -(parseFloat(arrow_key_seek_setting || 5)) : e.key == 'ArrowRight' ? parseFloat(arrow_key_seek_setting || 5) : 0;
    if(seek){
      seekWithArrowKeys({ ...params, ...{ seek: seek } });
    }
  })
}
function seekWithArrowKeys(params){
  var { video,seek } = params;
  video.currentTime = video.currentTime + seek;
}
