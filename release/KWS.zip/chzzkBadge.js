// KWS 1.2.5.8 — CHZZK pages: a small KWS badge for the channel on screen (channel, live or replay
// page), the same states as the badges on the other sites (Search ▶ / Today / Nd ago, red after
// the "red badge" setting). Clicking it opens the side panel, which asks and scans.
// Registered by the background only once the optional CHZZK permission was granted.
(function () {
  'use strict';
  if (window.__kwsChzzkBadge) return;
  window.__kwsChzzkBadge = true;
  const HISTORY_KEY = 'chzzkKwsHistory';
  const ID = 'kws-chzzk-badge';
  let HISTORY = {};
  let redDays = 14;
  let channelId = '';
  let channelName = '';
  let lastPath = '';

  const load = async () => {
    try {
      const d = await chrome.storage.local.get([HISTORY_KEY, 'kwsSpBadgeRedDays']);
      HISTORY = d[HISTORY_KEY] || {};
      if (Number.isFinite(d.kwsSpBadgeRedDays)) redDays = d.kwsSpBadgeRedDays;
    } catch (_) {}
  };

  async function channelFromPage() {
    const seg = location.pathname.split('/').filter(Boolean);
    const hex = seg.find((x) => /^[0-9a-f]{32}$/i.test(x));
    if (hex) return { id: hex.toLowerCase(), name: '' };
    const v = /\/video\/(\d+)/.exec(location.pathname);
    if (v) {
      try {
        const r = await fetch(`https://api.chzzk.naver.com/service/v3/videos/${v[1]}`, { credentials: 'include' });
        const c = (await r.json()).content;
        if (c && c.channel && c.channel.channelId) return { id: c.channel.channelId.toLowerCase(), name: c.channel.channelName || '' };
      } catch (_) {}
    }
    return null;
  }

  function render() {
    let el = document.getElementById(ID);
    if (!channelId) { if (el) el.remove(); return; }
    if (!el) {
      el = document.createElement('button');
      el.id = ID;
      el.type = 'button';
      el.style.cssText = 'position:fixed;right:18px;bottom:18px;z-index:2147483000;display:inline-flex;align-items:center;gap:6px;padding:6px 12px;border-radius:999px;font:700 12px/1.2 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;cursor:pointer;box-shadow:0 6px 18px rgba(0,0,0,.35);backdrop-filter:blur(8px);';
      el.addEventListener('click', async (e) => {
        e.preventDefault(); e.stopPropagation();
        pending[channelId] = Date.now(); render(); injectList(true);
        try { await chrome.runtime.sendMessage({ type: 'KWS_SP_EXTERNAL_SCAN', platform: 'chzzk', channel: channelId }); } catch (_) {}
      });
      document.documentElement.appendChild(el);
    }
    const h = HISTORY[channelId];
    const live = typeof liveOf === 'function' ? liveOf(channelId) : null;
    let label = 'KWS · Search ▶', c = ['rgba(239,68,68,.16)', 'rgba(239,68,68,.45)', '#fca5a5'];
    if (h) {
      const at = h.searchedAt || h.savedAt;
      const days = at ? Math.floor((Date.now() - new Date(at).getTime()) / 86400000) : null;
      label = 'KWS · ' + (days === 0 ? 'Today ↺' : days === 1 ? 'Yesterday ↺' : days != null ? days + 'd ago ↺' : 'Searched ↺');
      c = days != null && days <= 1 ? ['rgba(34,197,94,.16)', 'rgba(34,197,94,.45)', '#86efac']
        : days != null && days > redDays ? ['rgba(239,68,68,.16)', 'rgba(239,68,68,.45)', '#fca5a5']
          : ['rgba(234,179,8,.16)', 'rgba(234,179,8,.45)', '#fde68a'];
    }
    if (live) { label = 'KWS · ' + live.text; c = live.c; }
    el.textContent = label;
    el.title = (channelName || (h && h.nickname) || channelId) + (h ? '\n' + (h.matchedLines ?? 0) + ' hits' : '') + '\nKWS — click to search in the side panel';
    el.style.background = 'rgba(10,12,16,.82)';
    el.style.border = '1px solid ' + c[1];
    el.style.color = c[2];
    el.style.boxShadow = '0 6px 18px rgba(0,0,0,.35), inset 0 0 0 999px ' + c[0];
  }

  async function check() {
    if (location.pathname === lastPath) return;
    lastPath = location.pathname;
    const ch = await channelFromPage();
    channelId = ch ? ch.id : '';
    channelName = ch ? ch.name : '';
    render();
  }

  // ── list badges: next to every channel name link on CHZZK lists (home, lives, search, …) ──
  // A channel name is a link to "/{32-hex channel ID}" with text in it (e.g.
  // <a class="_channel_…" href="/2708…"><span>러끼</span></a>); thumbnails and titles link to
  // /live/… or /video/… instead, so they are left alone. Same look as the StreamRecorder badges.
  const LIST_CLASS = 'kws-chzzk-lbadge';
  // live state of side-panel scans (kwsSpScans in session storage), like the badges on SOOP
  let SCANS = {};
  const pending = {}; // clicked just now, before the hub has the scan
  try { chrome.storage.session.get('kwsSpScans').then((d) => { SCANS = d.kwsSpScans || {}; injectList(true); render(); }).catch(() => {}); } catch (_) {}
  function liveOf(id) {
    const e = SCANS['chzzk:' + id];
    if (e && (e.status === 'running' || e.status === 'queued')) {
      if (e.status === 'queued') return { text: '⏳ Queued', c: ['rgba(6,182,212,0.12)', 'rgba(6,182,212,0.35)', '#22d3ee'], tip: 'Waiting for its turn in KWS' };
      const pct = e.total ? Math.min(100, Math.round((e.done || 0) / e.total * 100)) : 0;
      return { text: '⏳ ' + pct + '%', c: ['rgba(251,146,60,0.15)', 'rgba(251,146,60,0.35)', '#fb923c'], tip: 'Scanning in KWS…' };
    }
    if (pending[id] && Date.now() - pending[id] < 15000 && !(e && e.status)) return { text: '⏳ Queued', c: ['rgba(6,182,212,0.12)', 'rgba(6,182,212,0.35)', '#22d3ee'], tip: 'Asked KWS to scan' };
    return null;
  }
  function stateOf(id) {
    const live = liveOf(id);
    if (live) return live;
    const h = HISTORY[id];
    if (!h) return { text: 'Search ▶', c: ['rgba(239,68,68,0.12)', 'rgba(239,68,68,0.35)', '#f87171'], tip: 'Not searched with KWS yet — click to search in the side panel' };
    const at = h.searchedAt || h.savedAt;
    const days = at ? Math.floor((Date.now() - new Date(at).getTime()) / 86400000) : null;
    const text = days === 0 ? 'Today ↺' : days === 1 ? 'Yesterday ↺' : days != null ? days + 'd ago ↺' : 'Searched ↺';
    const c = days != null && days <= 1 ? ['rgba(34,197,94,0.12)', 'rgba(34,197,94,0.35)', '#4ade80']
      : days != null && days > redDays ? ['rgba(239,68,68,0.1)', 'rgba(239,68,68,0.3)', '#f87171']
        : ['rgba(234,179,8,0.12)', 'rgba(234,179,8,0.35)', '#fbbf24'];
    return { text, c, tip: (h.matchedLines ?? 0) + ' hits with KWS — click to re-scan in the side panel' };
  }
  function paintList(b, id) {
    const st = stateOf(id);
    b.textContent = st.text;
    b.title = st.tip;
    b.style.cssText = `display:inline-flex;align-items:center;flex:none;padding:1px 6px;margin-left:6px;border-radius:99px;font:700 9px/1.5 -apple-system,BlinkMacSystemFont,sans-serif;white-space:nowrap;vertical-align:middle;cursor:pointer;background:${st.c[0]};border:1px solid ${st.c[1]};color:${st.c[2]};`;
  }
  function listBadge(id) {
    const b = document.createElement('span');
    b.className = LIST_CLASS;
    b.dataset.id = id;
    paintList(b, id);
    b.addEventListener('click', async (e) => {
      e.preventDefault(); e.stopPropagation();
      pending[id] = Date.now(); injectList(true); render();
      setTimeout(() => injectList(true), 15500); // the click-only "Queued" state ends on its own
      try { await chrome.runtime.sendMessage({ type: 'KWS_SP_EXTERNAL_SCAN', platform: 'chzzk', channel: id }); } catch (_) {}
    });
    return b;
  }
  // refresh = repaint the badges in place (live scan state, history changes)
  function injectList(refresh) {
    if (refresh) document.querySelectorAll('.' + LIST_CLASS).forEach((el) => paintList(el, el.dataset.id));
    for (const a of document.querySelectorAll('a[href]')) {
      const m = /^(?:https:\/\/chzzk\.naver\.com)?\/([0-9a-f]{32})\/?$/i.exec(a.getAttribute('href') || '');
      if (!m || !a.textContent.trim() || a.closest('#' + ID)) continue;
      if (a.querySelector('img,video,picture') || /thumbnail/i.test(a.className || '')) continue; // the name link only, not the picture
      const next = a.nextElementSibling;
      if (next && next.classList.contains(LIST_CLASS)) continue;
      a.insertAdjacentElement('afterend', listBadge(m[1].toLowerCase()));
    }
  }
  let listTimer = null;
  // Throttled, not debounced: on a live page the chat changes the DOM all the time, so a debounce
  // would never fire and the badges would show up late (or not at all).
  new MutationObserver(() => { if (!listTimer) listTimer = setTimeout(() => { listTimer = null; injectList(false); }, 250); })
    .observe(document.documentElement, { childList: true, subtree: true });

  let liveTimer = null;
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'session' && changes.kwsSpScans) {
      SCANS = changes.kwsSpScans.newValue || {};
      clearTimeout(liveTimer); liveTimer = setTimeout(() => { injectList(true); render(); }, 250);
      return;
    }
    if (area !== 'local') return;
    if (changes[HISTORY_KEY]) HISTORY = changes[HISTORY_KEY].newValue || {};
    if (changes.kwsSpBadgeRedDays) redDays = changes.kwsSpBadgeRedDays.newValue || 14;
    if (changes[HISTORY_KEY] || changes.kwsSpBadgeRedDays) { render(); injectList(true); }
  });
  load().then(() => { check(); injectList(false); });
  setInterval(check, 1000); // CHZZK is a single-page app: follow its route changes
})();
