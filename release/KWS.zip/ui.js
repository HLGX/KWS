






async function addInitTVDBtn() {
  if (gi(document, "init_tvd_program_btn")) {gi(document, "init_tvd_program_btn").remove();}
  let main_btn_settings = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'tvb_btn_dimensions' } });
  main_btn_settings
  let btn_border = {
    top: main_btn_settings ? (parseFloat(main_btn_settings)/10) * 8 : 8,
    left: main_btn_settings ? (parseFloat(main_btn_settings)/10) * 10 : 10,
    right: main_btn_settings ? (parseFloat(main_btn_settings)/10) * 10 : 10,
    bottom: main_btn_settings ? (parseFloat(main_btn_settings)/10) * 8 : 8,
    size: main_btn_settings ? (((parseFloat(main_btn_settings)/10) * 28) > 8 ? (parseFloat(main_btn_settings)/10) * 28 : 8) : 28
  }
  let nav = document.getElementsByTagName("nav")?.[0];
  let search_bar = nav?.getElementsByTagName("div")?.[0] ? Array.from(nav?.getElementsByTagName("div")).filter((i) => i.getAttribute("data-a-target") == "nav-search-box",)?.[0]?.parentElement?.parentElement: null;
  let search_rect = search_bar?.firstChild ? search_bar?.firstChild.getBoundingClientRect() : {};
  var init_program_cont = buildContainer({
    ...{top: 1,left: search_rect?.left ? search_rect?.left - 50 : 50,container_id: "init_tvd_program_btn",
    close_action: () => {
      // console.log("do nothing")
    },
    },
    ...uiSettings(),
    ...{
      resizeable: false,
      header_height: (btn_border?.top),
      left_panel_width: (btn_border?.left),
      right_panel_width: (btn_border?.right),
      footer_height: (btn_border?.bottom),
    },
  });
  init_program_cont.cls_btn.firstChild.remove();
  inlineStyler(init_program_cont.menu_body, `{overflow:clip;}`);
  resetMainBtnColor();

  // inlineStyler(init_program_cont.cont, `{ box-shadow: ${main_app_colors()?.edge}18 1px 1px 1px 0px, ${main_app_colors()?.edge}50 -2px -2px 2px -1px;}`);
  // init_program_cont.cont.classList.add('bg_glower');

  // inlineStyler(init_program_cont.menu_body.parentElement.parentElement, `{background:${main_app_colors()?.bg};}`);
  a(init_program_cont.cls_btn, [["class", ""],["style", ""]]);
  // init_program_cont.foot_resizer.remove();

  let btn = ele();
  btn.innerHTML = svgs()?.clipper_logo?.replace(/svg width="[\d\.]+px" height="[\d\.]+px"/, `svg width="${btn_border?.size}px" height="${btn_border?.size}px"`);
  // <svg width="28px" height="28px"

  inlineStyler(btn, `{height:${btn_border?.size}px; width:${btn_border?.size}px; cursor:pointer;}`);
  btn.addEventListener("click", () => { initUI(init_program_cont) });
  init_program_cont.menu_body.appendChild(btn);

  Array.from(btn.getElementsByClassName("vlogo") || []).forEach((elm) => {
    a(elm, [["stroke", main_app_colors()?.icon_color],["stroke-width", "0.2"],["fill", main_app_colors()?.icon_color],]);
  });
  let saved_position = await requestFromBackground({
    cmd: "getLocalStorage",
    params: {key: "init_tvd_program_btn",},
  });
  if (saved_position?.top) {
    inlineStyler(init_program_cont.cont,`{top:${saved_position?.top < -5 ? 0 : saved_position?.top + saved_position?.height > window.innerHeight ? 0 : saved_position?.top ? saved_position?.top : 0}px; left:${saved_position?.left < -5 ? 0 : saved_position?.left + saved_position?.width > window.innerWidth ? (search_rect?.left ? search_rect?.left - 50 : 50) : saved_position?.left ? saved_position?.left : search_rect?.left ? search_rect?.left - 50 : 50}px;}`,);
  }

  resetMainBtnIndexForTheatreMode()
  // if(/twitch.tv\/\w+\/\d+/.test(window.location.href)){
  //   await delay(2444)
  //   var page_channel_login = getChannelLogin();
  //   var tokens = getTokensFromCookies();
  //   var vods = await requestFromBackground({ cmd: 'getAvailableVODinfo', params: {...tokens,...{channel_login:page_channel_login}} });
  //   var vod_btn_cont = addViewVODBtn();
  //   if(vod_btn_cont){
  //     let vod_id = /(?<=twitch.tv\/\w+\/)\d+/.exec(window.location.href)?.[0];
  //     let vod = vods.filter(r => r.vod_id == vod_id)?.[0];
  //     vod_btn_cont.addEventListener('click', async () => {
  //       runTwitchSourceBuild({ ...vod, ...{ ref_elm: vod_btn_cont?.parentElement } });
  //     });
  //   }else{
  //     console.log('vod_btn_cont doesnt exist',vod_btn_cont)
  //   }
  // }
}





/*

  BUILD MENU UI ON BTN CLICK

*/

async function initUI(params) {
  let is_kick = /kick\.com/.test(window.location.href);
  let is_twitch = /twitch\.tv/.test(window.location.href);
  var page_channel_login = getChannelLogin();
  var init_btn_rect = params.cont.getBoundingClientRect();
  var main_contaier = buildContainer({
    ...{
      top: init_btn_rect?.top || 1,
      left: init_btn_rect?.left && init_btn_rect?.width ? init_btn_rect?.left + init_btn_rect?.width : 2,
      container_id: "tvd_main_cont",
    },
    ...uiSettings()
  });
  // inlineStyler(main_contaier?.menu_body,`{background-color:${main_app_colors()?.menu_bg}; color:${main_app_colors()?.text};}`,);
  var is_auth_user = await requestFromBackground({ cmd: 'getValidToken' });
  addBuffer({parent_elm:main_contaier.menu_body, height: 8 });
  addAuthBtn({
    parent_elm: main_contaier.menu_body,
    text: !is_auth_user ? 'Login/Sign Up for Best Experience' : 'Logout',
    cmd: !is_auth_user ? 'launchAuthFlow' : 'handleLogout'
  })
  addBuffer({parent_elm:main_contaier.menu_body, height: 6 });

  let view_live_btn_cont = ele();
  a(view_live_btn_cont, [["id", "view_live_btn_cont"]]);
  main_contaier.menu_body.appendChild(view_live_btn_cont);
  addBuffer({ parent_elm: main_contaier.menu_body, height: 6 });

  let view_vod_btn_cont = ele();
  a(view_vod_btn_cont, [["id", "view_vod_btn_cont"]]);
  main_contaier.menu_body.appendChild(view_vod_btn_cont);

  let dl_clip_btn_cont = ele();
  a(dl_clip_btn_cont, [['id', 'dl_clip_btn_cont']]);
  main_contaier.menu_body.appendChild(dl_clip_btn_cont);

  var main_inputs = addInputs({
    parent_elm: main_contaier.menu_body,
    options: main_input_fields,
  });

  var tokens = getTokensFromCookies();
  var vods = await requestFromBackground({ cmd: 'getAvailableVODinfo', params: {...tokens,...{channel_login:page_channel_login}} });
  if(/twitch.tv\/videos\/\d+/.test(window.location.href)){
    let vod_id = /(?<=twitch.tv\/videos\/)\d+/.exec(window.location.href)?.[0];
    let vod = vods.filter(r => r.vod_id == vod_id)?.[0];
    let view_vod_btn = addViewVodBtn({parent_elm: view_vod_btn_cont});
    if(!vod){
      let highlight = await getCurrentVODHighlightSource();
      if(highlight){
        view_vod_btn.textContent = `Watch Highlight: ${vod_id||''}`;
        view_vod_btn.addEventListener('click', async () => {
          runTwitchSourceBuild({ ...highlight, ...{ ref_elm: view_vod_btn?.parentElement } });
        });
      } else{
        view_vod_btn_cont.remove();
      }
    }else{
      view_vod_btn.textContent = `Watch VOD ID: ${vod_id||''}`
      view_vod_btn.addEventListener('click', async () => {
        runTwitchSourceBuild({ ...vod, ...{ ref_elm: view_vod_btn?.parentElement } });
      });
    }
    // view_vod_btn.addEventListener('click', async () => {
    //   runTwitchSourceBuild({ ...vod, ...{ ref_elm: view_vod_btn?.parentElement } });
    // });
  }

  if (page_channel_login) {
    //moved to avoid blocking thread. removes view_live_btn if no channel found
    var view_live_btn = ele();
    view_live_btn_cont.appendChild(view_live_btn);
    addViewLiveBtn({
      parent_elm: view_live_btn_cont,
      elm: view_live_btn,
      query: page_channel_login,
    });
    view_live_btn.addEventListener('click', async () => {
      runTwitchLiveView({ channel_login:page_channel_login,ref_elm:view_live_btn,vods:vods })
    });
  }else{
    view_live_btn_cont.remove();
  }

  let clip_info = await getClipSlugFromHref();
  if (clip_info?.url) {
    a(dl_clip_btn_cont,[['class','gen_btn'],['id','dl_clip_btn_cont'],['data-channel_login',clip_info?.channel_login]]);
    inlineStyler(dl_clip_btn_cont,`{height:36px; pointer:cursor; border-radius:2em; text-align:center; margin:auto; cursor:pointer; width:96%; display: flex; flex-wrap:wrap; justify-content: center; align-items: center;}`);
    dl_clip_btn_cont.innerHTML = `<div style="min-width:64%; margin-right:auto;">Download ${clip_info?.channel_login} Clip</div>${svgs()?.clipper?.replace(/^<svg/,`<svg style="margin-left:auto;"`) || ''}<div style="width:8px;"></div>`;
    dl_clip_btn_cont.addEventListener('click', () => {
      window.open(clip_info?.url);
    });
  }

  main_inputs.m3u8_url.btn.addEventListener('click', async () => {
    let val = (main_inputs?.m3u8_url?.input?.value)
    let is_valid = /https:\/\/stream.kick.com\/.+?m3u8/.test(val) || /(?<=https:\/\/)(\w+?)\.cloudfront\.net\/(\w+?)_(\w+?)_(\d+?)_(\d+?)\/(\w+?)\//.exec(val)?.[0];
    if (is_valid) {
      let stream_info = getInfoFromM3u8Link({ source: val });
      getStreamInformationAndBuildUI({
        ...stream_info,
        ...{ ref_elm: main_inputs.m3u8_url.btn.parentElement },
      });
    }
  });

  if(main_inputs.stream_start){
    main_inputs.stream_start.input.addEventListener("keyup", () => {
      validateDateTimeFormat(main_inputs.stream_start.input);
    });
    [main_inputs.stream_id, main_inputs.stream_start].forEach((elm) => {
      elm.btn.addEventListener("click", () => {
        // console.log(main_inputs.stream_start.input.value)
        let normalized_date = normalizeDateTimeInput(validateRecentYearInDateString(main_inputs.stream_start.input.value));
        // console.log({ normalized_date });
        let timestamp = normalized_date !== false ? new Date(normalized_date).getTime() : null;

        let stream_id = main_inputs.stream_id.input.value?.trim();
        let channel_login =
          main_inputs.recent_streams_channel.input.value?.trim();
        if (normalized_date !== false && stream_id && channel_login) {
          // console.log({ timestamp, stream_id, channel_login });
          // console.log('getStreamInformationAndBuildUI(',{
          //   ...{ timestamp, stream_id, channel_login },
          //   ...{ ref_elm: elm.btn.parentElement, ref_ob:elm },
          // })
          getStreamInformationAndBuildUI({
            ...{ timestamp, stream_id, channel_login },
            ...{ ref_elm: elm.btn.parentElement, ref_ob:elm },
          });
        } else {
          [
            main_inputs.stream_id.input,
            main_inputs.recent_streams_channel.input,
            main_inputs.stream_start.input,
          ].forEach((elm) => warnMissingInput(elm));
          // console.log("failed");
        }
      });
    });
  }


  main_inputs.recent_streams_channel.input.value = getChannelLogin() || "";
  main_inputs.recent_streams_channel.btn.addEventListener("click", () => {
    var channel_login_input_val = main_inputs.recent_streams_channel.input.value?.trim();
    // console.log("channel_login_input_val", channel_login_input_val);
    var channel_login = getChannelLogin();
    let rect = main_contaier.cont.getBoundingClientRect();
    // let rect = main_inputs.recent_streams_channel.input.parentElement.getBoundingClientRect();
    if(channel_login_input_val || channel_login){
      runRecentStreamsExtractor({
        channel_login: channel_login_input_val || channel_login,
        rect: {
          left: rect.left,
          top: rect.top,
          width: rect?.width,
          height: rect?.height,
        },
      });
    }
  });
  main_inputs.recent_streams_channel.input.addEventListener(
    "keyup",
    async (e) => {
      let val = main_inputs.recent_streams_channel.input.value?.trim();
      // console.log(val);
      if (val.length > 1) {
        if (e.key === "Enter") {
          var channel_login_input_val = main_inputs.recent_streams_channel.input.value?.trim();
          let rect = main_contaier.cont.getBoundingClientRect();
          // let rect = main_inputs.recent_streams_channel.input.parentElement.getBoundingClientRect();
          await runRecentStreamsExtractor({
            channel_login: channel_login_input_val,
            rect: {
              left: rect.left,
              top: rect.top,
              width: rect?.width,
              height: rect?.height,
            },
          });
          gi(document, "tvd_search_dropdown").remove();
        }
        if (is_twitch) {
          var results = await searchTwitch({ query: val });
        }
        if (is_kick) {
          var results = await searchKick({ query: val });
        }
        if (results?.length) {
          buildSearchResAutoDropdown({
            id: "tvd_search_dropdown",
            results: results,
            ref_elm: main_inputs.recent_streams_channel.input,
            input_ref: main_inputs.recent_streams_channel.input,
          });
          Array.from(cn(document, "is_live_search_result") || []).forEach(
            (live) => {
              let page_channel_login = live.getAttribute("data-channel_login");
              if (page_channel_login) {
                var view_live_btn = ele();
                view_live_btn_cont.appendChild(view_live_btn);
                addViewLiveBtn({
                  parent_elm: view_live_btn_cont,
                  elm: view_live_btn,
                  query: page_channel_login,
                });

                view_live_btn.addEventListener('click', () => {
                  runTwitchLiveView({ channel_login: page_channel_login, ref_elm: view_live_btn })
                });
              }
            },
          );
        }
        if (!results?.length) {
          gi(document, "tvd_search_dropdown").remove();
        }
      }
      if (val?.length == 0 && gi(document, "tvd_search_dropdown")) {
        gi(document, "tvd_search_dropdown").remove();
      }
    },
  );
    addBuffer({parent_elm:main_contaier.menu_body, height: 8 });

  let settings_btn = addSettingsBtn({ parent_elm: main_contaier.menu_body });

  addBuffer({parent_elm:main_contaier.menu_body, height: 8 });
  addDiscordBtn({ parent_elm: main_contaier.menu_body });
  addBuffer({parent_elm:main_contaier.menu_body, height: 8 });
  addDonationBtn({ parent_elm: main_contaier.menu_body });
  // inlineStyler(tn(settings_btn, 'svg')[0], `{border-radius:50%; transform:translate(${(main_contaier.menu_body.getBoundingClientRect().width - 42)}px,0px);}`);
  settings_btn.addEventListener('click', () => {
    openSettingsMenu({ rect: settings_btn.getBoundingClientRect(), ref_elm: settings_btn });
  });
  // main_inputs.m3u8_url.addEventListener()

  addBuffer({parent_elm:main_contaier.menu_body, height: 8 });
  addVersionNumber({ parent_elm: main_contaier.menu_body, });
  keepContInBoundary(main_contaier);
  // console.log(main_contaier);
}



async function runTwitchLiveView(params){
  // runTwitchLiveView({ channel_login,ref_elm,vods })
  var { channel_login,ref_elm,vods } = params;
  var tokens = getTokensFromCookies();
  if(!vods?.length){
    var vods = await requestFromBackground({ cmd: 'getAvailableVODinfo', params: {...tokens,...{channel_login:channel_login}} });
  }
  var channel_info = await requestFromBackground({
    cmd: "getTwitchStreamInformation",
    params: { ...tokens, ...params, ...{ channel_login: channel_login } },
  });
  // console.log({getTwitchStreamInformation: channel_info });
  // console.log({['channel_info?.start_timestamp_seconds']:channel_info?.start_timestamp_seconds,vods:vods?.[0]})
  let vod = vods?.filter(r =>  (r.stream_id == channel_info?.start_timestamp_seconds) || (r.stream_start_seconds == channel_info?.start_timestamp_seconds))?.[0];
  if(vod){
    runTwitchSourceBuild({ ...vod, ...{ is_live: true,ref_elm:ref_elm?.parentElement } });
  }else{
    // console.log('runTwitchLiveView',{channel_info})
    getStreamInformationAndBuildUI({
      ...channel_info,
      ...{
        ref_elm: ref_elm.parentElement,
      },});
  }
}
async function addVODViewBypass() {
  await delay(1111);
  var page_channel_login = getChannelLogin();
  var tokens = getTokensFromCookies();
  var vods = await requestFromBackground({ cmd: 'getAvailableVODinfo', params: { ...tokens, ...{ channel_login: page_channel_login } } });
  // console.log({ vods });
  if (/twitch.tv\/videos\/\d+/.test(window.location.href)) {
    let vod_id = /(?<=twitch.tv\/videos\/)\d+/.exec(window.location.href)?.[0];
    let vod = vods.filter(r => r.vod_id == vod_id)?.[0];
    let second_vod_view_btn = await subOnlyBypass();
    if(second_vod_view_btn){
      if(!vod){
        let highlight = await getCurrentVODHighlightSource();
        // console.log(highlight);
        second_vod_view_btn.addEventListener('click', async () => {
          runTwitchSourceBuild({ ...highlight, ...{ ref_elm: second_vod_view_btn?.parentElement } });
        });
      }else{
        second_vod_view_btn.addEventListener('click', async () => {
          runTwitchSourceBuild({ ...vod, ...{ ref_elm: second_vod_view_btn?.parentElement } });
        });
      }
    }
  }
}




/*

              ADD SETTINGS MENU

*/

async function updateMainBtnParams(params){
  var { input } = params;
  await requestFromBackground({ cmd: 'setLocalStorage', params: { key: 'tvb_btn_dimensions', data: (input.value || 10) } });
  addInitTVDBtn()
}

async function openSettingsMenu(params) {
  var { ref_elm,rect } = params;
  let tvd_settings_seek_default = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'tvd_settings_seek_default' } });
  let main_btn_settings = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'tvb_btn_dimensions' } });
  let settings_cont = buildContainer({
    ...{
      top: rect.top,
      left: params?.rect?.left && params?.rect?.width ? params?.rect?.left : 2,
      container_id: "tvd_settings_cont",
    },
    ...uiSettings()
  });
  // inlineStyler(settings_cont.menu_body, `{background:#ffffff;}`);
  // inlineStyler(settings_cont?.menu_body,`{background-color:${main_app_colors()?.menu_bg}; color:${main_app_colors()?.text};}`,);

  let icon_size_label = ele();
  settings_cont.menu_body.appendChild(icon_size_label);
  inlineStyler(icon_size_label, `{display:flex; flex-wrap:wrap; gap:6px; padding:6px;}`);
  icon_size_label.textContent = `Change Button Size`;

  let icon_size_cont = ele();
  settings_cont.menu_body.appendChild(icon_size_cont);
  inlineStyler(icon_size_cont, `{display:flex; flex-wrap:wrap; justify-content:space-between; gap:6px; padding:6px;}`);

  let icon_size_adjustment = ele('input');
  icon_size_cont.appendChild(icon_size_adjustment);
  a(icon_size_adjustment, [['type','range'],['min', 5], ['max', 20],['value',main_btn_settings]]);
  // let main_btn_settings = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'tvb_btn_dimensions' } });
  icon_size_adjustment.addEventListener('input', ()=>{
    updateMainBtnParams({ input: icon_size_adjustment });
  });

  let border_mode_label = ele();
  settings_cont.menu_body.appendChild(border_mode_label);
  inlineStyler(border_mode_label, `{display:flex; flex-wrap:wrap; gap:6px; padding:6px;}`);
  border_mode_label.textContent = `Select Border Color`;

  let border_mode_cont = ele();
  settings_cont.menu_body.appendChild(border_mode_cont);
  inlineStyler(border_mode_cont, `{display:flex; flex-wrap:wrap; justify-content:space-between; gap:6px; padding:6px;}`);

  // let classes = ['bg_glower', 'bg_f0f0f0', 'bg_000000','bg_9047ff','bg_1d56d1'];
  bg_classes.forEach(c=>{
    let pill = ele();
    border_mode_cont.appendChild(pill);
    // inlineStyler(pill, `{background:#000000;}`);
      let swatch = ele();
      pill.appendChild(swatch);
      a(swatch, [['class', c.c]]);
      inlineStyler(swatch, `{border-radius:1em;height:22px;width:22px; border:1px solid #000000;}`);
      pill.addEventListener('click', () => { updateBgColor(c.c); });
  })


  let color_mode_cont = ele();
  settings_cont.menu_body.appendChild(color_mode_cont);
  inlineStyler(color_mode_cont, `{display:flex; flex-wrap:wrap; gap:6px; padding:6px;}`);

  let darkmode_input = ele('input');
  a(darkmode_input, [['type', 'checkbox'],['class','custom_checkbox']]);
  inlineStyler(darkmode_input, `{width:29px; height:29px;}`);

  let color_settings = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'main_app_colors' } });

  color_mode_cont.innerHTML = `${color_settings == 'darkmode' ? svgs()?.moon : svgs()?.sun || '<div></div>'}<div style="margin:auto; font-size:1.1em;">${color_settings == 'darkmode' ? 'Toggle Light Mode' : 'Toggle Dark Mode'}</div>`;
  color_mode_cont.appendChild(darkmode_input);

  let moon_icon_holder_rect = color_mode_cont?.firstChild?.getBoundingClientRect();
  let toggle_dark_mode_label = color_mode_cont?.firstChild?.nextSibling;

  if(color_settings == 'darkmode'){
    darkmode_input.checked = true;
  }
  darkmode_input.addEventListener('click', async () => {
    if (darkmode_input.checked) {
      color_mode = 'darkmode';
      let color_settings = await requestFromBackground({ cmd: 'setLocalStorage', params: { key: 'main_app_colors', data: 'darkmode' } });
      resetCSS(params);
      resetMainBtnColor();
    } else {
      color_mode = 'lightmode';
      let color_settings = await requestFromBackground({ cmd: 'setLocalStorage', params: { key: 'main_app_colors', data: 'lightmode' } });
      resetCSS(params);
      resetMainBtnColor();
    }
  });

  let seek_settings_cont = ele();
  inlineStyler(seek_settings_cont, `{display:flex; flex-wrap:wrap; gap:6px; padding:6px;}`);
  settings_cont.menu_body.appendChild(seek_settings_cont);

    let seek_pad_left = ele();
    inlineStyler(seek_pad_left, `{display:flex; height:${moon_icon_holder_rect?.height || 30}px; width:${moon_icon_holder_rect?.width || 30}px;}`);
    seek_settings_cont.appendChild(seek_pad_left);
    seek_pad_left.innerHTML = svgs()?.forward2;
      // let seek_pad_icon = seek_pad_left.firstChild;
      // a(seek_pad_icon, [['height', `${(moon_icon_holder_rect?.height || 30)}px`], ['width', `${(moon_icon_holder_rect?.width || 30)}px`]])
      // ['fill', 'path'].forEach(tag => {
      //   let elm = seek_pad_icon.getElementsByTagName(tag)?.[0]
      //   if (elm) {
      //     a(elm, [['fill', main_app_colors()?.contrast_icon]])
      //   }
      // });

    let seek_default_label = ele();
    inlineStyler(seek_default_label, `{margin:auto; font-size:1.1em;}`);
    seek_settings_cont.appendChild(seek_default_label);
    seek_default_label.textContent = 'Default Seek Seconds';

    let seek_default_input = ele('input');
    a(seek_default_input, [['class', 'textarea'],['maxlength','2'],['max','99'],['min','1']]);
    inlineStyler(seek_default_input, `{padding:8px; height:30px; width:30px;}`);
    seek_settings_cont.appendChild(seek_default_input);
    seek_default_input.value = tvd_settings_seek_default || 30;

  let label_widths = [toggle_dark_mode_label, seek_default_label].map(elm => elm.getBoundingClientRect().width)?.filter(w=> w);
  let min_label_width = label_widths?.length ? Math.max(...label_widths) : 100;
  [toggle_dark_mode_label, seek_default_label].forEach(elm => inlineStyler(elm, `{width: ${min_label_width}px;}`));

  seek_default_input.addEventListener('blur', async () => {
    await requestFromBackground({ cmd: 'setLocalStorage', params: { key: 'tvd_settings_seek_default', data: floatString(seek_default_input.value) } });
    let seeker_adjustment = parseFloat(seek_default_input.value?.trim());
    ['seek_forward', 'seek_backward'].forEach(id => {
      let btn = document.getElementById(id);
      btn.innerHTML = svgs()?.[id?.replace(/seek_/, '')]?.replace(/\d+(?=<\/text>)/, seeker_adjustment);
    });
  });

  let filename_format_btn = ele();
  // a(filename_format_btn, [['class', 'gen_btn']]);
  inlineStyler(filename_format_btn, `{padding:12px;}`)
  settings_cont.menu_body.appendChild(filename_format_btn);
  filename_format_btn.innerHTML = `<div class="gen_btn" style="cursor:pointer; border-radius:2em; padding:8px;">Open File Name Format Options</div>`;
  filename_format_btn.addEventListener('click',()=>{
    buildFilenameFormatMenu({ parent_elm: filename_format_btn });
  });
  keepContInBoundary(settings_cont);
}

function resetCSS(params){
  setCSS('tvd_main_app_css',getMainAppCss());
  Array.from(document.getElementsByClassName('poly_fill_icon_color')).forEach(elm => {
    elm.setAttribute('fill', main_app_colors()?.icon_color)
  });
  Array.from(document.getElementsByClassName('poly_fill_contrast_icon')).forEach(elm => {
    elm.setAttribute('fill', main_app_colors()?.contrast_icon)
  });
}


/*

        ADD MENU INPUTS

*/
function addInputs(params) {
  var cont = ele();
  inlineStyler(cont,`{padding:12px; display:grid; grid-template-rows: auto; grid-gap:12px;}`,);
  appender({ ...params, ...{ cont: cont } });

  return params?.options.map((r) => {
      if (r.placeholder == 'm3u8 link') { addBuffer({parent_elm:cont, height: 12 });}
      let opt_cont = ele();
      let opt_label = ele();
      let opt_input_cont = ele();
      let opt_input = ele("input");
      let opt_btn = ele();

      a(opt_btn, [["class", "gen_btn"]]);
      a(opt_input, [["class", "textarea"],["placeholder", r.placeholder],]);

      inlineStyler(opt_input_cont, `{${gridCol(["1fr", "28px"], 8)}}`);
      inlineStyler(opt_input, `{padding:9px;}`);
      // inlineStyler(opt_btn,`{background-color: ${main_app_colors()?.bg};width:28px; height:28px; cursor:pointer; border-top-left-radius: 5%; border-bottom-left-radius: 5%; border-top-right-radius: 100%; border-bottom-right-radius: 100%;}`,);
      inlineStyler(opt_btn,`{width:28px; height:28px; cursor:pointer; border-top-left-radius: 5%; border-bottom-left-radius: 5%; border-top-right-radius: 100%; border-bottom-right-radius: 100%;}`,);
      opt_btn.innerHTML = svgs()?.play;
      opt_label.textContent = r.label;

      cont.appendChild(opt_cont);
      opt_cont.appendChild(opt_label);
      opt_cont.appendChild(opt_input_cont);
      opt_input_cont.appendChild(opt_input);
      opt_input_cont.appendChild(opt_btn);
      // if (r.placeholder == 'channel_name') { addBuffer({parent_elm:cont, height: 6 });}
      if (r.placeholder == 'm3u8 link') { addBuffer({parent_elm:cont, height: 12 });}
      return {[r.id]: { input: opt_input, btn: opt_btn },};
    }).reduce((a, b) => ({ ...a, ...b }));
}




/*
      RUN STREAM FINDER
*/



async function getRecentKickVODs(params){
  if(is_kick){
    var kick_vods = await getKickVODs(params);
    var tvd_streams = await requestFromBackground({
        cmd: 'handleGetStreams',
        params: { channel: params?.channel_login, service: 'kick' }
    });
    var kvs = kick_vods?.map(v=> {
       return {
          ...v,
          ...{
            stream_hsh:/\w+(?=\/media\/)/.exec(v.source)?.[0],
            timestamp:new Date(v.created_at).getTime(),
            title:v?.title || v?.session_title
          },
        }
    });
    var kvds = (tvd_streams?.streams || [])?.map(v=> {
      return {
        ...v,
        ...{
          stream_hsh:/(?<=\d+\/)\w+$/.exec(v.vod_path)?.[0],
          source:`https://stream.kick.com/3c81249a5ce0/ivs/v1/196233775518/${v.vod_path}/media/hls/master.m3u8`
        }
      }
    });
    return unqKey([...kvs,...kvds],'stream_hsh').sort((a, b) => b.timestamp - a.timestamp);
    //?.filter(r=> r?.video?.status !== 'subscriber_only');
  } else{
    return [];
  }
}

async function getRecentTwitchStreams(params){
  if(is_twitch){
    // console.log(params)
    var tvd_streams = await requestFromBackground({
        cmd: 'handleGetStreams',
        params: { channel: params?.channel_login, service: 'twitch' }
    });

    var sully_streams = await requestFromBackground({ cmd: "getSullyStreamsData", params: params,});
    // console.log('sully_streams',sully_streams);
    var merged_streams = unqKey([...(tvd_streams?.streams?.length ? tvd_streams?.streams : []),...(sully_streams?.length ? sully_streams : [])],'stream_id');
    var vods = await getAvailableVODinfo(params);

    var streams = mergeVODsWithSullyGnome({
      sully_data: merged_streams,
      vods: vods?.map(r=> ({...r,...{is_vod:true}})),
    });

    var tokens = getTokensFromCookies();
    var streamer_info = await requestFromBackground({ cmd: 'getTwitchChannelInfo', params: {...tokens,...{ channel_login: params?.channel_login }} });
    var vod_keep_milliseconds = streamer_info?.vod_keep_days ? streamer_info?.vod_keep_days * 86400000 : (60 * 86400000);
    var timestamp_threshold = ( new Date().getTime() - vod_keep_milliseconds);

    return streams?.filter(r=> r.timestamp >= timestamp_threshold)?.map(r=>({
      ...r,
      ...{vod_keep_days: streamer_info?.vod_keep_days}
    }));
  }else{
    return [];
  }
}


async function runRecentStreamsExtractor(params) {
  // console.log('runRecentStreamsExtractor(params)', params);
  addLoader({...{ left: params?.rect?.left, top: params?.rect?.top },...{ text: "searching" },});
  if(is_kick){
    var kick_vods = await getRecentKickVODs(params);
  }
  if(is_twitch){
    var twitch_streams = await getRecentTwitchStreams(params)
  }
  stopLoader();
  // console.log({ kick_vods, twitch_streams });
  var recent_streams_container = buildContainer({
    ...{top: 1,left: params?.rect?.left && params?.rect?.width ? params?.rect?.left + params?.rect?.width : 2,container_id: "tvd_recent_streams_cont",
    },
    ...uiSettings()
  });
  // inlineStyler(recent_streams_container?.menu_body,`{background-color:#ffffff; color:#1c1c1c;}`,);
  // inlineStyler(recent_streams_container?.menu_body,`{background-color:${main_app_colors()?.menu_bg}; color:${main_app_colors()?.text};}`,);
  // if (twitch_streams?.length || kick_vods?.length) {
    let cont = ele();
    inlineStyler(cont,`{padding:12px; display:grid; grid-template-rows: auto; grid-gap:12px;}`,);
    recent_streams_container.menu_body.appendChild(cont);
    // console.log({ kick_vods, twitch_streams });

    var kick_streamer_msg = is_kick && !kick_vods?.length
    if(!is_kick){
      var information_cont = ele();
      cont.appendChild(information_cont);
      inlineStyler(information_cont, `{background:${main_app_colors()?.edge}53; font-size:1.3em; border-radius: 0.4em; padding:8px;}`);
    information_cont.textContent = is_kick ? '' : !twitch_streams?.length ? `${twitch_streams?.[0]?.channel_login || params?.channel_login} does not have any recent VODs available.`
        : !twitch_streams?.some(ii=> ii.vod_id) ? `${twitch_streams?.[0]?.channel_login} may not have VODs enabled.`
        : `Twitch Keeps ${twitch_streams?.[0]?.channel_login} VODs for a Maximum of ${twitch_streams?.[0]?.vod_keep_days} days.`;
    }

    var priority_m3u8_servers = twitch_streams?.length ? unqHsh(twitch_streams?.map((r) => r.m3u8_server)?.filter((r) => r),{},): null;

    ([...(kick_vods || []),...(twitch_streams || [])]).forEach((r) => {
      let itm_cont = ele();
      cont.appendChild(itm_cont);
      a(itm_cont, [["class", "recent_vod_btn gen_btn max-height43"]]);
      let info_grid = [60, 110, 60, 210];
      let info_grid_gap = 8;
      let info_grid_px = info_grid.map((g) => g + info_grid_gap).reduce((a, b) => a + b);
      // inlineStyler(itm_cont,`{${gridCol([`${info_grid_px}px`, "32px"], 0)}text-align: center; border-radius:0.4em; margin:auto; width:99%;}`,);
      //moved to css file
      let info_cont = ele();
      itm_cont.appendChild(info_cont);
      if (r.title || r?.session_title) {
        a(info_cont, [["title", r.title || r?.session_title]]);
      }
      // inlineStyler(info_cont,`{${gridCol(info_grid.map((g) => `${g}px`),info_grid_gap,)} cursor:pointer; margin:auto;}`);
      inlineStyler(info_cont,`{display: flex; flex-wrap:wrap; gap:4px; width: 585px; cursor:pointer; justify-content: space-between;}`);
      if (r?.source) {
        let m3u8_cont = addBtnWithHoverTitle({parent_elm: itm_cont,btn_width: "26px",btn_svg: "copy",hover_text: "copy m3u8 link",copy_text: r?.source,});
      }else{
        addBuffer({ parent_elm: itm_cont, width: 26 });
      }
      // let title_html = r?.title ? `<div class="recent_title_view">${r?.title}</div>` : ''
      let kick_src = r?.thumbnail?.srcset ? getSmallestKickThumbnail(r) : "";
      let img_info = r?.animated_preview_url ? `<img class="preview_img" src="${r?.animated_preview_url}"></img>` : kick_src ? `<img src="${kick_src}"></img>` : svgs()?.hidden;
      info_cont.innerHTML = `
            <div style="border-radius:0.4em; width: 60px; height:35px; overflow:hidden;">${img_info}</div>
            <div style="text-align: left; max-width: 110px; display:flex; align-items:center; overflow:clip;">${r.channel_login || params?.channel_login || ""}</div>
            <div class="recent_title_view_cont"><div class="${r?.title?.length < 28 ? 'recent_title_view align_center' : r?.title?.length < 60 ? 'recent_title_view align_top' : 'recent_title_view align_top translateYneg20'}">${r?.title || ''}</div></div>
            <div style="text-align: left; width: 62px; display:flex; align-items:center;">${r?.duration ? parseTimeOffset(r?.duration / 1000) : ""}</div>
            <div style="text-align: right; width: 155px; display:flex; align-items:center; overflow-x: hidden;">${r?.created_at || r.timestamp_seconds ? dateTimeString(r.created_at || (r.timestamp_seconds * 1000)) : r.startDateTime ? dateTimeString(r.startDateTime) : r.published_at ? dateTimeString(r.published_at) : ""}</div>`;
      info_cont.addEventListener("click", () => {
        getStreamInformationAndBuildUI({...r,...params,...{
            ref_elm: itm_cont,
            priority_m3u8_servers: priority_m3u8_servers,
          },});
      });
    });
  // }
  keepContInBoundary(recent_streams_container);
}







/*
    BUILD STREAM UI
*/

// async function getTwitchVODSource(params){

// }


async function getStreamInformationAndBuildUI(params) {
  var { source,ref_ob } = params;
  let rect = params.ref_elm.getBoundingClientRect();

  if(source){
    // console.log({ source });
    // console.log('is_kick',is_kick)
    if(is_twitch) {runTwitchSourceBuild(params);}
    if(is_kick){runKickSourceBuild(params)}
  }else{
    let load_elm = addLoader({
      ...{ left: rect?.left, top: rect?.top },
      ...{ text: `searching ${is_kick ? "Kick" : "Twitch"}` },
    });
    var stream_info = await requestFromBackground({
      cmd: "getStreamDetailsFromStreamId",
      params: params,
    });
    // console.log({stream_info});
    if (!stream_info?.source) {
      let timestamp = fixUTClocalityTimestamp(params);
      if (load_elm) { load_elm.remove(); }
      let load_elm2 = addLoader({
        ...{ left: rect?.left, top: rect?.top },
        ...{ text: "trying again" },
      });
      var next_params = { ...params, ...{ timestamp: timestamp } };
      var stream_info2 = await requestFromBackground({
        cmd: "getStreamDetailsFromStreamId",
        params: next_params,
      });
      // console.log({stream_info2})
        if (load_elm2) { load_elm2.remove(); }
      if (stream_info2?.source) {
        // console.log('runTwitchSourceBuild stream_info2',{ ...params, ...stream_info2 })
        runTwitchSourceBuild({ ...params, ...stream_info2 });
      }else{
        let load_fail = addLoader({
          ...{ left: rect?.left, top: rect?.top },
          ...{ text: "VOD Does Not Exist" },
        });

        if(ref_ob?.input?.value){
          ref_ob.input.value = 'failed';
        }
        // console.log('getStreamInformationAndBuildUI', params);
        let latest_recordings = await getStreamrecorderAvailabilty({ channel_name: params?.channel_login || params?.channel_name, service: 'twitch' });
        // console.log(latest_recordings)

        var streamrecorder_promo = buildContainer({
          top: params.ref_elm.getBoundingClientRect().top,
          left: params.ref_elm.getBoundingClientRect().left,
          container_id: "streamrecorder_promo",
          background: main_background_gradient(),
          border_radius: "0.8em",inner_radius: "0.2em",header_height: 12,left_panel_width: 16,right_panel_width: 16,footer_height: 16,close_btn_px: 12,
          parent_elm: document.body,moveable_head: true,movable_left: true,movable_right: true,movable_footer: false,resizeable: true,
        });


        addStreamRecorderBtn({
          parent_elm: streamrecorder_promo.menu_body,
          text:'This VOD is not on the Twitch server. Try using Streamrecorder.'
        });

        addBuffer({parent_elm:streamrecorder_promo.menu_body, height: 8, width:400 });

        if(latest_recordings?.length){
          var near = filterRecorderVODsWithin24h({
            latest_recordings:latest_recordings,
            target:params,
          })
          // console.log(near);

          addAvailableStreamRecorderInfo( { parent_elm:streamrecorder_promo.menu_body, recordings:near })
        }

        await delay(1444);
        if(load_fail){load_fail.remove()}
      }
      // console.log('stream_info', stream_info2);
    }else{
      // console.log('runTwitchSourceBuild  stream_info',{ ...params, ...stream_info })
      runTwitchSourceBuild({ ...params, ...stream_info });
    }
    if (load_elm) { load_elm.remove(); }
  }
  // runTwitchSourceBuild({ ...params, ...stream_info2 });
  // //     } else {
  // //       runTwitchSourceBuild({ ...params, ...stream_info });
}


async function runKickSourceBuild(params){
  let rect = params.ref_elm?.getBoundingClientRect();
  let load_elm3 = addSpinner({ rect });
  let valid_resolutions = await requestFromBackground({
      cmd: "getKickVideoStreamData",
      params: params,
  });
  // console.log( {valid_resolutions});
  if (load_elm3){ load_elm3.remove(); }
  if(valid_resolutions?.length){
    buildVideoViewer({
      ...params,
      ...{ valid_resolutions },
    });
  }else{
    let novod = addSpinner({
      rect,
      icon: '🚫',
      iconBg: 'rgba(248,113,113,0.18)',
      text: 'VOD has been removed',
    });
    await delay(3333);
    if (novod) { novod.remove(); }
  }
}
async function runTwitchSourceBuild(params){
  let rect = params.ref_elm?.getBoundingClientRect();
  let load_elm3 = addSpinner({ rect });
  let valid_resolutions = await requestFromBackground({
      cmd: "getValidResolutions",
      params: params,
  });
  if (load_elm3){ load_elm3.remove(); }
  if(valid_resolutions?.length){
    buildVideoViewer({
      ...params,
      ...{ valid_resolutions },
    });
  }else{
    let novod = addSpinner({
      rect,
      icon: '🚫',
      iconBg: 'rgba(248,113,113,0.18)',
      text: 'VOD has been removed',
    });
    await delay(3333);
    if (novod) { novod.remove(); }
  }
}
// async function runTwitchSourceBuild_old(params) {
//   // console.log("runTwitchSourceBuild", params);
//   let rect = params.ref_elm.getBoundingClientRect();
//   let load_elm3 = addLoader({
//     ...{ left: rect?.left, top: rect?.top },
//     ...{ text: "checking resolutions" },
//   });

//   let valid_resolutions = await requestFromBackground({
//     cmd: "getValidResolutions",
//     params: params,
//   });
//   // console.log("valid_resolutions", valid_resolutions);
//   if (load_elm3) load_elm3.remove();
//   if (valid_resolutions) {
//     buildVideoViewer({
//       ...params,
//       ...{ valid_resolutions },
//     });
//     // console.log(valid_resolutions);
//   }
// }





/*

    BUILD VIDEO VIEWER

*/

async function getTwitchLivestreamPlaybackInfo(params){
  // console.log('getTwitchLivestreamPlaybackInfo');
  if(/twitch\.tv/.test(window.location.href)){
    // console.log('getTwitchLivestreamPlaybackInfo',params)
    let tokens = getTokensFromCookies();
    // console.log('getTwitchStreamInformation',{ ...tokens, ...params })
    var channel_info = await requestFromBackground({
      cmd: "getTwitchStreamInformation",
      params: { ...tokens, ...params, ...(channel_info?.channel_login ? {channel_login:channel_info?.channel_login} : {}) },
    });

    // console.log("getTwitchStreamInformation channel_info=>", channel_info);
    var livestream_playback_token = await requestFromBackground({
      cmd: "getLivestreamPlaybackToken",
      params: { ...tokens, ...params },
    });
    // console.log("livestream_playback_token=>", livestream_playback_token);
    var livestream_urls = await requestFromBackground({
      cmd: "getTwitchLivestreamUrl",
      params: { ...tokens, ...params },
    });
    // console.log("livestream_url=>", livestream_urls);
    return {livestream_urls,channel_info,livestream_playback_token}
  }else{
    return {}
  }
}





function kwsEnsureInlineVodSkin() {
  document.getElementById('kws-inline-vod-skin')?.remove();
  const style = document.createElement('style');
  style.id = 'kws-inline-vod-skin';
  style.textContent = '\n\
    #tvd_video_viewer.kws-ios-vod-player { background: rgba(10,12,18,.88) !important; border: 3px solid rgba(255,255,255,.22) !important; border-radius: 24px !important; box-shadow: 0 22px 70px rgba(0,0,0,.55), inset 0 1px 0 rgba(255,255,255,.14) !important; overflow: hidden !important; backdrop-filter: blur(22px) saturate(150%) !important; -webkit-backdrop-filter: blur(22px) saturate(150%) !important; min-width: 420px !important; min-height: 270px !important; }\n\
    #tvd_video_viewer.kws-ios-vod-player #tvd_video_viewer_menu_body { position: relative !important; background: #05070b !important; border-radius: 20px !important; overflow: hidden !important; resize: none !important; min-width: 384px !important; min-height: 216px !important; }\n\
    #tvd_video_viewer.kws-ios-vod-player video.pop_out_video { width: 100% !important; height: 100% !important; display: block !important; object-fit: contain !important; background:#000 !important; }\n\
    #tvd_video_viewer.kws-ios-vod-player #tvd_video_viewer_top_label { color: rgba(255,255,255,.72) !important; font-weight: 800 !important; letter-spacing: .02em !important; }\n\
    .kws-vod-glassbar { position:absolute; left:12px; right:12px; top:12px; z-index:7; display:flex; align-items:center; justify-content:space-between; gap:10px; padding:9px 10px; border-radius:18px; background:rgba(20,24,34,.58); border:1px solid rgba(255,255,255,.14); backdrop-filter:blur(18px); -webkit-backdrop-filter:blur(18px); opacity:0; transform:translateY(-6px); transition:opacity .16s ease, transform .16s ease; pointer-events:none; }\n\
    #tvd_video_viewer.kws-ios-vod-player:hover .kws-vod-glassbar { opacity:1; transform:translateY(0); pointer-events:auto; }\n\
    .kws-vod-title { min-width:0; color:#fff; font: 800 12px/1.25 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }\n\
    .kws-vod-subtitle { color:rgba(255,255,255,.52); font: 600 10px/1.2 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; margin-top:2px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }\n\
    .kws-vod-actions { display:flex; align-items:center; gap:6px; flex-wrap:wrap; justify-content:flex-end; }\n\
    .kws-vod-pill, .kws-vod-iconbtn { border:1px solid rgba(255,255,255,.16); background:rgba(255,255,255,.10); color:rgba(255,255,255,.86); border-radius:999px; min-height:28px; padding:0 10px; font:800 11px/1 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; cursor:pointer; display:inline-flex; align-items:center; justify-content:center; gap:5px; box-shadow: inset 0 1px 0 rgba(255,255,255,.08); }\n\
    .kws-vod-pill:hover, .kws-vod-iconbtn:hover { background:rgba(255,255,255,.20); color:#fff; border-color:rgba(255,255,255,.30); }\n\
    .kws-vod-pill.checked { background:rgba(250,204,21,.22) !important; color:#facc15 !important; border-color:rgba(250,204,21,.5) !important; }\n\
    .kws-vod-iconbtn { width:30px; padding:0; font-size:13px; }\n\
    .kws-vod-res-group { display:flex; gap:5px; align-items:center; max-width:42vw; overflow:auto; scrollbar-width:none; } .kws-vod-res-group::-webkit-scrollbar { display:none; }\n\
    #tvd_video_viewer.kws-ios-vod-player .video_controls_cont, #tvd_video_viewer.kws-ios-vod-player .vod_info_cont { display:none !important; }\n\
    #tvd_video_viewer.kws-ios-vod-player .custom_video_controls_cont { position:absolute !important; left:12px !important; right:12px !important; bottom:12px !important; top:auto !important; height:auto !important; max-height:none !important; display:flex !important; flex-direction:column !important; gap:6px !important; visibility:visible !important; opacity:0; background:rgba(12,15,23,.66) !important; border:1px solid rgba(255,255,255,.12) !important; border-radius:18px !important; margin:0 !important; padding:7px 10px !important; backdrop-filter: blur(14px) !important; -webkit-backdrop-filter: blur(14px) !important; transform:translateY(6px); transition:opacity .16s ease, transform .16s ease; pointer-events:none; box-sizing:border-box !important; width:auto !important; }\n\
    #tvd_video_viewer.kws-ios-vod-player .custom_video_controls_cont > div { max-width:100% !important; box-sizing:border-box !important; flex-shrink:0 !important; flex-grow:0 !important; }\n\
    #tvd_video_viewer.kws-ios-vod-player:hover .custom_video_controls_cont { opacity:1 !important; transform:translateY(0); pointer-events:auto; }\n\
    #tvd_video_viewer.kws-ios-vod-player video.pop_out_video { cursor:pointer; }\n\
    #tvd_video_viewer.kws-ios-vod-player #seeker_video_input { accent-color: #a78bfa !important; }\n\
    .kws-resize-hint { position:absolute; right:10px; bottom:10px; z-index:8; color:rgba(255,255,255,.42); font:900 15px/1 -apple-system,sans-serif; pointer-events:none; text-shadow:0 1px 8px rgba(0,0,0,.8); }\n\
    #tvd_chat_viewer_cont.kws-ios-chat-log { background:rgba(12,14,22,.84) !important; border:3px solid rgba(255,255,255,.22) !important; border-radius:24px !important; box-shadow:0 22px 70px rgba(0,0,0,.42), inset 0 1px 0 rgba(255,255,255,.10) !important; overflow:hidden !important; backdrop-filter: blur(22px) saturate(150%) !important; -webkit-backdrop-filter: blur(22px) saturate(150%) !important; }\n\
    #tvd_chat_viewer_cont.kws-ios-chat-log #tvd_chat_viewer_cont_menu_body { background:rgba(5,7,11,.68) !important; color:#e5e7eb !important; padding:10px !important; }\n\
    #tvd_chat_viewer_cont.kws-ios-chat-log .stream-chat-message-container { margin:0 0 7px 0 !important; padding:8px 9px !important; border-radius:14px !important; background:rgba(255,255,255,.055) !important; border:1px solid rgba(255,255,255,.075) !important; color:#e5e7eb !important; font: 12px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif !important; }\n\
    #tvd_chat_viewer_cont.kws-ios-chat-log .stream-chat-message { color:rgba(255,255,255,.84) !important; word-break:break-word !important; }\n\
    #tvd_chat_viewer_cont.kws-ios-chat-log .stream-chat-username { font-weight:900 !important; }\n\
  ';
  document.head.appendChild(style);
}

function kwsApplyInlineVodShell(video_viewer_cont, params) {
  kwsEnsureInlineVodSkin();
  const cont = video_viewer_cont?.cont;
  const body = video_viewer_cont?.menu_body;
  if (!cont || !body) return;
  cont.classList.add('kws-ios-vod-player');

  // 초기 크기 — 16:9 기본값
  const initW = Math.max(520, Math.round(window.innerWidth * 0.52));
  const initH = Math.round(initW * 9 / 16);
  inlineStyler(cont, `{top: 22px; left: ${Math.max(18, Math.round(window.innerWidth * 0.30))}px; width: ${initW}px;}`);
  inlineStyler(body, `{height: ${initH}px;}`);

  const label = document.getElementById('tvd_video_viewer_top_label');
  if (label) label.textContent = '';

  // 실제 영상 비율 읽어서 적용 + ResizeObserver로 리사이즈 시에도 비율 유지
  let videoRatio = 9 / 16; // 기본값
  const HEADER = 18 + 18; // header_height + footer_height (buildContainer params)
  const SIDE = 18 + 18;   // left_panel_width + right_panel_width

  function applyRatio(ratio) {
    videoRatio = ratio;
    // 세로 영상이면 화면 높이에 맞추고 창 너비도 좁힘 (window.KWSFitPlayerHeight, commonHistory.js)
    const bodyH = window.KWSFitPlayerHeight ? window.KWSFitPlayerHeight(cont, ratio, SIDE, true) : Math.round((cont.getBoundingClientRect().width - SIDE) * ratio);
    inlineStyler(body, `{height: ${bodyH}px;}`);
  }

  // ResizeObserver: cont 너비가 바뀔 때마다 body 높이를 비율에 맞게 재계산
  if (window.ResizeObserver) {
    const ro = new ResizeObserver(() => {
      const contW = cont.getBoundingClientRect().width;
      if (!contW) return;
      const bodyH = window.KWSFitPlayerHeight ? window.KWSFitPlayerHeight(cont, videoRatio, SIDE, false) : Math.round((contW - SIDE) * videoRatio);
      inlineStyler(body, `{height: ${bodyH}px;}`);
    });
    ro.observe(cont);
    // cont가 DOM에서 제거되면 observer 해제
    new MutationObserver((_, mo) => {
      if (!document.contains(cont)) { ro.disconnect(); mo.disconnect(); }
    }).observe(document.body, { childList: true, subtree: true });
  }

  // 영상 로드 후 실제 비율로 업데이트
  const tryFitToVideo = () => {
    const v = cont.querySelector('video.pop_out_video');
    if (!v) return;
    const onMeta = () => {
      if (!v.videoWidth || !v.videoHeight) return;
      applyRatio(v.videoHeight / v.videoWidth);
    };
    if (v.readyState >= 1 && v.videoWidth) { onMeta(); return; }
    v.addEventListener('loadedmetadata', onMeta, { once: true });
  };
  setTimeout(tryFitToVideo, 800);
  setTimeout(tryFitToVideo, 2500);
}

function kwsEnsureInlineVodHotfixStyle() {
  document.getElementById('kws-inline-vod-hotfix-style')?.remove();
  const style = document.createElement('style');
  style.id = 'kws-inline-vod-hotfix-style';
  style.textContent = `
    #tvd_video_viewer.kws-ios-vod-player #tvd_video_viewer_menu_body { resize:none !important; }
    #tvd_video_viewer.kws-ios-vod-player video.pop_out_video { resize:none !important; }
    #tvd_video_viewer.kws-ios-vod-player video.pop_out_video::-webkit-media-controls,
    #tvd_video_viewer.kws-ios-vod-player video.pop_out_video::-webkit-media-controls-enclosure { display:none !important; opacity:0 !important; pointer-events:none !important; }
    #tvd_video_viewer.kws-ios-vod-player .custom_video_controls_cont > div:first-child { display:flex !important; align-items:center !important; justify-content:space-between !important; gap:10px !important; flex-wrap:nowrap !important; }
    #tvd_video_viewer.kws-ios-vod-player .custom_video_controls_cont .speed_cont,
    #tvd_video_viewer.kws-ios-vod-player .custom_video_controls_cont .volume_cont { display:flex !important; align-items:center !important; gap:6px !important; flex:0 0 auto !important; background:rgba(255,255,255,.07) !important; border-radius:999px !important; padding:3px 8px !important; height:32px !important; box-sizing:border-box !important; }
    #tvd_video_viewer.kws-ios-vod-player .custom_video_controls_cont .speed_bar { visibility:visible !important; width:70px !important; transform:none !important; accent-color:#facc15 !important; }
    #tvd_video_viewer.kws-ios-vod-player .custom_video_controls_cont .volume_bar { visibility:visible !important; width:86px !important; transform:none !important; accent-color:#facc15 !important; }
    #tvd_video_viewer.kws-ios-vod-player .custom_video_controls_cont .speed_display { visibility:visible !important; width:42px !important; color:#fff !important; font-weight:800 !important; }
    .kws-unified-close { width:30px !important; height:30px !important; border-radius:999px !important; background:linear-gradient(135deg,rgba(255,255,255,.18),rgba(255,255,255,.07)) !important; border:1px solid rgba(255,255,255,.18) !important; box-shadow:0 8px 18px rgba(0,0,0,.35), inset 0 1px 0 rgba(255,255,255,.18) !important; display:flex !important; align-items:center !important; justify-content:center !important; font-size:15px !important; color:#fff !important; cursor:pointer !important; transition:transform .14s ease, background .14s ease, border-color .14s ease !important; flex-shrink:0 !important; }
    .kws-unified-close:hover { background:linear-gradient(135deg,rgba(248,113,113,.95),rgba(220,38,38,.88)) !important; border-color:rgba(255,255,255,.28) !important; transform:scale(1.06) !important; }
    #tvd_video_viewer.kws-ios-vod-player #tvd_video_viewer_close,
    #tvd_chat_viewer_cont.kws-ios-chat-log #tvd_chat_viewer_cont_close { display:none !important; }
    #tvd_video_viewer.kws-ios-vod-player #tvd_video_viewer_close + div,
    #tvd_video_viewer_close, #tvd_chat_viewer_cont_close { display:none !important; }
    #tvd_video_viewer.kws-ios-vod-player .drag_actor_left,
    #tvd_chat_viewer_cont.kws-ios-chat-log .drag_actor_left { display:none !important; }
    .kws-unified-close { width:30px !important; height:30px !important; border-radius:999px !important; background:linear-gradient(135deg,rgba(255,255,255,.18),rgba(255,255,255,.07)) !important; border:1px solid rgba(255,255,255,.18) !important; box-shadow:0 8px 18px rgba(0,0,0,.35), inset 0 1px 0 rgba(255,255,255,.18) !important; display:flex !important; align-items:center !important; justify-content:center !important; font-size:15px !important; color:#fff !important; cursor:pointer !important; transition:transform .14s ease, background .14s ease, border-color .14s ease !important; flex-shrink:0 !important; }
    .kws-unified-close:hover { background:linear-gradient(135deg,rgba(248,113,113,.95),rgba(220,38,38,.88)) !important; border-color:rgba(255,255,255,.28) !important; transform:scale(1.06) !important; }
    .kws-inline-download-pop { font-size:13px; position:fixed; z-index:9999999; right:24px; bottom:24px; width:min(760px, calc(100vw - 48px)); max-height:min(78vh,720px); overflow:hidden; border-radius:24px; background:rgba(9,11,18,.94); border:1px solid rgba(255,255,255,.16); box-shadow:0 28px 90px rgba(0,0,0,.62), inset 0 1px 0 rgba(255,255,255,.10); color:#e5e7eb; backdrop-filter:blur(22px) saturate(150%); -webkit-backdrop-filter:blur(22px) saturate(150%); }
    .kws-inline-download-head { position:sticky; top:0; z-index:2; display:flex; align-items:center; justify-content:space-between; gap:10px; padding:12px 14px; background:rgba(14,17,27,.88); border-bottom:1px solid rgba(255,255,255,.10); cursor:grab; user-select:none; }
    .kws-inline-download-head:active { cursor:grabbing; }
    .kws-inline-download-title { font:900 13px/1.2 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; color:#fff; }
    .kws-inline-download-close { border:1px solid rgba(255,255,255,.18); background:linear-gradient(135deg,rgba(255,255,255,.18),rgba(255,255,255,.07)); color:#fff; width:30px; height:30px; border-radius:999px; cursor:pointer; font-size:15px; line-height:1; display:flex; align-items:center; justify-content:center; box-shadow:0 8px 18px rgba(0,0,0,.35), inset 0 1px 0 rgba(255,255,255,.18); transition:transform .14s ease, background .14s ease, border-color .14s ease; flex-shrink:0; }
    .kws-inline-download-close:hover { background:linear-gradient(135deg,rgba(248,113,113,.95),rgba(220,38,38,.88)); border-color:rgba(255,255,255,.28); transform:scale(1.06); }
    .kws-inline-download-pop #download_view_holder { background:transparent !important; border-radius:0 !important; box-shadow:none !important; padding:14px !important; color:#e5e7eb !important; }
    .kws-inline-download-pop input[type=range] { width:100% !important; accent-color:#facc15 !important; }
    .kws-inline-download-pop select { background:rgba(255,255,255,.09); color:#fff; border:1px solid rgba(255,255,255,.16); border-radius:10px; padding:6px 8px; }
    .kws-inline-download-pop #video_progress_controls_cont { position:relative !important; height:176px !important; min-height:176px !important; margin:18px 10px 28px !important; overflow:visible !important; border-radius:18px !important; background:rgba(255,255,255,.035) !important; border:1px solid rgba(255,255,255,.08) !important; }
    .kws-inline-download-pop .vid_control_bar { display:block !important; visibility:visible !important; opacity:1 !important; height:14px !important; background:linear-gradient(90deg,rgba(250,204,21,.85),rgba(59,130,246,.85)) !important; border-radius:999px !important; box-shadow:0 0 0 1px rgba(255,255,255,.18), 0 8px 22px rgba(0,0,0,.35), inset 0 1px 0 rgba(255,255,255,.24) !important; overflow:visible !important; }
    .kws-inline-download-pop .vid_control_ball { display:block !important; visibility:visible !important; opacity:1 !important; border-radius:999px !important; background:linear-gradient(180deg,#fff,#cbd5e1) !important; border:3px solid rgba(250,204,21,.95) !important; box-shadow:0 10px 24px rgba(0,0,0,.50), inset 0 1px 0 rgba(255,255,255,.9) !important; cursor:ew-resize !important; box-sizing:border-box !important; }
    .kws-inline-download-pop .vid_control_ball:hover { transform:scale(1.04) !important; }
    .kws-inline-download-pop .vid_time_display { display:block !important; visibility:visible !important; opacity:1 !important; min-width:130px !important; width:130px !important; height:28px !important; padding:0 8px !important; box-sizing:border-box !important; background:rgba(15,23,42,.92) !important; color:#fff !important; border:1px solid rgba(255,255,255,.30) !important; border-radius:10px !important; text-align:center !important; font-size:13px !important; line-height:28px !important; font-weight:800 !important; letter-spacing:.01em !important; box-shadow:0 10px 24px rgba(0,0,0,.42), inset 0 1px 0 rgba(255,255,255,.14) !important; }
    .kws-inline-download-pop .vid_time_display:focus { border-color:rgba(250,204,21,.95) !important; box-shadow:0 0 0 3px rgba(250,204,21,.18), 0 10px 24px rgba(0,0,0,.42) !important; }
    .kws-inline-download-pop #download_view_holder > div { min-width:0 !important; }
    .kws-inline-download-pop .gen_btn { box-sizing:border-box !important; }

  `;
  document.head.appendChild(style);
}


function kwsMakeInlineDownloadDraggable(pop, head) {
  if (!pop || !head || pop.dataset.dragReady === '1') return;
  pop.dataset.dragReady = '1';
  let dragging = false;
  let startX = 0, startY = 0, startLeft = 0, startTop = 0;
  const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
  const begin = (e) => {
    if (e.target && e.target.closest && e.target.closest('button,select,input,textarea,a')) return;
    const pt = e.touches ? e.touches[0] : e;
    const rect = pop.getBoundingClientRect();
    dragging = true;
    startX = pt.clientX; startY = pt.clientY;
    startLeft = rect.left; startTop = rect.top;
    pop.style.left = rect.left + 'px';
    pop.style.top = rect.top + 'px';
    pop.style.right = 'auto';
    pop.style.bottom = 'auto';
    pop.style.transform = 'none';
    pop.style.position = 'fixed';
    // z-index는 고정된 9999999를 유지 — topZIndexer()로 재할당하면 공유 카운터(10만대) 값으로
    // 오히려 낮아져서 다른 패널(예: VOD 플레이어) 클릭 시 그 뒤로 밀려버림
    document.body.style.userSelect = 'none';
  };
  const move = (e) => {
    if (!dragging) return;
    const pt = e.touches ? e.touches[0] : e;
    const rect = pop.getBoundingClientRect();
    const nextLeft = clamp(startLeft + (pt.clientX - startX), 8, window.innerWidth - rect.width - 8);
    const nextTop = clamp(startTop + (pt.clientY - startY), 8, window.innerHeight - Math.min(rect.height, window.innerHeight - 16) - 8);
    pop.style.left = nextLeft + 'px';
    pop.style.top = nextTop + 'px';
    e.preventDefault();
  };
  const end = () => {
    if (!dragging) return;
    dragging = false;
    document.body.style.userSelect = '';
  };
  head.addEventListener('mousedown', begin);
  head.addEventListener('touchstart', begin, {passive:false});
  window.addEventListener('mousemove', move, {passive:false});
  window.addEventListener('touchmove', move, {passive:false});
  window.addEventListener('mouseup', end);
  window.addEventListener('touchend', end);
}

let _kwsRangeDragCallback = null; // (newStart, newEnd) => void — set by kwsOpenClipDownloader so drags feed back into its state

// 영상 등 "클릭하면 다른 동작(재생/정지)도 하는 요소"를 드래그 핸들로 쓸 때,
// 일정 거리 이상 움직였을 때만 진짜 드래그로 인식하고, 그 경우 뒤따라오는 click 이벤트를 한 번 무시하도록 표시.
function kwsAttachThresholdDrag(handleElm, moveElm, threshold) {
  const THRESH = threshold || 6;
  let startX = 0, startY = 0, dragging = false, moved = false, origLeft = 0, origTop = 0;
  handleElm.addEventListener('mousedown', (e) => {
    startX = e.clientX; startY = e.clientY; dragging = true; moved = false;
    const r = moveElm.getBoundingClientRect();
    origLeft = r.left; origTop = r.top;
    moveElm.style.left = r.left + 'px'; moveElm.style.top = r.top + 'px';
    document.body.style.userSelect = 'none';
  });
  document.addEventListener('mousemove', (e) => {
    if (!dragging) return;
    const dx = e.clientX - startX, dy = e.clientY - startY;
    if (!moved && Math.hypot(dx, dy) > THRESH) { moved = true; moveElm.style.zIndex = topZIndexer(); }
    if (moved) { moveElm.style.left = (origLeft + dx) + 'px'; moveElm.style.top = (origTop + dy) + 'px'; }
  });
  document.addEventListener('mouseup', () => {
    if (dragging && moved) handleElm._kwsSuppressNextClick = true;
    dragging = false;
    document.body.style.userSelect = '';
  });
}

function updateRangeOverlay(startSec, endSec, onChangeCb) {
  const OVERLAY_ID = 'kws-clip-range-overlay';
  let overlay = document.getElementById(OVERLAY_ID);
  if (onChangeCb !== undefined) _kwsRangeDragCallback = onChangeCb;
  if (startSec == null) { overlay?.remove(); _kwsRangeDragCallback = null; return; }
  const seeker = document.getElementById('seeker_video_input');
  if (!seeker) return;
  const video = document.querySelector('#tvd_video_viewer_menu_body video.pop_out_video');
  const total = video?.duration || parseFloat(seeker.max) || 1;

  const fmtT = sec => {
    if (sec == null || isNaN(sec)) return '--:--:--';
    sec = Math.max(0, sec);
    const h = Math.floor(sec/3600), m = Math.floor((sec%3600)/60), s = Math.floor(sec%60);
    return String(h).padStart(2,'0') + ':' + String(m).padStart(2,'0') + ':' + String(s).padStart(2,'0');
  };

  const render = (s, en) => {
    overlay.dataset.curStart = s; overlay.dataset.curEnd = en;
    const sp = Math.max(0, Math.min(100, (s/total)*100));
    const ep = Math.max(0, Math.min(100, (en/total)*100));
    const stripe = overlay.querySelector('.kws-range-stripe');
    stripe.style.left  = sp + '%';
    stripe.style.width = Math.max(0, ep - sp) + '%';
    const hs = overlay.querySelector('.kws-range-handle-start');
    const he = overlay.querySelector('.kws-range-handle-end');
    hs.style.left = 'calc(' + sp + '% - 8px)';
    he.style.left = 'calc(' + ep + '% - 8px)';
    hs.querySelector('.kws-range-label').textContent = fmtT(s);
    he.querySelector('.kws-range-label').textContent = fmtT(en);
  };

  if (!overlay) {
    overlay = ele('div');
    overlay.id = OVERLAY_ID;
    overlay.style.cssText = 'position:absolute;top:-8px;bottom:-8px;left:0;right:0;pointer-events:none;z-index:6;';
    const parent = seeker.parentElement;
    parent.style.position = 'relative';
    parent.appendChild(overlay);

    // Start=노랑, End=파랑 — 다운로더 팝업의 Start/End 라벨 색과 동일하게, 얇은 그라데이션 구간 + 안쪽을 가리키는 얇은 삼각 핸들
    // 스트라이프/라인은 시각 표시만 — 시크바 조작을 방해하지 않도록 pointer-events:none
    const stripe = ele('div');
    stripe.className = 'kws-range-stripe';
    stripe.style.cssText = 'position:absolute;top:-2px;bottom:-2px;left:0;width:0;box-sizing:border-box;border-radius:3px;pointer-events:none;' +
      'background:repeating-linear-gradient(135deg,rgba(255,255,255,0.12) 0px 6px,transparent 6px 12px),linear-gradient(90deg,rgba(250,204,21,0.42),rgba(96,165,250,0.42));' +
      'border-top:1px solid rgba(255,255,255,0.28);border-bottom:1px solid rgba(255,255,255,0.28);';
    overlay.appendChild(stripe);

    const mkHandle = (side, color) => {
      const h = ele('div');
      h.className = 'kws-range-handle kws-range-handle-' + side;
      // 드래그 가능한 hit area는 시크바 위쪽 라벨 영역에만 — 시크바 자체는 안 가림
      h.style.cssText = 'position:absolute;top:-16px;height:16px;width:16px;cursor:ew-resize;pointer-events:auto;' +
        'display:flex;align-items:center;justify-content:center;z-index:2;';

      const line = ele('div');
      // 위치 표시용 세로선은 시크바까지 이어지지만, 순수 시각 요소라 클릭은 통과시킴
      line.style.cssText = 'position:absolute;top:16px;bottom:-2px;left:50%;width:3px;margin-left:-1.5px;border-radius:2px;pointer-events:none;' +
        'background:' + color + ';box-shadow:0 0 5px ' + color + ',0 0 0 1px rgba(0,0,0,0.5);';
      h.appendChild(line);

      const tri = ele('div');
      const triCss = side === 'start'
        ? 'border-width:5px 0 5px 7px;border-color:transparent transparent transparent ' + color + ';'
        : 'border-width:5px 7px 5px 0;border-color:transparent ' + color + ' transparent transparent;';
      tri.style.cssText = 'position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:0;height:0;pointer-events:none;' +
        'border-style:solid;' + triCss + 'filter:drop-shadow(0 1px 2px rgba(0,0,0,0.6));';
      h.appendChild(tri);

      const label = ele('div');
      label.className = 'kws-range-label';
      label.style.cssText = 'position:absolute;bottom:100%;left:50%;transform:translateX(-50%);margin-bottom:6px;pointer-events:none;' +
        'padding:3px 7px;border-radius:6px;background:rgba(12,8,22,0.94);border:1px solid ' + color + '88;' +
        'color:' + color + ';font-size:10px;font-weight:700;font-family:monospace;white-space:nowrap;';
      h.appendChild(label);
      overlay.appendChild(h);
      return h;
    };
    mkHandle('start', '#facc15');
    mkHandle('end', '#60a5fa');

    // ── 드래그로 구간 조절 (양 끝 핸들만 — 구간 전체를 잡아 옮기는 기능은 제거, 시크바 조작 우선) ──
    let dragMode = null; // 'start' | 'end'
    const secAt = (clientX) => {
      const rect = seeker.getBoundingClientRect();
      const pct = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
      return pct * total;
    };
    const startDrag = (mode) => (e) => {
      e.preventDefault(); e.stopPropagation();
      dragMode = mode;
      document.body.style.userSelect = 'none';
    };
    const onMove = (e) => {
      if (!dragMode) return;
      let s = parseFloat(overlay.dataset.curStart), en = parseFloat(overlay.dataset.curEnd);
      if (dragMode === 'start') {
        s = Math.max(0, Math.min(secAt(e.clientX), en - 1));
      } else if (dragMode === 'end') {
        en = Math.max(secAt(e.clientX), s + 1);
        en = Math.min(en, total);
      }
      render(Math.round(s), Math.round(en));
      if (_kwsRangeDragCallback) _kwsRangeDragCallback(Math.round(s), Math.round(en));
    };
    const onUp = () => { dragMode = null; document.body.style.userSelect = ''; };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);

    overlay.querySelector('.kws-range-handle-start').addEventListener('mousedown', startDrag('start'));
    overlay.querySelector('.kws-range-handle-end').addEventListener('mousedown', startDrag('end'));
  }

  render(startSec, endSec);
}

function kwsOpenClipDownloader(params) {
  const POP_ID = 'kws_clip_downloader';
  if (document.getElementById(POP_ID)) { document.getElementById(POP_ID).remove(); updateRangeOverlay(null, null); return; }

  const { video, channel_login, timestamp, source, fragments, is_mp4, start_in, end_in } = params;

  // 파일명은 downloadFullSelection이 buildFilenameFromSettings로 자동 생성

  let clipStart = start_in != null ? start_in : Math.floor(video?.currentTime || 0);
  let clipEnd   = end_in   != null ? end_in   : Math.min(clipStart + 300, Math.floor(video?.duration || clipStart + 300));

  const fmtTime = sec => {
    if (sec == null || isNaN(sec)) return '--:--:--';
    const h = Math.floor(sec/3600), m = Math.floor((sec%3600)/60), s = Math.floor(sec%60);
    return String(h).padStart(2,'0') + ':' + String(m).padStart(2,'0') + ':' + String(s).padStart(2,'0');
  };

  const pop = ele('div');
  pop.id = POP_ID;
  pop.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:9999999;width:340px;' +
    'background:rgba(8,10,16,0.88);backdrop-filter:blur(20px) saturate(1.6);-webkit-backdrop-filter:blur(20px) saturate(1.6);' +
    'border:1px solid rgba(255,255,255,0.14);border-radius:18px;' +
    'box-shadow:0 16px 50px rgba(0,0,0,0.6);' +
    'font-family:-apple-system,BlinkMacSystemFont,sans-serif;color:#e2e8f0;font-size:12px;' +
    'display:flex;flex-direction:column;overflow:hidden;';

  pop.innerHTML =
    '<div id="' + POP_ID + '_head" style="display:flex;align-items:center;justify-content:space-between;padding:11px 14px 9px;' +
      'border-bottom:1px solid rgba(255,255,255,0.07);cursor:move;background:rgba(255,255,255,0.04);">' +
      '<span style="font-size:11px;font-weight:800;letter-spacing:0.05em;color:rgba(255,255,255,0.55);text-transform:uppercase;">Clip Downloader</span>' +
      '<button id="' + POP_ID + '_close" class="kws-unified-close" style="width:22px;height:22px;font-size:12px;">✕</button>' +
    '</div>' +
    '<div style="padding:12px 14px;display:flex;flex-direction:column;gap:10px;">' +

            '<div>' +
        '<div style="font-size:9px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:rgba(255,255,255,0.35);margin-bottom:4px;">Resolution</div>' +
        '<select id="' + POP_ID + '_res" ' +
          'style="width:100%;box-sizing:border-box;background:rgba(20,20,30,0.95);border:1px solid rgba(255,255,255,0.14);' +
          'border-radius:9px;color:#fff;font-size:11px;padding:5px 9px;outline:none;font-family:inherit;cursor:pointer;">' +
          (params?.valid_resolutions || []).map(r =>
            '<option value="' + r.name + '" data-source="' + (r.source||'') + '">' + (r.name === 'chunked' ? 'Source' : r.name === 'audio_only' ? 'Audio Only' : r.name) + '</option>'
          ).join('') +
        '</select>' +
      '</div>' +

      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">' +
        '<div style="background:rgba(250,204,21,0.07);border:1px solid rgba(250,204,21,0.2);border-radius:10px;padding:8px 10px;">' +
          '<div style="font-size:9px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:rgba(250,204,21,0.6);margin-bottom:4px;">Start</div>' +
          '<input id="' + POP_ID + '_start" type="text" value="' + fmtTime(clipStart) + '" ' +
            'style="width:100%;box-sizing:border-box;background:transparent;border:none;outline:none;font-size:13px;font-weight:800;color:#facc15;margin-bottom:6px;font-family:inherit;"/>' +
          '<button id="' + POP_ID + '_set_start" style="width:100%;padding:4px;border-radius:7px;font-size:10px;font-weight:800;' +
            'background:rgba(250,204,21,0.25);border:1px solid rgba(250,204,21,0.4);color:#fde68a;cursor:pointer;">Set to Current</button>' +
        '</div>' +
        '<div style="background:rgba(96,165,250,0.07);border:1px solid rgba(96,165,250,0.2);border-radius:10px;padding:8px 10px;">' +
          '<div style="font-size:9px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:rgba(96,165,250,0.6);margin-bottom:4px;">End</div>' +
          '<input id="' + POP_ID + '_end" type="text" value="' + fmtTime(clipEnd) + '" ' +
            'style="width:100%;box-sizing:border-box;background:transparent;border:none;outline:none;font-size:13px;font-weight:800;color:#60a5fa;margin-bottom:6px;font-family:inherit;"/>' +
          '<button id="' + POP_ID + '_set_end" style="width:100%;padding:4px;border-radius:7px;font-size:10px;font-weight:800;' +
            'background:rgba(96,165,250,0.25);border:1px solid rgba(96,165,250,0.4);color:#93c5fd;cursor:pointer;">Set to Current</button>' +
        '</div>' +
      '</div>' +

      '<div style="display:flex;align-items:center;justify-content:space-between;padding:6px 10px;border-radius:9px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07);">' +
        '<span style="font-size:9px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:rgba(255,255,255,0.3);">Duration</span>' +
        '<span id="' + POP_ID + '_duration" style="font-size:13px;font-weight:800;color:rgba(255,255,255,0.75);">' + fmtTime(clipEnd - clipStart) + '</span>' +
      '</div>' +

      '<div style="display:flex;align-items:center;gap:5px;padding:6px 9px;border-radius:9px;' +
        'background:rgba(251,191,36,0.08);border:1px solid rgba(251,191,36,0.22);color:#fde68a;font-size:10px;font-weight:600;">' +
        '<span>⚠️</span><span>Keep this tab open while downloading.</span>' +
      '</div>' +

      '<button id="' + POP_ID + '_single" style="width:100%;padding:9px;border-radius:11px;font-size:12px;font-weight:800;' +
        'background:linear-gradient(135deg,rgba(37,99,235,0.7),rgba(59,130,246,0.7));color:#fff;border:1px solid rgba(99,137,255,0.4);cursor:pointer;' +
        'box-shadow:inset 0 1px 0 rgba(255,255,255,0.12);">💾 Download</button>' +

    '</div>';

  document.body.appendChild(pop);
  // 1.2.6.8: always start on the best quality (Source / highest), never the one that happens to be playing
  { const rs = document.getElementById(POP_ID + '_res');
    if (rs && rs.options.length) {
      const rank = (o) => (o.value === 'chunked' ? 1e9 : o.value === 'audio_only' ? -1 : (parseInt(o.value, 10) || 0) * 1000 + (parseInt(String(o.value).split('p')[1], 10) || 0));
      let bi = 0; [...rs.options].forEach((o, i) => { if (rank(o) > rank(rs.options[bi])) bi = i; });
      rs.selectedIndex = bi;
    } }

  // z-index는 생성 시 지정한 9999999를 그대로 유지 (topZIndexer()로 재할당하지 않음) —
  // 그래야 인라인 VOD 플레이어를 조작해도 이 팝업이 항상 최상단에 남아있음.

  kwsMakeInlineDownloadDraggable(pop, document.getElementById(POP_ID + '_head'));
  document.getElementById(POP_ID + '_close').addEventListener('click', () => { pop.remove(); updateRangeOverlay(null, null); });

  const parseTimeInput = (str) => {
    const parts = str.split(':').map(Number);
    if (parts.length === 3) return parts[0]*3600 + parts[1]*60 + parts[2];
    if (parts.length === 2) return parts[0]*60 + parts[1];
    return parseFloat(str) || 0;
  };

  const updateUI = (skipOverlay) => {
    document.getElementById(POP_ID + '_start').value = fmtTime(clipStart);
    document.getElementById(POP_ID + '_end').value   = fmtTime(clipEnd);
    const dur = clipEnd > clipStart ? clipEnd - clipStart : 0;
    document.getElementById(POP_ID + '_duration').textContent = fmtTime(dur);
    if (!skipOverlay) {
      updateRangeOverlay(clipStart, clipEnd, (s, e) => {
        clipStart = s; clipEnd = e;
        updateUI(true); // 드래그 중엔 오버레이 자체 render()가 이미 갱신했으므로 재생성 생략
      });
    }
  };

  // input 직접 수정 시 반영
  document.getElementById(POP_ID + '_start').addEventListener('change', () => {
    clipStart = parseTimeInput(document.getElementById(POP_ID + '_start').value);
    updateUI();
  });
  document.getElementById(POP_ID + '_end').addEventListener('change', () => {
    clipEnd = parseTimeInput(document.getElementById(POP_ID + '_end').value);
    updateUI();
  });

  document.getElementById(POP_ID + '_set_start').addEventListener('click', () => {
    clipStart = Math.floor(video?.currentTime || 0);
    if (clipEnd <= clipStart) clipEnd = Math.min(clipStart + 300, Math.floor(video?.duration || clipStart + 300));
    updateUI();
  });

  document.getElementById(POP_ID + '_set_end').addEventListener('click', () => {
    clipEnd = Math.floor(video?.currentTime || 0);
    if (clipEnd <= clipStart) clipEnd = clipStart + 1;
    updateUI();
  });

  const holder = ele('div'); a(holder, [['id','download_view_holder']]); holder.style.display = 'none'; pop.appendChild(holder);

  document.getElementById(POP_ID + '_single').addEventListener('click', async () => {
    const resEl = document.getElementById(POP_ID + '_res');
    const selectedOpt = resEl?.options[resEl?.selectedIndex];
    const selectedSource = selectedOpt?.dataset?.source || source;
    const selectedResName = resEl?.value || 'chunked';
    kwsOpenClipDownloaderLegacy({
      ...params,
      source: selectedSource,
      resolution_name: selectedResName,
      start_in: clipStart,
      end_in: clipEnd,
    });
  });

  updateUI();
}

function kwsOpenInlineDownloadPopup(params) {
  const existing = document.getElementById('kws_clip_downloader');
  if (existing) existing.remove();
  kwsOpenClipDownloader(params);
}

// kwsOpenClipDownloaderLegacy는 largeDownload.js에 정의됨


async function buildVideoViewer(params) {
  kwsEnsureInlineVodHotfixStyle();
  document.getElementById('kws_clip_downloader')?.remove();
  updateRangeOverlay(null, null);
  var { channel_login, timestamp, valid_resolutions, title } = params;
  var video_viewer_cont = buildContainer({ top: 22, left: Math.max(18, Math.round(window.innerWidth * 0.30)), container_id: "tvd_video_viewer", background: "rgba(10,12,18,.88)", border_radius: "24px", inner_radius: "20px", header_height: 18, left_panel_width: 18, right_panel_width: 18, footer_height: 18, close_btn_px: 14, parent_elm: document.body, moveable_head: true, movable_left: true, movable_right: false, movable_footer: false, resizeable: true });
  if (video_viewer_cont?.cont && params?.vod_id != null) { video_viewer_cont.cont.dataset.vodId = String(params.vod_id); }

  // ESC로 닫기 — 닫기(✕) 버튼이랑 동일하게 다운로드 팝업/오버레이도 같이 정리
  const escHandler = (e) => {
    if (e.key === 'Escape') {
      video_viewer_cont?.cont?.remove();
      document.getElementById('kws_clip_downloader')?.remove();
      updateRangeOverlay(null, null);
      document.removeEventListener('keydown', escHandler);
    }
  };
  document.addEventListener('keydown', escHandler);

  kwsApplyInlineVodShell(video_viewer_cont, params);
  var video = ele("video");
  video_viewer_cont.menu_body.innerHTML = '';
  video_viewer_cont.menu_body.appendChild(video);
  a(video, [["autoplay", ""], ["webkit-playsinline", ""], ["playsinline", ""], ["class", "pop_out_video"]]);
  // 영상 아무 곳이나 클릭+드래그해도 창 전체가 움직이도록 (팟플레이어 스타일)
  // 단, 일정 거리 이상 움직였을 때만 "드래그"로 인식 — 짧은 클릭은 그대로 재생/정지 토글로 남겨둠
  kwsAttachThresholdDrag(video, video_viewer_cont.cont);

  let tokens = getTokensFromCookies();
  // Kick VOD는 "getTwitchStreamInformation"(Twitch GQL UseLive)을 호출할 이유가 전혀 없음 —
  // channel_login이 Kick 채널 슬러그인데 이걸 Twitch 쪽에 물어보는 것 자체가 틀린 질문이고,
  // 하필 같은 이름의 Twitch 채널이 실제로 방송 중이면 is_live가 true로 잘못 나와서
  // (버퍼링된 live-edge 로직이 오동작해 재생 시작 지점이 영상 끝 근처로 튀거나, 배속이
  // 자동으로 1x로 되돌아가는 등) Kick VOD 재생이 먹통처럼 보이는 원인이 될 수 있었음.
  // → Kick일 땐 이 호출 자체를 건너뛰고 항상 VOD(비라이브)로 취급함.
  var channel_info = is_kick ? null : await requestFromBackground({ cmd: "getTwitchStreamInformation", params: { ...tokens, ...params } });
  var last_resolution = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'last_resolution' } });
  var selected_resolution = last_resolution ? valid_resolutions?.filter(r => r.name == last_resolution)?.[0] || valid_resolutions?.[0] : valid_resolutions?.[0];
  // 1.2.5.17: default quality from the KWS settings ('last' keeps the remembered one above)
  var quality_pref = globalThis.KWSQuality ? await KWSQuality.pref() : 'last';
  if (quality_pref !== 'last' && globalThis.KWSQuality && valid_resolutions?.length) {
    var _hOf = (r) => r?.name == 'audio_only' ? 0 : (parseInt(r?.resolution) || parseInt(r?.name) || (r?.name == 'chunked' ? Infinity : 0));
    selected_resolution = KWSQuality.pick(valid_resolutions, _hOf, quality_pref) || selected_resolution;
  }
  var playlist = await attachSourceToVideoElm({ is_live: !is_kick && channel_info?.is_live === true && channel_info?.stream_id && valid_resolutions?.[0]?.stream_id && (channel_info?.stream_id == valid_resolutions?.[0]?.stream_id), vod: selected_resolution, video: video, cls_btn: video_viewer_cont?.cls_btn, cont: video_viewer_cont?.cont });

  const bar = ele('div'); bar.className = 'kws-vod-glassbar';
  const meta = ele('div'); meta.style.cssText = 'min-width:0;flex:1;cursor:move;';
  meta.setAttribute('data-move_id', video_viewer_cont.cont.id);
  meta.onmouseover = dragElement;
  const titleEl = ele('div'); titleEl.className = 'kws-vod-title'; titleEl.textContent = title || channel_login || 'VOD Player';
  const subEl = ele('div'); subEl.className = 'kws-vod-subtitle'; subEl.textContent = `${channel_login || ''}${timestamp ? ' · ' + dateTimeString(timestamp) : ''}`.replace(/^ · /,'');
  meta.appendChild(titleEl); meta.appendChild(subEl);
  const actions = ele('div'); actions.className = 'kws-vod-actions';
  const resGroup = ele('div'); resGroup.className = 'kws-vod-res-group';
  let current_res_selection = selected_resolution?.name;
  function changeResolutionSelection(elm) { Array.from(resGroup.querySelectorAll('.checked')).forEach((itm) => itm.classList.remove('checked')); elm.classList.add('checked'); }
  (valid_resolutions || []).forEach((r) => {
    const btn = ele('button'); btn.type = 'button'; btn.className = 'kws-vod-pill' + (r.name == current_res_selection ? ' checked' : ''); btn.textContent = r.name == "chunked" ? "Source" : r.name == "audio_only" ? "Audio" : r.name; btn.title = `Switch to ${r.name}`; a(btn, [["data-res_option", r.name]]);
    btn.addEventListener("click", async () => {
      // 1.2.5.19: show the choice at once (the switch itself takes a moment), ignore repeat clicks while it runs
      if (btn.classList.contains('checked') || resGroup.dataset.busy === '1') return;
      const prevBtn = resGroup.querySelector('.checked');
      changeResolutionSelection(btn);
      resGroup.dataset.busy = '1';
      try {
      requestFromBackground({ cmd: 'setLocalStorage', params: { key: 'last_resolution', data: r?.name } });
      let tokens = getTokensFromCookies(); let fresh_channel_info = is_kick ? null : await requestFromBackground({ cmd: "getTwitchStreamInformation", params: { ...tokens, ...params } });
      const res = await attachSourceToVideoElm({ is_live: !is_kick && fresh_channel_info?.is_live === true && fresh_channel_info?.stream_id && r?.stream_id && (fresh_channel_info?.stream_id == r?.stream_id), is_update: true, vod: r, video: video, cls_btn: video_viewer_cont?.cls_btn, cont: video_viewer_cont?.cont });
      if (res) playlist = res; // the download button then uses the new quality's fragments
      else if (prevBtn) changeResolutionSelection(prevBtn); // switch failed: back to the old pill
      } catch (e) { console.warn('[KWS player] resolution switch failed', e); if (prevBtn) changeResolutionSelection(prevBtn); }
      finally { resGroup.dataset.busy = ''; }
    });
    resGroup.appendChild(btn);
  });
  // 🔗 원본 VOD 페이지를 새 탭으로 열기 (SOOP과 동일한 방식 — 예전엔 m3u8 주소를 복사했음)
  //  · Twitch: twitch.tv/videos/{id}?t=현재재생위치 — VOD 번호가 없으면(예: 삭제된 VOD를 CDN에서 복구한 경우) 비활성(회색)
  //  · Kick: 개별 VOD 주소는 공개 데이터로 만들 수 없어서(kickSearcher.js 주석 참고) 채널의 VOD 목록 페이지로 이동
  const copyBtn = ele('button'); copyBtn.type = 'button'; copyBtn.className = 'kws-vod-iconbtn'; copyBtn.textContent = '🔗';
  const _origIdOk = is_kick ? !!channel_login : (!!params?.vod_id && !params?.is_cdn_recovered && /^\d+$/.test(String(params.vod_id)));
  if (_origIdOk) {
    copyBtn.title = is_kick ? 'Open original VOD on Kick at this time (new tab)' : 'Open original VOD on Twitch (new tab)';
    copyBtn.addEventListener('click', async () => {
      const t = Math.max(0, Math.floor(video?.currentTime || 0));
      if (!is_kick) {
        const url = `https://www.twitch.tv/videos/${params.vod_id}` + (t > 0 ? `?t=${Math.floor(t / 3600)}h${Math.floor((t % 3600) / 60)}m${t % 60}s` : '');
        window.open(url, '_blank', 'noopener');
        return;
      }
      // 1.2.5.29 Kick: the VOD page id is a ULID that only /api/v1/video/{video.uuid} gives
      // (livestream.vod_id); the uuid comes from the channel's VOD list (matched by livestream id /
      // m3u8). Page accepts ?t=<seconds>. The tab is opened first (inside the click) so the
      // lookups after it can't trip the popup blocker; anything missing → the channel's VOD list.
      const ch = encodeURIComponent(channel_login);
      const w = window.open('about:blank', '_blank');
      let url = `https://kick.com/${ch}/videos`;
      try {
        const list = await fetch(`https://kick.com/api/v2/channels/${ch}/videos`, { credentials: 'include' }).then((r) => r.json());
        const v = (Array.isArray(list) ? list : []).find((x) => (params?.vod_id != null && String(x.id) === String(params.vod_id)) || (params?.source && x.source === params.source));
        const uuid = v?.video?.uuid;
        if (uuid) {
          const d = await fetch(`https://kick.com/api/v1/video/${encodeURIComponent(uuid)}`, { credentials: 'include' }).then((r) => r.json());
          const ulid = d?.livestream?.vod_id;
          if (ulid) url = `https://kick.com/${ch}/videos/${encodeURIComponent(ulid)}` + (t > 0 ? `?t=${t}` : '');
        }
      } catch (e) { console.warn('[KWS player] Kick VOD link lookup failed', e); }
      if (w) { try { w.opener = null; } catch (_) {} w.location.href = url; } else window.open(url, '_blank', 'noopener');
    });
  } else {
    copyBtn.title = 'Original VOD link unavailable';
    copyBtn.disabled = true;
    copyBtn.style.cssText += 'opacity:0.35;cursor:not-allowed;filter:grayscale(1);';
  }
  const dlBtn = ele('button'); dlBtn.type = 'button'; dlBtn.className = 'kws-vod-iconbtn'; dlBtn.textContent = '⬇'; dlBtn.title = 'Download';
  dlBtn.addEventListener("click", () => {
    const selected = valid_resolutions?.[0];
    const currentSec = Math.floor(video?.currentTime || 0);
    const totalSec = Math.floor(video?.duration || 0);
    const startIn = currentSec;
    const endIn = totalSec ? Math.min(currentSec + 300, totalSec) : currentSec + 300;
    const frags = playlist?.playlist?.data?.fragments || playlist?.data?.fragments;
    const isMp4 = playlist?.playlist?.is_mp4 || playlist?.playlist?.data?.is_mp4 || playlist?.is_mp4 || playlist?.data?.is_mp4;
    const initPath = playlist?.playlist?.data?.init_path || playlist?.data?.init_path;
    kwsOpenInlineDownloadPopup({ ...params, video: video, valid_resolutions: valid_resolutions, channel_login: playlist?.vod?.channel_login || channel_login, timestamp: playlist?.vod?.timestamp || timestamp, source: selected?.source || params?.source, fragments: frags, is_mp4: isMp4, init_path: initPath, start_in: startIn, end_in: endIn });
  });
  const fsBtn = ele('button'); fsBtn.type = 'button'; fsBtn.className = 'kws-vod-iconbtn'; fsBtn.textContent = '⛶'; fsBtn.title = 'Fullscreen'; fsBtn.addEventListener('click', () => { try { video.requestFullscreen(); } catch(e){} });
  try { globalThis.KWSDblSeek && globalThis.KWSDblSeek(video); } catch (_) {} // 1.2.5.45: dbl-click left/right = -/+10 s
  video.addEventListener('dblclick', () => { try { video.requestFullscreen(); } catch(e){} });
  const chatToggleBtn = ele('button'); chatToggleBtn.type = 'button'; chatToggleBtn.className = 'kws-vod-iconbtn'; chatToggleBtn.textContent = '💬'; chatToggleBtn.title = 'Toggle Chat Log';
  chatToggleBtn.addEventListener('click', () => {
    const existing = document.getElementById('tvd_chat_viewer_cont');
    if (existing) { existing.remove(); chatToggleBtn.style.opacity = '0.5'; }
    else if (params?.vod_id) { buildChatContainer({ ...params, ...{video:video} }); chatToggleBtn.style.opacity = '1'; }
  });
  const closeBtn = ele('button'); closeBtn.type = 'button'; closeBtn.className = 'kws-unified-close'; closeBtn.textContent = '✕'; closeBtn.title = 'Close';
  closeBtn.addEventListener('click', () => {
    video_viewer_cont?.cont?.remove();
    // Clip Downloader (시간 선택 팝업)만 같이 닫기 — 다운로드 진행 팝업은 유지
    document.getElementById('kws_clip_downloader')?.remove();
    updateRangeOverlay(null, null);
  });
  // 채팅 동기 재생(💬)은 Twitch 자체 채팅 리플레이 API(ogChat.js/getChatMessages)를 쓰는
  // 기능이라 Kick에서는 그 스크립트 자체를 안 불러옴 — buildChatContainer가 없으면(Kick)
  // 버튼을 아예 안 보여줘서 눌러도 아무 반응 없는 죽은 버튼이 되는 걸 방지함.
  const hasChatReplay = typeof buildChatContainer === 'function';
  actions.appendChild(resGroup); actions.appendChild(copyBtn); actions.appendChild(dlBtn); if (params?.vod_id && hasChatReplay) actions.appendChild(chatToggleBtn); actions.appendChild(fsBtn); actions.appendChild(closeBtn);
  bar.appendChild(meta); bar.appendChild(actions); video_viewer_cont.menu_body.appendChild(bar);
  const resizeHint = ele('div'); resizeHint.className = 'kws-resize-hint'; resizeHint.textContent = '◢'; video_viewer_cont.menu_body.appendChild(resizeHint);
  if(document.getElementById('tvd_chat_viewer_cont')){document.getElementById('tvd_chat_viewer_cont').remove()}
  // Chat은 💬 버튼으로 수동 토글

  // 같은 VOD를 다른 타임스탬프로 다시 열 때(재빌드 없이) 재사용할 seek 함수
  video_viewer_cont.cont._twitchSeekTo = async (targetSecs) => {
    const v = video_viewer_cont.menu_body.querySelector('video.pop_out_video') || document.querySelector('#tvd_video_viewer video');
    if (!v) return false;
    for (let i = 0; i < 15; i++) {
      if (v.readyState >= 2 && v.seekable?.length > 0) break;
      await new Promise(r => setTimeout(r, 200));
    }
    try {
      v.currentTime = targetSecs;
      await new Promise(r => setTimeout(r, 400));
      if (Math.abs(v.currentTime - targetSecs) > 5) v.currentTime = targetSecs;
      v.play?.().catch(() => {});
    } catch (e) { return false; }
    // 실제로 이동했는지 확인 — 그대로면 실패로 간주하고 호출부에서 재빌드로 폴백
    await new Promise(r => setTimeout(r, 300));
    return Math.abs(v.currentTime - targetSecs) <= 8;
  };
}






async function addVODViewButtonToTwitchMenu() {
  await delay(1111);
  var page_channel_login = getChannelLogin();
  var tokens = getTokensFromCookies();
  var vods = await requestFromBackground({ cmd: 'getAvailableVODinfo', params: { ...tokens, ...{ channel_login: page_channel_login } } });
  // console.log({ vods });
  if (/twitch.tv\/videos\/\d+/.test(window.location.href)) {
    let vod_id = /(?<=twitch.tv\/videos\/)\d+/.exec(window.location.href)?.[0];
    let vod = vods.filter(r => r.vod_id == vod_id)?.[0];
    let second_vod_view_btn = await addViewVODBtnToLayoutBar();

    if(!vod){
      let highlight = await getCurrentVODHighlightSource();
      // console.log(highlight);
      second_vod_view_btn.addEventListener('click', async () => {
        runTwitchSourceBuild({ ...highlight, ...{ ref_elm: second_vod_view_btn?.parentElement } });
      });
    }else{
      second_vod_view_btn.addEventListener('click', async () => {
        runTwitchSourceBuild({ ...vod, ...{ ref_elm: second_vod_view_btn?.parentElement } });
      });
    }
  }
}




var current_href = window.location.href;

async function pageStateChange(){
  await delay(1111);
  if(current_href != window.location.href){
    // console.log(current_href, window.location.href);
    // 이 Twitch 자체 메뉴 버튼 삽입 계열(addVODViewBypass 등)은 전부 내부적으로
    // window.location.href가 twitch.tv/.../videos/... 등 Twitch 전용 패턴일 때만
    // 실제로 동작하도록 되어 있어서 Kick에서 호출해도 안전하긴 하지만, 그때마다
    // Twitch GQL로 불필요한 네트워크 요청이 나가므로 아예 is_twitch일 때만 실행함 —
    // Kick 쪽 인라인 플레이어(검색 결과 클릭)는 이 경로를 타지 않고 kickSearcher.js의
    // runKickSourceBuild → buildVideoViewer로 별도로 열림.
    if (is_twitch) {
      addVODViewBypass();
      addVODViewButtonToTwitchMenu();
      resetMainBtnIndexForTheatreMode();
      addDownloadStoryBtn();
    }
    current_href = window.location.href;
    if(document.getElementById('tvd_main_cont')){
      document.getElementById('tvd_main_cont').remove()
    }
    if(document.getElementById('tvd_recent_streams_cont')){
      document.getElementById('tvd_recent_streams_cont').remove()
    }
  }
}


if(!/twitch\.tv\/popout\/\w+\/\w+/.test(window.location.href) && /twitch\.tv|kick\.com/.test(window.location.href)){//|kick\.com
  document.body.addEventListener('keyup', removeMainBtnZindex);
  document.body.addEventListener('click', pageStateChange)
  window.addEventListener("load", async ()=>{
   let color_settings = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'main_app_colors' } });
   if(color_settings == 'darkmode'){
     color_mode = 'darkmode';
   }else{
     color_mode = 'lightmode'
   }
    await delay(10);
    if (is_twitch) {
      addVODViewBypass();
      addVODViewButtonToTwitchMenu();
      addDownloadStoryBtn();
    }
    setCSS('tvd_main_app_css',getMainAppCss());
    setCSS('tvd_logo_app_css', getLogoCSS())
    // addInitTVDBtn(); // 예전 VOD 파인더 위젯 — KWS 생기기 전 구버전 UI라 제거함
  });

}

if(/(voddownloader\.com)\/\?data\=/.test(window.location.href)){
  window.addEventListener("load", async ()=> {
    let color_settings = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'main_app_colors' } });
    if(color_settings == 'darkmode'){
      color_mode = 'darkmode';
    }else{
      color_mode = 'lightmode'
    }
    let data = atobJSON(/(?<=data\=).+/.exec(window.location.href)?.[0]);
    buildDownloadVODUI({
      start_in:'downloads',
      filename:data.filename,
      channel_login:data?.channel_login,
      timestamp:data?.timestamp,
      resolution:data?.resolution,
      // fragments: playlist?.playlist?.data?.fragments,
      source: data?.source,
      // parent_elm:video_viewer_cont.menu_body,
      // actor:dl_btn,
    });
    setCSS('tvd_main_app_css',getMainAppCss());
  });

}
