// KWS 1.2.5 — data folder (shared by the background service worker and the side panel).
//
// The user picks a folder once (side panel → settings). From then on everything KWS keeps —
// the four platform histories, keywords and settings — is written to <folder>/kws-data.json
// whenever it changes, plus one dated copy per day in <folder>/backups/ (the newest 14 are kept).
// After a reinstall the user picks the same folder again and the data comes back on its own.
//
// The file holds the chrome.storage values as they are (same keys and shapes as 1.2.4), so a
// restore is exact. Directory handle: IndexedDB "kws-sp" / store "kv" / key "dataDir".
(function (root) {
  'use strict';

  const FILE_NAME = 'kws-data.json';
  const BACKUP_DIR = 'backups';
  const BACKUP_KEEP = 14;
  const SCHEMA = 'kws-data.v1';
  const STATUS_KEY = 'kwsSpDataStatus';
  const DIRTY_KEY = 'kwsSpDataDirty'; // true = changes the background could not write yet // { state: 'none'|'ok'|'needsPermission'|'error', name, savedAt, error }

  const HISTORY_KEYS = ['twitchKwsHistory', 'kickKwsHistory', 'soopSearchHistory', 'ytKwsHistory', 'chzzkKwsHistory'];
  // 1.2.4 settings (same list as commonHistory.js) + the 1.2.5 panel settings.
  const SETTING_KEYS = ['kickKwsSettings', 'kwsLogSource', 'kwsJustlogUrl', 'kwsAutoCloseNoResult', 'kickKwsAutoCloseNoResult',
    'soopSearchSubtitles', 'soopAutoCloseNoResult', 'soopFetchMode', 'twitchKwsKeywordProfile', 'kwsKeyword', 'soopKeyword',
    'soopStartDate', 'soopEndDate', 'soopSaveTxt', 'ytKwsSettings',
    'kwsSpDefaultRange', 'kwsSpBadgeRedDays', 'kwsSpTranslateLang', 'kwsSpTheme', 'kwsSpBadgeClick', 'kwsSpScanOpts', 'kwsSpDefaultQuality', 'soopLastQuality', 'chzzkLastQuality'];
  const DATA_KEYS = HISTORY_KEYS.concat(SETTING_KEYS);

  // ── IndexedDB (the directory handle survives restarts; the permission may not) ──
  function idb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open('kws-sp', 1);
      req.onupgradeneeded = () => req.result.createObjectStore('kv');
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  async function kvGet(key) {
    const db = await idb();
    return new Promise((resolve, reject) => {
      const r = db.transaction('kv').objectStore('kv').get(key);
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  }
  async function kvSet(key, value) {
    const db = await idb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('kv', 'readwrite');
      if (value === undefined) tx.objectStore('kv').delete(key); else tx.objectStore('kv').put(value, key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
  const getHandle = () => kvGet('dataDir').catch(() => null);
  const setHandle = (h) => kvSet('dataDir', h);

  async function permission(handle) {
    try { return await handle.queryPermission({ mode: 'readwrite' }); } catch (_) { return 'prompt'; }
  }

  async function snapshot() {
    const got = await chrome.storage.local.get(DATA_KEYS);
    const keys = {};
    for (const k of DATA_KEYS) if (got[k] !== undefined) keys[k] = got[k];
    return { schema: SCHEMA, app: 'KWS', version: chrome.runtime.getManifest().version, savedAt: new Date().toISOString(), keys };
  }

  function countRecords(keys) {
    let n = 0;
    for (const k of HISTORY_KEYS) {
      const h = keys && keys[k];
      if (h && typeof h === 'object') n += Object.keys(h).filter((id) => !id.startsWith('_') && h[id] && typeof h[id] === 'object').length;
    }
    return n;
  }
  async function isEmpty() {
    const got = await chrome.storage.local.get(HISTORY_KEYS.concat(['twitchKwsKeywordProfile']));
    return countRecords(got) === 0 && !(got.twitchKwsKeywordProfile && got.twitchKwsKeywordProfile.keyword);
  }

  async function writeText(dir, name, text) {
    const fh = await dir.getFileHandle(name, { create: true });
    const w = await fh.createWritable();
    await w.write(text);
    await w.close();
  }
  async function readFile(dir) {
    try {
      const fh = await dir.getFileHandle(FILE_NAME);
      const text = await (await fh.getFile()).text();
      const data = JSON.parse(text);
      return data && data.schema === SCHEMA && data.keys ? data : null;
    } catch (_) { return null; }
  }
  const dayStamp = (d = new Date()) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');

  async function pruneBackups(dir) {
    const names = [];
    for await (const [name, h] of dir.entries()) if (h.kind === 'file' && /^kws-data-\d{4}-\d{2}-\d{2}\.json$/.test(name)) names.push(name);
    names.sort().reverse();
    for (const name of names.slice(BACKUP_KEEP)) { try { await dir.removeEntry(name); } catch (_) {} }
  }

  // Save everything now. Returns the new status.
  // opts.quiet: when this context has no permission, report it without touching the status line
  // (the background may lack the grant the open side panel holds — the panel then saves instead).
  async function save(handle, opts) {
    handle = handle || await getHandle();
    if (!handle) return setStatus({ state: 'none' });
    if (await permission(handle) !== 'granted') {
      const st = { state: 'needsPermission', name: handle.name };
      return opts && opts.quiet ? st : setStatus(st);
    }
    try {
      const snap = await snapshot();
      // Never replace a file that holds records with an empty data set (storage wiped by
      // something else): the file is what brings the data back.
      if (!countRecords(snap.keys)) {
        const existing = await readFile(handle);
        if (existing && countRecords(existing.keys)) return setStatus({ state: 'ok', name: handle.name, savedAt: existing.savedAt, keptFile: true });
      }
      const text = JSON.stringify(snap, null, 1);
      await writeText(handle, FILE_NAME, text);
      const backups = await handle.getDirectoryHandle(BACKUP_DIR, { create: true });
      await writeText(backups, 'kws-data-' + dayStamp() + '.json', text);
      await pruneBackups(backups);
      return setStatus({ state: 'ok', name: handle.name, savedAt: new Date().toISOString() });
    } catch (e) {
      return setStatus({ state: 'error', name: handle.name, error: String((e && e.message) || e) });
    }
  }

  // Keep a copy of the file that is about to be replaced (used when connecting a folder that
  // already holds different data and the user chooses to overwrite it).
  async function backupExisting(handle) {
    try {
      const fh = await handle.getFileHandle(FILE_NAME);
      const text = await (await fh.getFile()).text();
      const backups = await handle.getDirectoryHandle(BACKUP_DIR, { create: true });
      const d = new Date();
      await writeText(backups, 'kws-data-replaced-' + dayStamp(d) + '-' + String(d.getHours()).padStart(2, '0') + String(d.getMinutes()).padStart(2, '0') + '.json', text);
    } catch (_) {}
  }

  // Put a kws-data.json back into chrome.storage. mode 'replace' = exactly as saved (empty
  // install); 'merge' = keep what is here, add the file's history entries this browser does not
  // have (or has older), and fill only settings that are not set here.
  async function restore(data, mode) {
    const keys = (data && data.keys) || {};
    const set = {};
    if (mode === 'replace') {
      for (const k of DATA_KEYS) if (keys[k] !== undefined) set[k] = keys[k];
    } else {
      const cur = await chrome.storage.local.get(DATA_KEYS);
      for (const k of HISTORY_KEYS) {
        const from = keys[k];
        if (!from || typeof from !== 'object') continue;
        const out = Object.assign({}, cur[k] || {});
        for (const [id, rec] of Object.entries(from)) {
          const mine = out[id];
          const t = (r) => String((r && (r.searchedAt || r.savedAt)) || '');
          if (!mine || (rec && typeof rec === 'object' && t(rec) > t(mine))) out[id] = rec;
        }
        set[k] = out;
      }
      for (const k of SETTING_KEYS) if (cur[k] === undefined && keys[k] !== undefined) set[k] = keys[k];
    }
    await chrome.storage.local.set(set);
    return countRecords(keys);
  }

  async function setStatus(st) {
    try { await chrome.storage.local.set({ [STATUS_KEY]: st }); } catch (_) {}
    return st;
  }

  root.KWSDataFolder = {
    FILE_NAME, BACKUP_DIR, BACKUP_KEEP, SCHEMA, STATUS_KEY, DIRTY_KEY, DATA_KEYS, HISTORY_KEYS,
    getHandle, setHandle, permission, snapshot, save, readFile, restore, backupExisting, isEmpty, countRecords, setStatus,
  };
})(typeof self !== 'undefined' ? self : this);
