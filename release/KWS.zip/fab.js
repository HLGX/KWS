// KWS 1.2.5 — floating "open KWS" button on supported sites.
// A tab that sits on the right edge of the page (not bottom-right, where Twitch/Kick put the
// chat input). Drag it up or down to move it; the position is remembered per site.
// Hidden while the side panel is open in this window.
(function () {
  'use strict';
  if (window.top !== window || window.__kwsFab) return;
  window.__kwsFab = true;

  const info = globalThis.KWSPlatform && KWSPlatform.parseVodUrl(location.href);
  if (!info) return;

  const COLORS = {
    soop: ['#2563EB', '#FFFFFF'],
    kick: ['#53FC18', '#0B0B0B'],
    twitch: ['#9146FF', '#FFFFFF'],
    youtube: ['#FF0000', '#FFFFFF'],
    chzzk: ['#00FFA3', '#04130D'],
  };
  const [accent, on] = COLORS[info.platform];
  const POS_KEY = 'kwsFabTop';
  const msg = (k) => {
    try { return chrome.i18n.getMessage(k) || k; } catch (_) { return k; }
  };

  const host = document.createElement('div');
  host.id = 'kws-fab-host';
  host.style.cssText = 'all:initial;position:fixed;right:0;top:50%;z-index:2147483646;';
  const shadow = host.attachShadow({ mode: 'closed' });
  shadow.innerHTML = `
    <style>
      :host { all: initial; }
      .wrap { display: flex; align-items: center; gap: 10px; transform: translateY(-50%); }
      .tip {
        opacity: 0; pointer-events: none; transition: opacity .15s;
        font: 500 13px/1 system-ui, "Segoe UI", "Malgun Gothic", sans-serif;
        background: #FFFFFF; color: #1F1F1F; padding: 8px 12px; border-radius: 10px;
        box-shadow: 0 4px 16px rgba(0,0,0,.35); white-space: nowrap;
      }
      .wrap:hover .tip, .wrap:focus-within .tip { opacity: 1; }
      button {
        width: 44px; height: 52px; border: 0; padding: 0 0 0 4px; cursor: grab;
        border-radius: 26px 0 0 26px; display: flex; align-items: center; justify-content: center;
        background: ${accent}; color: ${on};
        box-shadow: 0 6px 20px rgba(0,0,0,.45); transition: width .15s;
        touch-action: none;
      }
      button:hover { width: 50px; }
      button:active { cursor: grabbing; }
      button:focus-visible { outline: 2px solid #FFFFFF; outline-offset: -4px; }
    </style>
    <div class="wrap">
      <span class="tip"></span>
      <button type="button">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/></svg>
      </button>
    </div>`;
  const btn = shadow.querySelector('button');
  shadow.querySelector('.tip').textContent = msg('fabOpen');
  btn.setAttribute('aria-label', msg('fabAria'));

  // Remembered vertical position (localStorage: chrome.storage is not reliable in every
  // content-script context on these sites, see the SOOP note in the 1.2.4 code).
  function clampTop(px) {
    const margin = 40;
    return Math.min(Math.max(px, margin), window.innerHeight - margin);
  }
  let ratio = 0.5;
  try {
    const saved = parseFloat(localStorage.getItem(POS_KEY));
    if (saved > 0 && saved < 1) ratio = saved;
  } catch (_) {}
  host.style.top = clampTop(ratio * window.innerHeight) + 'px';

  // Drag vertically; a press without movement is a click.
  let drag = null;
  btn.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    drag = { y0: e.clientY, top0: parseFloat(host.style.top), moved: false };
    btn.setPointerCapture(e.pointerId);
  });
  btn.addEventListener('pointermove', (e) => {
    if (!drag) return;
    const dy = e.clientY - drag.y0;
    if (!drag.moved && Math.abs(dy) < 5) return;
    drag.moved = true;
    host.style.top = clampTop(drag.top0 + dy) + 'px';
  });
  btn.addEventListener('pointerup', (e) => {
    if (!drag) return;
    const moved = drag.moved;
    drag = null;
    try { btn.releasePointerCapture(e.pointerId); } catch (_) {}
    if (moved) {
      try { localStorage.setItem(POS_KEY, String(parseFloat(host.style.top) / window.innerHeight)); } catch (_) {}
      return;
    }
    openPanel();
  });
  btn.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openPanel(); }
  });

  function openPanel() {
    // The background calls sidePanel.open() straight away, inside this click's user gesture.
    try {
      chrome.runtime.sendMessage({ type: 'KWS_SP_OPEN' }).catch(() => {});
    } catch (_) {
      // Extension was reloaded/updated while this page stayed open: the old content script is orphaned.
      host.remove();
    }
  }

  function setPanelOpen(open) {
    host.style.display = open ? 'none' : '';
  }

  chrome.runtime.onMessage.addListener((m) => {
    if (m && m.type === 'KWS_SP_STATE') setPanelOpen(!!m.open);
  });

  function refreshState() {
    try {
      chrome.runtime.sendMessage({ type: 'KWS_SP_GET_STATE' })
        .then((r) => setPanelOpen(!!(r && r.open)))
        .catch(() => {});
    } catch (_) {}
  }
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshState(); });
  window.addEventListener('resize', () => { host.style.top = clampTop(parseFloat(host.style.top)) + 'px'; });

  (document.body || document.documentElement).appendChild(host);
  refreshState();
})();
