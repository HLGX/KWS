
// 1.2.5: red badge threshold from the side panel settings (kwsSpBadgeRedDays, default 14 as in 1.2.4)
try { chrome.storage.local.get('kwsSpBadgeRedDays').then((d) => { if (Number.isFinite(d.kwsSpBadgeRedDays)) globalThis.__kwsRedDays = d.kwsSpBadgeRedDays; }); chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && c.kwsSpBadgeRedDays) globalThis.__kwsRedDays = c.kwsSpBadgeRedDays.newValue; }); } catch (_) {} try { chrome.storage.local.get('kwsSpBadgeClick').then((d) => { globalThis.__kwsBadgeClick = d.kwsSpBadgeClick || 'ask'; }); chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && c.kwsSpBadgeClick) globalThis.__kwsBadgeClick = c.kwsSpBadgeClick.newValue || 'ask'; }); } catch (_) {}
// ── KWS 페이지 이탈 방지 ──
const _kwsTwitchBeforeUnload = e => { e.preventDefault(); e.returnValue = ''; };
function kwsTwitchSetPageGuard(active) {
  if (active) window.addEventListener('beforeunload', _kwsTwitchBeforeUnload);
  else window.removeEventListener('beforeunload', _kwsTwitchBeforeUnload);
}

/* ============================================================
   KWS 1.2.0 — Twitch module
   - SOOP-style floating panel UI
   - Per-tab independent progress (each channel has its own state)
   - Badge click = immediate scan
   - Real-time result display
   - VOD popup inside panel
   ============================================================ */
(function () {
  'use strict';

  const PANEL_ID    = 'twitch-kws-panel';
  const HISTORY_KEY = 'twitchKwsHistory';
  const KEYWORD_PROFILE_KEY = 'twitchKwsKeywordProfile';
  const TRANSLATE_LANG_KEY = 'twitchKwsTranslateLangV2';
  const KWS_AUTO_CLOSE_KEY = 'kwsAutoCloseNoResult';
  let kwsAutoCloseNoResult = false;

  const DEFAULT_POS = { right: 20, bottom: 20 };

  // ── Per-channel scan states ────────────────────────────────
  // SCAN_STATES[channel] = { scanId, running, percent, done, total,
  //   matchedDays, matchedLines, message, keywords, startDate, endDate }
  const SCAN_STATES = {};

  // ── Result tabs ────────────────────────────────────────────
  // Each tab: { channel, live, groups:[], matchedLines, scanId }
  const RESULT_TABS = [];
  let ACTIVE_TAB = -1;

  // ── History ────────────────────────────────────────────────
  let HISTORY = {};

  // ── Global keyword / date inputs (used for badge-triggered scans) ─
  let GLOBAL_KEYWORD    = '';
  let LOG_SOURCE        = 'zonian'; // 'zonian' (External) | 'twitch' (Native) | 'combined_fast' | 'combined' (Accurate)
  let GLOBAL_START_DATE = '';
  let GLOBAL_END_DATE   = '';

  // ── Overload / Queue state ────────────────────────────────
  const OVERLOAD = {
    throttled: false,
    throttleUntil: 0,
    activeChannels: [],
    queue: [],           // [{ channel, tabId }]
    avgFetchMs: 0,
  };

  // 1.2.5: scanning lives in the side panel (scan_hub.js). The page keeps the site badges,
  // ?kws_autoscan=1, external scan requests and the inline VOD player; the old panel is not built.
  const SP_MODE = true;
  const SP_SCANS_KEY = 'kwsSpScans';
  let SP_HUB = {};
  const spEntry = (slug) => SP_HUB['twitch:' + slug];
  // Badge state in the 1.2.4 SCAN_STATES shape, read from the hub in SP mode.
  function badgeState(slug) {
    if (!SP_MODE) return SCAN_STATES[slug];
    const e = spEntry(slug);
    if (!e) return null;
    if (e.status === 'queued') return { queued: true, message: 'Queued' };
    if (e.status !== 'running') return null;
    const percent = e.total ? Math.min(100, Math.round((e.done || 0) / e.total * 100)) : 0;
    return { running: true, percent, done: e.done || 0, total: e.total || 0, matchedLines: e.matchedLines || 0 };
  }

  function spBadgeScan(slug, { auto = false } = {}) {
    const send = (mode) => {
      try { chrome.runtime.sendMessage({ type: 'KWS_SP_BADGE_SCAN', platform: 'twitch', channel: slug, mode, openPanel: !auto }).catch(() => {}); } catch (_) {}
    };
    const h = HISTORY[String(slug).toLowerCase()];
    const pref = globalThis.__kwsBadgeClick; // settings: 'ask' (popup) / 'new' / 'full'
    if (!auto && h?.lastDate && (pref === 'new' || pref === 'full')) send(pref);
    else if (!auto && h?.lastDate && typeof window.showRescanPopup === 'function') {
      window.showRescanPopup(slug, '', h.nickname || slug, h.lastDate, () => send('full'), () => send('new'));
    } else {
      send('full');
    }
  }

  async function spOpenVodFromPanel(item) {
    const channel = (item.vod_channel || guessChannelFromUrl() || '').toLowerCase();
    const date = item._date || item.localDate || '';
    try {
      await openVODInlineAtTimestamp({
        btn: null, channel, date, sourceDate: item._sourceDate || date,
        rawTs: item.rawTs, ts: item.ts, playback_offset: item.playback_offset ?? null,
        vod_id: item.vod_id ?? null, cdn_source: item.cdn_source ?? null,
      });
    } catch (e) {
      alert((e && e.message) || String(e)); // 1.2.6.7: the panel asks "Try native / StreamRecorder" up front instead
    }
    // clickedTimes, same key as the 1.2.4 timestamp buttons
    const tsKey = item.ts || item.rawTs || item.timestamp || '';
    if (channel && tsKey) {
      const cur = HISTORY[channel] || {};
      const clicked = { ...(cur.clickedTimes || {}), [tsKey]: true };
      await saveHistory(channel, { ...cur, clickedTimes: clicked });
    }
  }

  async function spOpenUrlFromPanel(raw) {
    const idMatch = /videos\/(\d+)/.exec(raw) || /^(\d{6,})$/.exec(String(raw).trim());
    const vodId = idMatch?.[1];
    if (!vodId) { alert('Could not find a Twitch VOD ID in that input.'); return; }
    try {
      const source = await requestFromBackground({ cmd: 'getOfficialVodM3u8Source', params: { vod_id: vodId } });
      if (!source) { alert('Could not load that VOD — it may be deleted or private.'); return; }
      await getStreamInformationAndBuildUI({ source, vod_id: vodId, timestamp: Date.now(), ref_elm: document.body });
    } catch (e) { alert('Failed to open VOD: ' + e.message); }
  }

  async function spInit() {
    HISTORY = await loadHistory();
    try { SP_HUB = (await chrome.storage.session.get(SP_SCANS_KEY))[SP_SCANS_KEY] || {}; } catch (_) {}
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'session' && changes[SP_SCANS_KEY]) { SP_HUB = changes[SP_SCANS_KEY].newValue || {}; injectSiteBadges(); }
      if (area === 'local' && changes.twitchKwsHistory) { HISTORY = changes.twitchKwsHistory.newValue || {}; injectSiteBadges(); }
    });
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (!msg) return;
      if (msg.type === 'KWS_EXTERNAL_QUEUE_SCAN' || msg.type === 'KWS_SET_CHANNEL_AND_SCAN') {
        const ch = String(msg.channel || msg.slug || '').toLowerCase().trim();
        if (ch) spBadgeScan(ch);
        return;
      }
      if (msg.platform !== 'twitch') return;
      if (msg.type === 'KWS_SP_OPEN_VOD') {
        spOpenVodFromPanel(msg.item || {}).catch((e) => console.warn('[KWS Twitch] open VOD failed', e));
        sendResponse({ ok: true });
      } else if (msg.type === 'KWS_SP_OPEN_URL') {
        spOpenUrlFromPanel(String(msg.raw || '')).catch((e) => console.warn('[KWS Twitch] open URL failed', e));
        sendResponse({ ok: true });
      }
    });
    const autoScanCh = guessChannelFromUrl();
    if (autoScanCh && /(?:^|[?&])kws_autoscan=1(?:&|$)/.test(location.search)) {
      try { history.replaceState(null, '', location.pathname + location.hash); } catch (e) {}
      setTimeout(() => spBadgeScan(autoScanCh, { auto: true }), 300);
    }
    [0, 500, 1000, 2000, 4000].forEach(d => setTimeout(() => injectSiteBadges(), d));
    new MutationObserver(() => injectSiteBadges()).observe(document.body, { childList: true, subtree: true });
  }

  init();

  async function init() {
    if (SP_MODE) return spInit();
    HISTORY = await loadHistory();
    createPanel();
    await restoreUiValues();
    updateActiveTabUI();

    // streamrecorder.io 뱃지에서 ?kws_autoscan=1 로 넘어온 경우 — 채널 ID만 채워놓고 마는 게
    // 아니라 바로 스캔을 시작함. history.replaceState로 쿼리스트링을 지워서 새로고침/뒤로가기
    // 했을 때 또 스캔이 시작되지 않게 함.
    {
      const autoScanCh = guessChannelFromUrl();
      if (autoScanCh && /(?:^|[?&])kws_autoscan=1(?:&|$)/.test(location.search)) {
        try { history.replaceState(null, '', location.pathname + location.hash); } catch (e) {}
        setTimeout(() => triggerBadgeScan(autoScanCh), 300);
      }
    }

    renderOverloadBanner(); // Initial banner render
    [0, 500, 1000, 2000, 4000].forEach(d => setTimeout(() => injectSiteBadges(), d));
    const obs = new MutationObserver(() => injectSiteBadges());
    obs.observe(document.body, { childList: true, subtree: true });

    // Sync Twitch UI when keyword saved from another tab
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      // twitchKwsHistory 변경 시 HISTORY 갱신 (다른 탭/플랫폼에서 Import 시)
      if (changes.twitchKwsHistory) {
        const newH = changes.twitchKwsHistory.newValue || {};
        Object.assign(HISTORY, newH);
        injectSiteBadges();
        if (window._twitchHistoryRender) window._twitchHistoryRender();
      }
      if (!changes.twitchKwsKeywordProfile) return;
      const profile = changes.twitchKwsKeywordProfile.newValue;
      if (!profile?.keyword) return;
      // Skip if saved from this tab (already applied)
      if (profile.keyword === GLOBAL_KEYWORD) return;
      GLOBAL_KEYWORD = profile.keyword;
      HISTORY.__keyword_profile__ = profile;
      const kwEl = document.getElementById('kws-keyword');
      if (kwEl) kwEl.value = profile.keyword;
      updateKeywordPreview(id => document.getElementById(id));
    });

    // Sync auto-close / search-engine settings when changed elsewhere (e.g. History Import)
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      if (changes.kwsAutoCloseNoResult) {
        kwsAutoCloseNoResult = !!changes.kwsAutoCloseNoResult.newValue;
        const cb = document.getElementById('kws-auto-close-no-result');
        if (cb) cb.checked = kwsAutoCloseNoResult;
      }
    });

    chrome.runtime.onMessage.addListener((msg) => {
      // streamrecorder.io 뱃지 — 이미 트위치 탭이 열려있으면 새 탭 대신 여기로 라우팅됨
      // (background.js의 KWS_SR_REQUEST_SCAN 처리 참고). triggerBadgeScan이 큐잉까지 처리.
      if (msg.type === 'KWS_EXTERNAL_QUEUE_SCAN') {
        const ch = (msg.channel || '').toLowerCase().trim();
        if (ch) triggerBadgeScan(ch);
        return;
      }
      if (msg.type === 'KWS_SCAN_STARTED')  handleScanStarted(msg);
      if (msg.type === 'KWS_SCAN_PROGRESS') handleScanProgress(msg);
      if (msg.type === 'KWS_SCAN_COMPLETE') handleScanComplete(msg);
      if (msg.type === 'KWS_SCAN_ERROR')    handleScanError(msg);
      if (msg.type === 'KWS_QUEUED')        handleScanQueued(msg);
      if (msg.type === 'KWS_SCAN_STOPPED')  { STOPPING_CHANNELS.delete((msg.channel || '').toLowerCase().trim()); }
      if (msg.type === 'KWS_SET_CHANNEL_AND_SCAN') {
        const { slug } = msg;
        if (!slug) return;

        // 채널 입력
        const chInput = document.getElementById('kws-channel');
        if (chInput) { chInput.value = slug; chInput.dispatchEvent(new Event('input')); }

        // 키워드 없으면 키워드 버튼 열기
        const kw = GLOBAL_KEYWORD || document.getElementById('kws-keyword')?.value?.trim() || '';
        if (!kw) { document.getElementById('kws-keyword-btn')?.click(); return; }

        // 패널 열기
        const panel = document.getElementById('kws-panel');
        if (panel && panel.style.display === 'none') document.getElementById('kws-toggle-btn')?.click();

        // hasHistory는 호출자(트위치트래커/streamrecorder.io) 쪽에서 항상 false/누락으로만
        // 보내와서 이 분기가 사실상 죽은 코드였음 — 대신 이 탭이 실제로 갖고 있는 HISTORY로
        // 직접 판단함.
        const h = HISTORY[slug.toLowerCase()];
        if (h?.lastDate) {
          // 히스토리 있으면 팝업 표시 (Full rescan / New only)
          showRescanPopup(slug, kw, h.nickname || slug, h.lastDate,
            () => { startScan({ channel: slug, keyword: kw, startDate: fmtDate(new Date(Date.now() - 60 * 86400000)), endDate: '', nick: null }); },
            () => { startScan({ channel: slug, keyword: kw, startDate: h.lastDate, endDate: '', nick: null }); }
          );
        } else {
          // 처음 검색하는 채널이면 패널에 그대로 남아있을 수 있는(완전히 다른 채널을 스캔했을
          // 때 저장된) 예전 시작 날짜를 물려받지 않도록, 항상 최근 60일로 리셋한 뒤 스캔함 —
          // 안 그러면 예전에 어떤 채널을 "전체 기록"으로 한 번 훑었을 때의 시작 날짜(예: 5월)가
          // 그대로 남아있다가, 전혀 관계없는 새 채널을 뱃지로 스캔할 때도 그 옛날 날짜까지
          // 거슬러 올라가서 검색해버리는 문제가 있었음.
          const freshStartDate = fmtDate(new Date(Date.now() - 60 * 86400000));
          const sdInput = document.getElementById('kws-start-date');
          if (sdInput) sdInput.value = freshStartDate;
          GLOBAL_START_DATE = freshStartDate;
          document.getElementById('kws-start-btn')?.click();
        }
      }
      if (msg.type === 'KWS_OVERLOAD_STATE') handleOverloadState(msg);
      if (msg.type === 'KWS_QUEUE_UPDATE')  handleQueueUpdate(msg);
    });

    // Poll background for status on init (in case extension was reloaded mid-scan)
    chrome.runtime.sendMessage({ type: 'KWS_GET_STATUS' }, res => {
      if (res) handleOverloadState({ ...res, type: 'KWS_OVERLOAD_STATE' });
    });
  }

  // ══════════════════════════════════════════════════════════
  //  HISTORY
  // ══════════════════════════════════════════════════════════
  async function loadHistory() {
    try { const d = await chrome.storage.local.get(HISTORY_KEY); return d[HISTORY_KEY] || {}; }
    catch { return {}; }
  }
  async function saveHistory(channel, data) {
    const key = (channel || '').toLowerCase().trim();
    HISTORY[key] = { ...(HISTORY[key] || {}), ...data, searchedAt: new Date().toISOString() };
    try { await chrome.storage.local.set({ [HISTORY_KEY]: HISTORY }); } catch {}
    injectSiteBadges();
  }
  function getHistoryText(channel) {
    const h = HISTORY[(channel || '').toLowerCase().trim()];
    if (!h) return null;
    const when = h.searchedAt
      ? new Date(h.searchedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
      : '?';
    return `Last: ${when} · ${h.matchedLines || 0} hits · ${h.matchedDays || 0} days`;
  }

  // ══════════════════════════════════════════════════════════
  //  OVERLOAD / QUEUE HANDLERS
  // ══════════════════════════════════════════════════════════

  function handleScanQueued(msg) {
    const ch = (msg.channel || '').toLowerCase().trim();
    if (!ch) return;

    // Mark channel state as queued
    SCAN_STATES[ch] = SCAN_STATES[ch] || {};
    const s = SCAN_STATES[ch];
    s.running  = false;
    s.queued   = true;
    s.percent  = 0;
    if (msg.scanId) s.scanId = msg.scanId; // 대기 중부터 이 요청의 scanId를 기억 — 이전 스캔의 메시지가 섞이지 않게
    s.message  = `⏳ Queued (pos ${msg.queuePos}) — ${msg.reason || 'waiting for slot'}`;

    // Find or create tab for this channel
    let tabIdx = RESULT_TABS.findIndex(t => t.channel === ch);
    if (tabIdx < 0) {
      tabIdx = RESULT_TABS.length;
      RESULT_TABS.push({ channel: ch, live: false, queued: true, groups: [], matchedLines: 0 });
    } else {
      RESULT_TABS[tabIdx].queued = true;
    }
    ACTIVE_TAB = tabIdx;

    renderResultTabs();
    renderFullResultList();
    updateActiveTabUI();
    renderOverloadBanner();
  }

  function handleOverloadState(msg) {
    OVERLOAD.throttled     = !!msg.throttled;
    OVERLOAD.throttleUntil = msg.throttleUntil || 0;
    OVERLOAD.activeChannels = msg.activeChannels || [];
    OVERLOAD.avgFetchMs    = msg.avgFetchMs || 0;
    renderOverloadBanner();
  }

  function handleQueueUpdate(msg) {
    OVERLOAD.queue          = msg.queue || [];
    OVERLOAD.activeChannels = msg.activeChannels || [];

    // (예전엔 여기서 'activeChannels에 이름이 있으면 시작된 것'으로 보고 queued를 내렸는데,
    //  같은 채널의 이전 스캔이 아직 정리 중이면 이름이 겹쳐서 실제로는 대기 중인 새 스캔의
    //  queued 표시가 사라지고, 그러면 재검색 팝업도 안 뜨고 탭도 대기/실행 어느 쪽으로도 안 보였음.
    //  시작 여부는 KWS_SCAN_STARTED로만 판단하고, 대기열에서 빠졌는지로만 queued를 내림.)
    // Remove queued state if no longer in background queue
    const queuedChannels = OVERLOAD.queue.map(q => q.channel);
    for (const tab of RESULT_TABS) {
      if (tab.queued && !queuedChannels.includes(tab.channel)) {
        tab.queued = false;
      }
    }
    renderResultTabs();
    updateActiveTabUI();
    renderOverloadBanner();
  }

  // SOOP(soopSearcher.js)의 네트워크 인디케이터 배너와 동일한 스타일로 단순화 — 예전엔
  // throttle/큐 상세 설명과 채널별 Cancel 버튼까지 길게 나열했는데, 큐에 들어간 항목은
  // 이미 결과 탭 바(RESULT_TABS)에서 🔴 queued 배지 + × 닫기 버튼으로 개별 취소가 가능해서
  // (renderResultTabs 참고) 배너에 똑같은 걸 또 보여줄 필요가 없었음 — SOOP과 같은 이유로
  // 여기도 "지금 Native API / Zonian API 중 뭐가 실제로 돌고 있는지"만 작은 점으로 표시.
  function renderOverloadBanner() {
    let banner = document.getElementById('kws-overload-banner');
    const body = document.getElementById('kws-panel-body');
    if (!body) return;
    if (!banner) {
      banner = document.createElement('div');
      banner.id = 'kws-overload-banner';
      if (body.firstChild) body.insertBefore(banner, body.firstChild);
      else body.appendChild(banner);
    }
    const runningStates = Object.values(SCAN_STATES).filter(s => s.running);
    if (!runningStates.length) { banner.innerHTML = ''; banner.style.cssText = 'display:none;'; return; }
    banner.style.cssText = 'margin-bottom:10px;padding:0;border-radius:10px;background:rgba(99,102,241,0.12);border:1px solid rgba(99,102,241,0.3);font-size:11px;overflow:hidden;transition:background .3s ease,border-color .3s ease;';

    // 예전엔 "선택된 모드"만 보고 불을 켰음 — 그래서 Combined/Native 모드를 골라놨는데
    // 실제로는 Native(Twitch 내부 API) 요청이 (지역 차단 등으로) 전부 실패/0건이어도
    // Native 쪽에 계속 불이 들어와 있는 "거짓말" 버그가 있었음. 실제로 지금 이 순간 그
    // 소스 쪽 요청이 몇 개나 나가있는지(inFlight/concurrency)를 직접 보고 켜지도록 바꿈 —
    // Zonian은 동시성 카운터가 따로 없어서(날짜 단위 순차 진행) 선택된 모드 기준을 유지.
    const nativeActive = runningStates.some(s => {
      if (s.mode === 'twitch') return (s.inFlight ?? s.concurrency ?? 0) > 0;
      if (s.mode === 'combined' || s.mode === 'combined_fast') return (s.twitchStatus?.inFlight ?? s.twitchStatus?.concurrency ?? 0) > 0;
      return false;
    });
    const zonianActive = runningStates.some(s => {
      if (s.mode === 'zonian') return true;
      if (s.mode === 'combined' || s.mode === 'combined_fast') return !!s.zonianStatus && (s.zonianStatus.done || 0) < (s.zonianStatus.total || 0);
      return false;
    });
    const dot = (label, active) =>
      `<span style="display:inline-flex;align-items:center;gap:4px;color:rgba(255,255,255,${active ? '0.85' : '0.35'});white-space:nowrap;">` +
      `<span style="width:7px;height:7px;border-radius:50%;background:${active ? '#4ade80' : 'rgba(255,255,255,0.22)'};${active ? 'box-shadow:0 0 6px rgba(74,222,128,0.9);' : ''}transition:background .2s ease,box-shadow .2s ease;"></span>${label}</span>`;

    banner.innerHTML = `<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:9px 12px;flex-wrap:wrap;">
      <span style="font-weight:700;color:rgba(255,255,255,0.9);">🟣 Scanning</span>
      <span style="display:flex;align-items:center;gap:10px;font-size:10px;">
        ${dot('Native API', nativeActive)}
        ${dot('Zonian API', zonianActive)}
        <span style="color:rgba(255,255,255,0.4);border-left:1px solid rgba(255,255,255,0.15);padding-left:10px;">${runningStates.length} running</span>
      </span>
    </div>`;
  }

  // ══════════════════════════════════════════════════════════
  //  SCAN ENGINE — sends message to background.js
  // ══════════════════════════════════════════════════════════
  const STOPPING_CHANNELS = new Set(); // 중지 요청 후 백그라운드가 '중지 완료'를 알려줄 때까지 대기 중인 채널
  function startScan({ channel, keyword, startDate, endDate, _confirmed }) {
    if (!channel || !startDate) return;
    const ch = channel.toLowerCase().trim();

    // 통일 규칙(4개 KWS 공통): 이미 스캔 중/대기 중인 ID를 다시 검색하면 확인 팝업 —
    // OK: 기존 스캔을 중지하고 처음부터 다시, Cancel: 기존 스캔 유지
    if (!_confirmed && (SCAN_STATES[ch]?.running || RESULT_TABS.some(t => t.channel === ch && (t.queued || t.live)) || OVERLOAD.queue.some(q => (q.channel || '').toLowerCase() === ch))) {
      window.KWSRestartDialog?.({
        name: ch,
        onRestart: () => {
          STOPPING_CHANNELS.add(ch);
          window.KWSStopAndRestart({
            stop: () => { try { chrome.runtime.sendMessage({ type: 'KWS_STOP', channel: ch }); } catch (e) {} },
            isRunning: () => STOPPING_CHANNELS.has(ch),
            start: () => {
              STOPPING_CHANNELS.delete(ch);
              if (SCAN_STATES[ch]) { SCAN_STATES[ch].running = false; SCAN_STATES[ch].queued = false; }
              startScan({ channel, keyword, startDate, endDate, _confirmed: true });
            }
          });
        }
      });
      return;
    }

    // 통일 규칙: 같은 채널을 다시 검색하면 기존 탭(live/완료 모두)을 교체 — 중복 탭 방지
    const existingIdx = RESULT_TABS.findIndex(t => t.channel === ch);
    if (existingIdx >= 0) {
      RESULT_TABS.splice(existingIdx, 1);
      if (ACTIVE_TAB >= RESULT_TABS.length) ACTIVE_TAB = RESULT_TABS.length - 1;
    }

    // Create new live result tab
    const groups = [];
    const tabIdx = RESULT_TABS.length;
    RESULT_TABS.push({ channel: ch, live: true, groups, matchedLines: 0, scanId: null });
    ACTIVE_TAB = tabIdx;

    // Initialize per-channel state
    SCAN_STATES[ch] = {
      scanId: null, running: true, percent: 0,
      done: 0, total: 0, matchedDays: 0, matchedLines: 0,
      message: `Starting scan for ${ch}...`,
      keywords: normalizeKeywords(keyword),
      startDate, endDate,
    };

    updateActiveTabUI();
    renderResultTabs();

    // Twitch API(Native) 모드는 이 탭(실제로 로그인돼있는 진짜 twitch.tv 탭)의 쿠키에서
    // device_id/oauth/client_id를 읽어서 같이 넘김 — background.js가 이미 인라인 채팅
    // 뷰어(ogChat.js)에서 쓰고 있는 것과 동일한 getGQL() 경로로 VOD 채팅을 조회하기 위함.
    // (예전엔 별도 숨김 탭을 열어서 페이지가 스스로 만든 토큰을 훔쳐 쓰는 방식으로 시도했는데
    // 계속 "failed integrity check"로 막혔음 — 실제로 잘 되는 인라인 채팅 뷰어는 이 방식
    // 대신 이 쿠키 기반 방식을 쓰고 있어서 그걸로 통일함.)
    let twitchTokens = null;
    if (LOG_SOURCE === 'twitch' || LOG_SOURCE === 'combined' || LOG_SOURCE === 'combined_fast') {
      try { twitchTokens = getTokensFromCookies(); } catch (e) {}
    }

    // Read stream language from page DOM before sending
    chrome.runtime.sendMessage({ type: 'KWS_START', channel: ch, keyword, startDate, endDate, pageDate: '', logSource: LOG_SOURCE, twitchTokens });
  }

  // ══════════════════════════════════════════════════════════
  //  SCAN MESSAGE HANDLERS — per-channel, not global
  // ══════════════════════════════════════════════════════════
  function getChannelFromScanId(scanId) {
    for (const [ch, s] of Object.entries(SCAN_STATES)) {
      if (s.scanId === scanId) return ch;
    }
    return null;
  }

  function handleScanStarted(msg) {
    // Find which tab this scanId belongs to — match by channel name in msg
    const ch = (msg.channel || '').toLowerCase().trim();
    if (!ch) return;

    if (!SCAN_STATES[ch]) {
      SCAN_STATES[ch] = { scanId: null, running: true, percent: 0, done: 0, total: 0, matchedDays: 0, matchedLines: 0, message: '', keywords: [], startDate: '', endDate: '' };
    }

    const s = SCAN_STATES[ch];
    if (msg.scanId) { s.scanId = msg.scanId; }
    s.running = true;
    kwsTwitchSetPageGuard(true);
    s.total   = msg.totalDates || 0;
    s.done    = 0;
    s.matchedDays = 0; s.matchedLines = 0;

    s.excludeKeywords = msg.excludeKeywords || s.excludeKeywords;
    s.mode = msg.mode || 'zonian'; // 'zonian' | 'twitch' (Native API) | 'combined'
    s.message  = `Scanning ${ch}... (${msg.totalDates || '?'} days)`;

    // Link scanId to the result tab, queued→live 전환
    let tab = RESULT_TABS.find(t => t.channel === ch && t.live);
    if (!tab) {
      // queued 탭을 live로 전환
      // handleQueueUpdate가 KWS_STARTED보다 먼저 와서 queued 플래그를 이미 내렸을 수 있음 —
      // 그래서 queued 여부와 상관없이 이 채널의 (live 아닌) 탭이면 live로 전환해야 함.
      // (예전엔 queued만 찾아서, 대기열을 거친 탭이 영영 live(주황)로 안 바뀌었음)
      const qTab = RESULT_TABS.find(t => t.channel === ch && (t.queued || !t.live));
      if (qTab) { qTab.live = true; qTab.queued = false; tab = qTab; }
    }
    if (tab && msg.scanId) tab.scanId = msg.scanId;

    renderResultTabs();
    if (getActiveChannel() === ch) updateActiveTabUI();
  }

  function handleScanProgress(msg) {
    const ch = (msg.channel || '').toLowerCase().trim()
             || getChannelFromScanId(msg.scanId);
    if (!ch || !SCAN_STATES[ch]) return;
    // Guard: ignore if scanId doesn't match
    if (msg.scanId && SCAN_STATES[ch].scanId && msg.scanId !== SCAN_STATES[ch].scanId) return;

    const s = SCAN_STATES[ch];
    s.done    = msg.done  || 0;
    s.total   = msg.total || 1;
    s.matchedDays  = msg.matchedDays  || 0;
    s.matchedLines = msg.matchedLines || 0;
    s.percent = msg.percent || 0;
    if (typeof msg.concurrency === 'number') { s.concurrency = msg.concurrency; s.inFlight = msg.inFlight; }
    if (msg.zonianStatus) s.zonianStatus = msg.zonianStatus;
    if (msg.twitchStatus) s.twitchStatus = msg.twitchStatus;

    if ((s.mode === 'combined' || s.mode === 'combined_fast') && (msg.zonianStatus || msg.twitchStatus)) {
      // Combined 모드는 Zonian(날짜 단위) / Twitch(VOD 단위)가 서로 다른 속도로
      // 따로 도는데 숫자만 합쳐서 보여주면 뭐가 어떻게 되고 있는지 알기 어려움 —
      // 소스별로 나눠서 각자 진행 상황을 따로 보여줌.
      const z = msg.zonianStatus, t = msg.twitchStatus;
      // Fast 모드의 zonianStatus.phase===2는 "Native API가 끝난 뒤 VOD 없는/삭제된
      // 것으로 의심되는 날짜만 재확인하는 중"이라 일반 진행률 문구 대신 명확하게 표시.
      const zPart = z
        ? (z.phase === 2
            ? `🔍 Searching deleted VOD (External API) ${z.done}/${z.total}d · ${z.matchedLines} hits`
            : `🔵 Zonian ${z.done}/${z.total}d · ${z.matchedLines} hits`) + (z.activityNote ? ` (${z.activityNote})` : '')
        : '';
      const tPart = t ? `🟢 Twitch ${t.done}/${t.total} VOD · ${t.matchedLines} hits` + (typeof t.concurrency === 'number' ? ` (${t.inFlight ?? t.concurrency} in process)` : '') : '';
      s.message = [zPart, tPart].filter(Boolean).join('  |  ');
    } else {
      // Native API(twitch) 단독 모드는 VOD를 여러 개 동시에 긁는 적응형 동시성
      // 풀을 쓰는데, 지금 몇 개가 실제로 동시에 요청 중인지(inFlight)를 쉬운
      // 말로 보여줘서 "멈춘 건지 도는 중인지" 알 수 있게 함.
      s.message = `${msg.done} / ${msg.total} days · ${msg.matchedLines} hits`
        + (typeof msg.concurrency === 'number' ? ` · ${msg.inFlight ?? msg.concurrency} VOD${(msg.inFlight ?? msg.concurrency) === 1 ? '' : 's'} in process` : '')
        + (msg.activityNote ? ` · ${msg.activityNote}` : '');
    }

    // Append new result groups to the correct tab
    if (msg.replaceGroups) {
      // Native(Twitch)/Combined 모드: 매 틱마다 "지금까지 전체" 스냅샷을 보내오므로
      // 통째로 교체하고 다시 그림 (병렬로 VOD를 긁어서 완료 순서가 뒤섞이기 때문에
      // 델타 방식 append로는 정확히 추적하기 어려움)
      const tab = RESULT_TABS.find(t => t.channel === ch && t.live);
      if (tab) {
        tab.groups = msg.newGroups || [];
        tab.matchedLines = s.matchedLines;
        if (RESULT_TABS.indexOf(tab) === ACTIVE_TAB) renderFullResultList();
      }
    } else if (msg.newGroups?.length) {
      const tab = RESULT_TABS.find(t => t.channel === ch && t.live);
      if (tab) {
        for (const g of msg.newGroups) {
          if (!tab.groups.some(x => x.date === g.date)) {
            tab.groups.push(g);
            // Append to DOM only if this tab is active
            if (RESULT_TABS.indexOf(tab) === ACTIVE_TAB) appendGroupToList(g, ch);
          }
        }
        tab.matchedLines = s.matchedLines;
      }
    }

    renderResultTabs();
    if (getActiveChannel() === ch) updateActiveTabUI();
    renderOverloadBanner();
  }

  function handleScanComplete(msg) {
    const ch = (msg.channel || '').toLowerCase().trim()
             || getChannelFromScanId(msg.scanId);
    if (!ch || !SCAN_STATES[ch]) return;
    if (msg.scanId && SCAN_STATES[ch].scanId && msg.scanId !== SCAN_STATES[ch].scanId) return;

    const s = SCAN_STATES[ch];
    s.running = false; s.queued = false; s.percent = 100; kwsTwitchSetPageGuard(Object.values(SCAN_STATES||{}).some(ss=>ss.running));
    s.matchedDays  = msg.matchedDays  || 0;
    s.matchedLines = msg.matchedLines || 0;
    s.concurrency = undefined; s.inFlight = undefined; s.zonianStatus = undefined; s.twitchStatus = undefined;
    s.message = (msg.failedDays > 0)
      ? `Done! ${msg.matchedDays} days · ${msg.matchedLines} hits (⚠️ ${msg.failedDays} day${msg.failedDays>1?'s':''} failed to load — results may be incomplete, try re-scanning)`
      : `Done! ${msg.matchedDays} days · ${msg.matchedLines} hits`;
    renderOverloadBanner(); // Native API 진행 배너를 원상태로 되돌림
    // History 창 배지 갱신
    if (window._twitchHistoryRender) window._twitchHistoryRender();
    // 결과 없으면 탭 자동 닫기
    if (kwsAutoCloseNoResult && (msg.matchedLines || 0) === 0) {
      setTimeout(() => {
        const closeIdx = RESULT_TABS.findIndex(t => t.channel?.toLowerCase() === ch?.toLowerCase());
        if (closeIdx >= 0) {
          RESULT_TABS.splice(closeIdx, 1);
          if (ACTIVE_TAB >= RESULT_TABS.length) ACTIVE_TAB = RESULT_TABS.length - 1;
          if (ACTIVE_TAB > closeIdx) ACTIVE_TAB--;
          renderResultTabs();
        }
      }, 300);
    }

    saveHistory(ch, {
      matchedLines: msg.matchedLines || 0,
      matchedDays:  msg.matchedDays  || 0,
      lastDate: msg.resolvedEndDate || s.endDate || '',
    });

    const tabIdx = RESULT_TABS.findIndex(t => t.channel === ch && t.live);
    if (tabIdx >= 0) {
      const tab = RESULT_TABS[tabIdx];
      tab.live = false;
      tab.queued = false; // 스캔 완료 시 queued 플래그 반드시 제거
      tab.matchedLines = msg.matchedLines || 0;
      // Merge any remaining groups
      if (msg.matchedGroups?.length) {
        for (const g of msg.matchedGroups) {
          if (!tab.groups.some(x => x.date === g.date)) {
            tab.groups.push(g);
            if (tabIdx === ACTIVE_TAB) appendGroupToList(g, ch);
          }
        }
      }
    }

    renderResultTabs();
    if (getActiveChannel() === ch) updateActiveTabUI();
  }

  function handleScanError(msg) {
    const ch = (msg.channel || '').toLowerCase().trim()
             || getChannelFromScanId(msg.scanId);
    if (!ch) return;
    const s = SCAN_STATES[ch];
    if (!s) return;
    if (msg.scanId && s.scanId && msg.scanId !== s.scanId) return;

    s.running = false; s.percent = 0; kwsTwitchSetPageGuard(Object.values(SCAN_STATES||{}).some(ss=>ss.running));
    s.message = `Error: ${msg.message || 'Unknown error'}`;
    const tab = RESULT_TABS.find(t => t.channel === ch && t.live);
    if (tab) tab.live = false;

    renderResultTabs();
    if (getActiveChannel() === ch) updateActiveTabUI();
  }

  // ══════════════════════════════════════════════════════════
  //  ACTIVE TAB HELPERS
  // ══════════════════════════════════════════════════════════
  function getActiveChannel() {
    const tab = RESULT_TABS[ACTIVE_TAB];
    return tab?.channel || null;
  }

  // Update the STATUS / PROGRESS / METRICS panel to show the ACTIVE tab's channel state
  function updateActiveTabUI() {
    const $d = id => document.getElementById(id);
    if (!$d('kws-status-text')) return;

    const ch  = getActiveChannel();
    const s   = ch ? SCAN_STATES[ch] : null;

    // Status text
    $d('kws-status-text').textContent = s ? s.message : 'Idle';

    // Progress bar
    const pct = s ? s.percent : 0;
    const bar = $d('kws-progress-bar');
    const lbl = $d('kws-progress-label');
    if (bar) bar.style.width = `${pct}%`;
    if (lbl) lbl.textContent = `${pct}%`;

    // Metrics
    const metrics = $d('kws-metrics');
    if (metrics) {
      if (s) {
        metrics.textContent = [
          `Channel  : ${ch}`,
          `Keywords : ${kwPreview(safeKwStrings(GLOBAL_KEYWORD ? GLOBAL_KEYWORD.split(',').map(s=>s.trim()).filter(s=>!s.startsWith('-')) : []), 3)}`,
          `Date     : ${s.startDate || 'any'} ~ ${s.endDate || 'now'}`,
          `Progress : ${s.done}/${s.total} days · ${s.matchedDays} matched · ${s.matchedLines} hits`,
        ].join('\n');
      } else {
        metrics.textContent = [
          `Channel  : -`,
          `Keywords : -`,
          `Date     : -`,
          `Progress : -`,
        ].join('\n');
      }
    }

    // Summary
    updateSummaryText();
  }

  // ══════════════════════════════════════════════════════════
  //  UI CREATION
  // ══════════════════════════════════════════════════════════
  function createPanel() {
    if (document.getElementById(PANEL_ID)) return;

    if (!document.getElementById('kws-panel-style')) {
      const s = document.createElement('style');
      s.id = 'kws-panel-style';
      s.textContent = `
        #${PANEL_ID} * { box-sizing:border-box; font-family:-apple-system,'SF Pro Display','SF Pro Text',BlinkMacSystemFont,sans-serif; }
        #${PANEL_ID} input, #${PANEL_ID} select { transition:border-color 0.2s,background 0.2s,box-shadow 0.2s; }
        #${PANEL_ID} input:focus, #${PANEL_ID} select:focus {
          border-color:rgba(145,70,255,0.55)!important;
          background:rgba(255,255,255,0.1)!important;
          box-shadow:0 0 0 3px rgba(120,60,255,0.13)!important;
        }
        #${PANEL_ID} input::placeholder { color:rgba(255,255,255,0.35); }
        #${PANEL_ID} button:hover { filter:brightness(1.12); }
        #${PANEL_ID} button:active { transform:scale(0.97)!important; }
        #${PANEL_ID} ::-webkit-scrollbar { width:8px; }
        #${PANEL_ID} ::-webkit-scrollbar-track { background:transparent; }
        #${PANEL_ID} ::-webkit-scrollbar-thumb { background:rgba(255,255,255,0.15);border-radius:99px; }
        .kws-time-btn.visited { background:rgba(16,185,129,0.18)!important;color:#86efac!important;border-color:rgba(16,185,129,0.45)!important; }
        .kws-local-time { margin-top:3px;text-align:center;font-size:9px;line-height:1.2;color:rgba(203,213,225,0.62);font-family:monospace;white-space:nowrap; }
        .kws-vod-popup { animation: kwsFadeIn 0.15s ease; }
        @keyframes kwsFadeIn { from{opacity:0;transform:translateY(-6px)} to{opacity:1;transform:translateY(0)} }
      `;
      document.head.appendChild(s);
    }

    const panel = document.createElement('div');
    panel.id = PANEL_ID;
    Object.assign(panel.style, {
      position: 'fixed', right: `${DEFAULT_POS.right}px`, bottom: `${DEFAULT_POS.bottom}px`,
      zIndex: String(topZIndexer()), width: '420px', maxWidth: 'calc(100vw - 20px)',
      maxHeight: 'calc(100vh - 20px)', overflow: 'hidden',
      color: 'rgba(255,255,255,0.95)', borderRadius: '26px',
      border: '1px solid rgba(255,255,255,0.14)',
      background: 'rgba(14,14,22,0.88)',
      backdropFilter: 'saturate(160%) blur(28px)', WebkitBackdropFilter: 'saturate(160%) blur(28px)',
      boxShadow: '0 40px 80px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.12)',
      fontSize: '13px', lineHeight: '1.5', userSelect: 'none',
    });

    panel.innerHTML = `
      <!-- HEADER -->
      <div id="kws-panel-header" style="
        display:flex;align-items:center;justify-content:space-between;
        padding:14px 16px 13px;cursor:move;flex-shrink:0;
        border-bottom:1px solid rgba(255,255,255,0.06);
        background:linear-gradient(180deg,rgba(255,255,255,0.07) 0%,rgba(255,255,255,0) 100%);
      ">
        <div>
          <div style="font-size:13px;font-weight:700;letter-spacing:-0.01em;color:#fff;line-height:1.2;">
            Twitch KWS
          </div>
          <div style="display:flex;align-items:center;gap:6px;margin-top:2px;">
            <span id="kws-version-badge" style="font-size:10px;font-weight:700;letter-spacing:0.04em;color:rgba(145,110,255,0.9);background:rgba(120,60,255,0.18);border:1px solid rgba(120,60,255,0.3);border-radius:5px;padding:1px 6px;">KWS</span>
            
          </div>
        </div>
        <div style="display:flex;gap:6px;align-items:center;">
          <button id="kws-api-btn" title="API Source" style="
            width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:14px;
            background:rgba(145,71,255,0.16);border:1px solid rgba(145,71,255,0.32);
            color:#c4b5fd;display:flex;align-items:center;justify-content:center;">⚙</button>
          <button id="kws-discover-btn" title="Find more streamers to search" style="
            width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:13px;
            background:rgba(145,71,255,0.16);border:1px solid rgba(145,71,255,0.32);
            color:#c4b5fd;display:flex;align-items:center;justify-content:center;">🔍</button>
          <button id="kws-player-btn" title="Play a VOD by URL or ID" style="
            width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:13px;
            background:rgba(96,165,250,0.16);border:1px solid rgba(96,165,250,0.32);
            color:#93c5fd;display:flex;align-items:center;justify-content:center;">▶</button>
          <button id="kws-history-btn" title="Search History" style="
            width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:13px;
            background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);
            color:rgba(255,255,255,0.7);display:flex;align-items:center;justify-content:center;">📋</button>
          <button id="kws-toggle-btn" style="
            width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:16px;
            background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);
            color:rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;padding:0;box-sizing:border-box;" title="Slim mode">⇔</button>
        </div>
      </div>

      <!-- BODY -->
      <div id="kws-panel-body" style="padding:14px 16px 16px;overflow-y:auto;max-height:calc(100vh - 80px);">
        <div id="kws-overload-banner" style="display:none;"></div>
<!-- API Source is opened from the top API button -->
        <div id="kws-api-inline" style="display:none;margin-bottom:12px;padding:12px 14px;border-radius:12px;background:rgba(145,71,255,0.06);border:1px solid rgba(145,71,255,0.16);">
          <div style="font-size:10px;font-weight:800;letter-spacing:0.07em;text-transform:uppercase;color:rgba(196,181,253,0.82);margin-bottom:9px;text-align:center;">API SOURCE</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:9px;">
            <button id="kws-logsource-combined_fast" class="kws-logsource-btn" data-mode="combined_fast" title="Zonian fills in only dates with no VOD, plus (afterward) dates whose VOD chat came back empty or failed. Much faster than Accurate." style="height:36px;border-radius:10px;border:1px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.05);color:rgba(255,255,255,0.62);font-size:11px;font-weight:800;cursor:pointer;display:flex;align-items:center;justify-content:center;text-align:center;">🟣 Combined (Fast)</button>
            <button id="kws-logsource-combined" class="kws-logsource-btn" data-mode="combined" title="Zonian always scans the full range, run together with Native API and merged. Most accurate, but slowest." style="height:36px;border-radius:10px;border:1px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.05);color:rgba(255,255,255,0.62);font-size:11px;font-weight:800;cursor:pointer;display:flex;align-items:center;justify-content:center;text-align:center;">🟣 Combined (Accurate)</button>
            <button id="kws-logsource-twitch" class="kws-logsource-btn" data-mode="twitch" title="Pulls VOD chat directly from Twitch. Only covers periods where the VOD still exists." style="height:36px;border-radius:10px;border:1px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.05);color:rgba(255,255,255,0.62);font-size:11px;font-weight:800;cursor:pointer;display:flex;align-items:center;justify-content:center;text-align:center;">🟢 Native API</button>
            <button id="kws-logsource-zonian" class="kws-logsource-btn" data-mode="zonian" title="Uses a third-party archive. Can also cover old dates whose VOD has been deleted." style="height:36px;border-radius:10px;border:1px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.05);color:rgba(255,255,255,0.62);font-size:11px;font-weight:800;cursor:pointer;display:flex;align-items:center;justify-content:center;text-align:center;">🔵 External (Zonian)</button>
          </div>
          <div style="font-size:10px;line-height:1.5;color:rgba(255,255,255,0.4);text-align:left;margin-bottom:9px;">
            <b style="color:rgba(255,255,255,0.55);">🟣 Combined (Fast)</b> — Zonian fills in only dates with no VOD, plus (afterward) dates whose VOD chat came back empty or failed. Much faster than Accurate.<br>
            <b style="color:rgba(255,255,255,0.55);">🟣 Combined (Accurate)</b> — Zonian always scans the full range, run together with Native API and merged. Most accurate, but slowest.<br>
            <b style="color:rgba(255,255,255,0.55);">🟢 Native API</b> — Pulls VOD chat directly from Twitch. Only covers periods where the VOD still exists.<br>
            <b style="color:rgba(255,255,255,0.55);">🔵 External API (Zonian)</b> — Uses a third-party archive. Can also cover old dates whose VOD has been deleted.
          </div>
          <div style="font-size:10px;font-weight:800;letter-spacing:0.07em;text-transform:uppercase;color:rgba(196,181,253,0.82);margin:13px 0 9px;text-align:center;">Options</div>
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;padding:7px 0;border-bottom:1px solid rgba(255,255,255,0.07);margin-bottom:9px;">
            <input type="checkbox" id="kws-auto-close-no-result" style="width:14px;height:14px;accent-color:#a78bfa;cursor:pointer;">
            <span style="font-size:11px;font-weight:600;color:rgba(255,255,255,0.8);">Auto-close tab if no results</span>
          </label>
          <div style="font-size:10px;font-weight:800;letter-spacing:0.07em;text-transform:uppercase;color:rgba(196,181,253,0.82);margin:13px 0 9px;text-align:center;" title="Chat messages are translated with Google Translate (free)">Translate to</div>
          <select id="kws-translate-lang" title="Translate result messages to this language (Google Translate)" style="width:100%;height:36px;border-radius:10px;border:1px solid rgba(145,71,255,0.28);background:#14101d;color:#ffffff;font-size:11px;font-weight:700;padding:0 12px;outline:none;font-family:inherit;box-sizing:border-box;color-scheme:dark;cursor:pointer;"><option value="en" style="background:#14101d;color:#ffffff;">English</option><option value="ko" style="background:#14101d;color:#ffffff;">한국어</option><option value="ja" style="background:#14101d;color:#ffffff;">日本語</option><option value="zh-CN" style="background:#14101d;color:#ffffff;">中文</option><option value="es" style="background:#14101d;color:#ffffff;">Español</option><option value="ru" style="background:#14101d;color:#ffffff;">Русский</option><option value="de" style="background:#14101d;color:#ffffff;">Deutsch</option><option value="fr" style="background:#14101d;color:#ffffff;">Français</option><option value="pt" style="background:#14101d;color:#ffffff;">Português</option><option value="id" style="background:#14101d;color:#ffffff;">Bahasa Indonesia</option><option value="th" style="background:#14101d;color:#ffffff;">ไทย</option><option value="vi" style="background:#14101d;color:#ffffff;">Tiếng Việt</option></select>
        </div>

        <div id="kws-input-area">
<!-- Channel -->
        <div style="margin-bottom:12px;">
          <div style="font-size:10px;font-weight:600;letter-spacing:0.08em;text-transform:uppercase;color:rgba(255,255,255,0.55);margin-bottom:6px;">Channel</div>
          <div style="position:relative;">
            <input id="kws-channel" type="text" placeholder="e.g. xqc, sodapoppin"
              style="width:100%;height:40px;padding:0 14px;
              border-radius:12px;border:1px solid rgba(255,255,255,0.2);
              background:rgba(255,255,255,0.1);color:#fff;
              font-size:13px;outline:none;font-family:inherit;">
            <div id="kws-ch-dropdown" style="
              display:none;position:absolute;top:calc(100% + 5px);left:0;right:0;z-index:9999;
              border-radius:12px;overflow:hidden;max-height:200px;overflow-y:auto;
              background:rgba(20,20,35,0.97);border:1px solid rgba(255,255,255,0.1);
              box-shadow:0 16px 40px rgba(0,0,0,0.5);backdrop-filter:blur(20px);
            "></div>
          </div>
          <div id="kws-history-hint" style="
            margin-top:6px;padding:7px 11px;border-radius:9px;
            background:rgba(120,60,255,0.08);border:1px solid rgba(120,60,255,0.15);
            font-size:11px;color:rgba(170,140,255,0.85);display:none;line-height:1.5;
          "></div>
        </div>

        <!-- Keywords -->
        <div style="margin-bottom:12px;">
          <div style="font-size:10px;font-weight:600;letter-spacing:0.08em;text-transform:uppercase;color:rgba(255,255,255,0.55);margin-bottom:6px;">Keywords</div>
          <button id="kws-keyword-btn" style="
            width:100%;height:40px;padding:0 14px;text-align:left;
            border-radius:12px;border:1px solid rgba(255,255,255,0.12);
            background:rgba(255,255,255,0.07);color:rgba(255,255,255,0.7);
            font-size:12px;cursor:pointer;font-family:inherit;
            display:flex;align-items:center;justify-content:space-between;gap:8px;
            transition:border-color 0.2s,background 0.2s;">
            <span id="kws-keyword-preview" style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"></span>
            <span style="font-size:10px;opacity:0.5;flex-shrink:0;">✏️ Edit</span>
          </button>
          <input id="kws-keyword" type="hidden" value="">
        </div>

                <!-- Date Range -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px;">
          <div>
            <div style="font-size:10px;font-weight:600;letter-spacing:0.08em;text-transform:uppercase;color:rgba(255,255,255,0.55);margin-bottom:6px;">From Date <span style="font-size:9px;color:rgba(255,255,255,0.3);text-transform:none;font-weight:400;letter-spacing:0;">(blank = 60 days ago)</span></div>
            <input id="kws-start-date" type="date"
              style="width:100%;height:40px;padding:0 12px;border-radius:12px;
              border:1px solid rgba(255,255,255,0.2);background:rgba(255,255,255,0.1);color:#fff;
              font-size:12px;outline:none;color-scheme:dark;font-family:inherit;">
          </div>
          <div>
            <div style="font-size:10px;font-weight:600;letter-spacing:0.08em;text-transform:uppercase;color:rgba(255,255,255,0.55);margin-bottom:6px;">To Date <span style="opacity:0.5;font-size:9px;">(blank=now)</span></div>
            <input id="kws-end-date" type="date"
              style="width:100%;height:40px;padding:0 12px;border-radius:12px;
              border:1px solid rgba(255,255,255,0.2);background:rgba(255,255,255,0.1);color:#fff;
              font-size:12px;outline:none;color-scheme:dark;font-family:inherit;">
          </div>
        </div>

        <!-- Buttons -->
        <div style="display:flex;gap:8px;margin-bottom:14px;">
          <button id="kws-start-btn" style="
            flex:1;height:42px;border:none;border-radius:13px;cursor:pointer;
            display:flex;align-items:center;justify-content:center;gap:6px;
            font-size:13px;font-weight:700;color:#fff;letter-spacing:0.01em;
            background:linear-gradient(135deg,rgba(88,80,236,0.9),rgba(124,58,237,0.9));
            box-shadow:0 4px 16px rgba(88,80,236,0.35),inset 0 1px 0 rgba(255,255,255,0.15);
            transition:all 0.15s;font-family:inherit;">▶ Start Scan</button>
          <button id="kws-stop-btn" style="
            width:80px;height:42px;border:none;border-radius:13px;cursor:pointer;
            display:flex;align-items:center;justify-content:center;gap:5px;
            font-size:13px;font-weight:700;color:#fff;
            background:linear-gradient(135deg,rgba(220,38,38,0.85),rgba(239,68,68,0.85));
            box-shadow:0 4px 16px rgba(220,38,38,0.3),inset 0 1px 0 rgba(255,255,255,0.1);
            transition:all 0.15s;font-family:inherit;">■ Stop</button>
        </div>
        </div><!-- /kws-input-area -->

        <!-- Status (shows active tab's channel status) -->
        <div style="margin-bottom:10px;padding:10px 13px;border-radius:12px;
          background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07);">
          <div style="font-size:9px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:rgba(255,255,255,0.5);margin-bottom:4px;">
            Status <span id="kws-status-channel" style="color:rgba(99,102,241,0.8);text-transform:none;font-weight:600;font-size:9px;margin-left:4px;"></span>
          </div>
          <div id="kws-status-text" style="color:rgba(255,255,255,0.9);font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">Idle</div>
        </div>

        <!-- Progress (shows active tab's channel progress) -->
        <div style="margin-bottom:10px;">
          <div style="display:flex;justify-content:space-between;margin-bottom:5px;">
            <span style="font-size:10px;color:rgba(255,255,255,0.5);">Progress</span>
            <span id="kws-progress-label" style="font-size:10px;color:rgba(255,255,255,0.6);">0%</span>
          </div>
          <div style="height:4px;background:rgba(255,255,255,0.06);border-radius:99px;overflow:hidden;">
            <div id="kws-progress-bar" style="width:0%;height:100%;border-radius:99px;
              background:linear-gradient(90deg,#7c3aed,#3b82f6);
              transition:width 0.4s cubic-bezier(0.4,0,0.2,1);"></div>
          </div>
        </div>

        <!-- Metrics -->
        <div id="kws-metrics" style="
          white-space:pre-wrap;font-size:11px;line-height:1.8;
          color:rgba(255,255,255,0.5);padding:8px 12px;border-radius:11px;
          background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.05);
          margin-bottom:12px;font-variant-numeric:tabular-nums;"></div>

        <!-- Results -->
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:7px;">
          <div style="display:flex;align-items:center;gap:8px;">
            <div style="font-size:12px;font-weight:700;color:rgba(255,255,255,0.9);">Results</div>
            <div id="kws-results-summary" style="font-size:11px;color:rgba(255,255,255,0.45);">No results</div>
          </div>
          <div style="display:flex;align-items:center;gap:4px;">
            <button id="kws-res-clear" title="Clear all" style="
              height:22px;padding:0 7px;border:1px solid rgba(255,255,255,0.07);border-radius:5px;cursor:pointer;
              display:flex;align-items:center;gap:2px;
              background:transparent;color:rgba(248,113,113,0.6);
              font-size:10px;font-weight:600;font-family:inherit;white-space:nowrap;">
              Clear</button>
          </div>
        </div>
        <div id="kws-result-tabs" style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:8px;"></div>
        <div id="kws-results-list" style="display:flex;flex-direction:column;gap:8px;"></div>

        <!-- VOD Popup area (inside panel so it moves with it) -->
        <div id="kws-vod-popup-area"></div>

      </div>
    `;

    document.body.appendChild(panel);
    const $d = id => document.getElementById(id);

    try {
      const vBadge = $d('kws-version-badge');
      if (vBadge) vBadge.textContent = 'KWS ' + (chrome.runtime.getManifest().version || '');
    } catch(e) {}

    bindCollapse(panel, $d('kws-panel-body'), $d('kws-toggle-btn'));
    enableDragging(panel, $d('kws-panel-header'));

    // Channel autocomplete
    const chInput = $d('kws-channel');
    const chDrop  = $d('kws-ch-dropdown');
    chInput.addEventListener('input', () => {
      GLOBAL_KEYWORD    = $d('kws-keyword').value.trim();
      GLOBAL_START_DATE = $d('kws-start-date').value;
      GLOBAL_END_DATE   = $d('kws-end-date').value;
      renderChannelDropdown(chInput.value.trim());
      renderHistoryHint(chInput.value.trim());
    });
    chInput.addEventListener('focus', () => renderChannelDropdown(chInput.value.trim()));
    chInput.addEventListener('blur',  () => setTimeout(() => { chDrop.style.display = 'none'; }, 150));
    chDrop.addEventListener('click', e => {
      const item = e.target.closest('[data-ch]');
      if (!item) return;
      chInput.value = item.dataset.ch; chDrop.style.display = 'none';
      renderHistoryHint(item.dataset.ch);
    });

    // Save globals on keyword/date change
    $d('kws-keyword').addEventListener('input', () => { GLOBAL_KEYWORD = $d('kws-keyword').value.trim(); });
    $d('kws-start-date').addEventListener('change', () => { GLOBAL_START_DATE = $d('kws-start-date').value; });
    $d('kws-end-date').addEventListener('change',   () => { GLOBAL_END_DATE   = $d('kws-end-date').value; });

    const trLang = $d('kws-translate-lang');
    if (trLang) {
      const savedLang = localStorage.getItem(TRANSLATE_LANG_KEY) || 'en';
      trLang.value = savedLang;
      trLang.addEventListener('change', () => localStorage.setItem(TRANSLATE_LANG_KEY, trLang.value || 'en'));
    }
    // auto-close 복원
    chrome.storage.local.get(KWS_AUTO_CLOSE_KEY).then(_acr => {
      kwsAutoCloseNoResult = !!_acr[KWS_AUTO_CLOSE_KEY];
      const _acCb = document.getElementById('kws-auto-close-no-result');
      if (_acCb) {
        _acCb.checked = kwsAutoCloseNoResult;
        _acCb.addEventListener('change', () => {
          kwsAutoCloseNoResult = _acCb.checked;
          chrome.storage.local.set({ [KWS_AUTO_CLOSE_KEY]: kwsAutoCloseNoResult }).catch(()=>{});
        });
      }
    }).catch(()=>{});

    chInput.value = guessChannelFromUrl();
    renderHistoryHint(chInput.value);

    if (!$d('kws-start-date').value) {
      const d = new Date(); d.setDate(d.getDate() - 60);
      $d('kws-start-date').value = fmtDate(d);
      GLOBAL_START_DATE = $d('kws-start-date').value;
    }

    // Start button
    // ── Log source: 'zonian' (External) | 'twitch' (Native) | 'combined_fast' | 'combined' (Accurate) ──────
    const KWS_LOG_SOURCE_KEY = 'kwsLogSource';
    const KWS_LOGSOURCE_COLORS = {
      combined_fast: { bg: 'rgba(168,85,247,0.18)', border: 'rgba(168,85,247,0.5)', text: '#e9d5ff' },
      combined:      { bg: 'rgba(168,85,247,0.18)', border: 'rgba(168,85,247,0.5)', text: '#e9d5ff' },
      twitch:        { bg: 'rgba(34,197,94,0.18)',  border: 'rgba(34,197,94,0.5)',  text: '#bbf7d0' },
      zonian:        { bg: 'rgba(96,165,250,0.18)', border: 'rgba(96,165,250,0.5)', text: '#bfdbfe' },
    };
    function setLogSource(src) {
      const valid = ['zonian','twitch','combined_fast','combined'];
      LOG_SOURCE = valid.includes(src) ? src : 'zonian';
      document.querySelectorAll('.kws-logsource-btn').forEach(b => {
        const active = b.dataset.mode === LOG_SOURCE;
        const c = KWS_LOGSOURCE_COLORS[b.dataset.mode] || KWS_LOGSOURCE_COLORS.zonian;
        b.style.background = active ? c.bg : 'rgba(255,255,255,0.05)';
        b.style.borderColor = active ? c.border : 'rgba(255,255,255,0.12)';
        b.style.color = active ? c.text : 'rgba(255,255,255,0.62)';
      });
    }
    chrome.storage.local.get([KWS_LOG_SOURCE_KEY]).then(data => {
      setLogSource(data[KWS_LOG_SOURCE_KEY] || 'zonian');
    }).catch(() => setLogSource('zonian'));
    document.querySelectorAll('.kws-logsource-btn').forEach(b => {
      b.addEventListener('click', () => {
        setLogSource(b.dataset.mode);
        try { chrome.storage.local.set({ [KWS_LOG_SOURCE_KEY]: b.dataset.mode }); } catch(e) {}
      });
    });


    $d('kws-start-btn').addEventListener('click', () => {
      const channel   = $d('kws-channel').value.trim();
      const keyword   = GLOBAL_KEYWORD || $d('kws-keyword').value.trim();
      const startDate = $d('kws-start-date').value;
      const endDate   = $d('kws-end-date').value;
      GLOBAL_KEYWORD = keyword; GLOBAL_START_DATE = startDate; GLOBAL_END_DATE = endDate;
      if (!channel)   { alert('Please enter a channel name.'); return; }
      if (!keyword)   { alert('⚠ No keywords set!\n\nPlease click the keyword button to set keywords first.'); document.getElementById('kws-keyword-btn')?.click(); return; }
      if (!startDate) { alert('Please enter a start date.'); return; }
      // 검색 시작 시 설정값 저장
      try { chrome.storage.local.set({ kwsChannel: channel, kwsKeyword: keyword, kwsStartDate: startDate, kwsEndDate: endDate, kwsDatesSavedDay: fmtDate(new Date()) }); } catch(e) {}
      startScan({ channel, keyword, startDate, endDate });
    });

    // Stop button — stops the ACTIVE tab's channel scan
    $d('kws-stop-btn').addEventListener('click', () => {
      const ch = getActiveChannel();
      if (ch && SCAN_STATES[ch]?.running) {
        try { chrome.runtime.sendMessage({ type: 'KWS_STOP', channel: ch }); } catch (e) {}
        SCAN_STATES[ch].running = false;
        SCAN_STATES[ch].message = 'Stopped';
        const tab = RESULT_TABS.find(t => t.channel === ch && t.live);
        if (tab) tab.live = false;
        updateActiveTabUI();
        renderResultTabs();
      }
    });

    $d('kws-api-btn')?.addEventListener('click', () => { const box=$d('kws-api-inline'); if(box) box.style.display = (box.style.display === 'none' || !box.style.display) ? 'block' : 'none'; });
    $d('kws-history-btn').addEventListener('click', () => createHistoryWindow());

    $d('kws-discover-btn')?.addEventListener('click', () => window.showKwsDiscoverPopup?.());

    $d('kws-player-btn').addEventListener('click', () => {
      showKwsUrlPrompt({
        title: 'Play Twitch VOD',
        placeholder: 'twitch.tv/videos/123456789 or just the ID',
        onSubmit: async (raw) => {
          const idMatch = /videos\/(\d+)/.exec(raw) || /^(\d{6,})$/.exec(raw.trim());
          const vodId = idMatch?.[1];
          if (!vodId) { alert('Could not find a Twitch VOD ID in that input.'); return; }
          try {
            const source = await requestFromBackground({ cmd: 'getOfficialVodM3u8Source', params: { vod_id: vodId } });
            if (!source) { alert('Could not load that VOD — it may be deleted or private.'); return; }
            await getStreamInformationAndBuildUI({ source, vod_id: vodId, timestamp: Date.now(), ref_elm: document.body });
          } catch (e) { alert('Failed to open VOD: ' + e.message); }
        }
      });
    });

    // Keyword button — KWSSharedKeywordEditor.open() (same as SOOP/Kick)
    $d('kws-keyword-btn').addEventListener('click', () => {
      // 이미 모달이 열려있으면 무시 (중복 방지)
      if (document.getElementById('kws-kw-modal')) return;
      if (window.KWSSharedKeywordEditor) {
        window.KWSSharedKeywordEditor.open({
          modalId: 'kws-kw-modal',
          inputId: 'kws-keyword',
          previewId: 'kws-keyword-preview',
          storageKey: 'kwsKeyword',
          historyKey: HISTORY_KEY,
          onSaved: (val, profile) => {
            GLOBAL_KEYWORD = val;
            HISTORY.__keyword_profile__ = profile;
            updateKeywordPreview(null);
          }
        });
      } else {
        createKeywordModal($d);
      }
    });
    updateKeywordPreview($d);

    // ── Results: Clear All ─────────────────
    $d('kws-res-clear').addEventListener('click', () => {
      if (!RESULT_TABS.length) return;
      const currentTab = (ACTIVE_TAB >= 0 && RESULT_TABS[ACTIVE_TAB]) ? RESULT_TABS[ACTIVE_TAB] : null;
      window.KWSClearDialog({
        running: RESULT_TABS.filter(t => t.live && SCAN_STATES[t.channel]?.running).map(t => t.channel),
        currentLabel: currentTab ? currentTab.channel : null,
        tabCount: RESULT_TABS.length,
        onCurrent: () => {
          const idx = RESULT_TABS.indexOf(currentTab);
          if (idx >= 0) RESULT_TABS.splice(idx, 1);
          ACTIVE_TAB = RESULT_TABS.length ? Math.min(idx, RESULT_TABS.length - 1) : -1;
          renderResultTabs(); renderFullResultList(); updateActiveTabUI();
        },
        onAll: () => {
          RESULT_TABS.length = 0;
          ACTIVE_TAB = -1;
          renderResultTabs(); renderFullResultList(); updateActiveTabUI();
        },
      });
    });

    updateActiveTabUI();
  }

  // ── Channel Dropdown ───────────────────────────────────────
  function renderChannelDropdown(query) {
    const drop = document.getElementById('kws-ch-dropdown');
    if (!drop) return;
    const q = (query || '').toLowerCase().trim();
    const entries = Object.entries(HISTORY)
      .filter(([ch]) => ch !== "__keyword_profile__" && (!q || ch.includes(q)))
      .sort((a, b) => (b[1].searchedAt || '').localeCompare(a[1].searchedAt || ''))
      .slice(0, 8);
    if (!entries.length || !q) { drop.style.display = 'none'; return; }
    drop.innerHTML = entries.map(([ch, h]) => {
      const info = h.matchedLines != null ? `<span style="color:#4b5563;font-size:10px;"> · ${h.matchedLines} hits</span>` : '';
      return `<div data-ch="${esc(ch)}" style="padding:8px 12px;cursor:pointer;border-bottom:1px solid rgba(255,255,255,0.05);font-size:12px;"
        onmouseenter="this.style.background='rgba(88,80,236,0.15)'" onmouseleave="this.style.background=''">
        <span style="color:#e5e7eb;font-weight:600;">${esc(ch)}</span>${info}</div>`;
    }).join('');
    drop.style.display = 'block';
  }

  function renderHistoryHint(channel) {
    const hint = document.getElementById('kws-history-hint');
    if (!hint) return;
    const h = channel ? HISTORY[channel.toLowerCase()] : null;
    if (!h) { hint.style.display = 'none'; return; }
    const daysAgo = h.searchedAt ? Math.floor((Date.now()-new Date(h.searchedAt))/86400000) : null;
    const when = daysAgo === 0 ? 'Today' : daysAgo === 1 ? 'Yesterday' : daysAgo !== null ? `${daysAgo}d ago` : '';
    hint.innerHTML = `<span style="font-weight:700;">${channel}</span> · ${when}${h.lastDate ? ' · up to ' + h.lastDate : ''} · ${h.matchedLines||0} hits`;
    hint.style.display = 'block';
  }



  // ══════════════════════════════════════════════════════════
  //  RESULT TABS — each tab tracks its own channel
  // ══════════════════════════════════════════════════════════
  function renderResultTabs() {
    const tabBar = document.getElementById('kws-result-tabs');
    if (!tabBar) return;

    tabBar.innerHTML = RESULT_TABS.map((t, i) => {
      const isActive  = i === ACTIVE_TAB;
      const ch        = esc(t.channel || '?');
      const chIcon    = '';
      const hits      = t.matchedLines || 0;
      const s         = SCAN_STATES[t.channel];
      const isQueued  = t.queued;                        // 🔴 queued
      const isLive    = t.live && s?.running;             // 🟠 scanning
      const isDone    = !t.live && !t.queued && hits > 0; // 🔵 done + results
      const isEmpty   = !t.live && !t.queued && hits === 0; // ⚫ done + no results
      const pct       = s ? s.percent : 0;

      let bg, color, border;

      if (isQueued) {
        // 🔴 queued
        bg = 'rgba(239,68,68,0.12)'; color = 'rgba(248,113,113,0.85)'; border = isActive ? 'rgba(6,182,212,0.8)' : 'rgba(239,68,68,0.3)';
      } else if (isLive) {
        // 🟠 actively scanning
        bg = 'rgba(251,146,60,0.15)'; color = '#fb923c'; border = isActive ? 'rgba(6,182,212,0.8)' : 'rgba(251,146,60,0.35)';
      } else if (isDone && isActive) {
        // 🔵 done, active tab (cyan 테두리)
        bg = 'rgba(37,99,235,0.25)'; color = '#93c5fd'; border = 'rgba(6,182,212,0.8)';
      } else if (isDone && !isActive) {
        // 🔵 done, inactive tab
        bg = 'rgba(37,99,235,0.10)'; color = 'rgba(147,197,253,0.65)'; border = 'rgba(37,99,235,0.2)';
      } else if (isActive) {
        // 🟣 active (no results, cyan 테두리)
        bg = 'rgba(99,102,241,0.2)'; color = '#a5b4fc'; border = 'rgba(6,182,212,0.8)';
      } else {
        // ⚫ inactive (no results)
        bg = 'rgba(255,255,255,0.05)'; color = 'rgba(148,163,184,0.55)'; border = 'rgba(255,255,255,0.07)';
      }

      const liveTag   = isLive   ? `<span style="font-size:9px;margin-left:2px;">⏳${pct}%</span>` : '';
      const queuedTag = isQueued ? `<span style="font-size:9px;margin-left:2px;opacity:0.8;">queued</span>` : '';
      const doneTag   = isDone && !isActive ? `<span style="font-size:9px;margin-left:2px;opacity:0.6;">✓</span>` : '';

      return `<div style="display:inline-flex;align-items:center;border-radius:8px;overflow:hidden;border:1px solid ${border};">
        <button data-tab="${i}" style="padding:5px 10px;border:none;cursor:pointer;font-size:11px;font-weight:700;white-space:nowrap;background:${bg};color:${color};display:flex;align-items:center;gap:3px;${isQueued ? 'opacity:0.85;' : ''}">
          ${chIcon}${ch}${hits ? ` <span style="color:#4ade80;">(${hits})</span>` : ''}${liveTag}${queuedTag}${doneTag}
        </button>
        <button data-close="${i}" style="padding:4px 6px;border:none;cursor:pointer;font-size:11px;background:${bg};color:${color};opacity:0.5;border-left:1px solid ${border};">×</button>
      </div>`;
    }).join('');

    tabBar.querySelectorAll('[data-tab]').forEach(btn => {
      btn.addEventListener('click', () => {
        ACTIVE_TAB = parseInt(btn.dataset.tab);
        renderFullResultList();
        renderResultTabs();
        updateActiveTabUI();
        const ch = getActiveChannel();
        const chInput = document.getElementById('kws-channel');
        if (chInput && ch) { chInput.value = ch; renderHistoryHint(ch); }
        const statusCh = document.getElementById('kws-status-channel');
        if (statusCh) statusCh.textContent = ch ? `(${ch})` : '';
      });
    });
    tabBar.querySelectorAll('[data-close]').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        const i = parseInt(btn.dataset.close);
        const tab = RESULT_TABS[i];
        if (tab) {
          const s = SCAN_STATES[tab.channel];
          const isRunning = !!(tab.live && s?.running);
          const hasResults = (tab.matchedLines || 0) > 0;
          // 대기열(queued)에 걸려있는 탭은 여기서 그냥 탭만 지우면 background의 큐에는
          // 여전히 남아있어서 나중에 알아서 스캔을 시작해버림 — 배너에 있던 전용 Cancel
          // 버튼이 하던 일(KWS_CANCEL_QUEUE 전송)을 여기서도 그대로 해줘야 진짜로 취소됨.
          if (tab.queued) {
            chrome.runtime.sendMessage({ type: 'KWS_CANCEL_QUEUE', channel: tab.channel });
            if (s) { s.queued = false; s.message = 'Cancelled'; }
          }
          if (isRunning || hasResults) {
            const reason = isRunning
              ? 'is still scanning'
              : `has ${tab.matchedLines} matched result(s)`;
            if (!confirm(`"${tab.channel}" tab ${reason}.\n\nClose this tab anyway?`)) return;
            if (isRunning) {
              try { chrome.runtime.sendMessage({ type: 'KWS_STOP', channel: tab.channel }); } catch (e) {}
              s.running = false;
              s.message = 'Stopped';
              tab.live = false;
            }
          }
        }
        RESULT_TABS.splice(i, 1);
        if (ACTIVE_TAB >= RESULT_TABS.length) ACTIVE_TAB = RESULT_TABS.length - 1;
        renderFullResultList();
        renderResultTabs();
        updateActiveTabUI();
      });
    });

    updateSummaryText();

    const statusCh = document.getElementById('kws-status-channel');
    const ch = getActiveChannel();
    if (statusCh) statusCh.textContent = ch ? `(${ch})` : '';
  }
  function updateSummaryText() {
    const sumEl = document.getElementById('kws-results-summary');
    if (!sumEl) return;
    const tab = RESULT_TABS[ACTIVE_TAB];
    if (!tab) { sumEl.textContent = 'No results'; return; }
    const hits = tab.matchedLines || 0;
    const s    = SCAN_STATES[tab.channel];
    const live = (tab.live && s?.running) ? ' · scanning...' : '';
    sumEl.textContent = hits ? `${hits} hits${live}` : ((tab.live && s?.running) ? 'Scanning...' : 'No results');
  }

  // ── Real-time group append ─────────────────────────────────
  function appendGroupToList(group, channel) {
    const list = document.getElementById('kws-results-list');
    if (!list) return;
    const placeholder = list.querySelector('[data-placeholder]');
    if (placeholder) placeholder.remove();
    list.appendChild(buildGroupCard(group, channel));
  }

  function renderFullResultList() {
    const list = document.getElementById('kws-results-list');
    if (!list) return;
    list.innerHTML = '';
    // Close any open VOD popup
    const area = document.getElementById('kws-vod-popup-area');
    if (area) { area.innerHTML = ''; area._lastBtn = null; }

    const tab = RESULT_TABS[ACTIVE_TAB];
    if (!tab) {
      list.innerHTML = `<div data-placeholder style="padding:14px;border-radius:14px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.05);color:rgba(100,116,139,0.6);font-size:12px;text-align:center;">Results will appear here after scanning.</div>`;
      return;
    }
    const groups = tab.groups || [];
    const s = SCAN_STATES[tab.channel];
    if (!groups.length) {
      const msg = (tab.live && s?.running) ? 'Scanning... results will appear in real-time.' : 'No matches found.';
      list.innerHTML = `<div data-placeholder style="padding:14px;border-radius:14px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.05);color:rgba(100,116,139,0.6);font-size:12px;text-align:center;">${msg}</div>`;
      return;
    }
    groups.forEach(g => list.appendChild(buildGroupCard(g, tab.channel)));
  }

  const TRANSLATE_CACHE = new Map();

  function getTranslateLang() {
    const sel = document.getElementById('kws-translate-lang');
    return (sel?.value || localStorage.getItem(TRANSLATE_LANG_KEY) || 'en').trim() || 'en';
  }









  async function translateTextAuto(text, targetLang) {
    const src = String(text || '').trim();
    if (!src) return '';
    const lang = targetLang || getTranslateLang();
    const cacheKey = `${lang}\n${src}`;
    if (TRANSLATE_CACHE.has(cacheKey)) return TRANSLATE_CACHE.get(cacheKey);
    const data = await globalThis.KWSGTranslate(src, lang); // 1.2.5.46: rotates gtx / dict-chrome-ex / at (platform.js)
    const translated = (data?.[0] || []).map(x => x?.[0] || '').join('').trim();
    if (!translated) throw new Error('empty translation');
    TRANSLATE_CACHE.set(cacheKey, translated);
    return translated;
  }

  function openGoogleTranslate(text, targetLang) {
    const lang = targetLang || getTranslateLang();
    const url = `https://translate.google.com/?sl=auto&tl=${encodeURIComponent(lang)}&text=${encodeURIComponent(text || '')}&op=translate`;
    window.open(url, '_blank');
  }

  function buildGroupCard(group, channel) {
    const card = document.createElement('div');
    card.dataset.groupDate = group.date;
    card.style.cssText = 'padding:11px 13px;border-radius:14px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);backdrop-filter:blur(4px);';

    const hdr = document.createElement('div');
    hdr.style.cssText = 'display:flex;align-items:center;justify-content:space-between;gap:8px;font-weight:800;font-size:12px;line-height:1.4;color:#7dd3fc;margin-bottom:7px;padding-bottom:5px;border-bottom:1px solid rgba(255,255,255,0.06);';
    const hdrLeft = document.createElement('span');
    hdrLeft.textContent = `📅 ${group.displayDate || group.date}  (${(group.rawMessages || []).length} hits)`;
    { const _names = [...new Set((group.rawMessages || []).map(m => m.vod_title).filter(t => t && t !== '(CDN recovered)'))];
      if (_names.length) { hdrLeft.title = _names.join('\n'); hdrLeft.style.cursor = 'help'; } }
    hdr.appendChild(hdrLeft);
    if (group.sourceServices?.length) {
      const labelMap = { zonian: 'Zonian', twitch: 'Native API' };
      const colorMap = {
        zonian: { bg: 'rgba(96,165,250,0.14)', fg: '#93c5fd', bd: 'rgba(96,165,250,0.3)' },
        twitch: { bg: 'rgba(52,211,153,0.14)', fg: '#6ee7b7', bd: 'rgba(52,211,153,0.3)' },
      };
      const badgeGroup = document.createElement('span');
      badgeGroup.style.cssText = 'flex-shrink:0;display:flex;align-items:center;gap:4px;';
      group.sourceServices.forEach(s => {
        const label = labelMap[s] || s;
        const c = colorMap[s] || { bg: 'rgba(96,165,250,0.14)', fg: '#93c5fd', bd: 'rgba(96,165,250,0.3)' };
        const badge = document.createElement('span');
        badge.textContent = label;
        badge.title = `Found via ${label}`;
        badge.style.cssText = `font-size:9px;font-weight:800;padding:2px 7px;border-radius:99px;letter-spacing:0.02em;background:${c.bg};color:${c.fg};border:1px solid ${c.bd};`;
        badgeGroup.appendChild(badge);
      });
      hdr.appendChild(badgeGroup);
    }
    card.appendChild(hdr);

    const msgList = document.createElement('div');
    msgList.style.cssText = 'display:flex;flex-direction:column;gap:5px;';
    const _trRows = [];

    const _msgs = group.rawMessages || [];
    // 연속 클러스터 감지 (3개 이상, 30초 이내 간격)
    const _sec = m => {
      if (m.playback_ts != null) {
        if (typeof m.playback_ts === 'number') return m.playback_ts;
        // "H:MM:SS" 또는 "MM:SS" 형식 파싱
        const parts = String(m.playback_ts).split(':').map(Number);
        if (parts.length === 3) return parts[0]*3600 + parts[1]*60 + parts[2];
        if (parts.length === 2) return parts[0]*60 + parts[1];
        return parseInt(m.playback_ts)||0;
      }
      // playback_ts 없으면 (Time error) → 실제 방송 timestamp 사용
      // timestamp 필드가 비어있는 경우가 있어서, 로컬 시간 표시에 쓰는 것과 동일하게
      // rawTs/ts까지 폴백 체크 — 안 그러면 전부 -1로 뭉개져서 실제로는 몇 시간씩
      // 떨어진 항목들이 같은 클러스터로 잘못 묶이는 버그가 있었음
      const raw = (typeof m.timestamp === 'number' ? m.timestamp : null)
        ?? (typeof m.rawTs === 'number' ? m.rawTs : null)
        ?? m.timestamp ?? m.rawTs ?? m.ts;
      if (typeof raw === 'number') return raw / 1000;
      if (typeof raw === 'string') {
        const parsed = Date.parse(raw);
        if (!isNaN(parsed)) return parsed / 1000;
      }
      return -1;
    };
    // timestamp 기준 정렬
    _msgs.sort((a, b) => _sec(a) - _sec(b));
    const _clusterSet = new Set();
    // 인접 쌍 간격 < 180초면 같은 클러스터
    const _clusterGroup = new Map();
    let _gid2 = 0, _gi2 = 0;
    while (_gi2 < _msgs.length) {
      let _gj2 = _gi2 + 1;
      while (_gj2 < _msgs.length && _sec(_msgs[_gj2]) - _sec(_msgs[_gj2-1]) < 180) _gj2++;
      if (_gj2 - _gi2 >= 2) {
        for (let _gk = _gi2; _gk < _gj2; _gk++) {
          _clusterSet.add(_gk);
          _clusterGroup.set(_gk, _gid2);
        }
        _gid2++;
      }
      _gi2 = _gj2;
    }
    _msgs.forEach((item, _itemIdx) => {
      const _isCluster = _clusterSet.has(_itemIdx);
      const _cgid = _clusterGroup.get(_itemIdx);
      const _isFirst = _isCluster && (_clusterGroup.get(_itemIdx-1) !== _cgid);
      const _isLast  = _isCluster && (_clusterGroup.get(_itemIdx+1) !== _cgid);
      const _cbr = _isCluster ? `${_isFirst?'9px 9px':'0 0'} ${_isLast?'9px 9px':'0 0'}` : '9px';
      const row = document.createElement('div');
      const _mt = (_isCluster && _isFirst && _itemIdx > 0) ? 'margin-top:6px;' : (!_isCluster && _itemIdx > 0 ? '' : '');
      row.style.cssText = `display:grid;grid-template-columns:auto 1fr;gap:8px;align-items:start;padding:6px 9px;border-radius:${_cbr};background:${_isCluster?'rgba(6,182,212,0.06)':'rgba(255,255,255,0.03)'};border:1px solid ${_isCluster?'rgba(6,182,212,0.45)':'rgba(255,255,255,0.06)'};border-bottom:${_isCluster&&!_isLast?'1px solid rgba(6,182,212,0.2)':'1px solid '+(_isCluster?'rgba(6,182,212,0.45)':'rgba(255,255,255,0.06)')};${_isCluster&&_isFirst?'box-shadow:0 0 8px rgba(6,182,212,0.15);':''}${_mt}`;

      const timeWrap = document.createElement('div');
      timeWrap.style.cssText = 'display:flex;flex-direction:column;align-items:center;min-width:max-content;';

      const btn = document.createElement('button');
      btn.className = 'kws-time-btn';
      // Fixed single-line size — same as original button
      btn.style.cssText = window.KWS_TBTN.base + window.KWS_TBTN.off;

      const localTime = formatLocalBroadcastTime(item.rawTs || item.timestamp || item.ts);
      const localTimeLine = document.createElement('div');
      localTimeLine.className = 'kws-local-time';
      localTimeLine.textContent = localTime || 'local time ?';

      if (item.playback_ts != null) {
        // VOD playback offset — primary display
        btn.textContent = '▶ ' + item.playback_ts;
        // Default: blue (unvisited). visited class overrides to green.
        btn.title = 'Click to open VOD at this timestamp\n'
          + '▶ VOD offset: ' + item.playback_ts
          + (item.vod_title ? '\n📺 ' + item.vod_title : '')
          + '\n⏱ Broadcast: ' + item.ts
          + (localTime ? '\n🕒 Local: ' + localTime : '');
        // ── clickedTimes 복원 — 이전 세션에서 클릭된 타임스탬프면 초록색으로 ──
        const ck = (channel || '').toLowerCase().trim();
        const tsKey = item.ts || item.rawTs || item.timestamp || '';
        if (ck && tsKey && HISTORY[ck]?.clickedTimes?.[tsKey]) {
          btn.classList.add('visited');
        }
      } else {
        // VOD not found or fetch failed — keep same blue style as normal buttons
        const _vs = item.vod_state;
        btn.textContent = _vs === 'expired' ? '⚠ VOD expired' : '⚠ Time error';
        btn.classList.add('kws-time-btn-error');
        btn.title = (_vs === 'expired' ? 'Stream exists but its video was not found on Twitch CDN (deleted / expired)\n' : 'Could not resolve VOD playback time\n')
          + '⏱ Broadcast: ' + item.ts
          + (localTime ? '\n🕒 Local: ' + localTime : '')
          + '\nClick to try opening VOD anyway';
      }

      btn.addEventListener('click', async e => {
        e.stopPropagation();
        // skip if already loading
        if (btn._loading) return;
        btn._loading = true;

        // reset error area
        const area = document.getElementById('kws-vod-popup-area');
        if (area) area.innerHTML = '';

        const origText = btn.textContent;
        btn.textContent = '⏳ Loading...';
        btn.style.opacity = '0.6';

        try {
          await openVODInlineAtTimestamp({
            btn,
            channel,
            date: group.displayDate || group.date,
            sourceDate: group.sourceDate || group.date,
            rawTs: item.rawTs,
            ts: item.ts,
            playback_offset: item.playback_offset ?? null,
            vod_id: item.vod_id ?? null,
            cdn_source: item.cdn_source ?? null,
          });
          btn.classList.add('visited');
          // ── clickedTimes 영구 저장 ──
          try {
            const ck = (channel || '').toLowerCase().trim();
            const tsKey = item.ts || item.rawTs || item.timestamp || '';
            if (ck && tsKey) {
              const cur = HISTORY[ck] || {};
              const clicked = cur.clickedTimes || {};
              clicked[tsKey] = true;
              await saveHistory(ck, { ...cur, clickedTimes: clicked });
            }
          } catch {}
        } catch (err) {
          // show error in popup
          if (area) {
            area.innerHTML = `
              <div style="margin-top:10px;display:flex;align-items:flex-start;gap:10px;background:rgba(10,12,18,0.82);backdrop-filter:blur(12px);border:1px solid rgba(248,113,113,0.28);border-radius:16px;padding:12px 14px;font-family:-apple-system,BlinkMacSystemFont,sans-serif;box-shadow:0 8px 28px rgba(0,0,0,0.45);">
                <div style="flex-shrink:0;width:26px;height:26px;border-radius:50%;background:rgba(248,113,113,0.16);display:flex;align-items:center;justify-content:center;font-size:13px;">⚠</div>
                <div style="min-width:0;flex:1;">
                  <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:4px;">
                    <div style="font-weight:700;font-size:12px;color:#fca5a5;">Couldn't load this VOD</div>
                    <button id="kws-err-close" style="flex-shrink:0;width:20px;height:20px;border:none;border-radius:6px;background:rgba(255,255,255,0.06);color:rgba(255,255,255,0.5);cursor:pointer;font-size:13px;line-height:1;display:flex;align-items:center;justify-content:center;">×</button>
                  </div>
                  <div style="font-size:11px;color:rgba(255,255,255,0.55);white-space:pre-wrap;line-height:1.6;word-break:break-word;">${esc(err.message || 'Unknown error')}</div>
                </div>
              </div>`;
            area.querySelector('#kws-err-close')?.addEventListener('click', () => { area.innerHTML = ''; });
            // 이미 화면에 보이는 위치면 스크롤 안 함 — 화면 밖으로 벗어났을 때만 부드럽게 보정
            setTimeout(() => {
              const r = area.getBoundingClientRect();
              const inView = r.top >= 0 && r.bottom <= window.innerHeight;
              if (!inView) area.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }, 50);
          }
        } finally {
          btn.textContent = origText;
          btn.style.opacity = '';
          btn._loading = false;
        }
      });

      const txt = document.createElement('div');
      txt.style.cssText = 'min-width:0;';

      const kwBadge = document.createElement('span');
      kwBadge.style.cssText = 'display:inline-block;margin-bottom:3px;padding:1px 6px;background:rgba(234,179,8,0.15);color:#fde047;border:1px solid rgba(234,179,8,0.25);border-radius:5px;font-size:9px;font-weight:700;white-space:nowrap;';
      kwBadge.textContent = (item.keywords && item.keywords.length)
        ? item.keywords.join(', ')
        : kwPreview(safeKwStrings(GLOBAL_KEYWORD ? GLOBAL_KEYWORD.split(',').map(s=>s.trim()).filter(s=>!s.startsWith('-')) : []), 3);

      const msgLine = document.createElement('div');
      msgLine.style.cssText = 'font-size:12px;color:#cbd5e1;word-break:break-word;line-height:1.45;';
      msgLine.innerHTML = `<span style="color:#a5b4fc;font-weight:600;">${esc(item.username)}</span>: ${hlKw(esc(item.message || ''), safeKwStrings(GLOBAL_KEYWORD ? GLOBAL_KEYWORD.split(',').map(s=>s.trim()).filter(s=>s&&!s.startsWith('-')) : []))}`;

      const translatedLine = document.createElement('div');
      translatedLine.style.cssText = 'display:none;margin-top:4px;padding:5px 7px;border-radius:7px;background:rgba(14,165,233,0.07);border:1px solid rgba(14,165,233,0.14);color:#bae6fd;font-size:11px;line-height:1.45;word-break:break-word;';
      _trRows.push({ text: item.message || '', box: translatedLine, cached: item._kwsTranslation, onDone: (l, t) => { item._kwsTranslation = { lang: l, text: t }; }, onHide: () => { item._kwsTranslation = null; } });

      txt.appendChild(kwBadge);
      txt.appendChild(document.createElement('br'));
      txt.appendChild(msgLine);
      txt.appendChild(translatedLine);
      timeWrap.appendChild(btn);
      timeWrap.appendChild(localTimeLine);
      row.appendChild(timeWrap); row.appendChild(txt);
      msgList.appendChild(row);
    });

    if (_trRows.length) {
      const gBtn = document.createElement('button');
      gBtn.style.cssText = 'flex-shrink:0;font-size:9px;font-weight:800;padding:2px 7px;border-radius:99px;letter-spacing:0.02em;cursor:pointer;font-family:inherit;line-height:1.3;background:rgba(14,165,233,0.14);color:#7dd3fc;border:1px solid rgba(14,165,233,0.3);';
      const _bg = hdr.children[1];
      if (_bg) _bg.insertBefore(gBtn, _bg.firstChild); else hdr.appendChild(gBtn);
      window.KWSBatchTranslate(gBtn, _trRows, getTranslateLang, translateTextAuto, openGoogleTranslate);
    }
    card.appendChild(msgList);
    return card;
  }

  // ══════════════════════════════════════════════════════════
  //  VOD INLINE OPEN — click timestamp to launch inline player
  //  1) Try matching from Twitch GQL VOD list
  //  2) If not found, fetch stream_id from Sullygnome and brute-force CDN
  //  3) Once source URL is obtained, open in inline player
  // ══════════════════════════════════════════════════════════
  async function openVODInlineAtTimestamp({ btn, channel, date, sourceDate, rawTs, ts, playback_offset, vod_id, cdn_source }) {

    let targetMs = normalizeTimestampMs(rawTs);
    if (!targetMs && date) targetMs = new Date(`${date}T00:00:00`).getTime();
    if (!targetMs && sourceDate) targetMs = new Date(`${sourceDate}T00:00:00Z`).getTime();
    if (!targetMs) throw new Error('Cannot parse timestamp.');

    const targetSecs = Math.floor(targetMs / 1000);
    let tokens = {};
    try { tokens = getTokensFromCookies(); } catch (e) {}

    let bestVod = null;
    let vods = null;
    // 스캔 단계에서 Cloudfront로 이미 확인된 영상이면 재탐색 없이 바로 그 주소로 재생
    if (cdn_source && playback_offset != null) {
      const startSecs = targetSecs - playback_offset;
      bestVod = { is_cdn_recovered: true, stream_id: vod_id, vod_id: vod_id, timestamp: startSecs * 1000, timestamp_seconds: startSecs, source: cdn_source, src: cdn_source };
    }

    // ── Step 1: Fetch available VODs from Twitch GQL ──
    if (!bestVod) vods = await requestFromBackground({ cmd: 'getAvailableVODinfo', params: { ...tokens, channel_login: channel } });

    if (vods?.length) {
      for (const vod of vods) {
        const vStart = vod.stream_start_seconds ?? vod.timestamp_seconds ?? (vod.timestamp != null ? Math.floor(vod.timestamp / 1000) : null);
        if (vStart == null) continue;
        const vDur = vod.duration != null ? Math.floor(vod.duration / 1000) : 18000;
        if (targetSecs >= (vStart - 300) && targetSecs <= (vStart + vDur + 300)) { bestVod = vod; break; }
      }
    }

    // ── Step 2: Not in GQL — fetch stream_id from Sullygnome and brute-force CDN ──
    if (!bestVod) {
      const sullyStreams = await requestFromBackground({ cmd: 'getSullyStreamsData', params: { channel_login: channel } });

      let sullyMatch = null;
      if (sullyStreams?.length) {
        for (const s of sullyStreams) {
          const sStart = s.timestamp_seconds ?? (s.timestamp ? Math.floor(s.timestamp / 1000) : null);
          if (sStart == null) continue;
          const sDur = s.duration ? Math.floor(s.duration / 1000) : 18000;
          if (targetSecs >= (sStart - 300) && targetSecs <= (sStart + sDur + 300)) { sullyMatch = s; break; }
        }
      }

      if (!sullyMatch) {
        let sullyWhy = '';
        if (!Array.isArray(sullyStreams)) { try { sullyWhy = await requestFromBackground({ cmd: 'kwsSullyDiag' }); } catch (_) {} }
        // both failed — throw error
        const availableList = (vods?.length ? vods : []).slice(0, 8).map(v => {
          const vStart = v.stream_start_seconds ?? v.timestamp_seconds ?? (v.timestamp ? Math.floor(v.timestamp / 1000) : 0);
          const vEnd   = vStart + (v.duration ? Math.floor(v.duration / 1000) : 18000);
          return `• ${formatDateFromSecs(vStart)} ~ ${formatDateFromSecs(vEnd)}`;
        }).filter(Boolean).join('\n');
        throw new Error(
          `${date} ${ts} : no matching VOD found.\n\nAvailable VODs:\n${availableList || '(none)'}\n\n[debug] Twitch VOD list: ${Array.isArray(vods) ? vods.length : 'failed'} · Sullygnome streams: ${Array.isArray(sullyStreams) ? sullyStreams.length : 'failed'}${sullyWhy ? ' (' + sullyWhy + ')' : ''}`
        );
      }

      // Got stream_id and timestamp_seconds from Sullygnome — brute-force CDN
      const cdnResult = await requestFromBackground({
        cmd: 'getStreamDetailsFromStreamId',
        params: {
          channel_login: channel,
          stream_id: sullyMatch.stream_id,
          timestamp: sullyMatch.timestamp,
          timestamp_seconds: sullyMatch.timestamp_seconds,
        }
      });

      if (!cdnResult?.source && !cdnResult?.url) {
        let diag = '';
        try { diag = await requestFromBackground({ cmd: 'kwsCdnProbe', params: { channel_login: channel, stream_id: sullyMatch.stream_id, timestamp: sullyMatch.timestamp, timestamp_seconds: sullyMatch.timestamp_seconds } }); } catch (_) {}
        if (/GEO-BLOCK/.test(diag || '')) {
          throw new Error(`한국 IP에서는 Twitch VOD CDN 접근이 차단되어 인라인 재생이 불가합니다.\n상단 🔗 버튼으로 원본 VOD를 여세요. (한국 밖 IP/VPN에서는 재생될 수 있습니다)\n\n[debug] ${diag}`);
        }
        throw new Error(`VOD CDN URL을 찾을 수 없습니다. 삭제됐거나 만료된 영상이거나, CDN 접근이 차단됐을 수 있습니다.\n\n[debug] ${diag || 'probe n/a'}`);
      }

      bestVod = {
        ...sullyMatch,
        source: cdnResult.source || cdnResult.url,
        src: cdnResult.source || cdnResult.url,
      };
    }

    const vodStart = bestVod.stream_start_seconds ?? bestVod.timestamp_seconds ?? Math.floor((bestVod.timestamp || 0) / 1000);
    // Prefer pre-computed playback offset if available (more accurate, avoids timezone drift)
    const seekSec  = playback_offset != null
      ? Math.max(0, playback_offset - 30)
      : Math.max(0, targetSecs - vodStart - 30);

    // ── Step 3: 이미 같은 VOD가 열려 있으면 새로 안 만들고 바로 seek만 (실패하면 아래 재빌드로 폴백) ──
    const existingViewer = document.getElementById('tvd_video_viewer');
    if (existingViewer && bestVod.vod_id != null && existingViewer.dataset.vodId === String(bestVod.vod_id) && typeof existingViewer._twitchSeekTo === 'function') {
      const seeked = await existingViewer._twitchSeekTo(seekSec);
      if (seeked) return;
      // 실패했으면 그대로 아래 정상 재빌드 로직으로 계속 진행
    }

    // ── Step 3: Open in inline player ──
    if (typeof getStreamInformationAndBuildUI === 'function') {
      await getStreamInformationAndBuildUI({
        ...bestVod,
        timestamp: targetMs,
        ref_elm: btn?.parentElement || document.body,
      });
      await new Promise(r => setTimeout(r, 3500));
      await seekVODPlayer(seekSec); return;
    }

    if (typeof runTwitchSourceBuild === 'function' && bestVod.source) {
      await runTwitchSourceBuild({ ...bestVod, timestamp: targetMs, ref_elm: btn?.parentElement || document.body });
      await new Promise(r => setTimeout(r, 3500));
      await seekVODPlayer(seekSec); return;
    }

    throw new Error('Could not open inline player. Please make sure you are logged in to Twitch.');
  }

  // (legacy — no longer used)

  async function seekVODPlayer(seconds) {
    if (!(seconds >= 0)) return;
    const find = () => document.querySelector('#tvd_video_viewer video') || document.querySelector('video.pop_out_video');

    // 최대 20초 대기, 0.3초 간격
    for (let i = 0; i < 66; i++) {
      const v = find();
      if (v) {
        // seekable 상태 확인 — readyState >= 2 (HAVE_CURRENT_DATA) 이상
        if (v.readyState >= 2 && v.seekable?.length > 0) {
          try { v.currentTime = seconds; } catch (e) {}
          // 0.5초 후 재확인 (HLS는 seek 후 약간 보정이 필요)
          await new Promise(r => setTimeout(r, 500));
          if (Math.abs(v.currentTime - seconds) > 5) {
            try { v.currentTime = seconds; } catch (e) {}
          }
          return;
        }
        // loadedmetadata 이벤트 대기
        if (v.readyState < 1) {
          await new Promise(res => {
            let done = false;
            const fin = () => { if (done) return; done = true; v.removeEventListener('loadedmetadata', ok); res(); };
            const ok = () => fin();
            v.addEventListener('loadedmetadata', ok, { once: true });
            setTimeout(fin, 1000);
          });
        }
      }
      await new Promise(r => setTimeout(r, 300));
    }
  }

  // ══════════════════════════════════════════════════════════
  //  SITE BADGES — click = immediate scan
  // ══════════════════════════════════════════════════════════
  let _badgeTimer = null;
  function injectSiteBadges() { clearTimeout(_badgeTimer); _badgeTimer = setTimeout(_doInjectBadges, 400); }

  function _doInjectBadges() {
    if (!document.getElementById('kws-badge-style')) {
      const s = document.createElement('style');
      s.id = 'kws-badge-style';
      s.textContent = `.kws-search-badge{display:inline-flex;align-items:center;padding:1px 6px;border-radius:99px;font-size:9px;font-weight:700;white-space:nowrap;vertical-align:middle;margin-left:4px;cursor:pointer;font-family:-apple-system,sans-serif;line-height:1.5;letter-spacing:0.01em;transition:all 0.15s;}`;
      document.head.appendChild(s);
    }

    document.querySelectorAll('.kws-search-badge').forEach(el => el.remove());

    const selectors = [
      'a[href^="/"][data-a-target="user-display-name"]',
      'a[href^="/"][data-a-target="participant-username"]',
      'a[data-a-target="live-channel-card-title"]',
      'a[data-a-target="preview-card-channel-link"]',
      'p[data-a-target="side-nav-title"] a',
      'a[href^="/"]',
    ];
    const seen = new Set();

    for (const sel of selectors) {
      document.querySelectorAll(sel).forEach(el => {
        if (seen.has(el)) return; seen.add(el);
        const href = el.getAttribute('href') || '';
        const m = /^\/([a-zA-Z0-9_]{3,25})(\/|$)/.exec(href.split('?')[0]);
        if (!m) return;
        const slug = m[1].toLowerCase();
        const skip = ['directory','videos','clips','search','subscriptions','settings','downloads','messages','friends','following','p','store'];
        if (skip.includes(slug) || /^\d+$/.test(slug)) return;
        if (el.querySelector('.kws-search-badge') || el.nextElementSibling?.classList?.contains('kws-search-badge')) return;

        const h = HISTORY[slug];
        const s = badgeState(slug);
        const isScanning = s?.running;
        const badge = document.createElement('span');
        badge.className = 'kws-search-badge';

        if (isScanning) {
          // Currently scanning — show live progress
          badge.textContent = `⏳ ${s.percent}%`;
          badge.style.cssText = 'background:rgba(251,146,60,0.15);border:1px solid rgba(251,146,60,0.4);color:#fb923c;';
          badge.title = `Scanning ${slug}... ${s.done}/${s.total} days · ${s.matchedLines} hits`;
          badge.style.cursor = 'default';
          // 통일 규칙: 이미 검색 중인 뱃지는 눌러도 아무 동작 없음 (아래 채널 링크로 새지도 않게 막기만 함)
          badge.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); });
        } else if (s?.queued) {
          // Queued — cyan
          badge.textContent = 'queued';
          badge.style.cssText = 'background:rgba(6,182,212,0.12);border:1px solid rgba(6,182,212,0.35);color:#22d3ee;cursor:default;';
          badge.title = s.message || `Queued — waiting for slot`;
        } else if (!h) {
          // Not searched — red, click = immediate scan
          badge.textContent = 'Search ▶';
          badge.style.cssText = 'background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);color:#f87171;';
          badge.title = `Not searched · Click to scan ${slug}`;
          badge.addEventListener('mouseenter', () => badge.style.background = 'rgba(239,68,68,0.2)');
          badge.addEventListener('mouseleave', () => badge.style.background = 'rgba(239,68,68,0.1)');
          badge.addEventListener('click', e => {
            e.preventDefault(); e.stopPropagation();
            triggerBadgeScan(slug);
          });
        } else {
          // Has history — green/yellow, click = refresh scan
          const daysAgo = h.searchedAt ? Math.floor((Date.now() - new Date(h.searchedAt)) / 86400000) : null;
          const isRecent = daysAgo !== null && daysAgo <= 1;
          const isStale = daysAgo !== null && daysAgo > (globalThis.__kwsRedDays || 14);
          const label = daysAgo === 0 ? 'Today ↺' : daysAgo === 1 ? 'Yesterday ↺' : daysAgo !== null ? `${daysAgo}d ago ↺` : 'Searched ↺';
          const col = isStale
            ? { bg: 'rgba(239,68,68,0.1)',  bdr: 'rgba(239,68,68,0.3)',  txt: '#f87171', hov: 'rgba(239,68,68,0.2)' }
            : isRecent
              ? { bg: 'rgba(34,197,94,0.12)', bdr: 'rgba(34,197,94,0.35)', txt: '#4ade80', hov: 'rgba(34,197,94,0.22)' }
              : { bg: 'rgba(234,179,8,0.12)',  bdr: 'rgba(234,179,8,0.35)',  txt: '#fbbf24', hov: 'rgba(234,179,8,0.22)' };
          badge.textContent = label;
          badge.style.cssText = `background:${col.bg};border:1px solid ${col.bdr};color:${col.txt};`;
          badge.title = `${h.matchedLines || 0} hits · ${h.matchedDays || 0} days · Click to re-scan`;
          badge.addEventListener('mouseenter', () => badge.style.background = col.hov);
          badge.addEventListener('mouseleave', () => badge.style.background = col.bg);
          badge.addEventListener('click', e => {
            e.preventDefault(); e.stopPropagation();
            triggerBadgeScan(slug);
          });
        }

        // 메모가 있으면 배지 텍스트에 포함
        const h2 = HISTORY[slug];
        if (h2?.memo) {
          const short = h2.memo.length > 15 ? h2.memo.slice(0, 15) + '…' : h2.memo;
          const _prevText = badge.textContent;
          badge.textContent = '';
          const _t1 = document.createElement('span'); _t1.textContent = _prevText; badge.appendChild(_t1);
          const _t2 = document.createElement('span'); _t2.textContent = ' · ' + short; _t2.style.cssText = 'color:#f87171;font-weight:800;'; badge.appendChild(_t2);
          badge.title = (badge.title || '') + '\n📝 ' + h2.memo;
        }
        el.tagName === 'A' ? el.insertAdjacentElement('afterend', badge) : el.appendChild(badge);
      });
    }

    // TwitchTracker 전용 배지
    if (location.hostname === 'twitchtracker.com') {
      // 채널 목록 페이지: td a 에서 스트리머 ID 추출
      document.querySelectorAll('td a').forEach(el => {
        if (el.querySelector('.kws-search-badge') || el.nextElementSibling?.classList?.contains('kws-search-badge')) return;
        const text = el.textContent.trim();
        if (!text) return; // 텍스트 없는 링크(이미지 링크 등) 스킵
        const m = /twitchtracker\.com\/([a-zA-Z0-9_]{3,25})$/.exec(el.href);
        if (!m) return;
        const slug = m[1].toLowerCase();
        const skip = ['channels','games','clips','statistics','languages','subscribers'];
        if (skip.includes(slug)) return;
        if (el.querySelector('.kws-search-badge') || el.nextElementSibling?.classList?.contains('kws-search-badge')) return;

        const h = HISTORY[slug];
        const s = badgeState(slug);
        const badge = document.createElement('span');
        badge.className = 'kws-search-badge';

        if (s?.running) {
          badge.textContent = `⏳ ${s.percent}%`;
          badge.style.cssText = 'background:rgba(251,146,60,0.15);border:1px solid rgba(251,146,60,0.4);color:#fb923c;cursor:default;';
        } else if (s?.queued) {
          badge.textContent = 'queued';
          badge.style.cssText = 'background:rgba(6,182,212,0.12);border:1px solid rgba(6,182,212,0.35);color:#22d3ee;cursor:default;';
        } else if (!h) {
          badge.textContent = 'Search ▶';
          badge.style.cssText = 'background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);color:#f87171;';
          badge.addEventListener('mouseenter', () => badge.style.background = 'rgba(239,68,68,0.2)');
          badge.addEventListener('mouseleave', () => badge.style.background = 'rgba(239,68,68,0.1)');
          badge.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); triggerBadgeScan(slug); });
        } else {
          const daysAgo = h.searchedAt ? Math.floor((Date.now() - new Date(h.searchedAt)) / 86400000) : null;
          const isRecent = daysAgo !== null && daysAgo <= 1;
          const isStale = daysAgo !== null && daysAgo > (globalThis.__kwsRedDays || 14);
          const label = daysAgo === 0 ? 'Today ↺' : daysAgo === 1 ? 'Yesterday ↺' : daysAgo !== null ? `${daysAgo}d ago ↺` : 'Searched ↺';
          const col = isStale
            ? { bg: 'rgba(239,68,68,0.1)',  bdr: 'rgba(239,68,68,0.3)',  txt: '#f87171', hov: 'rgba(239,68,68,0.2)' }
            : isRecent
              ? { bg: 'rgba(34,197,94,0.12)', bdr: 'rgba(34,197,94,0.35)', txt: '#4ade80', hov: 'rgba(34,197,94,0.22)' }
              : { bg: 'rgba(234,179,8,0.12)',  bdr: 'rgba(234,179,8,0.35)',  txt: '#fbbf24', hov: 'rgba(234,179,8,0.22)' };
          badge.textContent = label;
          badge.style.cssText = `background:${col.bg};border:1px solid ${col.bdr};color:${col.txt};`;
          badge.addEventListener('mouseenter', () => badge.style.background = col.hov);
          badge.addEventListener('mouseleave', () => badge.style.background = col.bg);
          badge.addEventListener('click', e => {
            e.preventDefault(); e.stopPropagation();
            triggerBadgeScan(slug);
          });
        }

        el.insertAdjacentElement('afterend', badge);
      });

      // 스트리머 개인 페이지: URL에서 ID 추출 후 패널 표시
      const ttMatch = /twitchtracker\.com\/([a-zA-Z0-9_]{3,25})$/.exec(location.href.split('?')[0]);
      if (ttMatch) {
        const slug = ttMatch[1].toLowerCase();
        const skip = ['channels','games','clips','statistics','languages','subscribers'];
        if (!skip.includes(slug)) {
          // 패널이 없으면 스트리머 ID를 자동으로 설정
          const kwsInput = document.getElementById('kws-channel');
          if (kwsInput && !kwsInput.value) {
            kwsInput.value = slug;
          }
        }
      }
    }
  }


  async function triggerBadgeScan(slug) {
    if (SP_MODE) return spBadgeScan(slug);
    const keyword = GLOBAL_KEYWORD || document.getElementById('kws-keyword')?.value?.trim() || '';
    const endDate = GLOBAL_END_DATE || document.getElementById('kws-end-date')?.value || '';
    if (!keyword) { alert('⚠ No keywords set!\n\nPlease click the keyword button to set keywords first.'); document.getElementById('kws-keyword-btn')?.click(); return; }

    // Show panel if collapsed
    const panel = document.getElementById(PANEL_ID);
    const body  = document.getElementById('kws-panel-body');
    if (panel && body && panel.dataset.collapsed === 'true') {
      panel.dataset.collapsed = 'false';
      body.style.display = 'block';
      const tb = document.getElementById('kws-toggle-btn');
      if (tb) tb.textContent = '—';
      panel.style.width = '420px';
    }

    // Update channel input
    const chInput = document.getElementById('kws-channel');
    if (chInput) { chInput.value = slug; renderHistoryHint(slug); }

    // 이전 검색 기록 확인
    const h = HISTORY[slug.toLowerCase()];
    if (h?.lastDate) {
      showRescanPopup(slug, keyword, h.nickname || slug, h.lastDate,
        () => {
          const startDate = GLOBAL_START_DATE || document.getElementById('kws-start-date')?.value || fmtDate(new Date(Date.now() - 60 * 86400000));
          startScan({ channel: slug, keyword, startDate, endDate });
        },
        () => { startScan({ channel: slug, keyword, startDate: h.lastDate, endDate }); }
      );
    } else {
      const startDate = GLOBAL_START_DATE || document.getElementById('kws-start-date')?.value || fmtDate(new Date(Date.now() - 60 * 86400000));
      startScan({ channel: slug, keyword, startDate, endDate });
    }
  }

  // ══════════════════════════════════════════════════════════
  //  KEYWORD PREVIEW + EDITOR MODAL
  // ══════════════════════════════════════════════════════════
  // sub:true  → ≈ contains (substring) default
  // sub:false → =  exact (word boundary) default
  //
  // [Language rationale]
  // ≈ Contains:
  //   🇰🇷 Korean   — particles/endings attach directly (no space before suffix)
  //   🇯🇵 Japanese — no word boundaries in writing system
  //   🇨🇳 Chinese  — no word boundaries in writing system
  //   🇸🇦 Arabic   — heavy root/affix morphology
  //   🇮🇳 Hindi    — heavy root/affix morphology
  //   🇹🇭 Thai     — syllabic script, no spaces
  //   🇪🇸 Spanish hipo  — EXCLUDE_REGEX guards it, but contains mode catches conjugations (hipando etc.)
  // = Exact:
  //   🇬🇧 English·🇩🇪 German·🇵🇱 Polish·🇷🇴 Romanian etc. — space-delimited word boundary languages
  //   🇷🇺 Russian  — Cyrillic word boundary applied
  //   🇻🇳 Vietnamese — syllable-separated; keywords are standalone words
  //   🇮🇩 Indonesian·🇫🇷 French·🇮🇹 Italian·🇵🇹 Portuguese·🇹🇷 Turkish
  //   🇳🇱 Dutch·🇸🇪 Swedish·🇳🇴 Norwegian·🇩🇰 Danish·🇫🇮 Finnish
  //   🇬🇷 Greek·🇮🇱 Hebrew
  const ALL_KW_GROUPS = [
    { lang: '🇬🇧 English',    sub: false, kws: ['hiccup','hiccups','hicup','hicups','hickup','hickups','hiccuping','hiccupped','hiccupp','hiccoughs','hiccough'] },
    { lang: '🇰🇷 한국어',      sub: true,  kws: ['딸꾹','딸국','딱꾹','딱국','꾹질','국질','딸꾹질','딸국질','딸꾸기','딸꾹이','딱꾹질'] },
    { lang: '🇷🇺 Русский',    sub: false, kws: ['икота','икотка','икоту','икоты','икнул','икнула','икает','икаю','икотта'] },
    { lang: '🇺🇦 Українська', sub: false, kws: ['гикавка','гикає','гикнув','гикнула','гикаю','гикати'] },
    { lang: '🇧🇾 Беларуская', sub: false, kws: ['гіканне','гікаць','гікае'] },
    { lang: '🇯🇵 日本語',     sub: true,  kws: ['しゃっくり','シャックリ','しゃくり','しゃっく','吃逆'] },
    { lang: '🇨🇳 中文',       sub: true,  kws: ['打嗝','打咯','嗝','呃逆','打格','打隔'] },
    { lang: '🇪🇸 Español',    sub: true,  kws: ['hipo','hipos','hipó','hipando','hipar'] },
    { lang: '🇩🇪 Deutsch',    sub: false, kws: ['schluckauf','schluckaif','schluckof','schluck auf','hickser'] },
    { lang: '🇵🇱 Polski',     sub: false, kws: ['czkawka','czkafka','czkawke','czkawki','czakwka','czkawką','czkawkę','mam czkawkę'] },
    { lang: '🇨🇿 Čeština',    sub: false, kws: ['škytavka','škytavku','škytám','škytá','škytat','skytavka'] },
    { lang: '🇸🇰 Slovenčina', sub: false, kws: ['čkanie','čká','čkam','čkať'] },
    { lang: '🇭🇺 Magyar',     sub: false, kws: ['csuklás','csuklok','csuklik','csuklást'] },
    { lang: '🇷🇸 Srpski',     sub: false, kws: ['štucanje','štuca','štucan','štucam','stucanje','stuca'] },
    { lang: '🇧🇬 Български',  sub: false, kws: ['хълцане','хълца','хълцам','haltsane'] },
    { lang: '🇲🇰 Македонски', sub: false, kws: ['штуцање','штуца','штуцам'] },
    { lang: '🇸🇮 Slovenščina',sub: false, kws: ['kolcanje','kolca','kolcam','kolcat'] },
    { lang: '🇷🇴 Română',     sub: false, kws: ['sughiț','sughit','sughitul','sughite','sughita','sugit','am sughițuri'] },
    { lang: '🇹🇭 ไทย',        sub: true,  kws: ['สะอึก'] },
    { lang: '🇻🇳 Tiếng Việt', sub: false, kws: ['nấc','nấc cụt','nac cut'] },
    { lang: '🇮🇩 Indonesia',  sub: false, kws: ['cegukan','ceguken'] },
    { lang: '🇲🇾 Melayu',     sub: false, kws: ['sedu','sedu sedan'] },
    { lang: '🇫🇷 Français',   sub: false, kws: ['hoquet','hoquets','hoqueter'] },
    { lang: '🇮🇹 Italiano',   sub: false, kws: ['singhiozzo','singhiozzi','singhiozzare'] },
    { lang: '🇵🇹 Português',  sub: false, kws: ['soluço','soluços','soluco','solucos','soluçar'] },
    { lang: '🇹🇷 Türkçe',     sub: false, kws: ['hıçkırık','hickirik','hıçkırıklar'] },
    { lang: '🇸🇦 العربية',    sub: true,  kws: ['فواق','حازوقة','هيكاب'] },
    { lang: '🇮🇳 हिन्दी',     sub: true,  kws: ['हिचकी','हिचकियाँ','हिचकी आना'] },
    { lang: '🇳🇱 Nederlands',  sub: false, kws: ['hik','hikken','de hik','gehik'] },
    { lang: '🇸🇪 Svenska',    sub: false, kws: ['hicka','hickan','hickade'] },
    { lang: '🇳🇴 Norsk',      sub: false, kws: ['hikke','hikker','hikkende'] },
    { lang: '🇩🇰 Dansk',      sub: false, kws: ['hikke','hikker'] },
    { lang: '🇫🇮 Suomi',      sub: false, kws: ['hikka','hikkaa','hikkailen','hikailen'] },
    { lang: '🇮🇸 Íslenska',   sub: false, kws: ['hicksti','histi','hista'] },
    { lang: '🇬🇷 Ελληνικά',   sub: false, kws: ['λόξιγκας','loxigas','λοξυγμός','loxygmos'] },
    { lang: '🇮🇱 עברית',      sub: false, kws: ['שיהוק','שיהוקים'] },
    { lang: '🇦🇱 Shqip',      sub: false, kws: ['lemzë','lemza'] },
    { lang: '🇬🇪 ქართული',    sub: true,  kws: ['ხვრინვა','ხვრინი'] },
    { lang: '🇦🇲 Հայերեն',    sub: true,  kws: ['կըտկըտոց','կըտկըտալ'] },
    { lang: '🇦🇿 Azərbaycan', sub: false, kws: ['hıçqırıq','hicqirig'] },
    { lang: '🇰🇿 Қазақша',    sub: false, kws: ['шоқ','шоқалу'] },
    { lang: '🇹🇦 தமிழ்',      sub: true,  kws: ['விக்கல்'] },
    { lang: '🇧🇩 বাংলা',       sub: true,  kws: ['হেঁচকি','হেচকি'] },
    { lang: '🇵🇰 اردو',        sub: true,  kws: ['ہچکی'] },
    { lang: '🇮🇷 فارسی',       sub: true,  kws: ['سکسکه','هیکاپ'] },
    { lang: '🇰🇭 ខ្មែរ',       sub: true,  kws: ['ក្អួត'] },
    { lang: '🇲🇲 မြန်မာ',      sub: true,  kws: ['မောင်းငင်'] },
    { lang: '🇳🇬 Yoruba',     sub: false, kws: ['òsúkèsúkè'] },
    { lang: '🇿🇦 Zulu',       sub: false, kws: ['ingwici'] },
    { lang: '🇰🇪 Kiswahili',  sub: false, kws: ['kwikwi','chwa'] },
    { lang: '🇪🇸 Català',     sub: false, kws: ['singlot','singlots','singlotar'] },
    { lang: '🇪🇸 Galego',     sub: false, kws: ['soluzo','soluzos'] },
    { lang: '🇪🇸 Euskara',    sub: false, kws: ['hipo','hipoaren'] },
  ];
  // Auto-excluded patterns (regex-based, always active, not editable)
  const AUTO_EXCLUDE_RULES = [
    { label: '🇪🇸 hipot*, hipoc*, hipod*, hipog*, hipop*, hipst*, hipn*, hipé*', desc: 'hypo- prefix (hipoteca, hipócrita, hipopotamo, etc.)' },
    { label: '🇷🇺 икотник*', desc: 'plant name' },
    { label: '🇩🇪 hicksville, hickory, hickok', desc: 'place/person name' },
    { label: '🇯🇵 しゃくりあ*, しゃくり上*', desc: 'sobbing (different meaning)' },
  ];
  // User-editable exclude words (set via the keyword modal)
  const DEFAULT_EXCLUDES = [
    'chipotle','chipo','chipotles','chipotle sauce','chipotle chicken','chipotle bowl','chipotle order',
    'chick','chicks','chicken','chickens','chicky','chickie','chickpea','chickpeas','chickadee','chickadees',
    'chick-fil-a','chickfila','chick fil a','chic','chico','chica','chicas','chicle',
    'hiccup sauce','hiccup drink','hiccup song','hiccup meme','hiccupcup','hiccupcupcup',
    'hippo','hippos','hippopotamus','hippopotamuses',
    'hipoteca','hipotecas','hipódromo','hipodromo','hipopótamo','hipopotamo','hipócrita','hipocrita',
    'hipocondria','hipoglucemia','hipnosis','hipnotizar','hiper','hipster','hipsters',
    'hoquetage','hickory','hickman','hickok','hicksville','hicks',
    'しゃくり上げる','しゃくりあげる','икотник','สะอื้น'
  ];

  function updateKeywordPreview($d) {
    // sharedKeywordEditor.updatePreview와 동일 포맷으로 위임
    if (typeof KWSSharedKeywordEditor !== 'undefined') {
      KWSSharedKeywordEditor.updatePreview('kws-keyword', 'kws-keyword-preview');
      return;
    }
    // fallback
    const el = $d ? $d('kws-keyword') : document.getElementById('kws-keyword');
    const val = el?.value?.trim() || '';
    const preview = document.getElementById('kws-keyword-preview');
    if (!preview) return;
    if (!val) { preview.textContent = '✦ Default keywords active — click to edit'; preview.style.color = 'rgba(255,255,255,0.38)'; return; }
    const parts = val.split(',').map(s => s.trim()).filter(Boolean);
    const inc = parts.filter(p => !p.startsWith('-'));
    const exc = parts.filter(p => p.startsWith('-'));
    const sub = inc.filter(p => p.startsWith('~')).length;
    const exact = inc.length - sub;
    preview.textContent = (inc.length ? '+' + inc.length + ' words' : 'Default +') + (sub ? ` (= ${exact} · ≈ ${sub})` : '') + (exc.length ? ' · -' + exc.length + ' words' : '') + ' — click to edit';
    preview.style.color = 'rgba(255,255,255,0.72)';
  }

  // KWSSharedKeywordEditor(sharedKeywordEditor.js)는 항상 로드되므로(manifest.json 참고)
  // 구버전 자체 제작 키워드 모달(createKeywordModal, ~234줄)은 사실상 도달 불가능한 코드였음 — 제거하고
  // 안전을 위한 최소 fallback만 남김.
  function createKeywordModal() {
    alert('⚠ Keyword editor failed to load. Please reload the page.');
  }

  // ══════════════════════════════════════════════════════════
  //  HISTORY WINDOW
  // ══════════════════════════════════════════════════════════
  function createHistoryWindow() {
    if (!window.KWSHistoryUI) return;
    window.KWSHistoryUI.open({
      platform: 'twitch',
      HISTORY,
      HISTORY_KEY,
      accentColor: '#a78bfa',
      onImport: () => { injectSiteBadges && injectSiteBadges(); },
      onScanComplete: (renderFn) => { window._twitchHistoryRender = renderFn; },
      onGetScanState: (ch) => {
        const s = SCAN_STATES[ch?.toLowerCase()];
        if (s?.running) return 'running';
        if (s?.queued) return 'queued';
        if (OVERLOAD?.queue?.some(q => q.channel?.toLowerCase() === ch?.toLowerCase())) return 'queued';
        return 'idle';
      },
      onIdClick: (ch, h) => {
        const chInput = document.getElementById('kws-channel');
        if (chInput) { chInput.value = ch; renderHistoryHint(ch); }
      },
      onScan: (ch, h) => {
        const chInput = document.getElementById('kws-channel');
        if (chInput) { chInput.value = ch; renderHistoryHint(ch); }
        const kw = GLOBAL_KEYWORD || document.getElementById('kws-keyword')?.value?.trim() || '';
        if (!kw) { document.getElementById('kws-keyword-btn')?.click(); return; }
        const stopAtDate = h.lastDate || '';
        const defaultStartDate = fmtDate(new Date(Date.now() - 60 * 86400000));
        if (stopAtDate) {
          showRescanPopup(ch, kw, ch, stopAtDate,
            () => { startScan({ channel: ch, keyword: kw, startDate: defaultStartDate, endDate: '', nick: null }); },
            () => { startScan({ channel: ch, keyword: kw, startDate: stopAtDate, endDate: '', nick: null }); }
          );
        } else {
          startScan({ channel: ch, keyword: kw, startDate: defaultStartDate, endDate: '', nick: null });
        }
      }
    });
  }



  // ══════════════════════════════════════════════════════════
  //  UTILITY
  // ══════════════════════════════════════════════════════════
  function esc(t) { return String(t||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
  function hlKw(html, kws) {
    let o = String(html || '');
    // kws entries may be "word" or "~word" (contains mode)
    for (const rawK of [...new Set((kws||[]).filter(Boolean))].sort((a,b)=>b.replace(/^~/,'').length-a.replace(/^~/,'').length)) {
      const isSub = rawK.startsWith('~');
      const k = isSub ? rawK.slice(1) : rawK;
      const escaped = k.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
      let pattern;
      if (isSub) {
        // contains mode: simple global match
        pattern = new RegExp(escaped, 'gi');
      } else if (/^[a-z0-9\s\'-]+$/i.test(k)) {
        // ASCII exact: word boundary
        pattern = new RegExp(`(?<![a-zA-Z0-9\'-])${escaped}(?![a-zA-Z0-9\'-])`, 'gi');
      } else if (/[\uAC00-\uD7AF\u3130-\u318F]/.test(k)) {
        // Korean: match only when not surrounded by Korean chars
        pattern = new RegExp(`(?<![가-힣ㄱ-ㅎㅏ-ㅣ])${escaped}(?![가-힣ㄱ-ㅎㅏ-ㅣ])`, 'gi');
      } else if (/[а-яёА-ЯЁ]/.test(k)) {
        // Cyrillic: match only when not surrounded by Cyrillic chars
        pattern = new RegExp(`(?<![а-яёА-ЯЁ])${escaped}(?![а-яёА-ЯЁ])`, 'gi');
      } else {
        // CJK etc.: simple contains
        pattern = new RegExp(escaped, 'g');
      }
      o = o.replace(pattern, '<mark style="background:rgba(250,204,21,0.28);color:#fde68a;padding:0 2px;border-radius:3px;">$&</mark>');
    }
    return o;
  }
  function normalizeKeywords(s) { return String(s||'').split(',').map(v=>v.trim()).filter(Boolean); }
  // Safely convert any keywords value to a clean string[] (guards against {word,substring} objects)
  function safeKwStrings(kws) {
    if (!Array.isArray(kws)) return [];
    return kws.map(k => {
      if (typeof k === 'string') return k.replace(/^~/, '');   // strip ~ prefix for display
      if (k && typeof k === 'object' && k.word) return k.word; // {word,substring} object
      return String(k);
    }).filter(Boolean);
  }
  // Compact keyword preview: "word1, word2, word3 +N more"
  function kwPreview(kws, max=3) {
    const words = safeKwStrings(kws);
    if (!words.length) return 'all';
    const shown = words.slice(0, max).join(', ');
    const more  = words.length - max;
    return more > 0 ? `${shown} +${more} more` : shown;
  }
  function fmtDate(d) { return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }
  function formatDateFromSecs(s) { if (!s) return ''; return fmtDate(new Date(s * 1000)); }
  function formatLocalBroadcastTime(value) {
    const ms = normalizeTimestampMs(value);
    if (!ms) return '';
    try {
      const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
      const parts = new Intl.DateTimeFormat(undefined, {
        timeZone: tz || undefined,
        month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', second: '2-digit',
        hour12: false, timeZoneName: 'shortOffset'
      }).formatToParts(new Date(ms));
      const get = type => parts.find(p => p.type === type)?.value || '';
      const month = get('month'), day = get('day'), hour = get('hour'), minute = get('minute'), second = get('second');
      let zone = get('timeZoneName') || '';
      if (zone === 'GMT') zone = 'GMT+0';
      // Uses browser/OS timezone. Korea displays as GMT+9.
      return `${month}/${day} ${hour}:${minute}:${second}${zone ? ' ' + zone : ''}`;
    } catch (_) {
      const d = new Date(ms);
      return d.toLocaleString();
    }
  }
  function normalizeTimestampMs(value) {
    if (value == null || value === '') return null;
    if (typeof value === 'number') return value > 1e12 ? value : value > 1e9 ? value * 1000 : null;
    const str = String(value).trim();
    if (/^\d{13}$/.test(str)) return parseInt(str, 10);
    if (/^\d{10}$/.test(str)) return parseInt(str, 10) * 1000;
    const p = new Date(str).getTime();
    return Number.isNaN(p) ? null : p;
  }
  function guessChannelFromUrl() {
    const m = /twitch\.tv\/([^/?#]+)/.exec(window.location.href);
    const skip = ['videos','directory','search','settings','subscriptions','following','moderator','clips'];
    return (m && !skip.includes(m[1])) ? m[1].toLowerCase() : '';
  }
  function bindCollapse(panel, body, tb) {
    tb.addEventListener('click', async e => {
      e.stopPropagation();
      const slim = panel.dataset.slim === 'true';
      setSlim(panel, tb, !slim);
      await chrome.storage.local.set({ kwsPanelSlim: !slim });
    });
  }
  function setSlim(panel, tb, slim) {
    panel.dataset.slim = slim ? 'true' : 'false';
    const inputArea = document.getElementById('kws-input-area');
    if (inputArea) inputArea.style.display = slim ? 'none' : '';
    tb.title = slim ? 'Expand' : 'Slim mode';
    tb.style.background = slim ? 'rgba(99,102,241,0.3)' : '';
    panel.style.width = slim ? '280px' : '420px';
  }
  function enableDragging(panel, handle) {
    let drag = false, ox = 0, oy = 0;
    handle.addEventListener('mousedown', e => {
      if (e.target.closest('button,input,textarea,select,label')) return;
      drag = true;
      panel.style.zIndex = topZIndexer();
      const r = panel.getBoundingClientRect();
      ox = e.clientX - r.left; oy = e.clientY - r.top;
      panel.style.left = `${r.left}px`; panel.style.top = `${r.top}px`;
      panel.style.right = 'auto'; panel.style.bottom = 'auto';
      document.body.style.userSelect = 'none';
    });
    panel.addEventListener('mousedown', () => { panel.style.zIndex = topZIndexer(); });
    window.addEventListener('mousemove', e => {
      if (!drag) return;
      panel.style.left = `${Math.min(Math.max(8, e.clientX-ox), window.innerWidth-panel.offsetWidth-8)}px`;
      panel.style.top  = `${Math.min(Math.max(8, e.clientY-oy), window.innerHeight-panel.offsetHeight-8)}px`;
    });
    window.addEventListener('mouseup', async () => {
      if (!drag) return; drag = false;
      document.body.style.userSelect = '';
      await chrome.storage.local.set({ kwsPanelPosition: { left: parseFloat(panel.style.left), top: parseFloat(panel.style.top) } });
    });
  }
  async function restoreUiValues() {
    const data = await chrome.storage.local.get(['kwsChannel','kwsKeyword',KEYWORD_PROFILE_KEY,'kwsPanelCollapsed','kwsPanelPosition','kwsStartDate','kwsEndDate','kwsDatesSavedDay']);
    const $d = id => document.getElementById(id);
    if (data.kwsChannel)   { $d('kws-channel').value = data.kwsChannel; renderHistoryHint(data.kwsChannel); }
    const _savedKw = data.kwsKeyword || data[KEYWORD_PROFILE_KEY]?.keyword || HISTORY.__keyword_profile__?.keyword || '';
    if (_savedKw) { $d('kws-keyword').value = _savedKw; GLOBAL_KEYWORD = _savedKw; updateKeywordPreview($d); }
    // 날짜: 저장된 값은 "오늘 저장한 것"만 복원 — To 기본값이 '오늘'이라 예전에 저장된 값을 그대로 쓰면
    // 며칠 지난 뒤 To가 과거 날짜로 굳어서 최신 VOD가 검색에서 빠지게 됨. 그 외엔 Kick처럼 실제 기본 날짜(60일 전 ~ 오늘)를 채움.
    {
      const _today = fmtDate(new Date());
      const _fresh = data.kwsDatesSavedDay === _today;
      const _sd = (_fresh && data.kwsStartDate) || fmtDate(new Date(Date.now() - 60 * 86400000));
      const _ed = (_fresh && data.kwsEndDate) || _today;
      $d('kws-start-date').value = _sd; GLOBAL_START_DATE = _sd;
      $d('kws-end-date').value   = _ed; GLOBAL_END_DATE   = _ed;
    }
    const panel = document.getElementById(PANEL_ID), body = $d('kws-panel-body'), tb = $d('kws-toggle-btn');
    if (panel && data.kwsPanelPosition?.left != null) {
      panel.style.left = `${data.kwsPanelPosition.left}px`; panel.style.top = `${data.kwsPanelPosition.top}px`;
      panel.style.right = 'auto'; panel.style.bottom = 'auto';
    }
    if (panel && tb && data.kwsPanelSlim) { setSlim(panel, tb, true); }
    else if (panel && tb && data.kwsPanelCollapsed) { setSlim(panel, tb, true); }
  }

})();
