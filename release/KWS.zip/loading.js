function addLoader(params) {

    let text_arr = (params?.text || '...loading...').split('');
    let gap = 3;
    let break_on = text_arr.indexOf(' ');
    let px = 28;
    let flex_width = break_on > 0 ? `width:${break_on*(20+gap)}px;` : '';
    let transform = params?.transform ? params?.transform : 'transform:translate(-15px,-30px);';
    let cells = text_arr.length;
    let cont = ele();
    let grid_cols = Array(cells).fill().map((_,i)=> ` ${px}px`).reduce((a,b)=> a+b);
    a(cont,[['class','loader_cont']]);

    if(params?.top && params.left){
        inlineStyler(cont, `{position:fixed; transform:translate(-15px,-0px); z-index:${topZIndexer()}; top:${params?.top+8}px; left:${params?.left+12}px; border-radius:2em; background: transparent;}`);
    }
    if(params?.flex) inlineStyler(cont, `{z-index:${topZIndexer()}; ${flex_width} ${transform} display:flex;flex-wrap:wrap;gap:${gap}px;}`);
    if(!params?.flex) inlineStyler(cont, `{display:grid; grid-template-columns:${grid_cols}; grid-gap:${gap}px;}`); // Fixed: added comma

    appender({...params,...{cont:cont}});

    Array(cells).fill().forEach((_,i)=> {
        let box = ele();
        cont.appendChild(box);
        a(box,[['class',`load_box box${i}`]]);

        let staggerDelay = (i) * (params?.stagger || 120);
        let animDuration = (params?.duration || 3000);
        inlineStyler(box,`{
            animation-name: loader-animation;
            animation-duration: ${animDuration}ms;
            animation-delay: ${staggerDelay}ms;
            animation-timing-function: cubic-bezier(0.68, -0.55, 0.265, 1.55);
            animation-iteration-count: infinite;
            height:${text_arr[i].trim().length ? px : (px/2)}px;
            width:${text_arr[i].trim().length ? px : (px/2)}px;
            ${!text_arr[i].trim().length ? 'transform:translate('+Math.floor(px/4)+'px,'+Math.floor(px/4)+'px);' : ''}
            text-align:center;
            font-size:14px;
            align-items: center;
            border-radius: 50%;
        }`);
        box.innerText = text_arr[i];
    });

    return cont;
}

let _kwsSpinnerStyleInjected = false;
function ensureKwsSpinnerStyle() {
    if (_kwsSpinnerStyleInjected) return;
    _kwsSpinnerStyleInjected = true;
    let style = document.createElement('style');
    style.textContent = `@keyframes kws-loader-spin { to { transform: rotate(360deg); } }`;
    document.head.appendChild(style);
}

// 화면 정중앙(대상 요소 기준)에 뜨는 심플한 로딩 스피너 — 글자별로 튀는 구식 텍스트 로더 대체용
function addSpinner(params) {
    ensureKwsSpinnerStyle();
    let rect = params?.rect || {};
    let cx = (rect.left || 0) + (rect.width || 0) / 2;
    let cy = (rect.top || 0) + (rect.height || 0) / 2;
    let accent = params?.accent || '#a78bfa';
    let iconBg = params?.iconBg || 'rgba(255,255,255,0.08)';

    let cont = ele();
    a(cont, [['class', 'kws-spinner-cont']]);
    inlineStyler(cont, `{
        position:fixed;
        z-index:${topZIndexer()};
        left:${cx}px;
        top:${cy}px;
        transform:translate(-50%,-50%);
        display:flex;
        align-items:center;
        justify-content:center;
        gap:8px;
        padding:11px 16px;
        border-radius:999px;
        background:rgba(10,12,18,0.74);
        backdrop-filter:blur(12px);
        pointer-events:none;
    }`);

    if (params?.icon) {
        // 정적 아이콘 모드 (경고/삭제됨 등 — 회전 없음)
        let iconEl = ele();
        iconEl.innerText = params.icon;
        inlineStyler(iconEl, `{
            width:20px;
            height:20px;
            border-radius:50%;
            background:${iconBg};
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:11px;
            flex-shrink:0;
        }`);
        cont.appendChild(iconEl);
    } else {
        let ring = ele();
        inlineStyler(ring, `{
            width:18px;
            height:18px;
            border-radius:50%;
            border:2.5px solid rgba(255,255,255,0.18);
            border-top-color:${accent};
            animation-name: kws-loader-spin;
            animation-duration:750ms;
            animation-timing-function:linear;
            animation-iteration-count:infinite;
        }`);
        cont.appendChild(ring);
    }

    if (params?.text) {
        let label = ele();
        label.innerText = params.text;
        inlineStyler(label, `{
            color:rgba(255,255,255,0.85);
            font-size:12px;
            font-weight:600;
            letter-spacing:0.01em;
            white-space:nowrap;
        }`);
        cont.appendChild(label);
    }

    appender({...params, ...{ cont: cont }});
    return cont;
}

// function addLoader(params){
//     // console.log(params);
// 	let text_arr = (params?.text || '...loading...').split('');
//     // let text_arr = text.filter(r=> r.trim());
//     let gap = 3;
//     let break_on = text_arr.indexOf(' ');
//     let px = 28;
//     let flex_width = break_on > 0 ? `width:${break_on*(20+gap)}px;` : '';

//     let transform = params?.transform ? params?.transform : 'transform:translate(-15px,-30px);';
// 	let cells = text_arr.length;

// 	let cont = ele();
//     let grid_cols = Array(cells).fill().map((_,i)=> ` ${px}px`).reduce((a,b)=> a+b);
//     a(cont,[['class','loader_cont']]);
//     if(params?.top && params.left){ inlineStyler(cont, `{position:fixed; transform:translate(-15px,-s0px); z-index:${topZIndexer()}; top:${params?.top+8}px; left:${params?.left+12}px; border-radius:2em; background: transparent;}`); }
//     if(params?.flex) inlineStyler(cont, `{z-index:${topZIndexer()}; ${flex_width} ${transform} display:flex;flex-wrap:wrap;gap:${gap}px;}`);
//     if(!params?.flex) inlineStyler(cont,`{display:grid; grid-template-columns:${grid_cols}; grid-gap:${gap}px;}`)
//     appender({...params,...{cont:cont}});
//     Array(cells).fill().forEach((_,i)=> {
//         let box = ele();
//         cont.appendChild(box);
//         a(box,[['class',`load_box box${i}`]]);
//         inlineStyler(box,`{animation-name: loader-animation;
//         animation-duration: ${(20000)/cells}ms;
//         animation-delay: ${(i)*(cells*7)}ms;
//         animation-timing-function: cubic-bezier(.59,-0.54,.49,1.55);
//         animation-iteration-count: infinite;
//         height:${text_arr[i].trim().length ? px : (px/2)}px;
//         width:${text_arr[i].trim().length ? px : (px/2)}px;
//         ${!text_arr[i].trim().length ? 'transform:translate('+Math.floor(px/4)+'px,'+Math.floor(px/4)+'px);' : ''}
//         text-align:center; font-size:14px;
//         align-items: center;}`);
//         box.innerText = text_arr[i];
//     });
//     // for(let i=0; i<3000; i++){//stupid hacky fix. need to rebuild this whole thing.
//     //     if(!document.getElementsByClassName('loader_cont')?.length){break}
//     //     await delay(100);
//     //     if(i >= 3000){
//     //         Array.from(document.getElementsByClassName('loader_cont'))?.forEach(elm=> {
//     //             if(elm) elm.remove();
//     //         });
//     //     }
//     // }
//     return cont;
// }
// addLoader()
function stopLoader(){
    Array.from(document.getElementsByClassName('loader_cont') || [])?.forEach(elm=> {
        if(elm) elm.remove();
    });
    // if(loading_elm_live) loading_elm_live = false;
}
