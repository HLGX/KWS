
// 1.2.5: red badge threshold from the side panel settings (kwsSpBadgeRedDays, default 14 as in 1.2.4)
try { chrome.storage.local.get('kwsSpBadgeRedDays').then((d) => { if (Number.isFinite(d.kwsSpBadgeRedDays)) globalThis.__kwsRedDays = d.kwsSpBadgeRedDays; }); chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && c.kwsSpBadgeRedDays) globalThis.__kwsRedDays = c.kwsSpBadgeRedDays.newValue; }); } catch (_) {} try { chrome.storage.local.get('kwsSpBadgeClick').then((d) => { globalThis.__kwsBadgeClick = d.kwsSpBadgeClick || 'ask'; }); chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && c.kwsSpBadgeClick) globalThis.__kwsBadgeClick = c.kwsSpBadgeClick.newValue || 'ask'; }); } catch (_) {}
// StreamRecorder.io (https://streamrecorder.io/latest/{kick,twitch,afreecatv}) 목록 페이지에
// KWS 검색 기록 뱃지를 붙여줌 — kick.com/twitch.tv/sooplive.com 자체 페이지에 있는 것과 같은
// "Search ▶ / Today ↺ / 3d ago ↺" 스타일. 이 사이트 자체에서 스캔을 돌릴 수는 없으니(그러려면
// 각 플랫폼 페이지에 떠 있는 KWS 패널이 필요함), 뱃지를 누르면 background.js에 OPEN_PLATFORM_AND_SCAN
// 메시지를 보내서 처리를 맡김 — twitchtracker.com 뱃지에 이미 쓰이던 OPEN_TWITCH_AND_SCAN과
// 똑같은 패턴: 그 플랫폼 탭이 이미 열려 있으면 새로 열지 않고 그 탭에 채널만 얹어서 큐에
// 넣고(각 패널이 MAX_CONCURRENT_SCANS 넘으면 알아서 대기열 처리), 없을 때만 새 탭을 염.
// 매번 새 탭이 뜨던 문제, 그리고 그 전엔 채널 ID만 채워놓고 검색은 시작 안 하던 문제(SOOP은
// 아예 www.sooplive.com/station/<id> 대신 라이브/VOD 화면으로 가버리기까지 했음)를 여기서
// 같이 해결함 — background가 탭을 찾거나 새로 연 다음 해당 플랫폼 패널에 직접 스캔 시작
// 메시지를 보내주기 때문에 페이지 로드 타이밍에 의존하는 쿼리스트링 트릭이 더 이상 필요 없음.
(function () {
  'use strict';
  if (window.__kwsStreamRecorderBadgeLoaded) return;
  window.__kwsStreamRecorderBadgeLoaded = true;

  const BADGE_CLASS = 'kkws-sr-badge';

  const PLATFORM_MAP = {
    kick:      { platform: 'kick',      historyKey: 'kickKwsHistory',    hrefPrefix: '/kick/' },
    twitch:    { platform: 'twitch',    historyKey: 'twitchKwsHistory',  hrefPrefix: '/twitch/' },
    afreecatv: { platform: 'afreecatv', historyKey: 'soopSearchHistory', hrefPrefix: '/afreecatv/' },
    // YouTube 카드는 "/yt/@handle" 형태의 href를 쓰고 .user-name 같은 고정 클래스가 없어서,
    // 다른 플랫폼과 같은 findCard() 방식이 안 먹음 — doInject()에서 이 플랫폼일 때만 href를
    // 직접 스캔하는 별도 경로(injectYT)를 탐. hrefPrefix는 여기선 안 쓰이지만 식별 목적으로 남겨둠.
    yt:        { platform: 'youtube',   historyKey: 'ytKwsHistory',      hrefPrefix: '/yt/' },
    // CHZZK cards link to /czk/{32-hex channel ID} (1.2.5.8)
    czk:       { platform: 'chzzk',     historyKey: 'chzzkKwsHistory',   hrefPrefix: '/czk/' },
  };

  function currentPlatform() {
    const m = /^\/latest\/(kick|twitch|afreecatv|yt|czk)\b/.exec(location.pathname);
    return m ? m[1] : null;
  }

  // HISTORY는 실제 스캔이 "완료"돼야(KICK_KWS_DONE 등) 저장되기 때문에, 뱃지를 눌러서 다른 탭에서
  // 스캔을 막 시작시켜도 그 스캔이 끝나기 전까진 여기서 볼 방법이 없어서 계속 "Search ▶"로 남아
  // 있었음(눌렀는지 안 눌렀는지 구분이 안 가던 문제). 그래서 클릭한 시각을 별도로 로컬에
  // 기록해두고, 그 이후로 HISTORY가 갱신되기 전까지는 "⏳ Queued"로 optimistic하게 보여줌.
  const PENDING_KEY = 'kwsSrPendingScans';
  const PENDING_TIMEOUT_MS = 20 * 60 * 1000; // 20분 지나도 안 끝났으면(탭을 닫았거나 등) 포기하고 원래 상태로

  let HISTORY = {};
  let PENDING = {};
  let loadedHistoryKey = null;

  async function loadHistory(historyKey) {
    if (loadedHistoryKey === historyKey) { await loadPending(); return; }
    try {
      const got = await chrome.storage.local.get([historyKey]);
      HISTORY = got[historyKey] || {};
      loadedHistoryKey = historyKey;
    } catch (e) { HISTORY = {}; }
    await loadPending();
  }

  async function loadPending() {
    try {
      const got = await chrome.storage.local.get([PENDING_KEY]);
      PENDING = (got[PENDING_KEY] || {})[loadedHistoryKey] || {};
    } catch (e) { PENDING = {}; }
  }

  async function markPending(historyKey, slug) {
    try {
      const got = await chrome.storage.local.get([PENDING_KEY]);
      const all = got[PENDING_KEY] || {};
      const now = Date.now();
      // 오래된 pending 기록은 여기서 같이 청소 — 안 그러면 계속 쌓이기만 함.
      for (const hk of Object.keys(all)) {
        for (const s of Object.keys(all[hk] || {})) {
          if (now - new Date(all[hk][s]).getTime() > PENDING_TIMEOUT_MS) delete all[hk][s];
        }
      }
      all[historyKey] = all[historyKey] || {};
      all[historyKey][slug] = new Date(now).toISOString();
      await chrome.storage.local.set({ [PENDING_KEY]: all });
      if (historyKey === loadedHistoryKey) PENDING = all[historyKey];
    } catch (e) {}
  }

  function ensureStyle() {
    if (document.getElementById('kkws-sr-badge-style')) return;
    const s = document.createElement('style');
    s.id = 'kkws-sr-badge-style';
    s.textContent = `.${BADGE_CLASS}{display:inline-flex;align-items:center;padding:1px 6px;border-radius:99px;font-size:9px;font-weight:700;white-space:nowrap;vertical-align:middle;margin-left:6px;cursor:pointer;font-family:-apple-system,BlinkMacSystemFont,sans-serif;line-height:1.5;letter-spacing:0.01em;transition:all 0.15s;} .${BADGE_CLASS}:hover{filter:brightness(1.15);}`;
    document.head.appendChild(s);
  }

  function buildBadge(slug, cfg) {
    const h = HISTORY[slug];
    const pendingAt = PENDING[slug];
    // 방금 눌러서 다른 탭에 스캔을 요청해둔 상태(아직 완료 기록은 안 들어온 상태)인지 판단.
    // HISTORY가 그 클릭 시각보다 최신으로 갱신됐으면 이미 끝난 것이므로 pending 취급 안 함.
    const isPending = pendingAt
      && (Date.now() - new Date(pendingAt).getTime()) < PENDING_TIMEOUT_MS
      && !(h && (h.searchedAt || h.savedAt) && new Date(h.searchedAt || h.savedAt).getTime() >= new Date(pendingAt).getTime());

    const badge = document.createElement('span');
    badge.className = BADGE_CLASS;

    if (isPending) {
      badge.textContent = '⏳ Queued';
      badge.style.cssText = 'background:rgba(6,182,212,0.12);border:1px solid rgba(6,182,212,0.35);color:#22d3ee;';
      badge.title = `Requested a scan for ${slug} in another tab\n(gets confirmed once that tab finishes — click to open it again)`;
    } else if (!h) {
      badge.textContent = 'Search ▶';
      badge.style.cssText = 'background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.35);color:#f87171;';
      badge.title = `Not searched with KWS yet\nClick to open ${slug} and scan it there`;
    } else {
      const searchedAt = h.searchedAt || h.savedAt || null;
      const daysAgo = searchedAt ? Math.floor((Date.now() - new Date(searchedAt).getTime()) / 86400000) : null;
      const isRecent = daysAgo !== null && daysAgo <= 1;
      const isStale = daysAgo !== null && daysAgo > (globalThis.__kwsRedDays || 14);
      const label = daysAgo === 0 ? 'Today ↺' : daysAgo === 1 ? 'Yesterday ↺' : daysAgo !== null ? `${daysAgo}d ago ↺` : 'Not searched ▶';
      const col = daysAgo === null ? { bg: 'rgba(56,189,248,0.12)', bdr: 'rgba(56,189,248,0.35)', txt: '#38bdf8' } : isStale
        ? { bg: 'rgba(239,68,68,0.1)',  bdr: 'rgba(239,68,68,0.3)',  txt: '#f87171' }
        : isRecent
          ? { bg: 'rgba(34,197,94,0.12)', bdr: 'rgba(34,197,94,0.35)', txt: '#4ade80' }
          : { bg: 'rgba(234,179,8,0.12)',  bdr: 'rgba(234,179,8,0.35)',  txt: '#fbbf24' };
      const hits = h.matchedLines ?? h.matchedCount ?? 0;
      badge.textContent = label;
      badge.style.cssText = `background:${col.bg};border:1px solid ${col.bdr};color:${col.txt};`;
      badge.title = `${hits} hits with KWS\nClick to open ${slug} and re-scan`;
    }

    badge.addEventListener('click', async e => {
      e.preventDefault();
      e.stopPropagation();
      await markPending(cfg.historyKey, slug);
      doInject(); // 바로 "⏳ Queued"로 갱신 — background 응답 기다릴 필요 없음
      try {
        const res = await chrome.runtime.sendMessage({ type: 'KWS_SP_EXTERNAL_SCAN', platform: cfg.platform === 'afreecatv' ? 'soop' : cfg.platform, channel: slug }); // 1.2.5: side panel asks + scans, no page change
        if (!res || !res.ok) throw new Error(res && res.reason || 'no response');
      } catch (e) {
        // background 릴레이가 어떤 이유로든 실패하면 최소한 그 채널 페이지라도 직접 열어줌
        // (자동 스캔은 안 걸리지만 채널 ID는 그쪽 패널이 URL에서 알아서 채워줌).
        const fallbackUrl = cfg.platform === 'kick' ? `https://kick.com/${slug}`
          : cfg.platform === 'twitch' ? `https://www.twitch.tv/${slug}`
          : cfg.platform === 'youtube' ? `https://www.youtube.com/@${slug.replace(/^@/, '')}/streams`
          : cfg.platform === 'chzzk' ? `https://chzzk.naver.com/${slug}`
          : `https://www.sooplive.com/station/${slug}`;
        window.open(fallbackUrl, '_blank');
      }
    });
    return badge;
  }

  // nameEl(채널명 표시용 span, 링크 아님)에서부터 위로 올라가면서 해당 플랫폼 링크를
  // 포함한 가장 가까운 조상(카드 컨테이너)을 찾음 — 사이트 마크업이 조금 바뀌어도 안 깨지도록
  // 고정 클래스명(.video-wrapper 등) 대신 "이 카드가 어떤 채널 카드인지"로 판단.
  function findCard(nameEl, hrefPrefix) {
    let el = nameEl;
    for (let i = 0; i < 8 && el; i++) {
      if (el.querySelector && el.querySelector(`a[href^="${hrefPrefix}"], a[href*="streamrecorder.io${hrefPrefix}"]`)) return el;
      el = el.parentElement;
    }
    return null;
  }

  // YouTube 카드 전용 주입 — kick/twitch/afreecatv처럼 고정된 ".user-name" 클래스가 없고,
  // 카드 하나에 같은 "/yt/@handle" 링크가 (썸네일용 + 채널명용) 두 번씩 들어있는 구조라서,
  // href 자체를 기준으로 핸들별 "마지막" 링크(보통 채널명 텍스트 링크) 하나에만 뱃지를 붙임 —
  // 같은 카드에 중복으로 두 개씩 뱃지가 붙는 걸 방지.
  function injectYT() {
    const cfg = PLATFORM_MAP.yt;
    // 같은 채널이 목록에 여러 카드로 나올 수 있음(예: 한 채널의 영상 2개) — 핸들 기준으로 1개만 붙이면
    // 나머지 카드들은 뱃지가 없었음. 그래서 "카드 단위"로 묶어서 카드마다 마지막 링크에 하나씩 붙임.
    const byCard = new Map(); // 카드 요소 -> { slug, anchor }
    document.querySelectorAll('a[href*="/yt/@"]').forEach(a => {
      // youtubeSearcher.js의 HISTORY/guessChannel()은 "@" 없이 핸들만 키로 쓰므로 "@"는 떼고 slug로 사용.
      const m = /\/yt\/@([^/?#]+)/.exec(a.getAttribute('href') || '');
      if (!m) return;
      const slug = decodeURIComponent(m[1]).toLowerCase().trim();
      if (!slug) return;
      const card = a.closest('.video-slide-item') || a.parentElement;
      byCard.set(card, { slug, anchor: a }); // 같은 카드에서는 마지막 링크(제목/채널명)를 사용
    });
    byCard.forEach(({ slug, anchor }) => {
      anchor.insertAdjacentElement('afterend', buildBadge(slug, cfg));
    });
  }

  async function doInject() {
    const platform = currentPlatform();
    if (!platform) return;
    const cfg = PLATFORM_MAP[platform];
    await loadHistory(cfg.historyKey);
    ensureStyle();

    document.querySelectorAll('.' + BADGE_CLASS).forEach(el => el.remove());

    if (platform === 'yt') { injectYT(); return; }

    document.querySelectorAll('.user-name').forEach(nameEl => {
      const card = findCard(nameEl, cfg.hrefPrefix);
      if (!card) return;
      const link = card.querySelector(`a[href^="${cfg.hrefPrefix}"], a[href*="streamrecorder.io${cfg.hrefPrefix}"]`);
      const href = (link && link.getAttribute('href') || '').replace(/^https?:\/\/[^/]+/, '');
      const slug = decodeURIComponent((href.slice(cfg.hrefPrefix.length).split(/[/?#]/)[0] || '')).toLowerCase().trim();
      if (!slug) return;
      nameEl.insertAdjacentElement('afterend', buildBadge(slug, cfg));
    });
    // CHZZK cards may not have the ".user-name" span: then badge the last /czk/{id} link of each
    // card (the name / title link), like the YouTube cards.
    if (platform === 'czk' && !document.querySelector('.' + BADGE_CLASS)) {
      const byCard = new Map();
      document.querySelectorAll('a[href*="/czk/"]').forEach((a) => {
        const m = /\/czk\/([0-9a-f]{32})/i.exec(a.getAttribute('href') || '');
        if (!m || !a.textContent.trim()) return;
        const card = a.closest('.video-slide-item') || a.parentElement;
        byCard.set(card, { slug: m[1].toLowerCase(), anchor: a });
      });
      byCard.forEach(({ slug, anchor }) => anchor.insertAdjacentElement('afterend', buildBadge(slug, cfg)));
    }
  }

  let injectTimer = null;
  function scheduleInject() { clearTimeout(injectTimer); injectTimer = setTimeout(doInject, 400); }

  [0, 500, 1200, 2500, 4500].forEach(d => setTimeout(scheduleInject, d));
  new MutationObserver(scheduleInject).observe(document.documentElement, { childList: true, subtree: true });

  // /latest/kick ↔ /latest/twitch ↔ /latest/afreecatv 탭 전환은 SPA 라우팅이라 페이지 리로드가
  // 없어서 pathname 변화를 직접 감시해야 새 플랫폼의 히스토리로 다시 로드/재주입됨.
  let lastPath = location.pathname;
  setInterval(() => {
    if (location.pathname !== lastPath) {
      lastPath = location.pathname;
      loadedHistoryKey = null;
      scheduleInject();
    }
  }, 800);

  // 다른 탭에서 스캔이 끝나 HISTORY가 바뀌거나(완료 확정), 다른 streamrecorder.io 탭에서
  // 같은 채널을 먼저 눌러 pending이 바뀌면 여기도 같이 갱신.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    const platform = currentPlatform();
    if (!platform) return;
    if (changes[PLATFORM_MAP[platform].historyKey] || changes[PENDING_KEY]) {
      loadedHistoryKey = null;
      scheduleInject();
    }
  });
})();
