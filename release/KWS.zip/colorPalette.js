function main_app_colors(){
  return app_colors[color_mode];
}
var bg_classes = [
    { c: 'bg_glower', fill: '#ffffff' },
    { c: 'bg_f0f0f0', fill: '#000000' },
    { c: 'bg_1c1c1c', fill: '#ffffff' },
    { c: 'bg_000000', fill: '#ffffff' },
    { c: 'bg_9047ff', fill: '#ffffff' },
    { c: 'bg_52fc18', fill: '#ffffff' },
    { c: 'bg_gradient', fill: '#ffffff' },
  ];

var color_mode = 'lightmode';
var app_colors = {
  lightmode: {
    btn_border: '#ccdbe8',
    icon_color: '#ffffff',
    contrast_icon: '#1c1c1c',
    bg: "#1c1c1c",
    text: "#1c1d1f",
    mid: "#dae8f5",
    light_fade: "#e6ebed88",
    input_shadow: '#ccdbe8',
    input_inset: '#b3bec7',
    placeholder: "#bcd1e3",
    menu_bg: "#ffffff",
    bg_highlight: "#45494d",
    bg_shadow: "#1d2730",
    edge: "#db1076",
    bg_border:'#f0f0f0',
  },
  darkmode: {
    btn_border: '#db1076',
    icon_color: '#ffffff',
    contrast_icon: '#ffffff',
    bg: "#000000",
    text: "#ffffff",
    mid: "#dae8f5",
    input_shadow: '#121212',
    input_inset: '#0c0c0c',
    light_fade: "#0a0a0a",
    placeholder: "#778691",
    menu_bg: "#1c1c1c",
    bg_highlight: "#7d8b99",
    bg_shadow: "#1d2730",
    edge: "#db1076",
    bg_border:'#000000',
  }
};
var main_background_gradient = ()=> `linear-gradient(135deg, ${main_app_colors()?.bg_border}80 0%, ${main_app_colors()?.bg_border} 0%, ${main_app_colors()?.bg_border} 95%, ${main_app_colors()?.edge}99 98%, ${main_app_colors()?.edge}98 99%)`.replace(/\n/g, "").replace(/\s+/g, " ");



// var lightmode = {
//   btn_border:'#ccdbe8',
//   icon_color:'#ffffff',
//   contrast_icon:'#1c1c1c',
//   bg: "#1c1c1c",
//   text: "#1c1d1f",
//   mid: "#dae8f5",
//   light_fade: "#e6ebed88",
//   input_shadow:'#ccdbe8',
//   input_inset:'#ffffff',
//   placeholder: "#bcd1e3",
//   menu_bg: "#ffffff",
//   bg_highlight: "#45494d",
//   bg_shadow: "#1d2730",
//   edge:"#db1076",
// };
// var darkmode = {
//   btn_border:'#db1076',
//   icon_color:'#ffffff',
//   contrast_icon:'#ffffff',
//   bg: "#000000",
//   text: "#ffffff",
//   mid: "#dae8f5",
//   input_shadow:'#121212',
//   input_inset:'#0c0c0c',
//   light_fade: "#0a0a0a",
//   placeholder: "#778691",
//   menu_bg: "#1c1c1c",
//   bg_highlight: "#7d8b99",
//   bg_shadow: "#1d2730",
//   edge:"#db1076",
// };
// main_app_colors["bg"] = "#1c1c1c";

// var main_app_colors = {
//   icon_color:'#ffffff',
//   bg: "#000000",
//   text: "#ffffff",
//   mid: "#dae8f5",
//   input_shadow:'#0c0c0c',
//   input_inset:'#000000',
//   light_fade: "#0a0a0a",
//   placeholder: "#1d2730",
//   menu_bg: "#1c1c1c",
//   bg_highlight: "#7d8b99",
//   bg_shadow: "#1d2730",
// };
// main_app_colors["bg"] = "#000000";
