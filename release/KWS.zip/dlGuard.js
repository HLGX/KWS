// KWS 1.2.5.2 — keeps a VOD download going while its tab is in the background.
// Chrome slows timers in a hidden tab (down to once a minute), may freeze it, and may discard it
// to save memory — any of these could break a long download. While a download runs:
//   • the tab is marked not-discardable (asked of the background: KWS_SP_TAB_GUARD),
//   • a Web Lock is held (Chrome does not freeze a page that holds one),
//   • retry waits in a hidden tab are timed by the background service worker (KWS_SP_SLEEP).
(function () {
  'use strict';
  if (globalThis.KWSDl) return;
  let count = 0;
  let releaseLock = null;
  function guard(on) {
    try { chrome.runtime.sendMessage({ type: 'KWS_SP_TAB_GUARD', on }, () => { void chrome.runtime.lastError; }); } catch (_) {}
  }
  function begin() {
    if (count++ > 0) return;
    guard(true);
    try {
      if (navigator.locks && navigator.locks.request) {
        navigator.locks.request('kws-download-' + Math.random().toString(36).slice(2), () => new Promise((r) => { releaseLock = r; })).catch(() => {});
      }
    } catch (_) {}
  }
  function end() {
    if (count === 0) return;
    if (--count > 0) return;
    guard(false);
    if (releaseLock) { try { releaseLock(); } catch (_) {} releaseLock = null; }
  }
  // setTimeout while visible; the service worker's (unthrottled) timer while hidden
  function sleep(ms) {
    return new Promise((r) => {
      if (!document.hidden) { setTimeout(r, ms); return; }
      try { chrome.runtime.sendMessage({ type: 'KWS_SP_SLEEP', ms }, () => { void chrome.runtime.lastError; r(); }); }
      catch (_) { setTimeout(r, ms); }
    });
  }
  globalThis.KWSDl = { begin, end, sleep, get active() { return count > 0; } };
})();
