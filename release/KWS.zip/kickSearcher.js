
// 1.2.5: red badge threshold from the side panel settings (kwsSpBadgeRedDays, default 14 as in 1.2.4)
try { chrome.storage.local.get('kwsSpBadgeRedDays').then((d) => { if (Number.isFinite(d.kwsSpBadgeRedDays)) globalThis.__kwsRedDays = d.kwsSpBadgeRedDays; }); chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && c.kwsSpBadgeRedDays) globalThis.__kwsRedDays = c.kwsSpBadgeRedDays.newValue; }); } catch (_) {} try { chrome.storage.local.get('kwsSpBadgeClick').then((d) => { globalThis.__kwsBadgeClick = d.kwsSpBadgeClick || 'ask'; }); chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && c.kwsSpBadgeClick) globalThis.__kwsBadgeClick = c.kwsSpBadgeClick.newValue || 'ask'; }); } catch (_) {}
/*
   KWS 1.2.0 — Kick module
   Runs exclusively on kick.com/*
   Chat log source: Kick's own official "chat replay" API (web.kick.com/api/v1/chat/{channel_id}/history)
     — public, no API key needed. See kick_scanChannelRange in background.js for details.
   VOD: self-contained hls.js inline player fed directly by each hit's saved .m3u8 source
     (see openKickInlinePlayer below) — Kick exposes no working public deep-link VOD id.

   UI architecture: multi-channel scan queue + per-channel result tabs, unified with
   Twitch's keywordSearcher.js / SOOP's soopSearcher.js (RESULT_TABS + SCAN_QUEUE). Unlike
   those, up to MAX_CONCURRENT_SCANS channels run at once here rather than strictly one at a
   time — Kick's own chat-replay API showed no rate limiting under heavy concurrent load in
   live testing, so there's no need to serialize channels the way Twitch's/SOOP's archives do.
   Anything beyond the concurrency cap queues and its tab shows "queued" until a slot frees up.
   Also includes the "site badge" click-to-scan pills next to channel links.
*/

(function () {
  'use strict';
  if (document.getElementById('kick-kws-panel')) return;

  const PANEL_ID    = 'kick-kws-panel';
  const STORAGE_KEY = 'kickKwsSettings';
  const HISTORY_KEY = 'kickKwsHistory';
  const TABS_SESSION_KEY = 'kickKwsResultTabs';
  const VERSION     = '1.3.0';
  const TRANSLATE_LANG_KEY = 'kickKwsTranslateLangV2';
  const KWS_AUTO_CLOSE_KEY = 'kickKwsAutoCloseNoResult';
  let kwsAutoCloseNoResult = false;

  // Kick's own chat-replay API itself is no longer the concurrency bottleneck: background.js's
  // kick_scanChannelRange now draws every chat-bucket request (from every channel/session
  // scanning at once) from ONE shared, network-wide adaptive pool (KICK_GLOBAL_POOL) that grows
  // when requests keep succeeding and immediately backs off on any failure — so total in-flight
  // requests self-tune to whatever the network/API will actually take, no matter how many
  // channels are running. That shared pool is what makes it safe to raise the number of
  // channels allowed to scan at once here, instead of the old fixed, lower cap.
  // 2026-09: 6으로 열어놨더니 채널을 20~30개씩 큐에 쌓아서 돌리는 사용량에서 Kick이 429를
  // 강하게 걸기 시작했고, 그로 인한 공유 쿨다운 대기 중 서비스워커가 죽어서 진행률이
  // 전부 멈추는 문제로 이어졌음. Twitch(KWS_OVERLOAD.MAX_CONCURRENT_CHANNELS)와 SOOP
  // (MAX_CONCURRENT_SCANS)이 이미 4로 고정돼 있는 것과 맞춰서 Kick도 4로 내림.
  const MAX_CONCURRENT_SCANS = 4;

  // KWS 1.2.5: scanning, results and settings live in the side panel. This page script keeps
  // only what has to be on the page: site badges (click = scan), ?kws_autoscan=1, and the
  // inline VOD player that the panel's timestamps open. Scan state comes from the hub
  // (chrome.storage.session "kwsSpScans", see scan_hub.js).
  const SP_MODE = true;
  const SP_SCANS_KEY = 'kwsSpScans';
  let SP_HUB = {};
  const spEntry = (slug) => SP_HUB['kick:' + slug];

  // ══════════════════════════════════════════════════════════
  //  STATE — multi-channel: one tab per channel, up to
  //  MAX_CONCURRENT_SCANS run at once, the rest wait in SCAN_QUEUE
  // ══════════════════════════════════════════════════════════
  let RESULT_TABS  = [];   // [{ channel, groups:[], matchedLines, matchedDays, pending, live, scanParams }]
  let SCAN_QUEUE   = [];   // [{ channel, keyword, startDate, endDate }]
  let SCAN_STATES  = {};   // channel -> { running, percent, done, total, matchedDays, matchedLines, message, keywords }
  let STATE        = { runningChannels: new Set() };
  let ACTIVE_TAB   = -1;
  let _kwsReactivateCh = null;
  let HISTORY      = {};
  let _kkwsReady   = false; // init() 끝(히스토리 로드 + 패널 생성) 여부
  let SETTINGS     = { keyword: '' };

  const esc   = s => String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  const $     = id => document.getElementById(id);
  const fmtDate = d => d.toISOString().slice(0,10);

  function guessChannel() {
    const m = /kick\.com\/([^/?#]+)/.exec(window.location.href);
    const skip = new Set(['browse','search','categories','settings','help','about','live','following','clips','videos','en','dashboard']);
    return (m && !skip.has(m[1])) ? m[1].toLowerCase() : '';
  }

  function safeKwStrings(kws) {
    if (!Array.isArray(kws)) return [];
    return kws.map(k => typeof k === 'string' ? k.replace(/^~/,'') : (k&&k.word||String(k))).filter(Boolean);
  }

  function kwPreview(kws, max) {
    max = max || 3;
    const words = safeKwStrings(kws);
    if (!words.length) return 'all';
    const shown = words.slice(0, max).join(', ');
    const more  = words.length - max;
    return more > 0 ? shown + ' +' + more + ' more' : shown;
  }

  function hlKw(html, kws) {
    let o = String(html||'');
    const sorted = [...new Set((kws||[]).filter(Boolean))].sort((a,b)=>b.replace(/^~/,'').length-a.replace(/^~/,'').length);
    for (const rawK of sorted) {
      const isSub = rawK.startsWith('~');
      const k = isSub ? rawK.slice(1) : rawK;
      const escaped = k.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
      const pattern = (isSub || !/^[a-z0-9\s'-]+$/i.test(k))
        ? new RegExp(escaped, 'gi')
        : new RegExp('(?<![a-zA-Z0-9\'-])' + escaped + '(?![a-zA-Z0-9\'-])', 'gi');
      o = o.replace(pattern, '<mark style="background:rgba(250,204,21,0.28);color:#fde68a;padding:0 2px;border-radius:3px;">$&</mark>');
    }
    return o;
  }

  function requestFromBackground(msg) {
    return new Promise((res, rej) => {
      chrome.runtime.sendMessage(msg, r => {
        if (chrome.runtime.lastError) rej(chrome.runtime.lastError);
        else res(r);
      });
    });
  }

  async function loadStorage() {
    const data = await chrome.storage.local.get([STORAGE_KEY, HISTORY_KEY]);
    SETTINGS = Object.assign({ keyword: '' }, data[STORAGE_KEY] || {});
    // twitchKwsKeywordProfile 변경 감지 → Kick 키워드 즉시 동기화
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      if (changes.twitchKwsKeywordProfile) {
        const profile = changes.twitchKwsKeywordProfile.newValue;
        if (profile?.keyword) {
          SETTINGS.keyword = profile.keyword;
          HISTORY.__keyword_profile__ = profile;
          const kwInput = document.getElementById('kkws-keyword');
          if (kwInput) { kwInput.value = profile.keyword; }
          if (typeof KWSSharedKeywordEditor !== 'undefined') KWSSharedKeywordEditor.updatePreview('kkws-keyword','kkws-keyword-preview');
        }
      }
      if (changes[HISTORY_KEY]) {
        HISTORY = changes[HISTORY_KEY].newValue || {};
        injectSiteBadges();
      }
      if (changes[KWS_AUTO_CLOSE_KEY]) {
        kwsAutoCloseNoResult = !!changes[KWS_AUTO_CLOSE_KEY].newValue;
        const cb = document.getElementById('kkws-auto-close-no-result');
        if (cb) cb.checked = kwsAutoCloseNoResult;
      }
    });
    try {
      const acr = await chrome.storage.local.get(KWS_AUTO_CLOSE_KEY);
      kwsAutoCloseNoResult = !!acr[KWS_AUTO_CLOSE_KEY];
      console.log('[KWS Kick] loadStorage: auto-close-no-result raw stored value =', acr[KWS_AUTO_CLOSE_KEY], '→', kwsAutoCloseNoResult);
    } catch (e) { console.error('[KWS Kick] loadStorage: failed reading auto-close-no-result', e); }
    try {
      const sv = await chrome.storage.local.get(['kickKwsSettingsVisible']);
      console.log('[KWS Kick] loadStorage: settings-section-visible raw stored value =', sv.kickKwsSettingsVisible);
    } catch (e) { console.error('[KWS Kick] loadStorage: failed reading settings-visible', e); }
    HISTORY  = data[HISTORY_KEY] || {};

    // Restore result tabs from this browsing session (survives page reload, not browser restart)
    try {
      const s = await chrome.storage.session.get(TABS_SESSION_KEY);
      const saved = s && s[TABS_SESSION_KEY];
      if (Array.isArray(saved) && saved.length) {
        RESULT_TABS = saved.map(t => ({ channel: t.channel, groups: t.groups||[], matchedLines: t.matchedLines||0, matchedDays: t.matchedDays||0, scanParams: t.scanParams||null, pending:false, live:false }));
        ACTIVE_TAB = 0;
      }
    } catch (_) {}
  }

  function saveTabsSession() {
    try {
      chrome.storage.session.set({
        [TABS_SESSION_KEY]: RESULT_TABS.map(t => ({
          channel: t.channel,
          groups: (t.groups||[]).slice(-40),
          matchedLines: t.matchedLines || 0,
          matchedDays: t.matchedDays || 0,
          scanParams: t.scanParams || null,
        }))
      }).catch(()=>{});
    } catch (_) {}
  }

  async function saveSettings() {
    SETTINGS.keyword = (($('kkws-keyword') && $('kkws-keyword').value) || '').trim();
    try { await chrome.storage.local.set({ [STORAGE_KEY]: SETTINGS }); } catch (e) { console.warn('[KWS Kick] could not save settings:', e?.message); }
  }






  // ══════════════════════════════════════════════════════════
  //  TRANSLATE — per-message 🌐 button + language picker, same
  //  engine/services as Twitch's/SOOP's translateTextAuto.
  // ══════════════════════════════════════════════════════════
  const TRANSLATE_CACHE = new Map();

  function getTranslateLang() {
    const sel = document.getElementById('kkws-translate-lang');
    return (sel?.value || localStorage.getItem(TRANSLATE_LANG_KEY) || 'en').trim() || 'en';
  }



  async function translateTextAuto(text, targetLang) {
    const src = String(text || '').trim();
    if (!src) return '';
    const lang = targetLang || getTranslateLang();
    const cacheKey = `${lang}\n${src}`;
    if (TRANSLATE_CACHE.has(cacheKey)) return TRANSLATE_CACHE.get(cacheKey);
    const data = await globalThis.KWSGTranslate(src, lang); // 1.2.5.46: rotates gtx / dict-chrome-ex / at (platform.js)
    const translated = (data?.[0] || []).map(x => x?.[0] || '').join('').trim();
    if (!translated) throw new Error('empty translation');
    TRANSLATE_CACHE.set(cacheKey, translated);
    return translated;
  }

  function openGoogleTranslate(text, targetLang) {
    const lang = targetLang || getTranslateLang();
    const url = `https://translate.google.com/?sl=auto&tl=${encodeURIComponent(lang)}&text=${encodeURIComponent(text || '')}&op=translate`;
    window.open(url, '_blank');
  }

  async function saveHistory(channel, entry) {
    const now = new Date().toISOString();
    // 기존 항목(matchedLines/keywords/clickedTimes 등)에 병합 — 통째로 덮어쓰면 예를 들어
    // "클릭한 타임스탬프 저장"만 하려던 호출이 방금 전 스캔 결과(matchedLines 등)를 날려버림.
    HISTORY[channel] = Object.assign({}, HISTORY[channel] || {}, entry, { savedAt: now, searchedAt: now });
    try { await chrome.storage.local.set({ [HISTORY_KEY]: HISTORY }); } catch (e) { console.warn('[KWS Kick] could not save history:', e?.message); }
  }

  function buildPanelHTML() {
    return `
      <style>
        #${PANEL_ID} * { box-sizing:border-box;font-family:inherit; }
        #${PANEL_ID} input { transition:border-color 0.2s,box-shadow 0.2s; }
        #${PANEL_ID} input:focus { outline:none;border-color:rgba(83,185,69,0.5)!important;box-shadow:0 0 0 3px rgba(83,185,69,0.1); }
        #${PANEL_ID} input::placeholder { color:rgba(255,255,255,0.28); }
        #${PANEL_ID} button:hover { filter:brightness(1.12); }
        #${PANEL_ID} button:active { transform:scale(0.97)!important; }
        #${PANEL_ID} ::-webkit-scrollbar { width:8px; }
        #${PANEL_ID} ::-webkit-scrollbar-track { background:transparent; }
        #${PANEL_ID} ::-webkit-scrollbar-thumb { background:rgba(83,185,69,0.3);border-radius:99px; }
        .kkws-card { transition:background 0.12s; }
        .kkws-card:hover { background:rgba(83,185,69,0.055)!important; }
        .kkws-tbtn { transition:all 0.15s;cursor:pointer; }
        .kkws-tbtn:hover { background:rgba(83,185,69,0.12)!important; }
        .kkws-vbtn { transition:all 0.15s; }
        /* Kick의 기본(안 눌러본) 타임스탬프 버튼 색이 이미 초록색(Kick 브랜드 컬러)이라, Twitch/SOOP처럼
           "다른 초록색"으로만 바꾸면 색 차이가 거의 안 보여서 "눌렀는지 안 눌렀는지 모르겠다"는
           문제가 있었음 — 초록색과 확실히 대비되는 주황색으로 바꿔서 구분되게 함. */
        .kkws-vbtn.visited { background:rgba(16,185,129,0.18)!important;color:#86efac!important;border-color:rgba(16,185,129,0.45)!important; }
      </style>

      <div id="kkws-hdr" style="display:flex;align-items:center;justify-content:space-between;
           padding:14px 16px 13px;border-bottom:1px solid rgba(255,255,255,0.06);cursor:move;background:linear-gradient(180deg,rgba(255,255,255,0.07) 0%,rgba(255,255,255,0) 100%);">
        <div>
          <div style="font-size:13px;font-weight:700;letter-spacing:-0.01em;color:#fff;line-height:1.2;">Kick KWS</div>
          <div style="display:flex;align-items:center;gap:6px;margin-top:2px;"><span id="kkws-version-badge" style="font-size:10px;font-weight:700;letter-spacing:0.04em;color:rgba(83,185,69,0.9);background:rgba(83,185,69,0.13);border:1px solid rgba(83,185,69,0.28);border-radius:5px;padding:1px 6px;">KWS</span></div>
        </div>
        <div style="display:flex;gap:5px;align-items:center;">
          <button id="kkws-settings-btn" title="Toggle settings" style="width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:14px;background:rgba(83,185,69,0.12);border:1px solid rgba(83,185,69,0.26);color:rgba(134,239,172,0.85);display:flex;align-items:center;justify-content:center;">⚙</button>
          <button id="kkws-discover-btn" title="Find more streamers to search" style="width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:13px;background:rgba(83,185,69,0.12);border:1px solid rgba(83,185,69,0.26);color:rgba(134,239,172,0.85);display:flex;align-items:center;justify-content:center;">🔍</button>
          <button id="kkws-player-btn" title="Open a VOD by URL or ID" style="width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:13px;background:rgba(96,165,250,0.16);border:1px solid rgba(96,165,250,0.32);color:#93c5fd;display:flex;align-items:center;justify-content:center;">▶</button>
          <button id="kkws-history-btn" title="Search History" style="width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:13px;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);color:rgba(255,255,255,0.7);display:flex;align-items:center;justify-content:center;">📋</button>
          <button id="kkws-toggle" title="Slim mode" style="width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:16px;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);color:rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;padding:0;box-sizing:border-box;">⇔</button>
          </div>
      </div>

      <div id="kkws-body" style="padding:14px 16px 16px;overflow-y:auto;max-height:calc(100vh - 150px);">

        <div id="kkws-net-banner" style="display:none;"></div>

        <div id="kkws-apikey-section" style="display:none;margin-bottom:12px;padding:12px 14px;border-radius:12px;background:rgba(83,185,69,0.05);border:1px solid rgba(83,185,69,0.15);">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:7px;">
            <div style="font-size:10px;font-weight:700;letter-spacing:0.07em;text-transform:uppercase;color:rgba(83,185,69,0.75);">API Source</div>
          </div>
          <div style="font-size:10.5px;line-height:1.5;color:rgba(255,255,255,0.45);margin-bottom:11px;"><b style="color:rgba(255,255,255,0.6);">Native API</b> — uses Kick's own chat-replay API.</div>
          <div style="font-size:10px;font-weight:800;letter-spacing:0.07em;text-transform:uppercase;color:rgba(83,185,69,0.75);margin:13px 0 9px;text-align:center;">Options</div>
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;padding:7px 0;border-bottom:1px solid rgba(255,255,255,0.07);margin-bottom:9px;">
            <input type="checkbox" id="kkws-auto-close-no-result" style="width:14px;height:14px;accent-color:#53b945;cursor:pointer;">
            <span style="font-size:11px;font-weight:600;color:rgba(255,255,255,0.8);">Auto-close tab if no results</span>
          </label>
          <div style="font-size:10px;font-weight:800;letter-spacing:0.07em;text-transform:uppercase;color:rgba(83,185,69,0.75);margin:13px 0 9px;text-align:center;" title="Chat messages are translated with Google Translate (free)">Translate to</div>
          <select id="kkws-translate-lang" title="Translate result messages to this language (Google Translate)" style="width:100%;height:36px;border-radius:10px;border:1px solid rgba(83,185,69,0.24);background:#14101d;color:#ffffff;font-size:11px;font-weight:700;padding:0 12px;outline:none;font-family:inherit;box-sizing:border-box;color-scheme:dark;cursor:pointer;"><option value="en" style="background:#14101d;color:#ffffff;">English</option><option value="ko" style="background:#14101d;color:#ffffff;">한국어</option><option value="ja" style="background:#14101d;color:#ffffff;">日本語</option><option value="zh-CN" style="background:#14101d;color:#ffffff;">中文</option><option value="es" style="background:#14101d;color:#ffffff;">Español</option><option value="ru" style="background:#14101d;color:#ffffff;">Русский</option><option value="de" style="background:#14101d;color:#ffffff;">Deutsch</option><option value="fr" style="background:#14101d;color:#ffffff;">Français</option><option value="pt" style="background:#14101d;color:#ffffff;">Português</option><option value="id" style="background:#14101d;color:#ffffff;">Bahasa Indonesia</option><option value="th" style="background:#14101d;color:#ffffff;">ไทย</option><option value="vi" style="background:#14101d;color:#ffffff;">Tiếng Việt</option></select>
        </div>

        <div id="kkws-input-area">
        <div style="margin-bottom:12px;">
          <div style="font-size:10px;font-weight:600;letter-spacing:0.08em;text-transform:uppercase;color:rgba(255,255,255,0.55);margin-bottom:6px;">Channel</div>
          <input id="kkws-channel" type="text" placeholder="e.g. xqc, streamername" style="width:100%;box-sizing:border-box;height:40px;padding:0 14px;border-radius:12px;border:1px solid rgba(255,255,255,0.2);background:rgba(255,255,255,0.1);color:#fff;font-size:13px;outline:none;font-family:inherit;">
          <div id="kkws-history-hint" style="margin-top:6px;padding:7px 11px;border-radius:9px;background:rgba(83,185,69,0.08);border:1px solid rgba(83,185,69,0.15);font-size:11px;color:rgba(134,239,172,0.85);display:none;line-height:1.5;"></div>
        </div>

        <div style="margin-bottom:12px;">
          <div style="font-size:10px;font-weight:600;letter-spacing:0.08em;text-transform:uppercase;color:rgba(255,255,255,0.55);margin-bottom:6px;">Keywords</div>
          <button id="kkws-keyword-btn" type="button" style="width:100%;height:40px;padding:0 14px;border-radius:12px;border:1px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.07);color:#fff;font-size:12px;text-align:left;display:flex;align-items:center;justify-content:space-between;gap:8px;cursor:pointer;font-family:inherit;"><span id="kkws-keyword-preview" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:rgba(255,255,255,0.65);"></span><span style="font-size:10px;color:rgba(83,185,69,0.8);flex-shrink:0;">✏️ Edit</span></button>
          <input id="kkws-keyword" type="hidden" value="">
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px;">
          <div>
            <div style="font-size:10px;font-weight:600;letter-spacing:0.08em;text-transform:uppercase;color:rgba(255,255,255,0.55);margin-bottom:6px;">From <span style="font-size:9px;color:rgba(255,255,255,0.26);text-transform:none;font-weight:400;">(blank=60d ago)</span></div>
            <input id="kkws-start" type="date" style="width:100%;box-sizing:border-box;height:40px;padding:0 12px;border-radius:12px;border:1px solid rgba(255,255,255,0.2);background:rgba(255,255,255,0.1);color:#fff;font-size:12px;outline:none;color-scheme:dark;font-family:inherit;">
          </div>
          <div>
            <div style="font-size:10px;font-weight:600;letter-spacing:0.08em;text-transform:uppercase;color:rgba(255,255,255,0.55);margin-bottom:6px;">To <span style="font-size:9px;color:rgba(255,255,255,0.26);text-transform:none;font-weight:400;">(blank=now)</span></div>
            <input id="kkws-end" type="date" style="width:100%;box-sizing:border-box;height:40px;padding:0 12px;border-radius:12px;border:1px solid rgba(255,255,255,0.2);background:rgba(255,255,255,0.1);color:#fff;font-size:12px;outline:none;color-scheme:dark;font-family:inherit;">
          </div>
        </div>

        <div style="display:flex;gap:8px;margin-bottom:14px;">
          <button id="kkws-start-btn" style="flex:1;height:42px;border:none;border-radius:13px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;font-size:13px;font-weight:700;color:#fff;background:linear-gradient(135deg,rgba(34,139,34,0.9),rgba(83,185,69,0.9));box-shadow:0 4px 16px rgba(83,185,69,0.3),inset 0 1px 0 rgba(255,255,255,0.12);">▶ Start Scan</button>
          <button id="kkws-stop-btn" style="width:80px;height:42px;border:none;border-radius:13px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:#fff;background:linear-gradient(135deg,rgba(220,38,38,0.85),rgba(239,68,68,0.85));box-shadow:0 4px 12px rgba(220,38,38,0.25);">■ Stop</button>
        </div>
        </div><!-- /kkws-input-area -->

        <div style="margin-bottom:10px;padding:10px 13px;border-radius:12px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07);">
          <div style="font-size:9px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:rgba(255,255,255,0.5);margin-bottom:4px;">Status</div>
          <div id="kkws-status" style="color:rgba(255,255,255,0.9);font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">Idle</div>
        </div>

        <div style="margin-bottom:10px;">
          <div style="display:flex;justify-content:space-between;margin-bottom:5px;">
            <span style="font-size:10px;color:rgba(255,255,255,0.5);">Progress</span>
            <span id="kkws-pct" style="font-size:10px;color:rgba(255,255,255,0.6);">0%</span>
          </div>
          <div style="height:4px;background:rgba(255,255,255,0.06);border-radius:99px;overflow:hidden;">
            <div id="kkws-bar" style="height:100%;width:0%;transition:width 0.4s;border-radius:99px;background:linear-gradient(90deg,#22863a,#53b945);"></div>
          </div>
        </div>

        <div id="kkws-metrics" style="white-space:pre-wrap;font-size:11px;line-height:1.8;color:rgba(255,255,255,0.5);padding:8px 12px;border-radius:11px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.05);margin-bottom:12px;font-variant-numeric:tabular-nums;"></div>

        <div id="kkws-results">
          ${window.KWSResultsHeaderHTML('kkws-results-summary','kkws-res-clear')}
          <div id="kkws-result-tabs" style="display:flex;flex-wrap:wrap;gap:5px;margin-bottom:8px;"></div>
          <div id="kkws-results-list" style="display:flex;flex-direction:column;gap:5px;"></div>
        </div>

      </div>
    `.replace(/\${VERSION}/g, VERSION);
  }

  // SOOP(soop-speed-banner)/Twitch(kws-overload-banner)와 동일한 스타일의 간단한 네트워크
  // 인디케이터 — Kick은 채팅 소스가 Kick 자체 chat-replay API 하나뿐이라 점 하나("Native API")만
  // 보여줌. 요청 단위까지는 background.js(kick_scanChannelRange)가 전담해서 content script에서
  // 개별 요청 시작/끝을 알 수 없으므로, KICK_KWS_PROGRESS 틱이 올 때마다 짧게 켜지는 걸로
  // "지금 실제로 가져오는 중"을 근사함 (SOOP의 NET_VISUAL_UNTIL 최소 표시시간 패턴과 동일).
  let _kkwsApiPulseUntil = 0;
  const KKWS_NET_PULSE_MS = 500;
  function pulseNetApi() {
    _kkwsApiPulseUntil = Date.now() + KKWS_NET_PULSE_MS;
    renderNetBanner();
    setTimeout(() => { if (Date.now() >= _kkwsApiPulseUntil) renderNetBanner(); }, KKWS_NET_PULSE_MS + 30);
  }
  function renderNetBanner() {
    const banner = $('kkws-net-banner');
    if (!banner) return;
    if (!STATE.runningChannels.size) { banner.innerHTML = ''; banner.style.cssText = 'display:none;'; return; }
    banner.style.cssText = 'margin-bottom:10px;padding:0;border-radius:10px;background:rgba(83,185,69,0.12);border:1px solid rgba(83,185,69,0.3);font-size:11px;overflow:hidden;transition:background .3s ease,border-color .3s ease;';
    const active = Date.now() < _kkwsApiPulseUntil;
    const dot = `<span style="display:inline-flex;align-items:center;gap:4px;color:rgba(255,255,255,${active ? '0.85' : '0.35'});white-space:nowrap;">` +
      `<span style="width:7px;height:7px;border-radius:50%;background:${active ? '#4ade80' : 'rgba(255,255,255,0.22)'};${active ? 'box-shadow:0 0 6px rgba(74,222,128,0.9);' : ''}transition:background .2s ease,box-shadow .2s ease;"></span>Native API</span>`;
    banner.innerHTML = `<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:9px 12px;flex-wrap:wrap;">
      <span style="font-weight:700;color:rgba(255,255,255,0.9);">🟢 Scanning</span>
      <span style="display:flex;align-items:center;gap:10px;font-size:10px;">
        ${dot}
        <span style="color:rgba(255,255,255,0.4);border-left:1px solid rgba(255,255,255,0.15);padding-left:10px;">${STATE.runningChannels.size}/${MAX_CONCURRENT_SCANS} running</span>
      </span>
    </div>`;
  }

  function setStatus(msg) { const el = $('kkws-status'); if (el) el.textContent = msg; }

  function setProgress(pct) {
    const bar = $('kkws-bar'), pctEl = $('kkws-pct');
    if (bar)   bar.style.width = Math.min(100, Math.max(0, pct)) + '%';
    if (pctEl) pctEl.textContent = Math.round(pct) + '%';

    updateKickMetrics();
  }

  // Twitch/SOOP과 같은 "Channel / Keywords / Date / Progress" 요약 박스
  function updateKickMetrics() {
    const el = $('kkws-metrics');
    if (!el) return;
    const ch = getActiveChannel();
    const s = ch ? SCAN_STATES[ch] : null;
    const tab = ch ? findTab(ch) : null;
    const sp = (tab && tab.scanParams) || {};
    if (!ch || !s) {
      el.textContent = ['Channel  : -', 'Keywords : -', 'Date     : -', 'Progress : -'].join('\n');
      return;
    }
    let kws = '-';
    try {
      const raw = String(sp.keyword || '').split(/[\n,]/).map(x => x.trim()).filter(x => x && !x.startsWith('-'));
      kws = kwPreview(raw, 3) || '-';
    } catch (_) {}
    el.textContent = [
      'Channel  : ' + ch,
      'Keywords : ' + kws,
      'Date     : ' + (sp.startDate || 'any') + ' ~ ' + (sp.endDate || 'now'),
      'Progress : ' + (s.done || 0) + '/' + (s.total || 0) + ' chunks · ' + (s.matchedDays || 0) + ' matched · ' + (s.matchedLines || 0) + ' hits',
    ].join('\n');
  }

  // ══════════════════════════════════════════════════════════
  //  MULTI-CHANNEL QUEUE + PER-CHANNEL RESULT TABS
  // ══════════════════════════════════════════════════════════
  function getActiveChannel() {
    const tab = RESULT_TABS[ACTIVE_TAB];
    return tab ? tab.channel : null;
  }

  function findTab(ch) { return RESULT_TABS.find(t => t.channel === ch); }

  function mergeGroupsInto(tab, incoming) {
    (incoming||[]).forEach(function(g) {
      const existing = tab.groups.find(function(x){ return x.date === g.date; });
      if (existing) {
        (g.messages||[]).forEach(function(m) {
          const key = m.rawTs + '|' + m.username + '|' + m.message;
          if (!existing.messages.find(function(x){ return x.rawTs+'|'+x.username+'|'+x.message === key; }))
            existing.messages.push(m);
        });
      } else {
        tab.groups.push(g);
      }
    });
  }

  function queueOrStartScan({ channel, keyword, startDate, endDate }) {
    const ch = (channel||'').trim().toLowerCase();
    if (!ch) { setStatus('⚠ Enter a channel name.'); return; }

    // 통일 규칙(4개 KWS 공통): 이미 스캔 중이면 확인 팝업 — OK: 중지 후 처음부터 다시, Cancel: 유지
    if (STATE.runningChannels.has(ch)) {
      const params = { channel, keyword, startDate, endDate };
      window.KWSRestartDialog?.({
        name: ch,
        onRestart: () => {
          setStatus('Stopping ' + ch + '…');
          window.KWSStopAndRestart({
            stop: () => chrome.runtime.sendMessage({ type: 'KICK_KWS_STOP', channel: ch }),
            isRunning: () => STATE.runningChannels.has(ch), // DONE/ERROR 때 advanceQueue가 지움
            start: () => { STATE.runningChannels.delete(ch); queueOrStartScan(params); }
          });
        }
      });
      return;
    }

    // Replace any existing (non-running) tab for this channel
    const existingIdx = RESULT_TABS.findIndex(t => t.channel === ch);
    // 지금 보고 있는 탭을 다시 검색하는 경우에만 새 탭을 활성화 (그 외엔 보던 탭 유지 — Twitch/SOOP과 동일)
    if (existingIdx >= 0 && existingIdx === ACTIVE_TAB) _kwsReactivateCh = ch;
    if (existingIdx >= 0) {
      RESULT_TABS.splice(existingIdx, 1);
      const qIdx = SCAN_QUEUE.findIndex(q => q.channel === ch);
      if (qIdx >= 0) SCAN_QUEUE.splice(qIdx, 1);
      if (ACTIVE_TAB >= RESULT_TABS.length) ACTIVE_TAB = RESULT_TABS.length - 1;
    }

    const scanParams = { channel: ch, keyword, startDate, endDate };

    if (STATE.runningChannels.size >= MAX_CONCURRENT_SCANS) {
      const tabIdx = RESULT_TABS.length;
      RESULT_TABS.push({ channel: ch, pending: true, live: false, groups: [], matchedLines: 0, matchedDays: 0, scanParams });
      if (ACTIVE_TAB < 0 || ACTIVE_TAB >= RESULT_TABS.length - 1 || _kwsReactivateCh === ch) ACTIVE_TAB = tabIdx;
      if (_kwsReactivateCh === ch) _kwsReactivateCh = null;
      SCAN_QUEUE.push(scanParams);
      setStatus('Queued ' + ch + '… (' + SCAN_QUEUE.length + ' waiting · ' + STATE.runningChannels.size + '/' + MAX_CONCURRENT_SCANS + ' running)');
      renderResultTabs();
      updateActiveStatusUI();
      injectSiteBadges();
      return;
    }

    runScanNow(scanParams);
  }

  function runScanNow(scanParams) {
    const ch = scanParams.channel;
    let idx = RESULT_TABS.findIndex(t => t.channel === ch);
    if (idx < 0) { RESULT_TABS.push({ channel: ch, groups: [], matchedLines: 0, matchedDays: 0 }); idx = RESULT_TABS.length - 1; }
    RESULT_TABS[idx].pending = false;
    RESULT_TABS[idx].live = true;
    RESULT_TABS[idx].groups = [];
    RESULT_TABS[idx].matchedLines = 0;
    RESULT_TABS[idx].matchedDays = 0;
    RESULT_TABS[idx].scanParams = scanParams;
    if (ACTIVE_TAB < 0 || ACTIVE_TAB >= RESULT_TABS.length || _kwsReactivateCh === ch) ACTIVE_TAB = idx;
    if (_kwsReactivateCh === ch) _kwsReactivateCh = null;

    STATE.runningChannels.add(ch);
    SCAN_STATES[ch] = { running: true, percent: 0, done: 0, total: 1, matchedDays: 0, matchedLines: 0, message: 'Starting scan for ' + ch + '…', keywords: [] };

    setProgress(0);
    setStatus(SCAN_STATES[ch].message);
    renderResultTabs();
    renderNetBanner();
    saveSettings();
    injectSiteBadges();

    chrome.runtime.sendMessage({ type: 'KICK_KWS_START', channel: ch, keyword: scanParams.keyword, startDate: scanParams.startDate, endDate: scanParams.endDate });
  }

  // Called when a channel's scan finishes (done/error/closed) — frees its concurrency slot
  // and pulls in the next queued channel(s) while there's room.
  function advanceQueue(ch) {
    if (ch) STATE.runningChannels.delete(ch);
    while (STATE.runningChannels.size < MAX_CONCURRENT_SCANS && SCAN_QUEUE.length) {
      runScanNow(SCAN_QUEUE.shift());
    }
    renderNetBanner();
    updateActiveStatusUI();
    injectSiteBadges();
  }

  function updateActiveStatusUI() {
    const ch = getActiveChannel();
    const s  = ch ? SCAN_STATES[ch] : null;
    const tab = RESULT_TABS[ACTIVE_TAB];
    if (tab && tab.pending) {
      setStatus('Queued — will start after the current scan finishes.');
      setProgress(0);
    } else {
      setStatus(s ? s.message : 'Idle');
      setProgress(s ? s.percent : 0);
    }
    renderResultsList();
  }

  function startScanFromForm() {
    const channel = (($('kkws-channel') && $('kkws-channel').value) || '').trim().toLowerCase();
    let keyword = (($('kkws-keyword') && $('kkws-keyword').value) || '').trim();
    if (!keyword && window.KWSSharedKeywordEditor) keyword = window.KWSSharedKeywordEditor.defaultValue();
    const sd = ($('kkws-start') && $('kkws-start').value) || fmtDate(new Date(Date.now() - 60*24*3600*1000));
    const ed = ($('kkws-end')   && $('kkws-end').value)   || fmtDate(new Date());
    if (!channel) { setStatus('⚠ Enter a channel name.'); return; }
    queueOrStartScan({ channel, keyword, startDate: sd, endDate: ed });
  }

  function stopScan() {
    const tab = RESULT_TABS[ACTIVE_TAB];
    if (!tab) return;
    const ch = tab.channel;
    if (STATE.runningChannels.has(ch)) {
      chrome.runtime.sendMessage({ type: 'KICK_KWS_STOP', channel: ch });
      setStatus('Stopping…');
    } else if (tab.pending) {
      const qIdx = SCAN_QUEUE.findIndex(q => q.channel === ch);
      if (qIdx >= 0) SCAN_QUEUE.splice(qIdx, 1);
      const tIdx = RESULT_TABS.findIndex(t => t.channel === ch);
      if (tIdx >= 0) RESULT_TABS.splice(tIdx, 1);
      if (ACTIVE_TAB >= RESULT_TABS.length) ACTIVE_TAB = RESULT_TABS.length - 1;
      renderResultTabs();
      updateActiveStatusUI();
      saveTabsSession();
    }
  }

  function renderResultTabs() {
    const tabBar  = $('kkws-result-tabs');
    const summary = $('kkws-results-summary');
    if (!tabBar) return;

    if (!RESULT_TABS.length) {
      tabBar.innerHTML = '';
      if (summary) summary.textContent = 'No results';
      renderResultsList();
      return;
    }

    tabBar.innerHTML = RESULT_TABS.map((t, i) => {
      const isActive = i === ACTIVE_TAB;
      const s = SCAN_STATES[t.channel];
      const running = !!(s && s.running);
      const matched = t.matchedLines || 0;
      let bg, color, border;
      if (t.pending) {
        bg = 'rgba(6,182,212,0.12)'; color = '#22d3ee'; border = isActive ? 'rgba(6,182,212,0.8)' : 'rgba(6,182,212,0.35)';
      } else if (running) {
        bg = 'rgba(251,146,60,0.15)'; color = '#fb923c'; border = isActive ? 'rgba(6,182,212,0.8)' : 'rgba(251,146,60,0.35)';
      } else if (matched > 0) {
        bg = isActive ? 'rgba(83,185,69,0.25)' : 'rgba(83,185,69,0.12)'; color = '#86efac'; border = isActive ? 'rgba(6,182,212,0.8)' : 'rgba(83,185,69,0.3)';
      } else {
        bg = isActive ? 'rgba(255,255,255,0.09)' : 'rgba(255,255,255,0.04)'; color = 'rgba(255,255,255,0.5)'; border = isActive ? 'rgba(6,182,212,0.8)' : 'rgba(255,255,255,0.08)';
      }
      const pct = running && s.total ? Math.round((s.done/s.total)*100) : 0;
      return `<div style="display:inline-flex;align-items:center;border-radius:8px;overflow:hidden;border:1px solid ${border};">
        <button data-tab="${i}" class="kkws-tbtn" style="padding:5px 9px;border:none;font-size:11px;font-weight:700;white-space:nowrap;background:${bg};color:${color};">${esc(t.channel)}${matched?` <span style="color:#4ade80;">(${matched})</span>`:''}${running?` <span style="font-size:9px;">⏳${pct}%</span>`:''}${t.pending?' <span style="font-size:9px;opacity:0.8;">queued</span>':''}</button>
        <button data-close="${i}" style="padding:4px 7px;border:none;cursor:pointer;font-size:11px;background:${bg};color:${color};opacity:0.55;border-left:1px solid ${border};">×</button>
      </div>`;
    }).join('');

    tabBar.querySelectorAll('[data-tab]').forEach(btn => {
      btn.addEventListener('click', () => {
        ACTIVE_TAB = parseInt(btn.dataset.tab); renderResultTabs(); updateActiveStatusUI();
        // Twitch와 동일: 탭을 누르면 그 채널 이름이 입력칸에 들어가서 복사/재검색이 쉬움
        const _ch = RESULT_TABS[ACTIVE_TAB]?.channel;
        const _inp = $('kkws-channel');
        if (_inp && _ch) { _inp.value = _ch; try { renderHistoryHint(_ch); } catch {} }
      });
    });
    tabBar.querySelectorAll('[data-close]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const i = parseInt(btn.dataset.close);
        const tab = RESULT_TABS[i];
        if (!tab) return;
        const running = STATE.runningChannels.has(tab.channel);
        const hasResults = (tab.matchedLines || 0) > 0;
        if (running || hasResults) {
          const reason = running ? 'is still scanning' : `has ${tab.matchedLines} matched result(s)`;
          if (!confirm(`"${tab.channel}" tab ${reason}.\n\nClose this tab anyway?`)) return;
        }
        if (running) { chrome.runtime.sendMessage({ type: 'KICK_KWS_STOP', channel: tab.channel }); }
        const qIdx = SCAN_QUEUE.findIndex(q => q.channel === tab.channel);
        if (qIdx >= 0) SCAN_QUEUE.splice(qIdx, 1);
        RESULT_TABS.splice(i, 1);
        if (ACTIVE_TAB >= RESULT_TABS.length) ACTIVE_TAB = RESULT_TABS.length - 1;
        if (ACTIVE_TAB > i) ACTIVE_TAB--;
        renderResultTabs();
        updateActiveStatusUI();
        saveTabsSession();
        injectSiteBadges();
        if (running) { if (SCAN_STATES[tab.channel]) SCAN_STATES[tab.channel].running = false; advanceQueue(tab.channel); }
      });
    });

    const activeTab = RESULT_TABS[ACTIVE_TAB];
    if (summary) {
      if (!activeTab) summary.textContent = 'No results';
      else if (activeTab.pending) summary.textContent = 'Queued';
      else summary.textContent = window.KWSHitsText(activeTab.matchedLines||0, !!(SCAN_STATES[activeTab.channel] && SCAN_STATES[activeTab.channel].running));
    }

    renderResultsList();
  }

  function clearAllTabs() {
    STATE.runningChannels.forEach(ch => chrome.runtime.sendMessage({ type: 'KICK_KWS_STOP', channel: ch }));
    STATE.runningChannels.clear();
    SCAN_QUEUE.length = 0;
    RESULT_TABS = [];
    ACTIVE_TAB = -1;
    SCAN_STATES = {};
    renderResultTabs();
    renderNetBanner();
    updateActiveStatusUI();
    saveTabsSession();
    injectSiteBadges();
  }

  function clearActiveTab() {
    const i = ACTIVE_TAB;
    const tab = RESULT_TABS[i];
    if (!tab) return;
    const wasRunning = STATE.runningChannels.has(tab.channel);
    if (wasRunning) {
      chrome.runtime.sendMessage({ type: 'KICK_KWS_STOP', channel: tab.channel });
    }
    const qIdx = SCAN_QUEUE.findIndex(q => q.channel === tab.channel);
    if (qIdx >= 0) SCAN_QUEUE.splice(qIdx, 1);
    RESULT_TABS.splice(i, 1);
    if (ACTIVE_TAB >= RESULT_TABS.length) ACTIVE_TAB = RESULT_TABS.length - 1;
    renderResultTabs();
    updateActiveStatusUI();
    saveTabsSession();
    injectSiteBadges();
    if (wasRunning) advanceQueue(tab.channel);
  }

  // ══════════════════════════════════════════════════════════
  //  INLINE VOD PLAYER — a small, Kick-specific player built directly on hls.js.
  //
  //  This does NOT reuse VOD Downloader's Twitch inline player (window.buildVideoViewer,
  //  in ui.js): that function is Twitch-only through and through — it reads Twitch's own
  //  site cookies for auth tokens and calls Twitch-specific endpoints — and more to the
  //  point, ui.js (and everything it depends on) was never even loaded on kick.com to begin
  //  with, so `typeof window.buildVideoViewer === 'function'` was always false here and this
  //  whole code path was silently dead. That's the real reason clicking a timestamp never did
  //  anything but fall through to a new tab.
  //
  //  The new-tab fallback that was built for hit timestamps was *also* broken in a separate,
  //  deeper way: Kick's public "/api/v2/channels/{slug}/videos" endpoint (used for scanning)
  //  doesn't expose the internal id its own "/{channel}/videos/{id}" page route needs — I
  //  checked every id-shaped field it returns (`slug`, `video.uuid`, the numeric `id`) live
  //  against real Kick pages and all of them 404/error. The only working id is a ULID that
  //  Kick's site generates client-side and never surfaces through any public endpoint, so a
  //  correct deep link can't reliably be reconstructed from scan data at all.
  //
  //  What scanning DOES give us is the VOD's own .m3u8 (vod_source) — confirmed directly
  //  fetchable now that host_permissions covers stream.kick.com — so playing that inline with
  //  hls.js sidesteps the whole broken-deep-link problem rather than trying to patch it.
  function ensureKickPlayerStyle() {
    if (document.getElementById('kkws-player-style')) return;
    const s = document.createElement('style');
    s.id = 'kkws-player-style';
    s.textContent = `
      #kkws-vod-player{position:fixed;z-index:2147483647;width:min(820px,calc(100vw - 40px));background:rgba(10,12,18,.94);border:1px solid rgba(83,185,69,0.25);border-radius:18px;box-shadow:0 28px 90px rgba(0,0,0,.6);overflow:hidden;font-family:-apple-system,BlinkMacSystemFont,sans-serif;}
      #kkws-vod-player .kkws-vp-bar{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 12px;cursor:move;background:rgba(255,255,255,0.03);}
      #kkws-vod-player .kkws-vp-title{color:#fff;font-size:12px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;}
      #kkws-vod-player .kkws-vp-close{width:26px;height:26px;flex:0 0 auto;border-radius:50%;border:1px solid rgba(255,255,255,0.15);background:rgba(255,255,255,0.06);color:#fff;cursor:pointer;font-size:12px;}
      #kkws-vod-player video{width:100%;display:block;background:#000;max-height:70vh;}
      #kkws-vod-player .kkws-vp-error{padding:16px;color:#fca5a5;font-size:12px;line-height:1.5;}
    `;
    document.head.appendChild(s);
  }

  function openKickInlinePlayer({ source, title, channel, seekSec }) {
    document.getElementById('kkws-vod-player')?.remove();
    ensureKickPlayerStyle();
    const box = document.createElement('div');
    box.id = 'kkws-vod-player';
    box.style.top = '40px';
    box.style.left = Math.max(18, Math.round(window.innerWidth * 0.25)) + 'px';
    box.innerHTML = `
      <div class="kkws-vp-bar">
        <span class="kkws-vp-title">${esc(title || channel || 'VOD')}</span>
        <button class="kkws-vp-close" title="Close">✕</button>
      </div>
      <video controls autoplay playsinline webkit-playsinline></video>
    `;
    document.body.appendChild(box);

    let hls = null;
    const destroy = () => { try { hls?.destroy(); } catch(_) {} box.remove(); };
    box.querySelector('.kkws-vp-close').addEventListener('click', destroy);

    const video = box.querySelector('video');
    if (window.Hls && window.Hls.isSupported()) {
      hls = new window.Hls();
      hls.on(window.Hls.Events.ERROR, (_evt, data) => {
        if (data?.fatal) {
          const err = box.querySelector('.kkws-vp-bar');
          err?.insertAdjacentHTML('afterend', '<div class="kkws-vp-error">Couldn’t load this VOD’s video (' + esc(data.details || 'playback error') + ').</div>');
        }
      });
      hls.loadSource(source);
      hls.attachMedia(video);
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = source; // Safari: native HLS
    } else {
      box.querySelector('.kkws-vp-bar').insertAdjacentHTML('afterend', '<div class="kkws-vp-error">This browser can’t play HLS video inline.</div>');
      return box;
    }
    if (seekSec > 0) {
      video.addEventListener('loadedmetadata', () => { try { video.currentTime = seekSec; } catch(_){} }, { once: true });
    }

    // Drag by the title bar
    let dragging = false, ox = 0, oy = 0;
    const bar = box.querySelector('.kkws-vp-bar');
    bar.addEventListener('mousedown', e => {
      if (e.target.closest('button')) return;
      dragging = true;
      const r = box.getBoundingClientRect();
      ox = e.clientX - r.left; oy = e.clientY - r.top;
      box.style.left = r.left + 'px'; box.style.top = r.top + 'px';
    });
    window.addEventListener('mousemove', e => { if (dragging) { box.style.left = (e.clientX - ox) + 'px'; box.style.top = (e.clientY - oy) + 'px'; } });
    window.addEventListener('mouseup', () => { dragging = false; });
    return box;
  }

  // Poll for the shared video-viewer's <video> element and seek once it's actually seekable —
  // same approach Twitch's keywordSearcher.js uses (HLS needs a moment after attachMedia before
  // currentTime sticks). Kept as our own local copy since Kick doesn't load keywordSearcher.js.
  async function seekVODPlayer(seconds) {
    if (!(seconds >= 0)) return;
    const find = () => document.querySelector('#tvd_video_viewer video') || document.querySelector('video.pop_out_video');
    for (let i = 0; i < 66; i++) {
      const v = find();
      if (v) {
        if (v.readyState >= 2 && v.seekable?.length > 0) {
          try { v.currentTime = seconds; } catch (e) {}
          await new Promise(r => setTimeout(r, 500));
          if (Math.abs(v.currentTime - seconds) > 5) { try { v.currentTime = seconds; } catch (e) {} }
          return;
        }
        if (v.readyState < 1) {
          await new Promise(res => {
            let done = false;
            const fin = () => { if (done) return; done = true; v.removeEventListener('loadedmetadata', ok); res(); };
            const ok = () => fin();
            v.addEventListener('loadedmetadata', ok, { once: true });
            setTimeout(fin, 1000);
          });
        }
      }
      await new Promise(r => setTimeout(r, 300));
    }
  }

  // Opens a Kick VOD hit in the same full-featured inline player Twitch uses (quality
  // selection, download, fullscreen, drag/resize — buildVideoViewer in ui.js), since that
  // whole pipeline (getKickVideoStreamData → getTwitchOrKickManifest → attachSourceToVideoElm)
  // was already built to be platform-agnostic — it just never used to be loaded on kick.com.
  // Falls back to our own minimal hls.js box only if that bundle isn't available for some reason.
  // 클릭한 타임스탬프 버튼을 어떤 메시지의 것인지 특정하는 키 (채널별로 HISTORY에 저장/복원할 때 사용).
  function kwsVisitedTsKey(item) {
    return item?.ts || item?.playback_ts || String(item?.rawTs ?? item?.playback_offset ?? '');
  }

  // 버튼에 방문 표시(초록색)를 남기고, 탭 전환/재렌더링 후에도 남아있도록 HISTORY에 영구 저장.
  // 주의: saveHistory는 채널당 기존 항목에 병합(merge)하므로 matchedLines 등 다른 필드를 덮어쓰지 않음.
  async function markVisited(item, btn) {
    if (btn) btn.classList.add('visited');
    try {
      const ck = (item?.vod_channel || '').toLowerCase().trim();
      const tsKey = kwsVisitedTsKey(item);
      if (ck && tsKey) {
        const cur = HISTORY[ck] || {};
        const clicked = { ...(cur.clickedTimes || {}), [tsKey]: true };
        await saveHistory(ck, { clickedTimes: clicked });
      }
    } catch (e) {}
  }

  async function openKickVODInline(item, btn) {
    // 1.2.5.21: subscriber-only VOD hits are not playable (older results may still carry a guessed source)
    if (item && item.vod_state === 'subonly') return;
    const seekSec = item.playback_offset != null ? Math.max(0, item.playback_offset - 30) : 0;
    const channel = item.vod_channel || (($('kkws-channel') && $('kkws-channel').value) || '').trim();

    // Same VOD already open — just seek, don't rebuild the whole player.
    const existingViewer = document.getElementById('tvd_video_viewer');
    if (existingViewer && item.vod_id != null && existingViewer.dataset.vodId === String(item.vod_id) && typeof existingViewer._twitchSeekTo === 'function') {
      const seeked = await existingViewer._twitchSeekTo(seekSec);
      if (seeked) { await markVisited(item, btn); return; }
    }

    if (item.vod_source && typeof runKickSourceBuild === 'function') {
      await runKickSourceBuild({
        source: item.vod_source,
        channel_login: channel,
        title: item.vod_title || channel,
        vod_id: item.vod_id,
        // VOD 시작 시각(ms) — 없으면 다운로드 파일명의 날짜 필드가 빈 채로 나가서
        // "채널명--해상도.ts" 처럼 구분자가 겹쳐 보임 (utilities.js의 getInfoFromM3u8Link 참고).
        timestamp: item.vod_timestamp || undefined,
        ref_elm: (btn && btn.parentElement) || document.body,
      });
      await new Promise(r => setTimeout(r, 3000));
      await seekVODPlayer(seekSec);
      await markVisited(item, btn);
      return;
    }

    if (item.vod_source) {
      openKickInlinePlayer({ source: item.vod_source, title: item.vod_title || channel, channel, seekSec });
      await markVisited(item, btn);
      return;
    }

    // No m3u8 source on this hit (older scan data from before source-tracking was added) and,
    // per the note above, there's no deep-link we can reliably build — send the user to the
    // channel's own video list instead of a guessed URL that would just error out.
    if (channel) {
      alert('This hit has no saved video source — try re-scanning this channel. Opening the channel’s VOD list instead.');
      window.open(`https://kick.com/${channel}/videos`, '_blank');
    }
    await markVisited(item, btn);
  }

  // Manual "Open a VOD by URL or ID" entry — looks the VOD up in Kick's own recent-VOD list to
  // get its .m3u8 source, then plays it the same way as a search-result hit.
  async function playKickVODFromInput(raw, channelHint) {
    const urlMatch  = /kick\.com\/([^/]+)\/videos\/([a-zA-Z0-9-]+)/.exec(raw);
    const slugOrId  = urlMatch?.[2] || (/^[a-zA-Z0-9-]{6,}$/.test(raw.trim()) ? raw.trim() : null);
    const chan      = (urlMatch?.[1] || channelHint || (($('kkws-channel') && $('kkws-channel').value) || '') || guessChannel() || '').trim().toLowerCase();
    if (!slugOrId) { alert('Could not find a Kick VOD ID in that input.'); return; }
    if (!chan) { alert('Enter a channel name above first, or paste the full kick.com/<channel>/videos/<id> URL.'); return; }

    let vodItem = null;
    try {
      const vods = await requestFromBackground({ cmd: 'getKickVODs', params: { channel_slug: chan } });
      if (Array.isArray(vods)) vodItem = vods.find(v => v.slug === slugOrId || String(v.id) === slugOrId) || null;
    } catch (e) { console.warn('KWS Kick: VOD lookup failed', e); }

    if (vodItem && vodItem.source && typeof runKickSourceBuild === 'function') {
      const vodStartMs = vodItem.start_time ? new Date(String(vodItem.start_time).replace(' ', 'T') + 'Z').getTime() : undefined;
      await runKickSourceBuild({ source: vodItem.source, channel_login: chan, title: vodItem.session_title || vodItem.title || chan, vod_id: vodItem.id, timestamp: (Number.isFinite(vodStartMs) ? vodStartMs : undefined), ref_elm: document.body });
      return;
    }
    if (vodItem && vodItem.source) {
      openKickInlinePlayer({ source: vodItem.source, title: vodItem.session_title || chan, channel: chan, seekSec: 0 });
    } else {
      alert(vodItem
        ? 'That VOD has no playable source right now.'
        : 'Couldn’t find that VOD in the channel’s recent list (Kick only exposes the ~20 most recent, with no way to page further back). Opening the channel’s VOD list instead.');
      window.open(`https://kick.com/${chan}/videos`, '_blank');
    }
  }

  function buildMessageCard(item, cluster, trRows) {
    const card = document.createElement('div');
    card.className = 'kkws-card';
    const cbr = cluster ? `${cluster.first?'10px 10px':'0 0'} ${cluster.last?'10px 10px':'0 0'}` : '10px';
    card.style.cssText = `padding:8px 10px;border-radius:${cbr};background:${cluster?'rgba(6,182,212,0.06)':'rgba(255,255,255,0.028)'};border:1px solid ${cluster?'rgba(6,182,212,0.45)':'rgba(255,255,255,0.055)'};border-bottom:${cluster&&!cluster.last?'1px solid rgba(6,182,212,0.2)':'1px solid '+(cluster?'rgba(6,182,212,0.45)':'rgba(255,255,255,0.055)')};display:grid;grid-template-columns:auto 1fr;gap:8px;align-items:start;${cluster&&cluster.first?'box-shadow:0 0 8px rgba(6,182,212,0.15);':''}`;

    const btn = document.createElement('button');
    btn.className = 'kkws-vbtn';
    btn.style.cssText = window.KWS_TBTN.base;

    if (item.playback_ts != null) {
      btn.textContent = '▶ ' + item.playback_ts;
      btn.style.cssText += window.KWS_TBTN.off;
      btn.title = 'Open VOD at this moment\n▶ ' + item.playback_ts + (item.vod_title ? '\n📺 '+item.vod_title : '');
    } else if (item.vod_id) {
      btn.textContent = '▶ Open VOD';
      btn.style.cssText += window.KWS_TBTN.off;
      btn.title = 'Open Kick VOD' + (item.vod_title ? ' — '+item.vod_title : '');
    } else {
      btn.textContent = '🕐 ' + item.ts;
      btn.style.cssText += 'border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.05);color:rgba(255,255,255,0.5);cursor:default;';
    }

    // 이전에 클릭했던 타임스탬프면 다시 렌더링될 때(탭 전환, 스캔 갱신 등)도 초록색 유지.
    {
      const ck = (item.vod_channel || '').toLowerCase().trim();
      const tsKey = kwsVisitedTsKey(item);
      if (ck && tsKey && HISTORY[ck]?.clickedTimes?.[tsKey]) {
        btn.classList.add('visited');
      }
    }

    if (item.vod_id) {
      // 클릭 즉시 로딩 표시 — 안 그러면 플레이어가 뜨는 몇 초 동안 눌렀는지 안 눌렀는지 알 수 없음.
      // (완료되면 원래 텍스트로 복원되고, 성공한 경우엔 markVisited()가 붙인 .visited 클래스로
      // 초록색이 계속 남아서 "이미 열어본 타임스탬프"라는 걸 표시함)
      (function(i, b){
        b.addEventListener('click', async function(){
          if (b._loading) return;
          b._loading = true;
          const origText = b.textContent;
          const origOpacity = b.style.opacity;
          b.textContent = '⏳ ...';
          b.style.opacity = '0.55';
          try {
            await openKickVODInline(i, b);
          } catch (e) {
            console.warn('KWS Kick: failed to open VOD at timestamp', e);
          } finally {
            b._loading = false;
            b.style.opacity = origOpacity || '';
            b.textContent = origText;
          }
        });
      })(item, btn);
    }

    const kwBadge = document.createElement('span');
    kwBadge.style.cssText = 'display:inline-block;margin-bottom:3px;padding:1px 6px;background:rgba(234,179,8,0.15);color:#fde047;border:1px solid rgba(234,179,8,0.25);border-radius:5px;font-size:9px;font-weight:700;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;vertical-align:top;';
    kwBadge.textContent = kwPreview(item.keywords, 3);

    const txt = document.createElement('div');
    txt.style.cssText = 'min-width:0;';
    if (!kwBadge.textContent) kwBadge.style.display = 'none';

    const msgLine = document.createElement('div');
    msgLine.style.cssText = 'font-size:12px;color:#cbd5e1;word-break:break-word;line-height:1.45;';
    msgLine.innerHTML = '<span style="color:#a5b4fc;font-weight:600;">' + esc(item.username) + '</span>: ' + hlKw(esc(item.message||''), item.keywords||[]);

    const translatedLine = document.createElement('div');
    translatedLine.style.cssText = 'display:none;margin-top:4px;padding:5px 7px;border-radius:7px;background:rgba(14,165,233,0.07);border:1px solid rgba(14,165,233,0.14);color:#bae6fd;font-size:11px;line-height:1.45;word-break:break-word;';
    // 스캔 중 리렌더가 카드를 통째로 다시 그려도 번역 결과가 사라지지 않게 item에 저장했다가
    // KWSBatchTranslate가 복원해줌 (접으면 onHide에서 비워서 다시 펴진 채로 복원되지 않음).
    if (trRows) trRows.push({ text: item.message || '', box: translatedLine, cached: item._kwsTranslation, onDone: (l, t) => { item._kwsTranslation = { lang: l, text: t }; }, onHide: () => { item._kwsTranslation = null; } });

    txt.appendChild(kwBadge);
    txt.appendChild(msgLine);
    txt.appendChild(translatedLine);
    card.appendChild(btn);
    card.appendChild(txt);
    return card;
  }

  // 공유 동시성 풀 덕분에 여러 채널이 동시에 빠르게 스캔되면서, 채널당 최대 초당 5번(200ms
  // 스로틀)인 진행 이벤트가 최대 6개 채널에서 동시에 들어오고, 그때마다 updateActiveStatusUI()
  // "그리고" renderResultTabs() 양쪽에서 각각 이 함수를 불러서 매번 결과 목록 DOM을 통째로
  // 지우고 (정렬+클러스터링까지) 다시 그렸음 — 결과가 많아질수록 초당 최대 수십 번의 풀
  // DOM 리빌드가 겹쳐서 검색 자체(네트워크)는 멀쩡한데 브라우저/컴퓨터가 버벅이는 원인이 됐음.
  // 실제 화면은 사람 눈에 초당 몇 번만 갱신돼도 충분히 매끄러워 보이니, 짧은 시간 안에 몰려온
  // 요청은 합쳐서 한 번만 다시 그리도록 디바운스 — 스캔 속도/네트워크 동시성에는 전혀 영향 없음.
  let _renderResultsListTimer = null;
  function renderResultsList() {
    clearTimeout(_renderResultsListTimer);
    _renderResultsListTimer = setTimeout(_renderResultsListImpl, 220);
  }

  function _renderResultsListImpl() {
    const list = $('kkws-results-list');
    if (!list) return;
    const tab = RESULT_TABS[ACTIVE_TAB];

    if (!tab) { list.innerHTML = '<div style="padding:14px;border-radius:10px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.05);color:rgba(255,255,255,0.35);font-size:11.5px;text-align:center;">No results yet. Start a scan to see hits here.</div>'; return; }
    if (tab.pending) { list.innerHTML = '<div style="padding:14px;border-radius:10px;background:rgba(6,182,212,0.05);border:1px solid rgba(6,182,212,0.15);color:rgba(103,232,249,0.75);font-size:11.5px;text-align:center;">⏳ Queued — will start after the current scan finishes.</div>'; return; }

    const total = (tab.groups||[]).reduce((s,g) => s + (g.messages||[]).length, 0);
    if (!total) {
      const s = SCAN_STATES[tab.channel];
      list.innerHTML = '<div style="padding:14px;border-radius:10px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.05);color:rgba(255,255,255,0.35);font-size:11.5px;text-align:center;">' + ((s && s.running) ? 'Scanning… results will appear here as they are found.' : 'No hits found.') + '</div>';
      return;
    }

    list.innerHTML = '';
    const groupsSorted = [...tab.groups].sort((a,b) => a.date < b.date ? 1 : -1); // newest date first (same as Twitch/SOOP)
    groupsSorted.forEach(function(group) {
      if (!group.messages || !group.messages.length) return;
      const dateHdr = document.createElement('div');
      dateHdr.style.cssText = 'font-weight:800;font-size:12px;line-height:1.4;color:#7dd3fc;margin:8px 0 7px;padding-bottom:5px;border-bottom:1px solid rgba(255,255,255,0.06);';
      dateHdr.style.display = 'flex'; dateHdr.style.alignItems = 'center'; dateHdr.style.justifyContent = 'space-between'; dateHdr.style.gap = '8px';
      const dateLbl = document.createElement('span');
      dateLbl.textContent = '📅 ' + (group.displayDate || group.date) + '  (' + group.messages.length + ' hits)';
      { const _names = [...new Set(group.messages.map(m => m.vod_title).filter(t => t && t !== '(CDN recovered)'))];
        if (_names.length) { dateLbl.title = _names.join('\n'); dateLbl.style.cursor = 'help'; } }
      dateHdr.appendChild(dateLbl);
      list.appendChild(dateHdr);
      const _trRows = [];

      // 연속 클러스터 감지 (2개 이상, 3분 이내)
      // 주의: m.playback_ts는 "1:22:08" 같은 "H:MM:SS" 표시용 문자열이라 parseInt()를
      // 쓰면 콜론 앞의 숫자만(=시간 단위) 읽혀버려서, 예를 들어 1:22:08(=4928초)과
      // 3:10:05(=11405초)처럼 실제로는 1시간 48분이나 떨어진 두 메시지가 각각 1과 3으로
      // "파싱"되어 차이가 2 밖에 안 되는 것처럼 보이는 바람에 같은 클러스터로 묶여버리는
      // 버그가 있었음 — 실제 초 단위인 playback_offset(없으면 rawTs를 초로 환산)을 써야 함.
      const secOf = m => m.playback_offset != null ? m.playback_offset : (m.rawTs != null ? Math.floor(m.rawTs / 1000) : 0);
      // 청크/세션이 이제 공유 동시성 풀(KICK_GLOBAL_POOL)로 병렬 처리되면서 완료 순서가
      // 뒤섞일 수 있어서, 클러스터 판정(인접 쌍 비교) 전에 실제 시간순으로 다시 정렬—
      // 안 그러면 배열 순서만 우연히 인접한 서로 먼 시간대 메시지가 묶일 수 있음.
      const msgs = group.messages.slice().sort((a, b) => secOf(a) - secOf(b));
      const clusterGroup = new Map();
      const clusterSet = new Set();
      let gid = 0, i = 0;
      while (i < msgs.length) {
        let j = i + 1;
        while (j < msgs.length && secOf(msgs[j]) - secOf(msgs[j-1]) < 180) j++;
        if (j - i >= 2) {
          for (let k = i; k < j; k++) { clusterSet.add(k); clusterGroup.set(k, gid); }
          gid++;
        }
        i = j;
      }

      msgs.forEach(function(item, idx) {
        const isCluster = clusterSet.has(idx);
        const cgid = clusterGroup.get(idx);
        const cluster = isCluster ? {
          first: clusterGroup.get(idx-1) !== cgid,
          last:  clusterGroup.get(idx+1) !== cgid,
        } : null;
        list.appendChild(buildMessageCard(item, cluster, _trRows));
      });
      if (_trRows.length) {
        const gBtn = document.createElement('button');
        gBtn.style.cssText = 'flex-shrink:0;font-size:9px;font-weight:800;padding:2px 7px;border-radius:99px;letter-spacing:0.02em;cursor:pointer;font-family:inherit;line-height:1.3;background:rgba(14,165,233,0.14);color:#7dd3fc;border:1px solid rgba(14,165,233,0.3);';
        dateHdr.appendChild(gBtn);
        window.KWSBatchTranslate(gBtn, _trRows, getTranslateLang, translateTextAuto, openGoogleTranslate);
      }
    });
  }

  function updateKeywordPreview(){
    if (window.KWSSharedKeywordEditor) return window.KWSSharedKeywordEditor.updatePreview('kkws-keyword','kkws-keyword-preview');
    const pr=$('kkws-keyword-preview'); if(pr) pr.textContent='✦ Default keywords active — click to edit';
  }
  function createKeywordEditor(){
    if (window.KWSSharedKeywordEditor) return window.KWSSharedKeywordEditor.open({
      modalId:'kkws-kw-modal', inputId:'kkws-keyword', previewId:'kkws-keyword-preview',
      accent:'linear-gradient(135deg,rgba(34,139,34,.92),rgba(83,185,69,.9))',
      storageKey:null, historyKey:HISTORY_KEY,
      onSaved:(val,profile)=>{ SETTINGS.keyword=val; KWSSharedKeywordEditor.saveToAllPlatforms(val,profile).catch(()=>{}); HISTORY.__keyword_profile__=profile; }
    });
  }

  function createHistoryWindow() {
    if (!window.KWSHistoryUI) return;
    window.KWSHistoryUI.open({
      platform: 'kick',
      HISTORY,
      HISTORY_KEY,
      accentColor: '#53b945',
      onImport: () => { renderHistoryHint((($('kkws-channel')?.value)||'').trim().toLowerCase()); injectSiteBadges(); },
      onGetScanState: (id) => {
        const nid = (id||'').toLowerCase();
        if (SCAN_STATES[nid]?.running) return 'running';
        if (SCAN_QUEUE.some(q => q.channel === nid)) return 'queued';
        return 'idle';
      },
      onIdClick: (id) => {
        const chInput = $('kkws-channel');
        if (chInput) { chInput.value = id; chInput.dispatchEvent(new Event('input')); renderHistoryHint(id); }
      },
      onScan: (id) => {
        const chInput = $('kkws-channel');
        if (chInput) { chInput.value = id; chInput.dispatchEvent(new Event('input')); renderHistoryHint(id); }
        $('kkws-start-btn')?.click();
      }
    });
  }

  function renderHistoryHint(channel) {
    const hint = $('kkws-history-hint');
    if (!hint) return;
    const h = HISTORY[channel];
    if (!h) { hint.style.display = 'none'; return; }
    const when = h.savedAt ? new Date(h.savedAt).toLocaleDateString() : '?';
    hint.textContent = 'Last: ' + when + ' · "' + kwPreview(Array.isArray(h.keywords)?h.keywords:(h.keywords?[h.keywords]:[]),3) + '" · ' + (h.matchedLines||0) + ' hits · ' + (h.matchedDays||0) + ' days';
    hint.style.display = 'block';
  }

  // ══════════════════════════════════════════════════════════
  //  SCAN MESSAGE HANDLERS — routed by channel, since a scan (or
  //  a queued one waiting its turn) can belong to any tab
  // ══════════════════════════════════════════════════════════
  chrome.runtime.onMessage.addListener(function(msg) {
    const ch = (msg.channel || '').toLowerCase().trim();
    if (!ch) return;

    // streamrecorder.io 뱃지를 눌렀을 때 background.js가 "이미 킥 탭이 열려있네" 하고
    // 새 탭 대신 이쪽으로 보내주는 메시지 — 새로 스캔을 시작하거나(자리 있으면), 이미
    // MAX_CONCURRENT_SCANS만큼 돌고 있으면 대기열에 넣어줌(triggerBadgeScan/queueOrStartScan이
    // 알아서 처리). 배지 클릭 한 번당 새 탭 하나씩 뜨던 걸 여기서 막아줌.
    if (msg.type === 'KWS_EXTERNAL_QUEUE_SCAN') {
      // 새 탭이면 init()(히스토리 로드 + 패널 생성)이 끝나기 전에 메시지가 올 수 있음 —
      // 그 상태로 처리하면 HISTORY가 비어서 "이어 검색/처음부터" 팝업이 안 뜨고 바로 스캔됨.
      (async () => {
        for (let i = 0; i < 30 && !_kkwsReady; i++) await new Promise(r => setTimeout(r, 200));
        showPanelIfCollapsed();
        const chInput = $('kkws-channel');
        if (chInput) { chInput.value = ch; renderHistoryHint(ch); }
        triggerBadgeScan(ch);
      })();
      return;
    }

    if (msg.type === 'KICK_KWS_RUNNING') {
      if (getActiveChannel() === ch) setStatus('Scanning ' + ch + '…');
      return;
    }

    if (msg.type === 'KICK_KWS_STARTED') {
      // 탭을 이미 닫았는데 뒤늦게 온 시작 메시지가 '스캔 중' 상태를 되살리지 않게 무시
      if (!findTab(ch)) return;
      const s = SCAN_STATES[ch] || (SCAN_STATES[ch] = { running:true, percent:0, done:0, total:1, matchedDays:0, matchedLines:0, message:'', keywords:[] });
      s.running = true;
      s.total = msg.totalDates || 1;
      s.keywords = msg.keywords || s.keywords;
      var sessTxt = (typeof msg.totalSessions === 'number') ? (msg.totalSessions + ' broadcast' + (msg.totalSessions!==1?'s':'') + ' found — ') : '';
      s.message = sessTxt + 'scanning chat (5s buckets — can take a while for long ranges)…';
      s.percent = 2;
      if (getActiveChannel() === ch) updateActiveStatusUI();
      renderResultTabs();
      return;
    }

    if (msg.type === 'KICK_KWS_PROGRESS') {
      const s = SCAN_STATES[ch]; if (!s || !findTab(ch)) return;
      s.done = msg.done || 0; s.total = msg.total || 1;
      s.matchedLines = msg.matchedLines || 0; s.matchedDays = msg.matchedDays || 0;
      s.percent = s.total > 0 ? Math.min(99, Math.round((s.done/s.total)*100)) : 50;
      s.message = 'Searching… ' + s.done + '/' + s.total + ' chunks · ' + s.matchedLines + ' hit' + (s.matchedLines!==1?'s':'') + ' found';
      const tab = findTab(ch);
      if (tab) { mergeGroupsInto(tab, msg.matchedGroups); tab.matchedLines = s.matchedLines; tab.matchedDays = s.matchedDays; }
      if (getActiveChannel() === ch) updateActiveStatusUI();
      renderResultTabs();
      pulseNetApi();
      return;
    }

    if (msg.type === 'KICK_KWS_DONE') {
      const s = SCAN_STATES[ch];
      // failedChunks: 네트워크 문제로 재시도까지 실패해서 못 가져온 5초-버킷 구간(최대 3분 단위) 개수 —
      // 조용히 스킵되지 않고 완료 메시지에 드러나도록 표시함
      const failNote = msg.failedChunks ? (' · ⚠️ ' + msg.failedChunks + '개 구간 네트워크 오류로 누락') : '';
      if (s) { s.running = false; s.percent = 100; s.message = 'Done — ' + (s.matchedDays||0) + ' day' + ((s.matchedDays||0)!==1?'s':'') + ' · ' + (s.matchedLines||0) + ' hit' + ((s.matchedLines||0)!==1?'s':'') + failNote; s.failedChunks = msg.failedChunks || 0; }
      const tab = findTab(ch);
      if (tab) { tab.live = false; tab.pending = false; tab.failedChunks = msg.failedChunks || 0; }
      saveHistory(ch, { keywords: safeKwStrings(s?.keywords||[]), matchedLines: s?.matchedLines||0, matchedDays: s?.matchedDays||0 });
      // 결과 없으면 탭 자동 닫기
      if (kwsAutoCloseNoResult && (s?.matchedLines || 0) === 0) {
        setTimeout(() => {
          const closeIdx = RESULT_TABS.findIndex(t => t.channel === ch);
          if (closeIdx >= 0) {
            RESULT_TABS.splice(closeIdx, 1);
            if (ACTIVE_TAB >= RESULT_TABS.length) ACTIVE_TAB = RESULT_TABS.length - 1;
            if (ACTIVE_TAB > closeIdx) ACTIVE_TAB--;
            renderResultTabs();
            updateActiveStatusUI();
            saveTabsSession();
          }
        }, 300);
      }
      if (getActiveChannel() === ch) updateActiveStatusUI();
      renderResultTabs();
      saveTabsSession();
      injectSiteBadges();
      if (STATE.runningChannels.has(ch)) advanceQueue(ch);
      return;
    }

    if (msg.type === 'KICK_KWS_ERROR') {
      const s = SCAN_STATES[ch];
      if (s) { s.running = false; s.message = '✗ ' + msg.message; }
      const tab = findTab(ch);
      if (tab) { tab.live = false; tab.pending = false; }
      if (getActiveChannel() === ch) updateActiveStatusUI();
      renderResultTabs();
      injectSiteBadges();
      if (STATE.runningChannels.has(ch)) advanceQueue(ch);
      return;
    }
  });

  function enableDrag(panel, handle) {
    var ox=0, oy=0;
    handle.addEventListener('mousedown', function(e) {
      e.preventDefault(); ox = e.clientX - panel.offsetLeft; oy = e.clientY - panel.offsetTop;
      if (typeof topZIndexer === 'function') panel.style.zIndex = topZIndexer();
      function move(e2) {
        panel.style.left  = Math.max(0, Math.min(window.innerWidth  - panel.offsetWidth,  e2.clientX - ox)) + 'px';
        panel.style.top   = Math.max(0, Math.min(window.innerHeight - panel.offsetHeight, e2.clientY - oy)) + 'px';
        panel.style.right = 'auto';
      }
      document.addEventListener('mousemove', move);
      document.addEventListener('mouseup', function(){ document.removeEventListener('mousemove', move); }, { once: true });
    });
    // Clicking anywhere on the panel (not just the header) also brings it to front — same as
    // Twitch/SOOP. Kick's panel used to sit at a hardcoded z-index way above the shared
    // topZIndexer() counter that the History window, keyword editor, and rescan/URL popups all
    // use, so those would render *behind* this panel and look like they'd silently failed to open.
    panel.addEventListener('mousedown', function(){ if (typeof topZIndexer === 'function') panel.style.zIndex = topZIndexer(); });
  }

  // ══════════════════════════════════════════════════════════
  //  SITE BADGES — pills next to channel links anywhere on Kick,
  //  click = immediate scan (same UX as Twitch/SOOP)
  // ══════════════════════════════════════════════════════════
  let _badgeTimer = null;
  function injectSiteBadges() { clearTimeout(_badgeTimer); _badgeTimer = setTimeout(_doInjectBadges, 400); }

  const KICK_BADGE_SKIP = new Set([
    'browse','search','categories','category','settings','help','about','live','following',
    'clips','videos','en','dashboard','subscriptions','messages','messaging','wallet',
    'membership','moderator','signup','login','terms','privacy','support','discover',
    'shop','store','notifications','embed','video','category-guide'
  ]);

  function _doInjectBadges() {
    if (!document.getElementById('kkws-badge-style')) {
      const s = document.createElement('style');
      s.id = 'kkws-badge-style';
      s.textContent = `.kkws-search-badge{display:inline-flex;align-items:center;padding:1px 6px;border-radius:99px;font-size:9px;font-weight:700;white-space:nowrap;vertical-align:middle;margin-left:4px;position:relative;z-index:5;pointer-events:auto;cursor:pointer;font-family:-apple-system,sans-serif;line-height:1.5;letter-spacing:0.01em;transition:all 0.15s;}`;
      document.head.appendChild(s);
    }

    document.querySelectorAll('.kkws-search-badge').forEach(el => el.remove());

    const seen = new Set();
    document.querySelectorAll('a[href^="/"]').forEach(el => {
      if (seen.has(el)) return; seen.add(el);
      if (el.closest('#' + PANEL_ID)) return;
      const href = el.getAttribute('href') || '';
      const m = /^\/([a-zA-Z0-9_]{2,25})(\/|\?|$)/.exec(href.split('#')[0]);
      if (!m) return;
      const slug = m[1].toLowerCase();
      if (KICK_BADGE_SKIP.has(slug) || /^\d+$/.test(slug)) return;
      if (el.querySelector('.kkws-search-badge') || el.nextElementSibling?.classList?.contains('kkws-search-badge')) return;

      const h = HISTORY[slug];
      const hub = SP_MODE ? spEntry(slug) : null;
      const s = SP_MODE ? (hub && hub.status === 'running' ? hub : null) : SCAN_STATES[slug];
      const isScanning = SP_MODE ? !!s : !!(s && s.running);
      const isQueued = SP_MODE ? !!(hub && hub.status === 'queued') : SCAN_QUEUE.some(q => q.channel === slug);
      const badge = document.createElement('span');
      badge.className = 'kkws-search-badge';

      if (isScanning) {
        const pct = s.total ? Math.round((s.done/s.total)*100) : 0;
        badge.textContent = `⏳ ${pct}%`;
        badge.style.cssText = 'background:rgba(251,146,60,0.15);border:1px solid rgba(251,146,60,0.4);color:#fb923c;';
        badge.title = `Scanning ${slug}... ${s.done}/${s.total} chunks · ${s.matchedLines} hits`;
        badge.style.cursor = 'default';
        // 통일 규칙: 이미 검색 중인 뱃지는 눌러도 아무 동작 없음 (아래 채널 링크로 새지도 않게 막기만 함)
        badge.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); });
      } else if (isQueued) {
        badge.textContent = 'queued';
        badge.style.cssText = 'background:rgba(6,182,212,0.12);border:1px solid rgba(6,182,212,0.35);color:#22d3ee;cursor:default;';
        badge.title = 'Queued — waiting for slot';
      } else if (!h) {
        badge.textContent = 'Search ▶';
        badge.style.cssText = 'background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);color:#f87171;';
        badge.title = `Not searched · Click to scan ${slug}`;
        badge.addEventListener('mouseenter', () => badge.style.background = 'rgba(239,68,68,0.2)');
        badge.addEventListener('mouseleave', () => badge.style.background = 'rgba(239,68,68,0.1)');
        badge.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); triggerBadgeScan(slug); });
      } else {
        const daysAgo = h.searchedAt ? Math.floor((Date.now() - new Date(h.searchedAt)) / 86400000) : null;
        const isRecent = daysAgo !== null && daysAgo <= 1;
        const isStale = daysAgo !== null && daysAgo > (globalThis.__kwsRedDays || 14);
        const label = daysAgo === 0 ? 'Today ↺' : daysAgo === 1 ? 'Yesterday ↺' : daysAgo !== null ? `${daysAgo}d ago ↺` : 'Searched ↺';
        const col = isStale
          ? { bg: 'rgba(239,68,68,0.1)',  bdr: 'rgba(239,68,68,0.3)',  txt: '#f87171', hov: 'rgba(239,68,68,0.2)' }
          : isRecent
            ? { bg: 'rgba(34,197,94,0.12)', bdr: 'rgba(34,197,94,0.35)', txt: '#4ade80', hov: 'rgba(34,197,94,0.22)' }
            : { bg: 'rgba(234,179,8,0.12)',  bdr: 'rgba(234,179,8,0.35)',  txt: '#fbbf24', hov: 'rgba(234,179,8,0.22)' };
        badge.textContent = label;
        badge.style.cssText = `background:${col.bg};border:1px solid ${col.bdr};color:${col.txt};`;
        badge.title = `${h.matchedLines || 0} hits · ${h.matchedDays || 0} days · Click to re-scan`;
        badge.addEventListener('mouseenter', () => badge.style.background = col.hov);
        badge.addEventListener('mouseleave', () => badge.style.background = col.bg);
        badge.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); triggerBadgeScan(slug); });
      }

      // Kick은 React 앱이라 행 전체가 pointer/mouse 이벤트로 이동 처리하는 경우가 있음 —
      // click뿐 아니라 down/up 계열도 막아서 뱃지 클릭이 아래 채널 링크로 새지 않게 함.
      ['pointerdown','pointerup','mousedown','mouseup','touchstart','touchend','dblclick','auxclick'].forEach(ev =>
        badge.addEventListener(ev, e => { e.stopPropagation(); }));
      el.insertAdjacentElement('afterend', badge);
    });
  }

  // Slim mode: hides the channel/keyword/date-range/start-stop inputs but keeps the header,
  // status, progress bar and Results section visible — same as Twitch/SOOP's "Slim mode" (⇔).
  // Kick used to have a *full* collapse instead (which also hid Results), which isn't what
  // "작은창모드" on the other platforms does, so this replaces that.
  function setSlim(panel, tb, slim) {
    panel.dataset.slim = slim ? 'true' : 'false';
    const inputArea = $('kkws-input-area');
    if (inputArea) inputArea.style.display = slim ? 'none' : '';
    if (tb) { tb.title = slim ? 'Expand' : 'Slim mode'; tb.style.background = slim ? 'rgba(83,185,69,0.3)' : ''; }
    panel.style.width = slim ? '280px' : '430px';
  }

  function showPanelIfCollapsed() {
    const panel = $(PANEL_ID);
    const tb    = $('kkws-toggle');
    if (panel && panel.dataset.slim === 'true') {
      setSlim(panel, tb, false);
      chrome.storage.local.set({ kickKwsPanelSlim: false }).catch(()=>{});
    }
  }

  // 1.2.5: badge / autoscan → the scan hub (side panel). Same rescan choice as 1.2.4.
  function spBadgeScan(slug, { auto = false } = {}) {
    const send = (mode) => {
      const m = { type: 'KWS_SP_BADGE_SCAN', platform: 'kick', channel: slug, mode, openPanel: !auto };
      if (globalThis.kwsBadgeSend) { globalThis.kwsBadgeSend(m); return; } // 1.2.6.9: instant feedback, no lost clicks
      try { chrome.runtime.sendMessage(m).catch(() => {}); } catch (_) {}
    };
    const h = HISTORY[slug.toLowerCase()];
    // 1.2.4 Kick history has no lastDate — the last search day stands in for it.
    const last = (h && (h.lastDate || String(h.searchedAt || h.savedAt || '').slice(0, 10))) || '';
    const pref = globalThis.__kwsBadgeClick; // settings: 'ask' (popup) / 'new' / 'full'
    if (!auto && /^\d{4}-\d{2}-\d{2}$/.test(last) && (pref === 'new' || pref === 'full')) send(pref);
    else if (!auto && /^\d{4}-\d{2}-\d{2}$/.test(last) && typeof window.showRescanPopup === 'function') {
      window.showRescanPopup(slug, '', slug, last, () => send('full'), () => send('new'));
    } else {
      send('full');
    }
  }

  async function triggerBadgeScan(slug) {
    if (SP_MODE) return spBadgeScan(slug);
    let keyword = (($('kkws-keyword') && $('kkws-keyword').value) || '').trim();
    if (!keyword && window.KWSSharedKeywordEditor) keyword = window.KWSSharedKeywordEditor.defaultValue();
    if (!keyword) { alert('⚠ No keywords set!\n\nPlease click the keyword button to set keywords first.'); $('kkws-keyword-btn')?.click(); return; }

    showPanelIfCollapsed();
    const chInput = $('kkws-channel');
    if (chInput) { chInput.value = slug; renderHistoryHint(slug); }

    const h = HISTORY[slug.toLowerCase()];
    // 이 채널을 처음 검색하는 거라면(히스토리 없음), 혹은 히스토리가 있어도 "전체 다시 검색"을
    // 고른 경우엔 패널에 남아있을 수 있는(같은 탭에서 전혀 다른 채널을 이미 스캔했을 때 입력된)
    // 예전 시작 날짜를 물려받지 않도록 항상 최근 60일로 리셋함 — Twitch/SOOP에서 확인된 것과
    // 같은 종류의 버그(뱃지로 새 채널을 스캔했는데 관계없는 예전 날짜까지 거슬러 올라가서
    // 검색되는 문제).
    const freshStart = fmtDate(new Date(Date.now() - 60*24*3600*1000));
    const ed = ($('kkws-end') && $('kkws-end').value) || fmtDate(new Date());

    if (h?.lastDate && typeof window.showRescanPopup === 'function') {
      showRescanPopup(slug, keyword, slug, h.lastDate,
        () => {
          if (chInput) chInput.value = slug;
          const sdInput = $('kkws-start'); if (sdInput) sdInput.value = freshStart;
          queueOrStartScan({ channel: slug, keyword, startDate: freshStart, endDate: ed });
        },
        () => queueOrStartScan({ channel: slug, keyword, startDate: h.lastDate, endDate: ed })
      );
    } else {
      const sdInput = $('kkws-start'); if (sdInput) sdInput.value = freshStart;
      queueOrStartScan({ channel: slug, keyword, startDate: freshStart, endDate: ed });
    }
  }

  async function spInit() {
    await loadStorage();
    try {
      const d = await chrome.storage.session.get(SP_SCANS_KEY);
      SP_HUB = d[SP_SCANS_KEY] || {};
    } catch (_) {}
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'session' && changes[SP_SCANS_KEY]) { SP_HUB = changes[SP_SCANS_KEY].newValue || {}; injectSiteBadges(); }
      // history written by the hub / panel → the popup and badges see it without a reload
      if (area === 'local' && changes[HISTORY_KEY]) { HISTORY = changes[HISTORY_KEY].newValue || {}; injectSiteBadges(); }
    });
    chrome.runtime.onMessage.addListener((m, _sender, sendResponse) => {
      if (!m || m.platform !== 'kick') return;
      if (m.type === 'KWS_SP_OPEN_VOD') {
        openKickVODInline(m.item || {}, null).catch((e) => { console.warn('[KWS Kick] open VOD failed', e); alert((e && e.message) || String(e)); });
        sendResponse({ ok: true });
      } else if (m.type === 'KWS_SP_OPEN_URL') {
        playKickVODFromInput(String(m.raw || ''), m.channel || '').catch((e) => console.warn('[KWS Kick] open URL failed', e));
        sendResponse({ ok: true });
      }
    });
    const ch = guessChannel();
    if (ch && /(?:^|[?&])kws_autoscan=1(?:&|$)/.test(location.search)) {
      try { history.replaceState(null, '', location.pathname + location.hash); } catch (e) {}
      setTimeout(() => spBadgeScan(ch, { auto: true }), 300);
    }
    [0, 500, 1000, 2000, 4000].forEach(d => setTimeout(() => injectSiteBadges(), d));
    const badgeObs = new MutationObserver(() => injectSiteBadges());
    badgeObs.observe(document.body, { childList: true, subtree: true });
    _kkwsReady = true;
  }

  async function init() {
    if (SP_MODE) return spInit();
    await loadStorage();
    const panel = document.createElement('div');
    panel.id = PANEL_ID;
    const initialZ = typeof topZIndexer === 'function' ? topZIndexer() : 2147483640;
    panel.style.cssText = 'position:fixed;top:80px;right:16px;z-index:' + initialZ + ';width:420px;max-width:calc(100vw - 24px);background:linear-gradient(180deg,rgba(255,255,255,0.07) 0,rgba(255,255,255,0) 110px),rgba(14,18,16,0.82);border:1px solid rgba(255,255,255,0.16);border-radius:26px;box-shadow:0 40px 80px rgba(0,0,0,0.55),inset 0 1px 0 rgba(255,255,255,0.14),0 0 0 1px rgba(83,185,69,0.10);backdrop-filter:saturate(150%) blur(24px);-webkit-backdrop-filter:saturate(150%) blur(24px);font-family:-apple-system,BlinkMacSystemFont,sans-serif;color:#e2e8f0;font-size:13px;user-select:none;';
    panel.innerHTML = buildPanelHTML();
    document.body.appendChild(panel);

    try {
      const vBadge = $('kkws-version-badge');
      if (vBadge) vBadge.textContent = 'KWS ' + (chrome.runtime.getManifest().version || '');
    } catch(e) {}

    const ch = guessChannel();
    if (ch) { $('kkws-channel').value = ch; renderHistoryHint(ch); }
    if (SETTINGS.keyword) $('kkws-keyword').value = SETTINGS.keyword; updateKeywordPreview();
    const trLang = $('kkws-translate-lang');
    if (trLang) {
      trLang.value = localStorage.getItem(TRANSLATE_LANG_KEY) || 'en';
      trLang.addEventListener('change', () => localStorage.setItem(TRANSLATE_LANG_KEY, trLang.value || 'en'));
    }
    const acCb = $('kkws-auto-close-no-result');
    if (acCb) {
      acCb.checked = kwsAutoCloseNoResult;
      console.log('[KWS Kick] init: applying auto-close-no-result to checkbox =', kwsAutoCloseNoResult);
      acCb.addEventListener('change', () => {
        kwsAutoCloseNoResult = acCb.checked;
        // 예전엔 .catch(()=>{})로 실패를 그냥 삼켜서, 저장이 (쿼터 초과 등으로) 실패해도
        // 콘솔에 아무 흔적도 안 남았음 — 원인 추적 가능하게 최소한 로그는 남기도록 함.
        chrome.storage.local.set({ [KWS_AUTO_CLOSE_KEY]: kwsAutoCloseNoResult })
          .then(() => console.log('[KWS Kick] saved auto-close-no-result =', kwsAutoCloseNoResult))
          .catch(e => console.error('[KWS Kick] failed to save auto-close setting', e));
      });
    }
    if (!$('kkws-start').value) $('kkws-start').value = fmtDate(new Date(Date.now() - 60*24*3600*1000));
    if (!$('kkws-end').value)   $('kkws-end').value   = fmtDate(new Date());

    try {
      const slimData = await chrome.storage.local.get(['kickKwsPanelSlim']);
      if (slimData.kickKwsPanelSlim) setSlim(panel, $('kkws-toggle'), true);
    } catch (_) {}

    renderResultTabs();
    renderNetBanner();
    updateActiveStatusUI();

    // streamrecorder.io 뱃지에서 ?kws_autoscan=1 로 넘어온 경우 — 채널 ID만 채워놓고 마는 게
    // 아니라 바로 스캔을 시작함(그쪽 배지들이 기대하는 동작). triggerBadgeScan()이 키워드
    // 미설정/재검색 팝업 등을 다 알아서 처리해줌. history.replaceState로 쿼리스트링을 지워서
    // 새로고침하거나 뒤로가기 했을 때 스캔이 또 시작되지 않게 함.
    if (ch && /(?:^|[?&])kws_autoscan=1(?:&|$)/.test(location.search)) {
      try {
        const cleanUrl = location.pathname + location.hash;
        history.replaceState(null, '', cleanUrl);
      } catch (e) {}
      setTimeout(() => triggerBadgeScan(ch), 300);
    }

    $('kkws-history-btn') && $('kkws-history-btn').addEventListener('click', createHistoryWindow);
    $('kkws-player-btn') && $('kkws-player-btn').addEventListener('click', () => {
      showKwsUrlPrompt({
        title: 'Open Kick VOD',
        placeholder: 'kick.com/channel/videos/xxxxxxxx or the video ID/slug',
        onSubmit: (raw) => { playKickVODFromInput(raw); }
      });
    });
    $('kkws-keyword-btn') && $('kkws-keyword-btn').addEventListener('click', () => {
      if (document.getElementById('kkws-kw-modal')) return; // duplicate guard
      createKeywordEditor();
    });
    $('kkws-discover-btn') && $('kkws-discover-btn').addEventListener('click', () => window.showKwsDiscoverPopup && window.showKwsDiscoverPopup());

    $('kkws-channel') && $('kkws-channel').addEventListener('input', function(e){ renderHistoryHint(e.target.value.trim().toLowerCase()); });

    // ⚙(Settings) 섹션 펼침/접힘 상태 — 예전엔 apiKeyVisible이 init()마다 true로 새로 선언되는
    // 지역 변수라서 전혀 저장이 안 됐고, 그래서 새로고침/새 탭마다 사용자가 접어놨어도 항상
    // 다시 펼쳐진 채로 나타났음(설정이 "기억 안 된다"는 리포트). Slim mode(kickKwsPanelSlim)와
    // 같은 방식으로 chrome.storage.local에 저장/복원함.
    // SOOP(soop-settings-inline)은 이 섹션을 애초에 마크업 기본값부터 display:none으로 두고
    // 세션 메모리로만 토글해서, storage 값이 비어있는(undefined) 최초 실행/재설치 때도 항상
    // "닫힌 채로 시작"이 보장됨 — 그래서 버그 리포트가 없었던 것. Kick은 반대로 마크업
    // 기본값이 "열림"이었고, storage 값이 명시적으로 false일 때만 닫는 방식이라서, 확장을
    // 새로 설치하거나(개발 중 zip을 새로 풀어 로드) storage가 비어있는 경우엔 항상 "열림"
    // 상태로 보였음 — 이게 "계속 내려와있다"는 리포트의 실제 원인. 기본값 자체를 SOOP과
    // 동일하게 닫힘으로 바꾸고, storage에 명시적으로 true가 저장돼 있을 때만 열어줌.
    var apiKeyVisible = false;
    try {
      const settingsData = await chrome.storage.local.get(['kickKwsSettingsVisible']);
      console.log('[KWS Kick] init: restoring settings-section-visible, stored =', settingsData.kickKwsSettingsVisible);
      if (settingsData.kickKwsSettingsVisible === true) {
        apiKeyVisible = true;
        const sec = $('kkws-apikey-section'); if (sec) sec.style.display = 'block';
      }
    } catch (e) { console.error('[KWS Kick] init: failed to restore settings-section-visible', e); }
    $('kkws-settings-btn') && $('kkws-settings-btn').addEventListener('click', async function(){
      apiKeyVisible = !apiKeyVisible;
      var sec = $('kkws-apikey-section'); if (sec) sec.style.display = apiKeyVisible ? 'block' : 'none';
      try {
        await chrome.storage.local.set({ kickKwsSettingsVisible: apiKeyVisible });
        console.log('[KWS Kick] saved settings-section-visible =', apiKeyVisible);
      } catch (e) { console.error('[KWS Kick] failed to save settings-section-visible', e); }
    });

    $('kkws-start-btn') && $('kkws-start-btn').addEventListener('click', startScanFromForm);
    $('kkws-stop-btn')  && $('kkws-stop-btn').addEventListener('click', stopScan);

    $('kkws-res-clear') && $('kkws-res-clear').addEventListener('click', () => {
      if (!RESULT_TABS.length) return;
      const cur = (ACTIVE_TAB >= 0 && RESULT_TABS[ACTIVE_TAB]) ? RESULT_TABS[ACTIVE_TAB] : null;
      window.KWSClearDialog({
        running: Array.from(STATE.runningChannels),
        currentLabel: cur ? cur.channel : null,
        tabCount: RESULT_TABS.length,
        onCurrent: clearActiveTab,
        onAll: clearAllTabs,
      });
    });
    $('kkws-toggle') && $('kkws-toggle').addEventListener('click', async function(){
      const tb = $('kkws-toggle');
      const slim = panel.dataset.slim === 'true';
      setSlim(panel, tb, !slim);
      await chrome.storage.local.set({ kickKwsPanelSlim: !slim });
    });

    [$('kkws-channel'), $('kkws-keyword')].forEach(function(el){
      el && el.addEventListener('keydown', function(e){ if (e.key === 'Enter') startScanFromForm(); });
    });

    enableDrag(panel, $('kkws-hdr'));

    // Site badges: initial staggered passes (page may still be hydrating) + live DOM watch,
    // same approach as Twitch/SOOP — Kick's own chat/feed DOM churns constantly, which is
    // what keeps already-placed badges' scanning/queued state fresh without polling.
    [0, 500, 1000, 2000, 4000].forEach(d => setTimeout(() => injectSiteBadges(), d));
    const badgeObs = new MutationObserver(() => injectSiteBadges());
    badgeObs.observe(document.body, { childList: true, subtree: true });
    _kkwsReady = true;
  }

  if (document.body) init();
  else document.addEventListener('DOMContentLoaded', init);

})();
