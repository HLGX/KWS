// /**
// https://developer.chrome.com/docs/capabilities/web-apis/file-system-access

// https://wicg.github.io/file-system-access/#api-showsavefilepicker

// https://github.com/GoogleChromeLabs/text-editor/blob/main/src/inline-scripts/fs-helpers.js
// */

var wakeLock = null;

const _kwsBeforeUnload = e => { e.preventDefault(); e.returnValue = ''; };
let _kwsDlGuarded = false;
const requestWakeLock = async () => {
  if (!_kwsDlGuarded && globalThis.KWSDl) { _kwsDlGuarded = true; KWSDl.begin(); } // background-safe download
  window.addEventListener('beforeunload', _kwsBeforeUnload);
  try {
      wakeLock = await navigator.wakeLock.request('screen');
      wakeLock.addEventListener('release', () => {
      // console.log(`Wake Lock was released at ${new Date()}, ${new Date().getTime()}`)
    });
    // console.log(`Wake Lock was actived at  ${new Date()}, ${new Date().getTime()}`);
  } catch (err) {
    // console.error(`${err.name}, ${err.message}`);
  }
};

const releaseWakeLock = async () => {
  if (_kwsDlGuarded && globalThis.KWSDl) { _kwsDlGuarded = false; KWSDl.end(); }
  window.removeEventListener('beforeunload', _kwsBeforeUnload);
  if (!wakeLock) {
    return;
  }
  try {
    await wakeLock.release();
    wakeLock = null;
  } catch (err) {
    // console.error(`${err.name}, ${err.message}`);
  }
};

var tab_inactive_start = 0;
document.addEventListener('visibilitychange', function() {
  if (!document.hidden) {
    tab_inactive_start = 0;
    requestWakeLock();
  }
  if (document.hidden) {
    tab_inactive_start = new Date().getTime();
  }
});



// 조각 하나를 재시도하며 받음. 끝내 실패하면 null (조용히 건너뛰어 파일에 구멍이 생기는 걸 막기 위해 호출부가 중단 처리)
async function kwsGetFragBuffer(url, tries) {
  tries = tries || 6; // a bit more patient: a hidden tab or a waking service worker can fail a request or two
  for (let a = 0; a < tries; a++) {
    try {
      const res = await requestFromBackground({ cmd: 'getDownloadableArrayBuffer', params: { url } });
      const buf = res?.transport_data ? new Uint8Array(JSON.parse(res.transport_data).data).buffer : null;
      if (buf?.byteLength) return buf;
    } catch (_) {}
    await (globalThis.KWSDl ? KWSDl.sleep(500 * (a + 1)) : new Promise(r => setTimeout(r, 500 * (a + 1))));
  }
  return null;
}

function buildDownloadStatusUI(params) {
  var { parent_elm, actor, warn } = params;
  let cont = ele();
  (parent_elm || document).appendChild(cont);
  inlineStyler(cont, `{display:grid; grid-gap:10px; font-size:1em; padding:14px 16px; color:#e5e7eb;}`);

  if (warn) {
    let warning_cont = ele();
    a(warning_cont, [['id', 'warning_container']]);
    cont.appendChild(warning_cont);
    inlineStyler(warning_cont, `{display:flex; align-items:center; gap:8px; padding:8px 12px; border-radius:12px; background:rgba(251,191,36,0.10); border:1px solid rgba(251,191,36,0.28); color:#fde68a; font-size:0.85em; font-weight:600;}`);
    warning_cont.innerHTML = `<span style="font-size:1.1em;">⚠️</span><span>Keep this tab active — navigating away may interrupt the download.</span>`;
  }

  let status_cont = ele();
  cont.appendChild(status_cont);
  inlineStyler(status_cont, `{display:grid; gap:8px;}`);

    let section_downloading_display = ele();
    status_cont.appendChild(section_downloading_display);
    inlineStyler(section_downloading_display, `{font-size:0.82em; color:rgba(255,255,255,0.52); font-weight:600; letter-spacing:0.02em;}`);

    let status_bar = ele();
    status_cont.appendChild(status_bar);
    inlineStyler(status_bar, `{border-radius:10px; padding:8px 12px; font-size:0.9em; font-weight:700; color:#ffffff; border:1px solid rgba(37,99,235,0.45); background:linear-gradient(90deg, rgba(2,52,181,0.9) 0%, rgba(2,52,181,0.5) 0.5%, rgba(2,52,181,0.04) 1%, rgba(2,52,181,0.04) 100%);}`);
    status_bar.textContent = 'initiating download';

  let options_cont = ele();
  cont.appendChild(options_cont);
  inlineStyler(options_cont, `{display:grid; gap:6px;}`);

    let info_display_cont = ele();
    options_cont.appendChild(info_display_cont);
    inlineStyler(info_display_cont, `{display:grid; gap:3px; font-size:0.82em; color:rgba(255,255,255,0.65); font-weight:600;}`);

        let file_size_display = ele();
        info_display_cont.appendChild(file_size_display);
        let duration_display = ele();
        info_display_cont.appendChild(duration_display);
        let vod_position_display = ele();
        info_display_cont.appendChild(vod_position_display);

    let download_btn = ele();
    options_cont.appendChild(download_btn);
    a(download_btn, [['class', 'gen_btn']]);
    inlineStyler(download_btn, `{width:100%; text-align:center; color:#ffffff; cursor:pointer; background:rgba(37,99,235,0.55); border:1px solid rgba(99,137,255,0.35); backdrop-filter:blur(8px); padding:9px 12px; border-radius:12px; font-size:0.9em; font-weight:700; box-shadow:inset 0 1px 0 rgba(255,255,255,0.10);}`);
    download_btn.textContent = "Stop and Download Progress";

  return { status_bar, options_cont, cont, download_btn, file_size_display, vod_position_display, duration_display, section_downloading_display };
}



async function buildDownloadVODUI(params){
  var { fragments, source, filename, start_in, is_mp4 } = params;

  var resolutions = await requestFromBackground({ cmd: 'getValidResolutions', params: { source } });
  var ext_dl_notif = document.getElementById('ext_dl_notif');
  var ext_download_cont = document.getElementById('ext_download_cont');
  if(ext_dl_notif){ext_dl_notif.remove()}
  if(ext_download_cont){ext_download_cont.remove()}

  if(!fragments?.length){
    var playlist = await requestFromBackground({
      cmd: "getTwitchOrKickManifest",
      params: {source},
    });
    fragments = playlist?.data?.fragments;
    is_mp4 = playlist?.is_mp4 || playlist?.data?.is_mp4;
    params.init_path = playlist?.data?.init_path; // 아래 downloadFullSelection 호출에서 ...params로 같이 전달되도록
  } else {
  }
  var total_duration = playlist?.data?.fragments ? playlist?.data?.fragments?.map(r => r.dur).reduce((a, b) => a + b) : 0;
  var download_view_holder = document.getElementById('download_view_holder');

  // ── 전체 컨테이너 (frosted glass, 좌우 넓게) ──
  let cont = ele();
  download_view_holder.appendChild(cont);
  inlineStyler(cont, `{display:grid; gap:14px; padding:18px 20px; color:#e5e7eb; font-family:-apple-system,BlinkMacSystemFont,sans-serif;}`);

  // ── 해상도 선택 ──
  let resolutions_cont = ele();
  cont.appendChild(resolutions_cont);
  inlineStyler(resolutions_cont, `{display:flex; align-items:center; gap:10px; flex-wrap:wrap;}`);

  let res_label = ele();
  res_label.textContent = 'Resolution';
  inlineStyler(res_label, `{font-size:0.8em; font-weight:700; color:rgba(255,255,255,0.52); letter-spacing:0.06em; text-transform:uppercase;}`);
  resolutions_cont.appendChild(res_label);

  let incoming_resolution = /(?<=\/)[\w-_]+(?=\/index-dvr)/.exec(source)?.[0];
  let resolutions_opt = ele('select');
  a(resolutions_opt, [['id','resolutions_opt']]);
  inlineStyler(resolutions_opt, `{height:32px; padding:0 10px; border-radius:10px; border:1px solid rgba(255,255,255,0.18); background:rgba(255,255,255,0.08); color:#fff; font-size:0.85em; font-weight:700; outline:none; cursor:pointer;}`);
  resolutions_cont.appendChild(resolutions_opt);
  resolutions.forEach(t => {
    let type = ele('option');
    a(type, [['value', t.name]]);
    resolutions_opt.appendChild(type);
    type.textContent = t.name == 'chunked' ? 'source' : t.name;
    if(t.name == incoming_resolution){ type.selected = true; }
  });

  // ── 슬라이더 힌트 ──
  let hint = ele();
  hint.innerHTML = `<span style="color:rgba(255,255,255,0.38); font-size:0.78em; font-weight:600;">▶ Set start / end time &nbsp;—&nbsp; </span><span style="color:${main_app_colors()?.edge}; font-size:0.82em; font-weight:800;">${params?.channel_login}</span>`;
  cont.appendChild(hint);

  // ── 슬라이더 ──
  let slider_container = ele();
  cont.appendChild(slider_container);

  // ── 경고 + 버튼 행 ──
  let bottom_row = ele();
  cont.appendChild(bottom_row);
  inlineStyler(bottom_row, `{display:flex; flex-wrap:wrap; align-items:flex-end; gap:10px;}`);

  let full_dl_warning = ele();
  bottom_row.appendChild(full_dl_warning);

  let dl_option_cont = ele();
  bottom_row.appendChild(dl_option_cont);
  inlineStyler(dl_option_cont, `{display:flex; gap:10px; margin-left:auto;}`);

  // ── 청크 다운로드 버튼 ──
  let dl_chunked = ele();
  dl_chunked.innerHTML = `<span style="font-size:1.1em;">📦</span> Multiple Files`;
  dl_option_cont.appendChild(dl_chunked);
  a(dl_chunked, [['class', 'gen_btn']]);
  inlineStyler(dl_chunked, `{display:flex; align-items:center; gap:6px; text-align:center; font-size:0.9em; font-weight:800; background:rgba(37,99,235,0.45); color:#ffffff; padding:10px 18px; border-radius:14px; border:1px solid rgba(99,137,255,0.35); cursor:pointer; backdrop-filter:blur(8px); box-shadow:inset 0 1px 0 rgba(255,255,255,0.10); white-space:nowrap;}`);

  dl_chunked.addEventListener('click', () => {
    let slider_values = Array.from(document.getElementsByClassName('vid_time_display') || []).map(r => getTimeValueFromInputString(r.value));
    let end = Math.max(...slider_values);
    let start = Math.min(...slider_values);
    downloadAsChunkedFiles({
      ...params,
      ...{
        is_mp4: is_mp4,
        fragments: fragments,
        parent_elm: download_view_holder,
        start_offset: start,
        end_offset: end ? end : (end+11),
        opt_cont: cont,
      }
    });
  });

  // ── 단일 파일 버튼 (Brave 제외) ──
  if(!navigator.brave){
    inlineStyler(full_dl_warning, `{display:flex; align-items:center; gap:6px; padding:7px 11px; border-radius:11px; background:rgba(251,191,36,0.08); border:1px solid rgba(251,191,36,0.22); color:#fde68a; font-size:0.78em; font-weight:600; max-width:320px;}`);
    full_dl_warning.innerHTML = `<span>⚠️</span><span>Keep this tab open while downloading as one file.</span>`;

    let dl_full_btn = ele();
    dl_full_btn.innerHTML = `<span style="font-size:1.1em;">💾</span> One File`;
    dl_option_cont.appendChild(dl_full_btn);
    a(dl_full_btn, [['class', 'gen_btn']]);
    inlineStyler(dl_full_btn, `{display:flex; align-items:center; gap:6px; text-align:center; font-size:0.9em; font-weight:800; background:rgba(37,99,235,0.45); color:#ffffff; padding:10px 18px; border-radius:14px; border:1px solid rgba(99,137,255,0.35); cursor:pointer; backdrop-filter:blur(8px); box-shadow:inset 0 1px 0 rgba(255,255,255,0.10); white-space:nowrap;}`);

    dl_full_btn.addEventListener('click', () => {
      let slider_values = Array.from(document.getElementsByClassName('vid_time_display') || []).map(r => getTimeValueFromInputString(r.value));
      let end = Math.max(...slider_values);
      let start = Math.min(...slider_values);
      downloadFullSelection({
        ...params,
        ...{
          is_mp4: is_mp4,
          fragments: fragments,
          parent_elm: download_view_holder,
          start_offset: start,
          end_offset: end ? end : (end+11),
          opt_cont: cont,
          warn: true,
        }
      });
    });
  }

  // ── 슬라이더 빌드 ──
  var available_fragments = fragments
    .map((p, i, rr) => {
      let current_time = rr.slice(0, i + 1).map((r) => r.dur).reduce((a, b) => a + b) - p.dur;
      let seconds = Array(Math.ceil(p.dur)).fill().map((_, i) => current_time + i);
      return { ...p, ...{ current_time, seconds } };
    })
    .map((p, i, rr) => {
      let percent = p.current_time / rr.at(-1).current_time;
      return { ...p, ...{ percent } };
    });

  var video_progress_controls_cont = buildPlayerOptionsContainer({
    parent_elm: slider_container,
    width: "100%",
    height: 120,
    id: "video_progress_controls_cont",
    background: "transparent",
  });

  var video_progress_params = {
    id: "progress",
    parent_elm: video_progress_controls_cont.cont,
    bar_height: 12,
    display_width: 130,
    display_height: 28,
    display_font_size: 16,
    display_key: "current_time",
    available_fragments: available_fragments,
    start_in: params?.start_in || 0,
    end_in: params?.end_in || null,
    balls: [
      { height: 48, width: 38 },
      { height: 48, width: 38 },
    ],
    valueToDisplay: parseTimeOffset,
    displayToValue: getTimeValueFromInputString,
  };

  buildVideoProgressBar(video_progress_params);
}

function trimFragmentListByOffsets(params){
  var { fragments,start_offset,end_offset } = params;
  var current_offset = 0;
  var with_offsets = fragments.map(r => {
    current_offset = (current_offset + r.dur);
    return {
      ...r,
      ...{ offset: (current_offset - r.dur) }
    }
  }).filter(r => {
    const fragEnd = r.offset + r.dur;
    // start: fragment 끝이 start_offset 이후인 것
    // end: fragment 시작이 end_offset 이전인 것 (항상 반올림 — 설정 시간 이후의 fragment까지 포함)
    return fragEnd > start_offset && r.offset < end_offset + r.dur;
  });
  return with_offsets;
}

var funct = {
    awsDateTime:awsDateTime,
    parseTimeOffset:parseTimeOffset,
    friendlyDate:friendlyDate,
}
function buildFilenameFromSettings(params){
    var {filename_options}=params;
    let filename_arr = filename_options.map(r=>{
        return r.separator ? r.separator :
            r.fn ? funct[r.fn](params[r.key])
            : params[r.key]
    });
    return filename_arr?.length ? filename_arr.reduce((a,b)=>a+b) : '';
}




async function downloadFullSelection(params) {
  var { fragments, source, filename, start_in, start_offset, end_offset, opt_cont, is_mp4, init_path } = params;
  inlineStyler(opt_cont, `{display:none;}`);
  var fragments = trimFragmentListByOffsets(params);
  var vod_info = getInfoFromM3u8Link(params);
  let tvd_filetype_setting = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'tvd_filetype_setting'} });
  var file_type = vod_info.resolution == 'audio_only' ? 'wav' : is_mp4 ? 'mp4' : tvd_filetype_setting ? tvd_filetype_setting : 'ts';
  var mime_type = vod_info.resolution == 'audio_only' ? 'audio/wave' : is_mp4 ? 'video/mp4' : 'video/MP2T';
  requestWakeLock();
  var filename_options = await buildFileFormatOptions();
  let selected_resolution = Array.from(tn(document.getElementById('resolutions_opt'), 'option')).filter(ss => ss.selected)?.[0]?.value;
  let file_name_info = {
    channel_login: vod_info?.channel_login,
    start_time: params?.clip_start_time ?? fragments?.[0]?.offset,
    end_time: params?.clip_end_time ?? (fragments?.at(-1)?.offset + fragments?.at(-1)?.dur),
    timestamp: vod_info?.timestamp,
    dateString: vod_info?.timestamp,
    resolution: selected_resolution || vod_info?.resolution,
    filename_options: filename_options?.filter(r => r.include === true),
  };
  let file_name = buildFilenameFromSettings({ ...file_name_info });
  var appended_filename = (params?.filename && params.filename.trim())
    ? `${params.filename}.${file_type}`
    : (file_name ? `${file_name}.${file_type}` : `stream file.${file_type}`);

  const newHandle = await window.showSaveFilePicker({
    types: [{ description: 'mpeg transport stream', accept: { [mime_type]: ['.ts','.mp4','.mkv','.m4v','.wav'] } }],
    startIn: 'downloads',
    suggestedName: appended_filename || '',
  });
  const writableStream = await newHandle.createWritable({mode:"siloed"});
  var bytes = 0;

  // fMP4(.mp4) 형식은 이 init 세그먼트가 파일 맨 앞에 없으면 재생 불가능한 손상된 파일이 됨.
  // 클립이 VOD 맨 처음부터 시작하지 않는 이상(거의 항상 그럼) 데이터 조각만으로는 부족함.
  if (is_mp4 && init_path) {
    try {
      let initUrl = source?.replace(/[^\/]+?m3u8/, init_path);
      let initRes = await requestFromBackground({ cmd: 'getDownloadableArrayBuffer', params: { url: initUrl } });
      let initBuffer = initRes?.transport_data ? new Uint8Array(JSON.parse(initRes?.transport_data).data).buffer : null;
      if (initBuffer?.byteLength) {
        await writableStream.write({ type: "write", data: initBuffer, position: bytes, size: bytes });
        bytes = bytes + initBuffer.byteLength;
      }
    } catch (e) {}
  }

  var { status_bar, options_cont, cont, download_btn, file_size_display, vod_position_display, duration_display, section_downloading_display } = buildDownloadStatusUI(params);
  var end_download = false;
  var error_occured = false;
  var fail_pos = null;
  section_downloading_display.textContent = `Downloading ${parseTimeOffset(fragments?.[0]?.offset)} to ${parseTimeOffset(fragments?.at(-1)?.offset + fragments?.at(-1)?.dur)}`;

  download_btn.addEventListener('click', () => {
    download_btn.remove();
    status_bar.textContent = `Processing download. This could take a minute.`;
    end_download = true;
  });

  var total_duration_saved = 0;
  for (let i = 0; i < fragments?.length; i++) {
    try {
      if (end_download === true) { break; }
      let url = source?.replace(/[^\/]+?m3u8/, fragments[i].path.replace(/unmuted/, "muted"));
      let buffer = await kwsGetFragBuffer(url);
      let res = null;
      if (!buffer && end_download !== true) { error_occured = true; fail_pos = fragments[i].offset; break; }
      let perc_complete = nthFloat((((i+1) / fragments.length) * 100),2,'round');
      status_bar.textContent = `${perc_complete}% complete`;
      inlineStyler(status_bar, `{width: minmax(50%, 400px); background: linear-gradient(90deg, #00237d ${perc_complete-0.5}%, #0234b5 ${perc_complete+1}%, #0234b501 ${perc_complete+1.5}%, #0234b501 100%);}`);
      if (end_download === true) { break; }
      if (buffer?.byteLength) {
        let mb_saved = nthFloat((bytes / 1000000), 2, 'round');
        total_duration_saved = total_duration_saved + fragments[i].dur;
        file_size_display.textContent = `Current File Size: ${mb_saved >= 1000 ? nthFloat((mb_saved/1000),3,'round') : mb_saved}${mb_saved >= 1000 ? 'gb' : 'mb'}`;
        duration_display.textContent = `Current File Duration: ${parseTimeOffset(total_duration_saved)}`;
        vod_position_display.textContent = `Current VOD Position: ${parseTimeOffset(fragments[i].offset)}`;
        download_btn.textContent = `Click to Stop and Download Progress`;
        await writableStream.write({ type:"write", data:buffer, position:bytes, size:bytes });
        if (end_download === true) { break; }
        bytes = bytes + (buffer?.byteLength || 0);
        buffer = null; res = null;
      }
    } catch(err) {
      error_occured = true;
      status_bar.textContent = `Error Occured`;
      download_btn.textContent = `Error Occured - ${parseTimeOffset(total_duration_saved)}`;
      break;
    }
  }

  if (error_occured === false) status_bar.textContent = `Processing download. This could take a minute.`;
  if (error_occured === true) status_bar.textContent = `Error Occured Processing ${parseTimeOffset(total_duration_saved)} of download.`;
  await writableStream.close();
  await delay(1000);

  if (error_occured === false) {
    cont.innerHTML = '';
    cont.style.cssText += 'display:flex;align-items:center;justify-content:center;flex-direction:column;gap:12px;padding:24px;';
    const doneMsg = ele(); doneMsg.textContent = '✅ Download Complete';
    inlineStyler(doneMsg, `{font-size:1em; font-weight:800; color:#86efac;}`);
    cont.appendChild(doneMsg);
    const closeMsg = ele('button'); closeMsg.textContent = 'Close';
    inlineStyler(closeMsg, `{display:flex; align-items:center; justify-content:center; text-align:center; padding:10px 32px; border-radius:12px; background:rgba(220,38,38,0.75); color:#fff; border:1px solid rgba(239,68,68,0.5); cursor:pointer; font-size:0.95em; font-weight:800; box-shadow:inset 0 1px 0 rgba(255,255,255,0.15);}`);
    closeMsg.addEventListener('click', () => cont.closest('.kws-inline-download-pop')?.remove());
    cont.appendChild(closeMsg);
  } else {
    cont.innerHTML = '';
    cont.style.cssText += 'display:flex;align-items:center;justify-content:center;flex-direction:column;gap:12px;padding:24px;';
    const errMsg = ele();
    errMsg.textContent = `⚠️ Incomplete — a segment failed after retries${fail_pos != null ? ' at ' + parseTimeOffset(fail_pos) : ''}. File saved up to ${parseTimeOffset(total_duration_saved)}.`;
    inlineStyler(errMsg, `{font-size:0.95em; font-weight:800; color:#fca5a5; text-align:center;}`);
    cont.appendChild(errMsg);
    const errClose = ele('button'); errClose.textContent = 'Close';
    inlineStyler(errClose, `{display:flex; align-items:center; justify-content:center; padding:10px 32px; border-radius:12px; background:rgba(220,38,38,0.75); color:#fff; border:1px solid rgba(255,255,255,0.25); font-weight:800; cursor:pointer;}`);
    errClose.addEventListener('click', () => cont.closest('.kws-inline-download-pop')?.remove());
    cont.appendChild(errClose);
  }
  releaseWakeLock();
  inlineStyler(opt_cont, `{display:block;}`);
}

async function downloadAsChunkedFiles(params){
  var { fragments, source, filename, start_in, start_offset, end_offset, opt_cont, is_mp4, init_path } = params;
  if(document.getElementById('warning_container')) document.getElementById('warning_container').remove();
  inlineStyler(opt_cont, `{display:none;}`);
  var fragments = trimFragmentListByOffsets(params);
  var vod_info = getInfoFromM3u8Link(params);
  var { status_bar, options_cont, cont, download_btn, file_size_display, vod_position_display, duration_display, section_downloading_display } = buildDownloadStatusUI(params);
  duration_display.remove();
  var end_download = false;
  download_btn.addEventListener('click', () => { download_btn.remove(); status_bar.textContent = `Processing download. This could take a minute.`; end_download = true; });
  var time_position_start = fragments?.[0]?.offset;
  var time_position_end = fragments?.[0]?.offset;
  var frags_downloaded = 0;
  var chunk_failed = false;
  var bytes_saved = 0;
  var initBuffer = null;
  if (is_mp4 && init_path) {
    try {
      let initUrl = source?.replace(/[^\/]+?m3u8/, init_path);
      let initRes = await requestFromBackground({ cmd: 'getDownloadableArrayBuffer', params: { url: initUrl } });
      initBuffer = initRes?.transport_data ? new Uint8Array(JSON.parse(initRes?.transport_data).data).buffer : null;
    } catch (e) {}
  }
  // 각 청크 파일이 독립적으로 재생 가능해야 하니, init 세그먼트가 있으면 매 청크 맨 앞에 넣음
  var file = initBuffer ? [initBuffer] : [];
  section_downloading_display.textContent = `Downloading ${parseTimeOffset(fragments?.[0]?.offset)} to ${parseTimeOffset(fragments?.at(-1)?.offset + fragments?.at(-1)?.dur)}`;
  var filename_options = await buildFileFormatOptions();
  let tvd_filetype_setting = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'tvd_filetype_setting'} });
  let selected_resolution = Array.from(tn(document.getElementById('resolutions_opt'), 'option')).filter(ss => ss.selected)?.[0]?.value;
  let file_name_info = {
    channel_login: vod_info?.channel_login,
    start_time: fragments?.[0]?.offset,
    end_time: fragments?.at(-1)?.offset,
    timestamp: vod_info?.timestamp,
    dateString: vod_info?.timestamp,
    resolution: selected_resolution || vod_info?.resolution,
    filename_options: filename_options?.filter(r => r.include === true),
  };
  for (let i = 0; i < fragments?.length; i++){
    if(end_download === true){ break; }
    try{
      let url = source?.replace(/[^\/]+?m3u8/, fragments[i].path.replace(/unmuted/, "muted"));
      let buffer = await kwsGetFragBuffer(url);
      if (!buffer) { chunk_failed = true; break; }
      bytes_saved = bytes_saved + buffer.byteLength;
      file.push(buffer);
      time_position_end = (fragments[i].offset + fragments[i].dur);
      let perc_complete = nthFloat((((i+1) / fragments.length) * 100),2,'round');
      status_bar.textContent = `${perc_complete}% complete`;
      inlineStyler(status_bar, `{width: minmax(50%, 400px); background: linear-gradient(90deg, #00237d ${perc_complete-0.5}%, #0234b5 ${perc_complete+1}%, #0234b501 ${perc_complete+1.5}%, #0234b501 100%);}`);
      let mb_saved = nthFloat((bytes_saved / 1000000), 2, 'round');
      file_size_display.textContent = `Current File Size: ${mb_saved >= 1000 ? nthFloat((mb_saved/1000),3,'round') : mb_saved}${mb_saved >= 1000 ? 'gb' : 'mb'}`;
      vod_position_display.textContent = `Current VOD Position: ${parseTimeOffset(fragments[i].offset)}`;
      download_btn.textContent = `Click to Stop and Download Progress`;
      if(bytes_saved >= 1000000000){
        let blob_dl = new Blob(file, {type: is_mp4 ? 'video/mp4' : 'video/MP2T'});
        let link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob_dl);
        let f = buildFilenameFromSettings({ ...file_name_info, start_time: time_position_start, end_time: (fragments[i].offset + fragments[i].dur) });
        link.download = `${f}.${is_mp4 ? 'mp4' : tvd_filetype_setting || 'ts'}`;
        link.click();
        await delay(1111);
        time_position_start = (fragments[i].offset + fragments[i].dur);
        bytes_saved = 0; file = initBuffer ? [initBuffer] : []; frags_downloaded = i;
      }
    }catch(err){}
  }
  if(file.length){
    let blob_dl = new Blob(file, {type: is_mp4 ? 'video/mp4' : 'video/MP2T'});
    let link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob_dl);
    let f = buildFilenameFromSettings({ ...file_name_info, start_time: time_position_start, end_time: time_position_end });
    link.download = `${f}.${is_mp4 ? 'mp4' : tvd_filetype_setting || 'ts'}`;
    link.click();
  }
  status_bar.textContent = chunk_failed ? `⚠️ Incomplete — a segment failed after retries (saved up to ${parseTimeOffset(time_position_end)})` : `Download complete`;
}

function kwsOpenClipDownloaderLegacy(params) {
  const popId = 'kws_inline_download_pop_' + Date.now();
  const pop = ele('div');
  a(pop, [['id', popId], ['class','kws-inline-download-pop']]);
  document.body.appendChild(pop);
  const head = ele('div'); head.className = 'kws-inline-download-head'; pop.appendChild(head);
  const title = ele('div'); title.className = 'kws-inline-download-title'; title.textContent = 'Clip Downloader'; head.appendChild(title);
  const close = ele('button'); close.type = 'button'; close.className = 'kws-inline-download-close'; close.textContent = '×'; head.appendChild(close);
  close.addEventListener('click', () => pop.remove());
  const optCont = ele('div'); optCont.style.display = 'none'; pop.appendChild(optCont);
  const holder = ele('div'); a(holder, [['id','download_view_holder']]); pop.appendChild(holder);
  const hiddenSel = ele('select'); a(hiddenSel, [['id','resolutions_opt']]); hiddenSel.style.display = 'none';
  const hiddenOpt = ele('option'); a(hiddenOpt, [['value', params?.resolution_name || 'chunked'], ['selected','']]); hiddenSel.appendChild(hiddenOpt);
  pop.appendChild(hiddenSel);

  // 드래그 지원
  (function makeDraggable() {
    let dragging = false, startX = 0, startY = 0, startLeft = 0, startTop = 0;
    const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
    head.addEventListener('mousedown', e => {
      if (e.target.closest && e.target.closest('button,select,input')) return;
      e.preventDefault();
      const rect = pop.getBoundingClientRect();
      dragging = true;
      startX = e.clientX; startY = e.clientY;
      startLeft = rect.left; startTop = rect.top;
      pop.style.left = rect.left + 'px'; pop.style.top = rect.top + 'px';
      pop.style.right = 'auto'; pop.style.bottom = 'auto';
      pop.style.transform = 'none'; pop.style.position = 'fixed';
      pop.style.zIndex = topZIndexer();
      document.body.style.userSelect = 'none';
    });
    window.addEventListener('mousemove', e => {
      if (!dragging) return;
      const rect = pop.getBoundingClientRect();
      pop.style.left = clamp(startLeft + (e.clientX - startX), 8, window.innerWidth - rect.width - 8) + 'px';
      pop.style.top = clamp(startTop + (e.clientY - startY), 8, window.innerHeight - Math.min(rect.height, window.innerHeight - 16) - 8) + 'px';
    });
    window.addEventListener('mouseup', () => { dragging = false; document.body.style.userSelect = ''; });
    // 클릭 시 최상위로
    pop.addEventListener('mousedown', () => { pop.style.zIndex = topZIndexer(); });
  })();

  (async () => {
    let { fragments, source, is_mp4, init_path, start_in, end_in } = params;
    if (!fragments?.length) {
      const playlist = await requestFromBackground({ cmd: 'getTwitchOrKickManifest', params: { source } });
      fragments = playlist?.data?.fragments;
      is_mp4 = playlist?.is_mp4 || playlist?.data?.is_mp4;
      init_path = playlist?.data?.init_path;
    }
    if (!fragments?.length) {
      holder.textContent = 'Failed to load VOD data.';
      holder.style.cssText += 'color:#f87171;padding:16px;font-size:12px;';
      return;
    }
    downloadFullSelection({
      ...params, fragments, is_mp4, init_path,
      parent_elm: holder,
      start_offset: start_in || 0,
      end_offset: end_in || fragments.reduce((a, f) => a + f.dur, 0),
      clip_start_time: start_in || 0,
      clip_end_time: end_in || fragments.reduce((a, f) => a + f.dur, 0),
      opt_cont: optCont,
      warn: true,
    });
  })();
}
