
function buildContainer(params){
    var {
        top,
        left,
        container_id,
        application_label,
        close_action,
        open_action,
        ref_elm,
        header_height,
        left_panel_width,
        right_panel_width,
        footer_height,
        shift_col_px,
        close_btn_px,
        parent_elm,
        force_top,
        force_left,
        border_radius,
        moveable_head,
        movable_left,
        movable_right,
        movable_footer,
        resizeable,
        background,
        inner_radius,
    } = params;
    // if(open_action) open_action();
    let ref_rect = ref_elm?.getBoundingClientRect();
    var cont_top = force_top || ref_rect?.top || top || 50;
    var cont_left = force_left || ref_rect?.left || left || 50;

    if(gi(document,container_id)) gi(document,container_id).outerHTML = '';
    const cont = ele('div');
    a(cont,[['id',container_id],['class','build_container']]);
    let shadow = 'box-shadow: rgba(0, 0, 0, 0.07) 0px 1px 2px, rgba(0, 0, 0, 0.07) 0px 2px 4px, rgba(0, 0, 0, 0.07) 0px 4px 8px, rgba(0, 0, 0, 0.07) 0px 8px 16px, rgba(0, 0, 0, 0.07) 0px 16px 32px, rgba(0, 0, 0, 0.07) 0px 32px 64px;';
    inlineStyler(cont,`{display: grid; grid-template-columns: ${(left_panel_width || 32)}px 1fr ${(right_panel_width || 32)}px; ${shadow} text-align: left; border-radius: ${border_radius ? border_radius :'0px'}; position: fixed; z-index: ${topZIndexer()}; top: ${cont_top}px; left: ${cont_left}px;}`);
    appender({...params,...{cont:cont}});
    //  background:${background || main_background_gradient() || main_app_colors()?.bg || '#1c1c1c'}
    //  color: ${main_app_colors()?.text || '#ffffff'};
    addStoredBGclass(cont);
    cont.addEventListener('click', this.topIndexHover);
    cont.addEventListener('mousedown', () => { cont.style.zIndex = topZIndexer(); });

    let left_side = ele('div');
    cont.appendChild(left_side);
    inlineStyler(left_side, `{height:100%; display:grid; grid-template-rows: ${(header_height || 32)}px 1fr ${(footer_height || 32)}px; }`);

        let cls_btn = document.createElement('div');
        cls_btn.innerHTML = svgs()?.close?.replace(/(?<=width\:\s+)\d+/,(close_btn_px||shift_col_px))?.replace(/(?<=height\:\s+)\d+/,(close_btn_px||shift_col_px));
        a(cls_btn,[['id',`${container_id}_close`],['class','hover_btn overflow-clip'],['data-container_id',container_id]]);
        left_side.appendChild(cls_btn);
        inlineStyler(cls_btn, `{background-color:${main_app_colors()?.icon_color}; transform:translate(2px,2px); cursor: pointer; width: ${((close_btn_px||shift_col_px) || 32)}px; height: ${((close_btn_px||shift_col_px) || 32)}px;}`);
        cls_btn.style.display = 'none';

        let left_dragger = ele('div');
        a(left_dragger,[['class','drag_actor_left drag_actor']]);
        inlineStyler(left_dragger,`{min-height:10px; ${movable_left ? 'cursor: move;' : ''}}`);
        left_side.appendChild(left_dragger);
        if(movable_left) left_dragger.onmouseover = dragElement;

    let middle_cont = ele('div');
    cont.appendChild(middle_cont);
    a(middle_cont,[['class','middle_cont']]);

        let header = ele('div');
        middle_cont.appendChild(header);
        a(header,[['class','drag_actor_head drag_actor']]);
        inlineStyler(header, `{height: ${(header_height || 32)}px; user-select: none;${moveable_head ? 'cursor: move;' : ''}}`);
        if(moveable_head) header.onmouseover = dragElement;
            let head_mover = document.createElement('div');
            inlineStyler(head_mover, `{text-align: left; user-select: none;}`);
            header.appendChild(head_mover);

                let top_label = ele('div');
                a(top_label,[['id',`${container_id}_top_label`]]);
                inlineStyler(top_label,`{text-align: left;}`);
                head_mover.appendChild(top_label);
                top_label.innerHTML = application_label ? application_label : '';

        let menu_body = ele('div');
        middle_cont.appendChild(menu_body);
        a(menu_body,[['class','menu_body'],['id',`${container_id}_menu_body`]]);
        inlineStyler(menu_body, `{border-radius: ${inner_radius ? inner_radius : '0px'}; overflow: auto; min-height:10px; max-height:${document.body.getBoundingClientRect().height - (header_height+footer_height)}px;}`);
        //

        let footer = ele();
        middle_cont.appendChild(footer);
        a(footer,[['id',`${container_id}_footer`]]);
        inlineStyler(footer,`{height:${footer_height}px; user-select: none; ${movable_footer ? 'cursor: move;' : ''}}`);
        if(movable_footer) footer.onmouseover = dragElement;


    let right_side = ele('div');
    cont.appendChild(right_side);
    // a(right_side,[['class','drag_actor_right']]);
    inlineStyler(right_side, `{height:100%; display:grid; grid-template-rows: ${(header_height || 32)}px 1fr ${(footer_height || 32)}px; }`);

        let right_top_btn = document.createElement('div');
        right_side.appendChild(right_top_btn);
        // inlineStyler(cls_btn, `{cursor: pointer; width: ${(right_panel_width || 32)}px; height: ${(right_panel_width || 32)}px;}`);

        let right_dragger = ele('div');
        a(right_dragger,[['class','drag_actor_right drag_actor']]);
        inlineStyler(right_dragger,`{min-height:10px; user-select: none; ${movable_right ? 'cursor: move;' : ''}}`);
        right_side.appendChild(right_dragger);
        if(movable_right) right_dragger.onmouseover = dragElement;

        let foot_resizer = ele('div');
        a(foot_resizer,[['data-resize-id',`${container_id},${container_id}_menu_body`],['data-parent_dimensions',btoaJSON({header_height:header_height,left_panel_width:left_panel_width,right_panel_width:right_panel_width,footer_height:footer_height,shift_col_px:shift_col_px,close_btn_px:close_btn_px})],['id',`${container_id}_foot_resizer`]]);
        inlineStyler(foot_resizer,`{${resizeable ? 'cursor:nw-resize;' : ''}}`);
        right_side.appendChild(foot_resizer);
        if(resizeable){
            foot_resizer.innerHTML = svgs()?.resize?.replace(/(?<=width\:\s+)\d+/,right_panel_width)?.replace(/(?<=height\:\s+)\d+/,footer_height);
            foot_resizer.onmouseover = adjustElementSize;
        }


    if(close_action) cls_btn.addEventListener('click',close_action);
    else cls_btn.addEventListener('click',()=>{
      cont.remove();
      if(cont.id === 'tvd_video_viewer') {
        document.getElementById('kws_clip_downloader')?.remove();
        if(typeof updateRangeOverlay === 'function') updateRangeOverlay(null, null);
      }
    });
    Array.from(cont.querySelectorAll('div, a')).forEach(elm=> inlineStyler(elm,`{font-family: 'Open Sans', sans-serif; font-size:12px;}`) );

    let output = {
        cont:cont,
        cls_btn:cls_btn,
        head_mover:head_mover,
        middle_cont:middle_cont,
        menu_body:menu_body,
        top_label:top_label,
        left_dragger:left_dragger,
        foot_resizer:foot_resizer,
        right_side:right_side,
        footer:footer,
    }
    return output;
} /*buildContainer*/





function buildSearchResAutoDropdown(params){
    var {id,results,ref_elm,input_ref}=params;
    var rect = ref_elm.getBoundingClientRect();
    if(gi(document,id)) gi(document,id).remove();
    var dropdown_cont = buildContainer({
        top:rect.top+rect.height,
        left:rect?.left-4,
        container_id:id,
        background:main_app_colors()?.bg,
        // application_label:``,
        border_radius:'0.2em',
        header_height:10,
        left_panel_width:10,
        right_panel_width:10,
        footer_height:10,
        shift_col_px:10,
        parent_elm:document.body,
        moveable_head:true,
        movable_left:true,
        movable_right:true,
        movable_footer:true,
    });
    inlineStyler(dropdown_cont.menu_body,`{display:grid; grid-template-rows:auto; grid-gap:6px; width:${30+130+42+20}px;}`);
    addBuffer({parent_elm:dropdown_cont.menu_body,height:1});
    results?.forEach(r=> {
        let cont = ele();
        a(cont,[['class','gen_btn']]);
        dropdown_cont.menu_body.appendChild(cont);
        inlineStyler(cont,`{${gridCol(['30px','130px','42px'],1)} cursor:pointer; margin:auto; border-radius:0.2em;}`);
        let avatar = ele(r?.profile_image_url ? 'img' : 'div');
        let channel = ele();
        let partner = ele();
        let status = ele();

        cont.appendChild(avatar);
        cont.appendChild(channel);
        // cont.appendChild(partner);
        cont.appendChild(status);

        if(r?.profile_image_url){
            a(avatar,[['src',r.profile_image_url],['style','transform:translate(6px,0px); height:28px; width:28px; border-radius:50%;']]);
        }
        inlineStyler(channel,`{margin:auto; font-size:12px;}`);
        inlineStyler(status,`{margin:auto;}`);
        // inlineStyler(partner,`{margin:auto;}`);
        // if(r?.is_partner){
        //     partner.innerHTML = svgs()?.partner;
        // }
        if(r.is_live) {
            a(status,[['class','is_live_search_result'],['data-channel_login',r?.channel_login]]);
            inlineStyler(status,`{transform:translateX(-4px); border:2px solid #eb0400; margin:auto; border-radius:0.2em; background:#eb0400; color:#ffffff; font-size:12px;}`);
            status.textContent = 'LIVE';
        }
        channel.textContent = r.channel_login || '';
        cont.addEventListener('click',()=>{
            input_ref.value = r.channel_login;
            let view_live_btn_cont = document.getElementById('view_live_btn_cont');
            if(view_live_btn_cont){
                let page_channel_login = r?.channel_login;
                if(page_channel_login){
                    var view_live_btn = ele();
                    view_live_btn_cont.appendChild(view_live_btn);
                    addViewLiveBtn({parent_elm:view_live_btn_cont,elm:view_live_btn,query:page_channel_login});
                    view_live_btn.addEventListener('click',()=>{
                      runTwitchLiveView({ channel_login: page_channel_login, ref_elm: view_live_btn });
                    })
                }
            }
            dropdown_cont.cont.remove();
        })
    });
    addBuffer({parent_elm:dropdown_cont.menu_body,height:1});
}



async function addViewLiveBtn(params){
    var {parent_elm,elm,query} =params
    var current_page_channel_login_search_res = await searchTwitch({query:query});
    var current_page_channel_login = current_page_channel_login_search_res?.filter(r=> r.channel_login == query)?.[0];
    // console.log('current_page_channel_login',current_page_channel_login);
    if(current_page_channel_login?.is_live){
        if(document.getElementById('view_live_streamer_btn')){document.getElementById('view_live_streamer_btn').remove()}
        let img_url = current_page_channel_login?.profile_image_url;
        a(elm,[['class','gen_btn'],['id','view_live_streamer_btn'],['data-channel_login',current_page_channel_login?.channel_login]]);
        let grid = gridCol(['30px','140px','42px']);
        // console.log(grid);
        inlineStyler(elm,`{${grid} pointer:cursor; border-radius:2em; padding:4px; text-align:center; margin:auto; cursor:pointer; width:90%;}`);
        elm.innerHTML = `<${img_url ? 'img src="'+img_url+'" style="transform:translateX(2px); height:28px; width:28px; border-radius:50%;"' : 'div'}$></${img_url ? 'img' : 'div'}><div data-channel_login="${query}" style="margin:auto; font-size:12px;">Watch ${query||''}</div><div style="transform:translateX(-4px); border:2px solid #eb0400; margin:auto; border-radius:0.2em; background:#eb0400; color:#ffffff; font-size:12px;">LIVE</div>`;
        // return elm.getElementsByClassName
    }else{
        elm.remove();
    }
}
function addViewVodBtn(params){
  var {parent_elm,animated_preview_url,kick_src,channel_login,vod_id,preview_url} =params
  if(document.getElementById('view_vod_id_vod_btn')){document.getElementById('view_vod_id_vod_btn').remove()}
  let elm = ele();
  parent_elm.appendChild(elm);
  a(elm,[['class','gen_btn'],['id','view_vod_id_vod_btn'],['data-channel_login',channel_login]]);
  inlineStyler(elm,`{height:36px; pointer:cursor; border-radius:2em; text-align:center; margin:auto; cursor:pointer; width:90%; display: flex; justify-content: center; align-items: center;margin:auto; font-size:12px;}`);
  // let img_info = preview_url ? `<div style="border-radius:1em; overflow:clip; max-height:36px;"><img class="preview_img" src="${preview_url}"></img></div>` : kick_src ? `<div style="overflow:clip; max-height:40px;"><img src="${kick_src}"></img></div>` : svgs()?.hidden;
      // ${img_info ? img_info : ''};
  return elm;
}


function addViewVODBtnToLayoutBar(params){
    let bar = document.getElementsByClassName('metadata-layout__support')?.[0];
    let btns_cont = bar?.firstChild?.nextSibling;
    if(btns_cont && btns_cont?.firstChild){
      if(document.getElementById('view_vod_no_ad_btn')) {document.getElementById('view_vod_no_ad_btn').remove()}
      let vod_btn_cont = ele();
      btns_cont.insertBefore(vod_btn_cont,btns_cont?.firstChild);
      a(vod_btn_cont,[['class','gen_btn'],['id','view_vod_no_ad_btn']]);
      inlineStyler(vod_btn_cont,`{height:36px; pointer:cursor; border-radius:2em; text-align:center; margin:auto; cursor:pointer; width:90%; display: flex; justify-content: center; align-items: center; cursor:pointer; width:fit-content; }`);
      vod_btn_cont.innerHTML = `<div style="padding:8px; width:fit-content; margin:auto; font-size:12px;">Watch VOD Without Ads</div>`;
      return vod_btn_cont;
    }

}

async function subOnlyBypass(){
    await delay(1444);
    var overlays = Array.from(document.getElementsByClassName('content-overlay-gate__allow-pointers'));
    let is_sub_only = overlays.some(elm=> /This video is only available to subscribers/i.test(elm.textContent));
    let sub_btn = overlays.filter(elm=> !/This video is only available to subscribers/i.test(elm.textContent))?.[0];
    if(is_sub_only){
        // console.log(sub_btn)
        if(sub_btn){
          if(document.getElementById('view_vod_no_ad_btn_2')){ document.getElementById('view_vod_no_ad_btn_2').remove(); }
          let vod_btn_cont = ele();
          sub_btn.insertBefore(vod_btn_cont,sub_btn?.firstChild);
          a(vod_btn_cont,[['class','gen_btn'],['id','view_vod_no_ad_btn_2']]);
          inlineStyler(vod_btn_cont,`{height:36px; pointer:cursor; border-radius:2em; text-align:center; margin:auto; cursor:pointer; width:90%; display: flex; justify-content: center; align-items: center; cursor:pointer; width:fit-content; }`);
          vod_btn_cont.innerHTML = `<div style="padding:8px; width:fit-content; margin:auto; font-size:12px;">Watch VOD Without Ads</div>`;
          if(sub_btn?.firstChild?.nextSibling){sub_btn.firstChild.nextSibling.remove();}
          return vod_btn_cont;
        }
    }
    else{
      return null;
    }
}


function addAvailableStreamRecorderInfo(params) {
  var { parent_elm, recordings } = params;
  if(recordings?.length && parent_elm){
    let cont = ele();
    parent_elm.appendChild(cont);
    inlineStyler((cont), `{display:grid; grid-gap:12px; border-radius: 0.8em; border-radius:2em; cursor:pointer; margin:auto; width:96%;}`);
    recordings?.forEach(r=> {
      let card = ele();
      a(card, [['class', 'gen_btn']]);
      inlineStyler(card, `{padding: 12px; border-radius: 0.8em; display:grid; grid-template-columns:200px 1fr;}`);
      cont.appendChild(card);
      card.addEventListener('click', () => {
        window.open('https://streamrecorder.io/?r=1YTHIQ');
      });
      let img_cont = ele();
      card.appendChild(img_cont);
      // inlineStyler(img_cont, ``);
      a(img_cont, [['style', `position: relative; width: 192px; height: 107.625px; background-image: url('${r?.media?.thumb_small_192}'); background-size: 200% 200%; animation: cycle-frames 5s steps(1) infinite;`]]);

      let dur = ele();
      img_cont.appendChild(dur);
      inlineStyler(dur, `{background:#000000; padding:4px; border-radius:0.2em; color:#ffffff; width:fit-content; position: absolute; bottom: 0; left: 0;}`);
      dur.textContent = r?.duration ? parseTimeOffset(r?.duration) : '';

      let info_cont = ele()
      inlineStyler(info_cont, `{margin:auto;}`);
      card.appendChild(info_cont);

      let streamtitle = ele();
      info_cont.appendChild(streamtitle);
      inlineStyler(streamtitle, `{font-size: 1.3em;}`);
      streamtitle.textContent = r?.streamtitle || '';

      let recorded_at = ele();
      info_cont.appendChild(recorded_at);
      recorded_at.textContent = r?.recorded_at || '';
    })

  }

}
function addStreamRecorderBtn(params){
  var { parent_elm, ref_elm, actor,text } = params;
  let cont = ele();
  // a(cont, [['class', 'gen_btn']]);
  parent_elm.appendChild(cont);
  inlineStyler((cont), `{border-radius:2em; cursor:pointer; margin:auto; width:96%;}`);
    let display = ele();
    cont.appendChild(display);
    inlineStyler((display), `{margin: auto; width: fit-content;}`);
    display.textContent = text || 'This VOD is not on the Twitch server. Try Streamrecorder.';

    addBuffer({ parent_elm: cont, height: 24 });

    let btn = ele();
    cont.appendChild(btn);
    a(btn, [['class', 'gen_btn']]);
    inlineStyler((btn), `{border-radius: 0.8em; padding:20px;}`);

  btn.innerHTML = `<div style="margin:auto; width:fit-content;">${svgs().streamrecorder}</div>`;
  cont.addEventListener('click',()=>{
    window.open('https://streamrecorder.io/?r=1YTHIQ');
  })
  return cont;

}

function addAuthBtn(params) {
  var { parent_elm, elm, text, cmd } = params;
  if (elm) {
    const clone = elm.cloneNode(false); // Clone without children or listeners
    elm.parentNode.replaceChild(clone, elm);
    elm = clone; // Use the new element
  } else {
    // Create new element
    elm = ele();
    if (parent_elm) {
      parent_elm.appendChild(elm);
    }
  }
  // Set up the button
  a(elm, [['class', 'gen_btn']]);
  inlineStyler(elm, `{border-radius:2em; display:flex; flex-wrap:wrap; cursor:pointer; margin:auto; width:96%;}`);

  let display = ele();
  elm.appendChild(display);
  inlineStyler(display, `{margin: auto; text-align:center;}`);
  display.textContent = text;

  let btn = ele();
  elm.appendChild(btn);
  inlineStyler(btn, `{margin-right:10px;}`);
  btn.innerHTML = `${svgs()?.profile}`;
  elm.addEventListener('click', async () => {
    if (elm.classList.contains('disabled')) return;
    // console.log('runRecentStreamsExtractor(params)', params);
    elm.style.cursor = 'wait';
    elm.classList.add('disabled');
    addLoader({...{ left: (elm.getBoundingClientRect()?.left - 20), top: elm.getBoundingClientRect()?.top },...{ text: "Authenticating" },});

    let t = await requestFromBackground({ cmd: cmd });
    stopLoader();
    elm.classList.remove('disabled');
    elm.style.cursor = 'pointer';
    if (t) {
      let is_login = /Login/i.test(text);
      addAuthBtn({
        elm: elm,
        text: is_login ? 'Logout' : 'Login/Sign Up for Best Experience',
        cmd: is_login ? 'handleLogout' : 'launchAuthFlow'
      });
    }
  });

  return elm;
}


function addDiscordBtn(params){
  var { parent_elm, ref_elm, actor } = params;
  let cont = ele();
  a(cont, [['class', 'gen_btn open_settings']]);
  parent_elm.appendChild(cont);
  inlineStyler((cont), `{border-radius:2em; display:flex; flex-wrap:wrap; cursor:pointer; margin:auto; width:96%;}`);
    let display = ele();
    cont.appendChild(display);
    inlineStyler((display), `{margin: auto; text-align:center;}`);
    display.textContent = 'Join Our Discord';

    let btn = ele();
    cont.appendChild(btn);
    inlineStyler((btn), `{margin-right:10px;}`);
  btn.innerHTML = `${svgs()?.discord}`;
  cont.addEventListener('click',()=>{
    window.open('https://discord.gg/sSJsqjKyYg');
  })
  return cont;
}

function addSettingsBtn(params){
  var { parent_elm} = params;
  let cont = ele();
  a(cont, [['class', 'gen_btn open_settings']]);
  parent_elm.appendChild(cont);
  inlineStyler((cont), `{border-radius:2em; display:flex; flex-wrap:wrap; cursor:pointer; margin:auto; width:96%;}`);
    let display = ele();
    cont.appendChild(display);
    inlineStyler((display), `{margin: auto; text-align:center;}`);
    display.textContent = 'Open Settings Menu';

    let btn = ele();
    cont.appendChild(btn);
    inlineStyler((btn), `{margin-right:10px;}`);
  btn.innerHTML = `${svgs()?.settings}`;
  return cont;
}
function addDonationBtn(params){
  var { parent_elm} = params;
  let cont = ele();
  a(cont, [['class', 'gen_btn']]);
  parent_elm.appendChild(cont);
  inlineStyler((cont), `{border-radius:2em; display:flex; flex-wrap:wrap; cursor:pointer; margin:auto; width:96%;}`);
    let display = ele();
    cont.appendChild(display);
    inlineStyler((display), `{margin: auto; text-align:center;}`);
    display.textContent = 'Help Cover Server Costs';

    let btn = ele();
    cont.appendChild(btn);
    inlineStyler((btn), `{margin-right:10px;}`);
  btn.innerHTML = `${svgs()?.dono}`;
  cont.addEventListener('click',()=>{
    window.open(`https://paypal.me/quickliio`);
  })
}


function addVersionNumber(params){
  var { parent_elm} = params;
  let cont = ele();
  // color:${main_app_colors()?.text};
  inlineStyler(cont, `{width:fit-content; display:flex; flex-wrap:wrap; gap:4px; cursor:pointer; font-size:8px; text-align:right; }`);
  parent_elm.appendChild(cont);
    let display = ele();
    inlineStyler((display), `{margin-left:10px;}`);
    cont.appendChild(display);
    display.textContent = `v${ext_version_number}`;

    // Changelog / contact / external info entry removed from the main UI.
}



function addDownloadStoryBtn() {
  if (/twitch.tv\/\w+\/stories\/\w+/.test(window.location.href)) {
    if(document.getElementById('download_story_btn')){document.getElementById('download_story_btn').remove()}
    let play_btn = document.querySelector('[aria-label*="(space/k)"]');
    let bar = play_btn?.parentElement?.parentElement?.parentElement;
    let dl_btn = ele();
    a(dl_btn, [['id','download_story_btn'],['class', 'control_btn']]);
    dl_btn.innerHTML = svgs()?.dl_svg?.replace(/<svg/,`<svg style="transform:translate(0px,2px);"`);
    if (bar) { bar.insertBefore(dl_btn, play_btn?.parentElement?.parentElement); }
    let url = document.getElementById('stories-video-player')?.src?.trim();
    dl_btn.addEventListener('click', () => {
      window.open(url);
    });
  }
}


async function buildFilenameFormatMenu(params){
  var { parent_elm } = params;
  let rect = parent_elm.getBoundingClientRect();
  let format_menu = buildContainer({
    ...uiSettings(),
    ...{
      top: rect.top,
      left: 50,
      container_id: "tvd_filename_format_cont",
      resizeable: false,
      background:main_app_colors()?.bg,
    },
  });
  // inlineStyler(format_menu?.menu_body,`{background-color:${main_app_colors()?.menu_bg}; color:${main_app_colors()?.text};}`,);

  fileSaveFormat({ parent_elm: format_menu.menu_body,cont_id:'tvd_filename_format_cont' });

}


async function buildFileFormatOptions(){
  let default_options = [
    {
      display: 'Start Time',
      example: '01h12m10s',
      key: 'start_time',
      fn:'parseTimeOffset',
      // position:0,
      include: true,
    },
    {
      key: 'spacer',
      // position:1,
      include: true,
      separator: '-',
    },
    {
      display: 'End Time',
      example: '03h12m10s',
      key: 'end_time',
      fn:'parseTimeOffset',
      // position:2,
      include: true,
    },
    {
      key: 'spacer',
      // position:3,
      include: true,
      separator: '-',
    },
    {
      display: 'Channel Name',
      example: 'streamername',
      key: 'channel_login',
      // position:4,
      include: true,
    },
    {
      key: 'spacer',
      // position:5,
      include: true,
      separator: '-',
    },
    {
      display: 'VOD Date Time',
      example: awsDateTime(new Date().getTime() - 86400000),
      key: 'dateString',
      fn:'awsDateTime',
      // position:6,
      include: false,
    },
    {
      display: 'VOD Date',
      example: friendlyDate(new Date().getTime() - 86400000),
      key: 'timestamp',
      fn:'friendlyDate',
      include: true,
    },
    {
      key: 'spacer',
      // position:5,
      include: true,
      separator: '-',
    },
    {
      display: 'Video Resolution',
      example: '720p',
      key: 'resolution',
      // position:8,
      include: true,
    },
  ];
  let saved_file = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'tvd_file_format_setting' } });
  let saved_file_options = [];
  if (saved_file) {
    try {
      saved_file_options = typeof saved_file === 'string' ? JSON.parse(saved_file) : saved_file;
      if (!Array.isArray(saved_file_options)) saved_file_options = [];
    } catch { saved_file_options = []; }
  }
  let not_in_saved = default_options?.filter(d => !saved_file_options.some(sf => sf.key == d.key));
  return saved_file_options?.length ? [...not_in_saved.map(d => ({ ...d, ...{ include: false } })), ...[{key: 'spacer',include: false,separator: '-'}], ...saved_file_options] : not_in_saved;
}

async function fileSaveFormat(params) {
  var { parent_elm } = params;

  let options = await buildFileFormatOptions();
  // console.log({options})
  let id = 'filename_format_container';
  if(document.getElementById(id)){document.getElementById(id).remove()}

  let cont = ele()
  a(cont, [['id', id]]);
  inlineStyler(cont, `{padding:18px;}`);
  parent_elm.appendChild(cont);
  let small_add_btn = svgs()?.add?.replace(/(?<=height\=\").+?(?=\")/, '14px')?.replace(/(?<=width=").+?(?=")/, '14px')?.replace(/<svg/,`<svg style="cursor:pointer;"`);
  cont.innerHTML = `<div style="font-size:1.4em;">File Name Format Options</div>
    <div style="height:20px;"></div>

    <div style="display:flex;"><div>Select File Format. </div><div style="displau:flex; align-items:center; font-size:0.6em;">(mp4 is not possible at this time)</div></div>
    <select id="tvd_select_file_type">
    </select>
    <div style="height:18px;"></div>
    <div style="display:flex;">
      <div>Click </div>${small_add_btn || ''}<div> to Add to File Name Format</div>
    </div>
    <div style="height:8px;"></div>`;

  let file_type_cont = document.getElementById('tvd_select_file_type');

  let options_list = ele();
  a(options_list, [['id', 'filename_format_list']]);
  inlineStyler(options_list, `{display:flex; flex-wrap:wrap; gap:6px;}`);
  cont.appendChild(options_list);
  options.filter(r => r.include === false)?.forEach(r => {
    addFileNameOption({ parent_elm: options_list, option: r });
  });

  addBuffer({ parent_elm: cont, height: 20 });

  let info_cont = ele();
  cont.appendChild(info_cont);
  // inlineStyler(info_cont, `{padding:12px;}`);//display:flex; flex-wrap:wrap;

    let info = ele();
    info_cont.appendChild(info);
    let small_del_btn = svgs()?.del?.replace(/(?<=height\=\").+?(?=\")/, '12px')?.replace(/(?<=width=").+?(?=")/, '12px')?.replace(/<svg/,`<svg style="cursor:pointer;"`);
    info.innerHTML = `<div style="display:flex; gap:2px;">

        <div>Drag options to desired file name structure. Click </div><div>${small_del_btn}</div><div>to remove.</div>
    </div>
    <div style="height:8px;"></div>`;

  let options_cont = ele();
  a(options_cont, [['id', 'filename_format_options']]);
  inlineStyler(options_cont, `{display:flex; flex-wrap:wrap; gap:6px;}`)
  cont.appendChild(options_cont);

  options.filter(r => r.include === true)?.forEach(r => {
    addFileNameOption({ parent_elm: options_cont, option: r });
  });

  addBuffer({ parent_elm: cont, height: 12 });
  let example_cont = ele();
  cont.appendChild(example_cont);
  inlineStyler(example_cont, `{display:flex; flex-wrap:wrap; color:${main_app_colors()?.edge};}`);

  let example_display = ele();
  a(example_display, [['class', 'example_display']]);
  inlineStyler(example_display, `{font-size:1.4em;}`);
  example_cont.appendChild(example_display)
  file_type_cont.addEventListener('change', () => {
    setExampleFilenameDisplay();
  });
  let tvd_filetype_setting = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'tvd_filetype_setting'} });
  let filetypes = unqHsh([tvd_filetype_setting, 'm4v', 'mkv', 'ts'], {}).filter(r => r);
  // console.log({filetypes})
  filetypes.forEach(t => {
    let type = ele('option');
    a(type, [['value', t]]);
    file_type_cont.appendChild(type);
    type.textContent = t;
  });
  // Array.from(document.getElementById('tvd_select_file_type').getElementsByTagName('option')).filter(r=> r.selected)?.[0]?.value
  await setExampleFilenameDisplay();
  keepContInBoundary({cont:document.getElementById(params?.cont_id)});
  // example_display.textContent = example;
}

async function addFileNameOption(params){
  var { parent_elm, option, added} = params;
  var insert_before = findFirstElmSeparatorInsertOpportinity(params);
  let btn_cont = ele();
  if(added === true && option?.separator && insert_before){
    parent_elm.insertBefore(btn_cont, insert_before);
  }else{
    parent_elm.appendChild(btn_cont);
  }
  a(btn_cont, [['class', `move_btn dragged_item${option?.separator ? ' filename_separator': ''}`],['data-file_format_option',btoaJSON(option)]]);
  inlineStyler(btn_cont, `{display:flex; flex-wrap:wrap; gap:2px; border-radius:0.4em;}`);

  let onoff = ele();
  if(option?.include === false){btn_cont.appendChild(onoff);}
  a(onoff, [['data-state', (option?.include === true ? 'on' : 'off')],['class','onoff_item']]);
  inlineStyler(onoff, `{display:flex; align-items:center;}`);
  onoff.innerHTML = (option?.include === true ? svgs()?.del : svgs()?.add) || '';
  if(option?.include === true){ inlineStyler(onoff, `{transform:translate(5px,5px);}`);}

  let mover_elm = ele();
  a(mover_elm, [['class', 'draggable_option_item']]);
  inlineStyler(mover_elm, `{user-select: none; ${(option?.include === true) ? 'cursor: ew-resize;' : ''} width:fit-content; display:flex; flex-wrap:wrap; gap:0px; padding:2px;}`)
  btn_cont.appendChild(mover_elm);
  if(option?.include === true){mover_elm.onmouseenter = initMoveHandler;}

    if(option?.separator){
      let input = ele('input');
      a(input, [['class', 'option_itm filename_spacer textarea']]);
      inlineStyler(input, `{width:20px; padding:4px;}`);
      mover_elm.appendChild(input);
      input.value = option?.separator;
      input.addEventListener('keyup', setExampleFilenameDisplay);
    }
    if(option?.display){
      let display = ele();
      a(display, [['class', 'option_itm'],['data-example',(option?.example || '')]]);
      inlineStyler(display, `{display:flex; align-items:center;}`)
      mover_elm.appendChild(display);
      display.textContent = option?.display || '';
    }
    if(option?.include === true){ mover_elm.appendChild(onoff); }

  onoff.addEventListener('click', async ()=>{
    let actor = onoff;
    await addRemoveFromFileNameStructure({
      actor: actor,
      option:option,
      // parent_elm:parent_elm,
    });
    // setExampleFilenameDisplay()
  });
}

function findFirstElmSeparatorInsertOpportinity(params) {
  let { parent_elm } = params;
  let elms = Array.from(parent_elm.getElementsByClassName('dragged_item'));
  let marked = elms.map((r,i) => (/filename_separator/.test(elms[i]?.className) === false) && (/filename_separator/.test(elms[i+1]?.className) === false) );
  let index = marked.indexOf(true);
  let insert_before = index > -1 ? elms[index+1] : null;
  return insert_before;
}

async function addRemoveFromFileNameStructure(params){
  var { actor, parent_elm,option } = params;
  let is_on = actor.getAttribute('data-state') === 'on';
  // let parent_id = parent_elm.id;
  // console.log({is_on,parent_id});
  let filename_spacer = cn(actor.parentElement, 'filename_spacer')?.[0];
  if(is_on){
    await animateRemovalOption({
      actor: actor,
      parent_elm: document.getElementById('filename_format_list'),
      do_remove: true,
      remove_elm: actor.parentElement.parentElement,
      option: { ...option, ...{ include: false } },
      do_add: !filename_spacer,
      multiplier: -0.1,
      parent_id:'filename_format_list',
    });
    setExampleFilenameDisplay();
  }else{
    await animateRemovalOption({
      actor: actor,
      parent_elm: document.getElementById('filename_format_options'),
      do_remove: !filename_spacer,
      remove_elm: actor.parentElement,
      option: { ...option, ...{ include: true } },
      do_add: true,
      multiplier: -0.2,
      parent_id:'filename_format_options',
    });
    setExampleFilenameDisplay();
  }

}

async function animateRemovalOption(params){
  var { actor, parent_elm,do_remove,remove_elm,do_add,multiplier,parent_id} = params;
  let separator = parent_id !== 'filename_format_list' ? findFirstElmSeparatorInsertOpportinity({ parent_elm: parent_elm }) : null;
  let srect = separator?.previousElementSibling?.getBoundingClientRect();
  let rects = Array.from(parent_elm.getElementsByClassName('dragged_item'))?.map(r => r.getBoundingClientRect());
  let parent_rect = parent_elm.getBoundingClientRect();
  let lefts = rects.map(r => r.left);
  let largest = Math.max(...lefts);
  let rect = remove_elm?.getBoundingClientRect();

  let target = srect ? srect : rects?.length ? rects[lefts.indexOf(largest)] : {top:parent_rect?.top,left:parent_rect?.left,height:rect?.height,width:40};
  let top = ((target?.top+(target?.height * multiplier)) - rect?.top);
  let left = ((target?.left+(target?.width*1.2)) - rect?.left);
  inlineStyler(remove_elm, `{transition:all 233ms; transform:translate(${left}px,${top}px);}`);
  await delay(133);
  if(do_add === true){
    addFileNameOption({...params,...{added:true}});
  }
  if(do_remove) {
    await delay(100);
    remove_elm.remove();
  }else{
    await delay(84);
    inlineStyler(remove_elm, `{transition:all 0ms; transform:translate(0px,0px);}`);
  }
}

// async function updateFileNameOptionsState(){

// }
async function setExampleFilenameDisplay(){
  let filename_format_container = document.getElementById('filename_format_container');
  let example_display = cn(filename_format_container, 'example_display')?.[0];
  let draggable_option_items = Array.from(cn(filename_format_container, 'draggable_option_item') || []);
  let items = draggable_option_items?.filter(r => cn(r, 'onoff_item')?.[0]?.getAttribute('data-state') === 'on')?.map(r => {
    let itm = cn(r, 'option_itm')?.[0];
    return (itm?.tagName == 'INPUT') ? itm.value : itm?.getAttribute('data-example');
  });
  // let add_items = draggable_option_items?.filter(r => !tn(r, 'input')?.[0]?.checked).map(r => {
  //   let itm = cn(r, 'option_itm')?.[0];
  //   return (itm.tagName == 'INPUT') ? itm.value : itm.getAttribute('data-example');
  // });
  let filetype = Array.from(document.getElementById('tvd_select_file_type').getElementsByTagName('option')).filter(r=> r.selected)?.[0]?.value
  if(example_display){
    example_display.textContent = items?.length ? `${items.reduce((a,b)=> a+b)}.${filetype}` : `.${filetype}`;
  }
  updateUserFileFormatSettings()
}
async function updateUserFileFormatSettings(){
  let options = Array.from(cn(document.getElementById('filename_format_options'),'dragged_item'))?.map(r=> {
    let option = atobJSON(r.getAttribute('data-file_format_option'));
    let separator = /filename_separator/.test(r.className) ? { separator: cn(r,'filename_spacer')?.[0]?.value } : {};
    return {
      ...option,
      ...separator,
    }
  })
  // console.log(options)
  let filetype = Array.from(document.getElementById('tvd_select_file_type').getElementsByTagName('option')).filter(r=> r.selected)?.[0]?.value
  await requestFromBackground({ cmd: 'setLocalStorage', params: { key: 'tvd_file_format_setting', data: JSON.stringify(options) } });
  await requestFromBackground({ cmd: 'setLocalStorage', params: { key: 'tvd_filetype_setting', data: filetype } });
  // ,btoaJSON(option)
}




/*
    ********************************************************
                    HORIZONTAL MOVE HANDLER
    ********************************************************
*/
function initMoveHandler(){
    var target_el = this.parentElement;
    let draggingEle;
    let placeholder;
    let isDraggingStarted = false;
    let x = 0;
    const swap = function(nodeA, nodeB) {
        const parentA = nodeA.parentNode;
        const siblingA = nodeA.nextSibling === nodeB ? nodeA : nodeA.nextSibling;
        nodeB.parentNode.insertBefore(nodeA, nodeB);
        parentA.insertBefore(nodeB, siblingA);
    };
    const isAbove = function(nodeA, nodeB) {
        const rectA = nodeA.getBoundingClientRect();
        const rectB = nodeB.getBoundingClientRect();
        return (rectA.left + rectA.width / 2 < rectB.left + rectB.width / 2);
    };
    const mouseDownHandler = function(e) {
        draggingEle = target_el;
        const rect = draggingEle ? draggingEle.getBoundingClientRect() : placeholder.getBoundingClientRect();
        x = e.pageX - rect.left;
        document.addEventListener('mousemove', mouseMoveHandler);
        document.addEventListener('mouseup', mouseUpHandler);
        document.removeEventListener('mouseenter', initMoveHandler);
    };

    const mouseMoveHandler = function(e) {
        const draggingRect = draggingEle.getBoundingClientRect();
        if (!isDraggingStarted) {
            isDraggingStarted = true;
            placeholder = document.createElement('div');
            placeholder.classList.add('placeholder');
            draggingEle.parentNode.insertBefore(placeholder, draggingEle.nextSibling);
            placeholder.style.width = `${draggingRect.width}px`;
        }
        const rect = draggingEle ? draggingEle.getBoundingClientRect() : placeholder.getBoundingClientRect();
        draggingEle.style.position = 'fixed';
        draggingEle.style.left = `${e.pageX - x}px`;
        const prevEle = draggingEle.previousElementSibling;
        const nextEle = placeholder.nextElementSibling;
        if (prevEle && isAbove(draggingEle, prevEle)) {
            swap(placeholder, draggingEle);
            swap(placeholder, prevEle);
            return;
        }
        if (nextEle && isAbove(nextEle, draggingEle)) {
            swap(nextEle, placeholder);
            swap(nextEle, draggingEle);
        }
    };
    const mouseUpHandler = function() {
        if(placeholder && placeholder.parentNode) {
            placeholder.parentNode.removeChild(placeholder);
        } else {
            if(placeholder) placeholder.outerHTML = '';
        }
        draggingEle.style.removeProperty('top');
        draggingEle.style.removeProperty('left');
        draggingEle.style.removeProperty('position');
        x = null;
        draggingEle = null;
        isDraggingStarted = false;
        document.removeEventListener('mousemove', mouseMoveHandler);
        document.removeEventListener('mouseup', mouseUpHandler);
      setExampleFilenameDisplay();
    };
    this.onmousedown = mouseDownHandler;
}



async function updateBgColor(c){
  await requestFromBackground({ cmd: 'setLocalStorage', params: { key: 'bg_color_setting',data:c } });
  Array.from(cn(document, 'build_container')).forEach(elm => bg_classes.forEach(cc => elm.classList.remove(cc.c)));
  await delay(1);
  Array.from(cn(document, 'build_container')).forEach(elm => elm.classList.add(c));
  await delay(1);
  resetMainBtnColor();
}
async function addStoredBGclass(elm){
  let bg_color_setting = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'bg_color_setting' } });
  if(bg_color_setting) {
    elm.classList.add(bg_color_setting);
    await delay(1);
    resetMainBtnColor();
  }
}

async function resetMainBtnColor() {
  let color_settings = await requestFromBackground({ cmd: 'getLocalStorage', params: { key: 'main_app_colors' } });
  var cont = document.getElementById('init_tvd_program_btn');
  let current_class_selected = bg_classes.filter(c => Array.from(cont.classList).some(l => l == c.c))?.[0];
  // console.log({current_class_selected})
  let fill = current_class_selected?.fill || (color_settings == 'darkmode' ? '#ffffff' : '#000000');
  var menu_body = cn(cont, 'menu_body')?.[0];
  var tvd_clipper_logo = document.getElementById('tvd_clipper_logo');
  Array.from(tvd_clipper_logo?.getElementsByClassName("vlogo") || []).forEach((elm) => {
    a(elm, [["stroke", fill],["stroke-width", "0.2"],["fill", fill],]);
  });
  // Array.from(tn(tvd_clipper_logo,'path')).map(path=> a(path,[['fill',]]))
  // inlineStyler(cont, `{background:${main_app_colors()?.menu_bg};}`);
  inlineStyler(menu_body, `{background:transparent;}`);
}
