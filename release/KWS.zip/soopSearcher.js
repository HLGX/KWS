
// 1.2.5: red badge threshold from the side panel settings (kwsSpBadgeRedDays, default 14 as in 1.2.4)
try { chrome.storage.local.get('kwsSpBadgeRedDays').then((d) => { if (Number.isFinite(d.kwsSpBadgeRedDays)) globalThis.__kwsRedDays = d.kwsSpBadgeRedDays; }); chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && c.kwsSpBadgeRedDays) globalThis.__kwsRedDays = c.kwsSpBadgeRedDays.newValue; }); } catch (_) {} try { chrome.storage.local.get('kwsSpBadgeClick').then((d) => { globalThis.__kwsBadgeClick = d.kwsSpBadgeClick || 'ask'; }); chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && c.kwsSpBadgeClick) globalThis.__kwsBadgeClick = c.kwsSpBadgeClick.newValue || 'ask'; }); } catch (_) {}
/* ============================================================
   KWS — SOOP module
   Runs on www.sooplive.com; the side panel's scan hub drives scans in a SOOP tab (one tab
   runs up to 4 channels at once).
   - VOD list: chapi.sooplive.com · files: api.m.sooplive.com view API · chat: ChatLoadSplit.php
     (5-min chunks; 404 = no chat there; the old .co.kr host answers 400 to everything — 1.2.5.33)
   - Subscriber / fan-only VODs: thumbnail-key guessing or the VOD tab ("Subs" / "Manual" dots)
   - Failed VODs keep the history date at the oldest one, marked "!" (1.2.5.52)
   - Site badges (also on Catch cards — the clip's original streamer, 1.2.5.42) and the inline player
   ============================================================ */
(() => {
  'use strict';

  const PANEL_ID   = 'soop-vod-scan-panel';
  const DEFAULT_POS = { right: 20, bottom: 20 };
  // 한 VOD 안에서 300초 단위 채팅 조각을 동시에 몇 개씩 "제출"할지 — 실제 동시 요청 수의
  // 진짜 상한은 background.js의 SOOP_CHAT_GLOBAL_POOL(모든 탭이 공유하는 적응형 풀)이 관리하니,
  // 여기는 그보다 넉넉하게 잡아도 안전함 (예전엔 여기 숫자가 유일한 안전장치라 6으로 보수적이었음).
  const CHAT_CHUNK_CONC = 12;

  // Twitch(keywordSearcher.js)의 오버로드 배너와 동일하게, 실행 중인 스트리머는 개별
  // 이름/진행률 줄이 아니라 헤더의 집계 카운트("N/4 running")로만 보여줌 — 각 스트리머의
  // 개별 진행률은 이미 결과 탭 바(각 탭 옆 ⏳%)에서 보이고, 대기 중인 항목도 탭 바에
  // "queued" 배지 + × 취소 버튼으로 이미 개별 표시되므로, 이 배너에서 아이디 목록/Queue를
  // 중복으로 나열하지 않음(Twitch 배너와 동일한 정책). 대신 지금 실제로 어떤 네트워크
  // 경로가 뛰고 있는지(API 채팅조각 / VodCore 탭 / Thumb 목록) 작은 원형 인디케이터로
  // 실시간 표시 — NET_ACTIVITY 카운터가 바뀔 때마다 netBump()가 이 함수를 다시 부름.
  function renderSpeedBanner() {
    const banner = document.getElementById('soop-speed-banner');
    if (!banner) return;
    const runningList = Object.values(SCAN_STATES).filter(s => s.running);
    if (!runningList.length) { banner.innerHTML = ''; banner.style.cssText = 'display:none;'; return; }
    banner.style.cssText = 'margin-bottom:10px;padding:0;border-radius:10px;background:rgba(59,130,246,0.12);border:1px solid rgba(59,130,246,0.3);font-size:11px;overflow:hidden;transition:background .3s ease,border-color .3s ease;';
    const dot = (label, kind, tip) => {
      // 실제 카운트가 이미 0으로 떨어졌어도, netBump()가 예약해둔 "최소 표시 시간"이
      // 아직 안 지났으면 계속 켜진 것처럼 보여줌 — 아주 빠른 네트워크 요청(특히 thumb
      // 검증)이 눈 깜빡할 새에 끝나버려서 아예 안 보이는 문제 대응.
      const active = NET_ACTIVITY[kind] > 0 || Date.now() < (NET_VISUAL_UNTIL[kind] || 0);
      return `<span title="${tip}" style="display:inline-flex;align-items:center;gap:4px;color:rgba(255,255,255,${active ? '0.85' : '0.35'});white-space:nowrap;cursor:help;">` +
        `<span style="width:7px;height:7px;border-radius:50%;background:${active ? '#4ade80' : 'rgba(255,255,255,0.22)'};${active ? 'box-shadow:0 0 6px rgba(74,222,128,0.9);' : ''}transition:background .2s ease,box-shadow .2s ease;"></span>${label}</span>`;
    };
    banner.innerHTML = `<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:9px 12px;flex-wrap:wrap;">
      <span style="font-weight:700;color:rgba(255,255,255,0.9);">🟣 Scanning</span>
      <span style="display:flex;align-items:center;gap:10px;font-size:10px;">
        ${dot('Native API', 'api', "Native API (original name: API) — chat is being fetched directly from SOOP's own API.")}
        ${dot('Legacy', 'vodcore', 'Legacy (original name: VodCore tab) — a VOD is being opened in a tab and scraped manually. Slow. Only used as a fallback, or in Legacy Mode.')}
        ${dot('Partial', 'thumb', "Partial (original name: Thumb) — for subscription-only VODs you can't access: looks up the streamer's VOD thumbnails to find a chat key. Works only when a thumbnail exists and usually covers just the first part of the VOD.")}
        <span style="color:rgba(255,255,255,0.4);border-left:1px solid rgba(255,255,255,0.15);padding-left:10px;">${runningList.length}/${MAX_CONCURRENT_SCANS} running</span>
      </span>
    </div>`;
  }
  const HISTORY_KEY = 'soopSearchHistory';
  const MASTER_KEY = 'soopMasterTabId'; // 현재 스캔 실행 중인 탭 ID

  // ── 상태 ──────────────────────────────────────────────────
  // 탭마다 고유 ID (페이지 메모리, 탭간 공유 안 됨)
  const TAB_SESSION_ID = Math.random().toString(36).slice(2) + Date.now().toString(36);

  // 예전엔 STATE 하나(싱글톤)가 "지금 실행 중인 스캔 1개"를 표현했음. 4개 동시 스캔을
  // 지원하기 위해 Twitch(keywordSearcher.js)의 SCAN_STATES[channel] 패턴을 그대로 가져옴 —
  // SCAN_STATES[streamerId(lowercase)] = 그 스트리머의 독립된 스캔 상태 객체.
  // 스캔 파이프라인 함수들(collectVodList, scanVod 등)은 이제 이 객체를 ctx로 받아서 동작하고,
  // 서로 다른 ctx끼리는 전혀 간섭하지 않음 — 이게 진짜 "동시에 4개" 스캔이 가능한 핵심.
  const SCAN_STATES = {};
  const MAX_CONCURRENT_SCANS = 4; // 고정 (사용자 요청)

  // 네트워크 배너의 API / VodCore / Thumb 원형 인디케이터가 참조하는 "지금 진행 중인
  // 요청 개수" 카운터. 실제 동시성(글로벌 풀)과는 무관한 순수 표시용 카운터임.
  const NET_ACTIVITY = { api: 0, vodcore: 0, thumb: 0 };
  // 각 인디케이터가 "최소 이 시각까지는 켜진 걸로 보여야 함"을 기록해두는 타임스탬프.
  // thumb 검증(fetchOnce) 같은 요청은 왕복이 수십ms 안에 끝나버릴 때가 있어서, 카운터가
  // 0→1→0으로 바뀌는 걸 그대로만 렌더링하면 사람 눈에는 아예 안 켜진 것처럼 보임.
  const NET_VISUAL_UNTIL = { api: 0, vodcore: 0, thumb: 0 };
  const NET_MIN_VISIBLE_MS = 450;
  function netBump(kind, delta) {
    NET_ACTIVITY[kind] = Math.max(0, (NET_ACTIVITY[kind] || 0) + delta);
    if (delta > 0) {
      NET_VISUAL_UNTIL[kind] = Date.now() + NET_MIN_VISIBLE_MS;
      renderSpeedBanner();
    } else if (NET_ACTIVITY[kind] === 0) {
      // 진짜 카운트는 0이 됐지만, 아직 "최소 표시 시간"이 안 지났으면 그 시간이 지난
      // 뒤에 한 번 더 다시 그려서 그때 꺼지게 함 (지금 당장 렌더링하면 아직 켜져 보여야 함).
      const remaining = NET_VISUAL_UNTIL[kind] - Date.now();
      if (remaining > 0) setTimeout(() => { if (NET_ACTIVITY[kind] === 0) renderSpeedBanner(); }, remaining + 30);
      else renderSpeedBanner();
    } else {
      renderSpeedBanner();
    }
  }
  // vodCore(탭 열기) 관련 background 메시지는 전부 이 래퍼를 통해서만 보냄 —
  // OPEN_VOD_TAB / SCAN_VOD_IN_TAB_FULL 전부 여기로 통일해서 VodCore 인디케이터가
  // 실제 탭 기반 요청이 뜨고 지는 걸 그대로 반영하게 함.
  async function netTabMessage(msg) {
    netBump('vodcore', 1);
    try {
      return await chrome.runtime.sendMessage(msg);
    } finally {
      netBump('vodcore', -1);
    }
  }
  function runningCount() { return Object.values(SCAN_STATES).filter(s => s.running).length; }
  function isRunningId(id) { return !!SCAN_STATES[(id || '').toLowerCase()]?.running; }
  function newScanCtx(streamerId) {
    return {
      running: false, stopRequested: false, phase: 'idle',
      streamerId, keywords: [], startPage: 1, endPage: null,
      vodItems: [], results: [],
      collectedPages: 0, totalPagesPlanned: 0, lastPage: null,
      completedVodCount: 0, matchedVodCount: 0, message: '',
      abortCtrl: new AbortController(), // 이 스캔만의 abort — 다른 동시 스캔을 건드리지 않음
    };
  }

  // ── beforeunload 경고 (스캔/다운로드 중 페이지 이탈 방지) ──
  const _beforeUnloadHandler = e => { e.preventDefault(); e.returnValue = ''; };
  function kwsSetPageGuard(active) {
    if (active) window.addEventListener('beforeunload', _beforeUnloadHandler);
    else window.removeEventListener('beforeunload', _beforeUnloadHandler);
  }

  // 스캔 대기열
  const SCAN_QUEUE = []; // [{ streamerId, keyword, startPage, endPage, stopAtDate }]

  // 스트리머별 결과 탭 (세션 복원 지원)
  const RESULT_TABS = [];
  let ACTIVE_TAB = -1;
  const TABS_SESSION_KEY = 'soopResultTabs';
  const TRANSLATE_LANG_KEY = 'soopKwsTranslateLangV2';


  // 검색 이력: { [streamerId]: { lastDate, lastPage, keywords, matchedCount, searchedAt } }
  let HISTORY = {};

  // ══════════════════════════════════════════════════════════
  //  1.2.5 side panel mode
  //  SOOP chat (ChatLoadSplit.php) only answers requests made from a sooplive.com page, so the
  //  scan engine below stays in the page; the background scan hub asks this page to run a scan
  //  (KWS_SP_PAGE_RUN) and receives its progress (KWS_SP_PAGE_EVENT). The panel shows the
  //  results. The page keeps the site badges, ?kws_autoscan=1 and the inline player; the old
  //  floating panel is not built.
  // ══════════════════════════════════════════════════════════
  const SP_MODE = true;
  const SP_SCANS_KEY = 'kwsSpScans';
  let SP_HUB = {};
  const spEntry = (id) => SP_HUB['soop:' + String(id || '').toLowerCase()];
  const SP_RUNS = new Map(); // hub scan id → ctx
  // In the hub's background tab, setTimeout is throttled (1/s, then once a minute after 5 min),
  // which stalled the engine's short waits. There the wait is done by the service worker.
  let SP_WORKER = false;
  const spDelay = (ms) => new Promise((r) => {
    if (!SP_WORKER && !document.hidden) { setTimeout(r, ms); return; } // hidden tab (scan or download): service worker timer
    try { chrome.runtime.sendMessage({ type: 'KWS_SP_SLEEP', ms }, () => { void chrome.runtime.lastError; r(); }); }
    catch (_) { setTimeout(r, ms); }
  });

  function spBadgeScan(streamerId, { auto = false } = {}) {
    const sid = String(streamerId || '').toLowerCase().trim();
    if (!sid) return;
    const e = spEntry(sid);
    if (!auto && e && (e.status === 'running' || e.status === 'queued')) return; // same rule as 1.2.4: ignore while scanning
    const send = (mode) => {
      try { chrome.runtime.sendMessage({ type: 'KWS_SP_BADGE_SCAN', platform: 'soop', channel: sid, mode, openPanel: !auto }).catch(() => {}); } catch (_) {}
    };
    const h = HISTORY[sid];
    const pref = globalThis.__kwsBadgeClick; // settings: 'ask' (popup) / 'new' / 'full'
    if (!auto && h?.lastDate && (pref === 'new' || pref === 'full')) send(pref);
    else if (!auto && h?.lastDate && typeof window.showRescanPopup === 'function') {
      window.showRescanPopup(sid, '', h.nickname || sid, h.lastDate, () => send('full'), () => send('new'));
    } else {
      send('full');
    }
  }

  function spEmit(id, kind, payload) {
    try { chrome.runtime.sendMessage({ type: 'KWS_SP_PAGE_EVENT', platform: 'soop', id, kind, ...(payload || {}) }).catch(() => {}); } catch (_) {}
  }

  const spTitleNo = (r) => ((r.playerUrl || '').match(/\/player\/(\d+)/) || [])[1] || '';
  // 1.2.4 per-VOD results → panel groups (one group per VOD, newest first in the panel).
  function spGroups(ctx) {
    const sid = String(ctx.streamerId || '').toLowerCase();
    return ctx.results.filter((r) => (r.matchedEntries || []).length).map((r) => {
      const titleNo = spTitleNo(r);
      return {
        key: (r.dateText || '') + '|' + titleNo,
        // how this VOD's chat was read (1.2.4 network dots): Native API / Legacy (VOD tab) / Partial (thumbnail key)
        sourceServices: [r._usedTab ? 'soop-legacy' : r._needsFix ? 'soop-thumb' : 'soop-api'],
        partial: !!r._hadFetchFailure,
        date: r.dateText || '', displayDate: r.dateText || '', vodTitle: r.title || '',
        messages: r.matchedEntries.map((m) => ({
          ts: m.timeLabel, playback_ts: m.timeLabel, playback_offset: m.seconds || 0,
          username: m.nickname || m.userId || '', userId: m.userId || '', message: m.message || '',
          keywords: m.matchedKeywords || [], subtitle: !!m._subtitle,
          vod_id: titleNo, vod_title: r.title || '', vod_channel: sid, playerUrl: r.playerUrl, dateText: r.dateText || '',
        })),
      };
    });
  }
  // Subscriber-only VODs can only be read partly (or not at all) without a subscription — that is
  // counted on its own, not as "couldn't be fetched".
  // 1.2.5.37: why VODs fail — shown next to the "couldn't fetch N VODs" warning in the panel
  const SOOP_FAIL_TALLY = {};
  const soopNoteFail = (why) => { const k = String(why || '?').slice(0, 60); SOOP_FAIL_TALLY[k] = (SOOP_FAIL_TALLY[k] || 0) + 1; };
  function spFailReason(ctx) {
    const t = {};
    for (const r of ctx.results) {
      if (r._subOnly) continue;
      if (/^ERROR/.test(r.status || '')) { const k = String(r.status).replace(/^ERROR:\s*/, '').slice(0, 60); t[k] = (t[k] || 0) + 1; }
      else if (r._hadFetchFailure) t['chunks'] = (t['chunks'] || 0) + 1;
    }
    const parts = Object.entries(t).sort((a, b) => b[1] - a[1]).slice(0, 2).map(([k, v]) => k + ' ×' + v);
    const net = Object.entries(SOOP_FAIL_TALLY).sort((a, b) => b[1] - a[1]).slice(0, 2).map(([k, v]) => k + ' ×' + v);
    if (net.length) parts.push('req: ' + net.join(', '));
    return parts.join(' · ');
  }
  const spFailed = (ctx) => ctx.results.filter((r) => !r._subOnly && (/^ERROR/.test(r.status || '') || r._hadFetchFailure)).length;
  const spSubOnly = (ctx) => ctx.results.filter((r) => r._subOnly).length;
  function spSnapshot(ctx) {
    const groups = spGroups(ctx);
    return {
      done: ctx.completedVodCount, total: ctx.vodItems.length, matchedLines: ctx.matchedVodCount,
      matchedDays: groups.length, totalSessions: ctx.vodItems.length, groups, failed: spFailed(ctx), failReason: spFailReason(ctx),
      nickname: ctx.streamerNick || null,
      subOnly: spSubOnly(ctx),
      net: { api: NET_ACTIVITY.api > 0, vodcore: NET_ACTIVITY.vodcore > 0, thumb: NET_ACTIVITY.thumb > 0 },
    };
  }

  // 1.2.4 SOOP history: lastDate = newest VOD scanned (not today), plus the streamer's nickname.
  function spHistoryPatch(ctx) {
    const p = {};
    if (ctx.vodItems.length && ctx.vodItems[0].dateText) p.lastDate = ctx.vodItems[0].dateText;
    if (ctx.streamerNick) p.nickname = ctx.streamerNick;
    // 1.2.5.52: VODs that failed (timeout, chunks that never came) must not be skipped by the next
    // "new VODs only" scan — record the history only up to the oldest failed VOD's date (that scan
    // starts there and searches it again) and mark the entry with "!" (partial) until then.
    const failed = ctx.results.filter((r) => !r._subOnly && (/^ERROR/.test(r.status || '') || r._hadFetchFailure));
    const dates = failed.map((r) => String(r.dateText || '').slice(0, 10)).filter((d) => /^\d{4}-\d{2}-\d{2}$/.test(d)).sort();
    if (dates.length) {
      p.lastDate = dates[0];
      p.partial = { through: dates[0], at: new Date().toISOString(), failedVods: failed.length };
    }
    return p;
  }

  async function spLoadSettings() {
    try {
      const d = await chrome.storage.local.get([SOOP_SUBTITLE_KEY, SOOP_FETCH_MODE_KEY]);
      soopSearchSubtitles = !!d[SOOP_SUBTITLE_KEY];
      soopFetchMode = d[SOOP_FETCH_MODE_KEY] === 'tab' ? 'tab' : 'api';
    } catch (_) {}
  }

  async function spRunScan({ id, channel, params }) {
    if (SP_RUNS.has(id)) return;
    const sid = String(channel || '').toLowerCase().trim();
    await spLoadSettings();
    let keyword = (params && params.keyword) || '';
    if (!keyword && window.KWSSharedKeywordEditor) keyword = window.KWSSharedKeywordEditor.defaultValue() || '';
    const ctx = SCAN_STATES[sid] = newScanCtx(sid);
    Object.assign(ctx, {
      running: true, stopRequested: false, phase: 'collecting',
      keywords: normalizeKeywords(keyword), startPage: 1, endPage: null,
      startDate: (params && params.startDate) || null, endDate: (params && params.endDate) || null,
      streamerNick: HISTORY[sid]?.nickname || null, stopAtDate: null,
      _collectDone: false, _noNewVods: false, sessionId: 1, _scanQueue: [],
    });
    SP_RUNS.set(id, ctx); // runs in the hub's own background tab: no leave-page warning
    spEmit(id, 'start', { keywords: ctx.keywords, total: 0 });
    let lastSent = 0;
    let lastNet = '';
    let ticking = true;
    const tickOnce = () => {
      const net = String(NET_ACTIVITY.api > 0) + (NET_ACTIVITY.vodcore > 0) + (NET_ACTIVITY.thumb > 0);
      if (ctx.completedVodCount + ctx.vodItems.length === lastSent && net === lastNet) return;
      lastSent = ctx.completedVodCount + ctx.vodItems.length;
      lastNet = net;
      spEmit(id, 'progress', spSnapshot(ctx));
      broadcastSoopStatusToRanking(ctx, 'scanning', ctx.vodItems.length ? Math.round(ctx.completedVodCount / ctx.vodItems.length * 100) : 0);
    };
    (async () => { while (ticking) { await spDelay(700); if (ticking) tickOnce(); } })();
    fetchStreamerNick(sid).then((n) => { if (n) ctx.streamerNick = n; }).catch(() => {});
    let scanDone = null;
    try {
      _streamerVodThumbCache.clear();
      scanDone = scanAllVods(ctx);
      await collectVodList(ctx);
      ctx._collectDone = true;
      checkStop(ctx);
      ctx.phase = 'scanning';
      await scanDone;
      checkStop(ctx);
      ctx.phase = 'finished';
      spEmit(id, 'done', { ...spSnapshot(ctx), historyPatch: spHistoryPatch(ctx) });
    } catch (err) {
      ctx._collectDone = true;
      if (!ctx.stopRequested) { ctx.stopRequested = true; try { ctx.abortCtrl.abort(); } catch (_) {} }
      if (scanDone) scanDone.catch(() => {});
      spEmit(id, ctx.phase === 'finished' ? 'done' : 'ended', { ...spSnapshot(ctx), error: ctx._spStopped ? '' : (err && err.message) || String(err), stopped: !!ctx._spStopped, historyPatch: spHistoryPatch(ctx) });
    } finally {
      ticking = false;
      ctx.running = false;
      SP_RUNS.delete(id);
      broadcastSoopStatusToRanking(ctx, 'done');
    }
  }

  function spStopScan(id) {
    const ctx = SP_RUNS.get(id);
    if (!ctx) return false;
    ctx._spStopped = true;
    ctx.stopRequested = true;
    try { ctx.abortCtrl.abort(); } catch (_) {}
    return true;
  }

  // A hit from the panel → inline player at that second; clicked seconds saved per VOD like 1.2.4.
  async function spOpenVod(item) {
    const sid = String(item.vod_channel || '').toLowerCase();
    const titleNo = String(item.vod_id || '');
    const secs = item.playback_offset || 0;
    if (sid && titleNo) {
      if (!HISTORY[sid]) HISTORY[sid] = {};
      const ct = HISTORY[sid].clickedTimes || (HISTORY[sid].clickedTimes = {});
      if (!ct[titleNo]) ct[titleNo] = [];
      if (!ct[titleNo].includes(secs)) ct[titleNo].push(secs);
      chrome.storage.local.set({ [HISTORY_KEY]: HISTORY }).catch(() => {});
    }
    await openSoopInlinePlayer({ playerUrl: item.playerUrl || `https://vod.sooplive.com/player/${titleNo}`, seekSecs: secs, title: item.vod_title || '', dateText: item.dateText || '', streamerId: sid, nick: HISTORY[sid]?.nickname || '' });
  }

  function spBadgeState(streamerId) {
    const e = spEntry(streamerId);
    if (!e) return null;
    if (e.status === 'queued') return 'queued';
    if (e.status === 'running') return e.total ? Math.min(100, Math.round((e.done || 0) / e.total * 100)) : 0;
    return null;
  }
  function spUpdateBadges() {
    document.querySelectorAll('.soop-search-badge').forEach((badge) => {
      const st = spBadgeState(badge.dataset.streamerId);
      if (st === null) return;
      badge.textContent = st === 'queued' ? 'queued' : `⏳${st}%`;
      const c = st === 'queued' ? ['rgba(6,182,212,0.12)', 'rgba(6,182,212,0.35)', '#22d3ee'] : ['rgba(251,146,60,0.15)', 'rgba(251,146,60,0.35)', '#fb923c'];
      badge.style.background = c[0]; badge.style.borderColor = c[1]; badge.style.color = c[2];
    });
  }


  // Hub worker tab: keep "KWS 스캔 중 · <site title>" as the tab title so it isn't closed as a stray tab.
  function kwsMarkWorker(title) {
    if (!title || window.__kwsWorkerMark) return;
    window.__kwsWorkerMark = true;
    const prefix = '[' + title + '] ';
    const fix = () => { const t = document.title || ''; if (!t.startsWith(prefix)) document.title = prefix + t.replace(/^\[[^\]]*\]\s*/, ''); };
    // The worker tab is never looked at: stop the site's own video (SOOP main autoplays a live
    // stream) so it doesn't take the CPU the scan needs.
    const quiet = () => { fix(); document.querySelectorAll('video').forEach((v) => { try { v.muted = true; if (!v.paused) v.pause(); } catch (_) {} }); };
    quiet();
    // A plain timer, not a MutationObserver: when the site resets its own title, an observer and
    // the site would rewrite it back and forth without end and hang the page.
    setInterval(quiet, 3000);
  }
  async function spInit() {
    HISTORY = await loadHistory();
    try { SP_HUB = (await chrome.storage.session.get(SP_SCANS_KEY))[SP_SCANS_KEY] || {}; } catch (_) {}
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'session' && changes[SP_SCANS_KEY]) { SP_HUB = changes[SP_SCANS_KEY].newValue || {}; spUpdateBadges(); }
      if (area === 'local' && changes[HISTORY_KEY]) { HISTORY = changes[HISTORY_KEY].newValue || {}; injectSiteBadges(); }
    });
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (msg && msg.type === 'KWS_SP_PAGE_PING') { sendResponse({ ok: true, running: [...SP_RUNS.keys()] }); return; }
      if (!msg || msg.platform !== 'soop') return;
      if (msg.type === 'KWS_SP_PAGE_RUN') { kwsMarkWorker(msg.worker); SP_WORKER = true; spRunScan(msg); sendResponse({ ok: true }); }
      else if (msg.type === 'KWS_SP_PAGE_STOP') { sendResponse({ ok: spStopScan(msg.id) }); }
      else if (msg.type === 'KWS_SP_OPEN_VOD') { spOpenVod(msg.item || {}).catch((e) => console.warn('[KWS SOOP] open VOD failed', e)); sendResponse({ ok: true }); }
      else if (msg.type === 'KWS_SP_OPEN_URL') {
        const raw = String(msg.raw || '');
        const idMatch = /player\/(\d+)/.exec(raw) || /^(\d{5,})$/.exec(raw.trim());
        if (idMatch) openSoopInlinePlayer({ playerUrl: `https://vod.sooplive.com/player/${idMatch[1]}`, seekSecs: 0, title: '', dateText: '', streamerId: '', nick: '' });
        else alert('Could not find a SOOP VOD ID in that input.');
        sendResponse({ ok: true });
      }
    });
    const autoId = guessStreamerIdFromUrl();
    if (autoId && /(?:^|[?&])kws_autoscan=1(?:&|$)/.test(location.search)) {
      try { history.replaceState(null, '', location.pathname + location.hash); } catch (e) {}
      setTimeout(() => spBadgeScan(autoId, { auto: true }), 400);
    }
    [0, 500, 1000, 2000, 4000].forEach((d) => setTimeout(() => injectSiteBadges(), d));
    _soopBadgeObserver = new MutationObserver(() => injectSiteBadges());
    _soopBadgeObserver.observe(document.body, { childList: true, subtree: true });
  }

  init();
  async function init() {
    if (SP_MODE) return spInit();
    HISTORY = await loadHistory();
    // 글로벌 키워드 복원 (HISTORY._globalKeyword 우선, 없으면 local)
    if (HISTORY._globalKeyword) {
      chrome.storage.local.set({ soopKeyword: HISTORY._globalKeyword }).catch(()=>{});
    }
    // 새로고침 후 RESULT_TABS 복원
    try {
      const saved = await chrome.storage.session.get(TABS_SESSION_KEY).catch(()=>({}));
      const tabs = saved[TABS_SESSION_KEY];
      if (tabs?.length) {
        RESULT_TABS.push(...tabs);
        ACTIVE_TAB = RESULT_TABS.length - 1;
      }
    } catch {}
    createPanel();
    await restoreUiValues();

    // streamrecorder.io 뱃지에서 ?kws_autoscan=1 로 넘어온 경우 — 채널 ID만 채워놓고 마는 게
    // 아니라 바로 스캔을 시작함. restoreUiValues()가 방금 전에 저장돼 있던 이전 검색 채널로
    // streamer-id 입력을 덮어썼을 수 있으니, URL에서 다시 뽑아서 확실히 지금 보고 있는 채널로
    // 맞춰준 다음 시작 버튼을 눌러줌. history.replaceState로 쿼리스트링을 지워서
    // 새로고침/뒤로가기 시 또 시작되지 않게 함.
    {
      const autoId = guessStreamerIdFromUrl();
      if (autoId && /(?:^|[?&])kws_autoscan=1(?:&|$)/.test(location.search)) {
        try { history.replaceState(null, '', location.pathname + location.hash); } catch (e) {}
        setTimeout(() => {
          const idInput = document.getElementById('soop-streamer-id');
          if (idInput) { idInput.value = autoId; idInput.dispatchEvent(new Event('input')); }
          renderHistoryHint(autoId);
          document.getElementById('soop-start-btn')?.click();
        }, 400);
      }
    }

    // auto-close 체크박스 복원
    try {
      const r = await chrome.storage.local.get(SOOP_AUTO_CLOSE_KEY);
      soopAutoCloseNoResult = !!r[SOOP_AUTO_CLOSE_KEY];
      const cb = document.getElementById('soop-auto-close-no-result');
      if (cb) cb.checked = soopAutoCloseNoResult;
    } catch {}
    // 자막(CC) 검색 체크박스 복원 + 이벤트
    try {
      const rs = await chrome.storage.local.get(SOOP_SUBTITLE_KEY);
      soopSearchSubtitles = !!rs[SOOP_SUBTITLE_KEY];
      const scb = document.getElementById('soop-search-subtitles');
      if (scb) {
        scb.checked = soopSearchSubtitles;
        scb.addEventListener('change', () => {
          soopSearchSubtitles = scb.checked;
          chrome.storage.local.set({ [SOOP_SUBTITLE_KEY]: soopSearchSubtitles }).catch(()=>{});
        });
      }
    } catch {}
    // fetch mode(API / API Accurate / TAB) 복원
    function setSoopFetchMode(mode) {
      soopFetchMode = mode;
      document.querySelectorAll('.soop-fetch-btn').forEach(b => {
        const active = b.dataset.mode === mode;
        b.style.background = active ? 'rgba(96,165,250,0.18)' : 'rgba(255,255,255,0.05)';
        b.style.borderColor = active ? 'rgba(96,165,250,0.5)' : 'rgba(255,255,255,0.12)';
        b.style.color = active ? '#bfdbfe' : 'rgba(255,255,255,0.62)';
      });
    }
    try {
      const r3 = await chrome.storage.local.get(SOOP_FETCH_MODE_KEY);
      const savedMode = r3[SOOP_FETCH_MODE_KEY];
      setSoopFetchMode(['api','tab'].includes(savedMode) ? savedMode : 'api');
    } catch { setSoopFetchMode('api'); }
    document.querySelectorAll('.soop-fetch-btn').forEach(b => {
      b.addEventListener('click', () => {
        setSoopFetchMode(b.dataset.mode);
        chrome.storage.local.set({ [SOOP_FETCH_MODE_KEY]: b.dataset.mode }).catch(()=>{});
      });
    });
    // 체크박스 이벤트
    const _autoCb = document.getElementById('soop-auto-close-no-result');
    if (_autoCb) {
      _autoCb.addEventListener('change', () => {
        soopAutoCloseNoResult = _autoCb.checked;
        chrome.storage.local.set({ [SOOP_AUTO_CLOSE_KEY]: soopAutoCloseNoResult }).catch(()=>{});
      });
    }
    renderState();
    // 키워드 preview 재확인 - 여러 타이밍에 재시도 (키워드 없어도 No keywords set 표시)
    [50, 200, 500, 1000].forEach(ms => setTimeout(() => updateKeywordPreview(), ms));
    // 사이트에 검색 이력 배지 표시 — 초기 로드 시 SPA 렌더링 대기
    // 500ms, 1s, 2s, 4s 간격으로 재시도 (동적 렌더링 커버)
    [0, 500, 1000, 2000, 4000].forEach(delay =>
      setTimeout(() => injectSiteBadges(), delay)
    );
    // DOM 변경 감지 (SPA 페이지 전환 대응)
    _soopBadgeObserver = new MutationObserver(() => injectSiteBadges());
    _soopBadgeObserver.observe(document.body, { childList: true, subtree: true });
  }

  // ══════════════════════════════════════════════════════════
  //  HISTORY
  // ══════════════════════════════════════════════════════════

  async function loadHistory() {
    try {
      const local = await chrome.storage.local.get(HISTORY_KEY).catch(() => ({}));
      const h = local[HISTORY_KEY] || {};
      // 메타 키 자동 정리 (Export JSON이 잘못 Import된 경우)
      const _META = ['schema','version','exportedAt','settings','records'];
      let _dirty = false;
      for (const k of _META) { if (k in h) { delete h[k]; _dirty = true; } }
      if (_dirty) chrome.storage.local.set({ [HISTORY_KEY]: h }).catch(()=>{});
      return h;
    } catch { return {}; }
  }


  // 마지막 검색 이후 새 VOD 있는지 확인 (API 1회 호출)
  async function checkNewVods(streamerId, lastDate) {
    try {
      const res = await fetchWT(
        `https://chapi.sooplive.com/api/${encodeURIComponent(streamerId)}/vods/review?page=1`,
        { credentials: 'include' }, 8000
      );
      if (!res.ok) return -1;
      const data = await res.json();
      const vods = Array.isArray(data?.data) ? data.data : (data?.data?.broad_list || data?.broad_list || []);
      if (!vods.length) return 0;
      // lastDate 이후 VOD 수 카운트
      const last = new Date(lastDate);
      const newVods = vods.filter(v => {
        const d = v.reg_date || v.broad_start || v.broad_date || '';
        return d && new Date(d.slice(0,10)) > last;
      });
      return newVods.length;
    } catch(e) { return -1; } // 확인 실패
  }

  async function saveHistory(streamerId, { lastDate, endPage, lastPage, keywords, matchedCount, streamerNick }) {
    const sid = (streamerId || '').toLowerCase().trim(); // 항상 lowercase
    HISTORY[sid] = {
      ...( HISTORY[sid] || {} ),  // 기존 데이터 유지 (nickname 등)
      lastDate,
      endPage: endPage || lastPage,
      keywords,
      matchedCount,
      nickname: streamerNick || HISTORY[sid]?.nickname || null,
      searchedAt: new Date().toISOString()
    };
    try {
      await chrome.storage.local.set({ [HISTORY_KEY]: HISTORY }).catch(() => {});
      const json = JSON.stringify(HISTORY);
      
    } catch {}
    injectSiteBadges();
  }

  function getHistoryText(streamerId) {
    const h = HISTORY[streamerId?.trim()?.toLowerCase()] || HISTORY[streamerId?.trim()];
    if (!h) return null;
    const when = h.searchedAt ? new Date(h.searchedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '?';
    const rangeText = h.endPage ? `up to p${h.endPage}` : 'All pages';
    const kwText = '';
    const dateText = h.lastDate || '?';
    const nickPart = h.nickname ? `${h.nickname} · ` : '';
    return `${nickPart}Last searched: ${when} · ${rangeText} · "${kwText}" · up to ${dateText} · ${h.matchedCount || 0} matches`;
  }

  // ══════════════════════════════════════════════════════════
  //  CORE
  // ══════════════════════════════════════════════════════════

  async function startScan({ streamerId, keyword, startPage, endPage, stopAtDate, nick, startDate, endDate }) {
    if (!keyword?.trim()) { broadcast(null, 'Please enter a keyword first.'); return; }
    const sid = streamerId.toLowerCase();
    kwsSetPageGuard(true);
    // 이미 이 스트리머가 돌고 있으면 중복 실행하지 않음 (호출자 쪽에서 대개 먼저 걸러주지만 안전망)
    if (isRunningId(sid)) { broadcast(null, `Already scanning: ${streamerId}`); return; }
    // 동시 실행 개수가 MAX_CONCURRENT_SCANS(4)에 도달했으면 대기열에 추가 — 그 외에는(다른
    // 스트리머가 몇 개 돌고 있든 4개 미만이면) 바로 동시 실행 시작.
    if (runningCount() >= MAX_CONCURRENT_SCANS) {
      // 같은 ID가 이미 대기열에 있으면 업데이트
      const existing = SCAN_QUEUE.findIndex(q => q.streamerId === streamerId);
      if (existing >= 0) {
        const oldTabIdx = SCAN_QUEUE[existing]._tabIdx;
        if (oldTabIdx !== undefined) {
          RESULT_TABS.splice(oldTabIdx, 1);
          if (ACTIVE_TAB > oldTabIdx) ACTIVE_TAB--;
          // SCAN_QUEUE의 다른 항목들도 index 보정
          SCAN_QUEUE.forEach(q => { if (q._tabIdx !== undefined && q._tabIdx > oldTabIdx) q._tabIdx--; });
        }
        SCAN_QUEUE.splice(existing, 1);
      }
      // 대기열 탭 미리 생성 (회색/pending 상태)
      const qTabIdx = RESULT_TABS.length;
      const qNick = nick || HISTORY[sid]?.nickname || null;
      RESULT_TABS.push({ streamerId, nick: qNick || streamerId, results: [], matchedCount: 0, timestamp: Date.now(), pending: true, keywords: normalizeKeywords(keyword), startDate: startDate||'', endDate: endDate||'', vodTotal: 0 });
      SCAN_QUEUE.push({ streamerId, keyword, startPage, endPage, stopAtDate, nick: qNick, _tabIdx: qTabIdx });
      renderQueueUI();
      renderResultTabs();
      return;
    }

    // 이 스트리머만의 독립된 스캔 상태 — 다른 동시 스캔과 전혀 공유하지 않음
    const ctx = SCAN_STATES[sid] = newScanCtx(streamerId);
    Object.assign(ctx, {
      running: true, stopRequested: false, _stopCurrentOnly: false, phase: 'collecting',
      keywords: normalizeKeywords(keyword),
      startPage: 1, endPage: null,
      startDate: startDate || null,
      endDate: endDate || null,
      vodItems: [], results: [],
      collectedPages: 0, totalPagesPlanned: endPage ? (endPage - startPage + 1) : 0,
      lastPage: null, completedVodCount: 0, matchedVodCount: 0,
      streamerNick: HISTORY[sid]?.nickname || null,
      stopAtDate: stopAtDate || null,
      _collectDone: false,
      _noNewVods: false,
      sessionId: 1
    });
    broadcast(ctx, `Starting... keyword: ${keyword.slice(0,40)}${keyword.length>40?'...':''}`);
    // 마스터 실행 중 플래그 — 이제 "실행 중인 스트리머가 1명이라도 있는지"로 판단(다른 탭에서
    // 참고하는 값이라 sessionId 대신 heartbeat만으로 충분)
    chrome.storage.local.set({ [MASTER_KEY]: { id: TAB_SESSION_ID, ts: Date.now() } }).catch(()=>{});
    // 스캔 중 10초마다 heartbeat 갱신 — 이 ctx가 도는 동안만
    ctx._heartbeat = setInterval(() => {
      if (!ctx.running) { clearInterval(ctx._heartbeat); return; }
      chrome.storage.local.set({ [MASTER_KEY]: { id: TAB_SESSION_ID, ts: Date.now() } }).catch(()=>{});
    }, 10000);
    // 대기열에서 미리 만든 pending 탭 재활용, 없으면 새 탭 생성
    // 통일 규칙: 같은 스트리머를 다시 검색하면 기존(완료된) 탭을 교체 — 같은 이름 탭이 중복으로 생기지 않게
    // (중복 탭은 같은 스캔 상태를 같이 봐서 둘 다 주황색으로 보였음)
    {
      const dupIdx = RESULT_TABS.findIndex(t => (t.streamerId || '').toLowerCase() === sid && !t.pending);
      if (dupIdx >= 0) {
        RESULT_TABS.splice(dupIdx, 1);
        if (ACTIVE_TAB > dupIdx) ACTIVE_TAB--;
        else if (ACTIVE_TAB >= RESULT_TABS.length) ACTIVE_TAB = RESULT_TABS.length - 1;
        for (const s of Object.values(SCAN_STATES)) { if (s !== ctx && s._tabIdx !== undefined && s._tabIdx > dupIdx) s._tabIdx--; }
        SCAN_QUEUE.forEach(q => { if (q._tabIdx !== undefined && q._tabIdx > dupIdx) q._tabIdx--; });
      }
    }
    const existingPendingIdx = RESULT_TABS.findIndex(t => t.streamerId === streamerId && t.pending);
    let tabIdx;
    if (existingPendingIdx >= 0) {
      tabIdx = existingPendingIdx;
      RESULT_TABS[tabIdx].pending = false;
      RESULT_TABS[tabIdx].results = [];
      RESULT_TABS[tabIdx].matchedCount = 0;
      RESULT_TABS[tabIdx].timestamp = Date.now();
      RESULT_TABS[tabIdx].keywords = [...(ctx.keywords||[])];
      RESULT_TABS[tabIdx].startDate = ctx.startDate||'';
      RESULT_TABS[tabIdx].endDate = ctx.endDate||'';
      RESULT_TABS[tabIdx].vodTotal = 0;
    } else {
      tabIdx = RESULT_TABS.length;
      RESULT_TABS.push({ streamerId, nick: ctx.streamerNick || streamerId, results: [], matchedCount: 0, timestamp: Date.now(), pending: false, keywords: [...(ctx.keywords||[])], startDate: ctx.startDate||'', endDate: ctx.endDate||'', vodTotal: 0 });
    }
    if (ACTIVE_TAB < 0 || ACTIVE_TAB >= RESULT_TABS.length) ACTIVE_TAB = tabIdx;
    ctx._tabIdx = tabIdx;
    renderResultTabs();
    // 닉네임 비동기 조회 (검색과 병렬)
    fetchStreamerNick(streamerId).then(nick => {
      if (nick) {
        ctx.streamerNick = nick;
        if (HISTORY[sid]) {
          HISTORY[sid].nickname = nick;
          chrome.storage.local.set({ [HISTORY_KEY]: HISTORY }).catch(()=>{});
        }
        renderState();
      }
    });

    try {
      // 파이프라인: 수집과 스캔 동시 진행
      ctx.phase = 'collecting';
      ctx._scanQueue = []; // 수집된 VOD 공유 큐
      _streamerVodThumbCache.clear();
      ctx._collectDone = false;

      // 스캔 워커 먼저 시작 (수집 기다리지 않음)
      const scanDone = scanAllVods(ctx);

      // 수집 진행 (VOD 찾을 때마다 큐에 추가)
      await collectVodList(ctx);
      ctx._collectDone = true;
      checkStop(ctx);

      // 수집 완료 후 스캔 완료 대기
      ctx.phase = 'scanning';
      await scanDone;
      checkStop(ctx);

      // 검색 완료 후 이력 저장
      const lastDate = ctx.vodItems.length ? ctx.vodItems[0].dateText : (HISTORY[sid]?.lastDate || '');
      await saveHistory(sid, {
        lastDate,
        endPage,
        lastPage: ctx.lastPage,
        keywords: ctx.keywords,
        matchedCount: ctx.matchedVodCount,  // total matched lines
        streamerNick: ctx.streamerNick
      });
      // 이력 힌트 업데이트
      renderHistoryHint(streamerId);

      ctx.phase = 'finished';
      ctx.running = false;
      clearInterval(ctx._heartbeat);
      if (!runningCount()) chrome.storage.local.remove(MASTER_KEY).catch(()=>{});
      broadcastSoopStatusToRanking(ctx, 'done');
      if (ctx._noNewVods) {
        broadcast(ctx, 'Up to date — no new VODs found.');
      } else {
        broadcast(ctx, `Done! ${ctx.matchedVodCount} VOD(s) matched`);
      }
      // 결과 없으면 탭 자동 닫기 (noNewVods 포함)
      // 주의: 동시에 여러 스트리머를 스캔할 때(멀티 스캔), 이 300ms 대기 동안 다른 스캔의
      // 완료/자동닫기/수동닫기가 먼저 RESULT_TABS를 splice해서 인덱스가 밀릴 수 있음.
      // 예전엔 ctx._tabIdx를 여기서 미리 숫자로 캡처해서 그대로 썼는데, 그러면 밀린 뒤엔
      // 엉뚱한(나중에 그 자리로 밀려온) 탭을 지워버리고 정작 결과 없는 이 탭은 안 닫히는
      // 버그가 있었음 — ctx._tabIdx는 다른 곳(수동 탭 닫기 등)에서 splice될 때마다 계속
      // 갱신되고 있으므로, setTimeout이 실제로 실행되는 시점에 다시 읽어야 정확함.
      if (soopAutoCloseNoResult && ctx.matchedVodCount === 0 && ctx._tabIdx !== undefined) {
        setTimeout(() => {
          const closeIdx = ctx._tabIdx;
          if (closeIdx !== undefined && RESULT_TABS[closeIdx]) {
            RESULT_TABS.splice(closeIdx, 1);
            if (ACTIVE_TAB >= RESULT_TABS.length) ACTIVE_TAB = RESULT_TABS.length - 1;
            if (ACTIVE_TAB > closeIdx) ACTIVE_TAB--;
            // 수동 탭 닫기(×)와 동일한 규칙: 이 삭제로 밀리는 다른 실행 중인 스캔들의
            // _tabIdx와 대기열의 _tabIdx도 같이 보정해줘야 다음 자동/수동 닫기가 안 꼬임.
            for (const s of Object.values(SCAN_STATES)) { if (s !== ctx && s._tabIdx !== undefined && s._tabIdx > closeIdx) s._tabIdx--; }
            SCAN_QUEUE.forEach(q => { if (q._tabIdx !== undefined && q._tabIdx > closeIdx) q._tabIdx--; });
            renderResultTabs();
          }
        }, 300);
      }
      // 탭에 완료 상태 snapshot 저장
      if (ctx._tabIdx !== undefined && RESULT_TABS[ctx._tabIdx]) {
        RESULT_TABS[ctx._tabIdx].snapshot = {
          message: `Done! ${ctx.matchedVodCount} VOD(s) matched`,
          pct: 100,
          streamerId: ctx.streamerId,
          streamerNick: ctx.streamerNick,
          keywords: ctx.keywords,
          startDate: ctx.startDate,
          endDate: ctx.endDate,
          vodTotal: ctx.vodItems.length,
          vodScanned: ctx.completedVodCount,
          matchedVodCount: ctx.matchedVodCount,
        };
        RESULT_TABS[ctx._tabIdx].nick = ctx.streamerNick || ctx.streamerId;
      }
      renderResultTabs();
      renderQueueUI();
      // 대기열에 다음 항목 있으면(그리고 자리가 나면) 자동 시작
      if (SCAN_QUEUE.length > 0 && runningCount() < MAX_CONCURRENT_SCANS) {
        const next = SCAN_QUEUE.shift();
        renderQueueUI();
        setTimeout(() => startScan(next), 800);
      }
    } catch (err) {
      ctx.running = false;
      renderSpeedBanner();
      broadcastSoopStatusToRanking(ctx, 'done');
      ctx.phase = ctx.stopRequested ? 'stopped' : 'failed';
      clearInterval(ctx._heartbeat);
      if (!runningCount()) chrome.storage.local.remove(MASTER_KEY).catch(()=>{});
      // 일부라도 스캔했으면 이력 저장
      if (ctx.completedVodCount > 0 || ctx._noNewVods) {
        try {
          const lastDate = ctx.vodItems.length ? ctx.vodItems[0].dateText : (HISTORY[sid]?.lastDate || '');
          await saveHistory(sid, {
            lastDate,
            endPage,
            lastPage: ctx.lastPage,
            keywords: ctx.keywords,
            matchedCount: ctx.matchedVodCount,  // total matched lines
            streamerNick: ctx.streamerNick
          });
          renderHistoryHint(streamerId);
        } catch {}
      }
      broadcast(ctx, ctx.stopRequested ? 'Stopped' : `Error: ${err.message}`);
      renderQueueUI();
      renderResultTabs();
      const startNextIfRoom = () => {
        if (SCAN_QUEUE.length > 0 && runningCount() < MAX_CONCURRENT_SCANS) {
          const next = SCAN_QUEUE.shift();
          renderQueueUI();
          setTimeout(() => startScan(next), 800);
        }
      };
      if (!ctx.stopRequested) {
        startNextIfRoom();
      } else if (ctx._stopCurrentOnly) {
        // X 버튼으로 현재 탭만 중지 → 큐는 유지하고 자리가 나면 다음 스캔 진행
        ctx._stopCurrentOnly = false;
        startNextIfRoom();
      } else {
        // 전체 Stop — 큐까지 비움
        SCAN_QUEUE.length = 0;
        RESULT_TABS.forEach(t => { if (t.pending) t.pending = false; });
        renderResultTabs();
        renderQueueUI();
      }
    }
  }

  // ── VOD 목록 수집 ─────────────────────────────────────────
  async function collectVodList(ctx) {
    const seenNos = new Set();
    let page = 1; // 날짜 기반이므로 항상 1페이지부터
    const stopAtDate = ctx.stopAtDate || null;
    const startDate = ctx.startDate || null; // 이 날짜 이후 VOD만
    const endDate = ctx.endDate || null;     // 이 날짜 이전 VOD만
    while (true) {
      checkStop(ctx);
      if (ctx.endPage && page > ctx.endPage) break;
      broadcast(ctx, `Collecting VOD list page ${page}...`);
      // review + highlight 동시 수집 (ctx.abortCtrl.signal — 이 스캔만 Stop해도 다른 동시
      // 스캔의 fetch는 안 끊기도록 스캔별 signal을 넘김)
      const [reviewRes, highlightRes] = await Promise.allSettled([
        fetchWT(`https://chapi.sooplive.com/api/${encodeURIComponent(ctx.streamerId)}/vods/review?page=${page}`, { credentials: 'include' }, 12000, ctx.abortCtrl.signal),
        fetchWT(`https://chapi.sooplive.com/api/${encodeURIComponent(ctx.streamerId)}/vods/highlight?page=${page}`, { credentials: 'include' }, 12000, ctx.abortCtrl.signal),
      ]);
      let json, json2;
      try {
        if (reviewRes.status === 'fulfilled' && reviewRes.value.ok) json = await reviewRes.value.json();
        else if (reviewRes.status === 'rejected') throw new Error(reviewRes.reason?.message || 'VOD API failed');
      } catch (e) { throw new Error(`VOD API failed: ${e.message}`); }
      try { if (highlightRes.status === 'fulfilled' && highlightRes.value.ok) json2 = await highlightRes.value.json(); } catch {}

      // review + highlight 목록 합산
      const list = [...(json?.data || []), ...(json2?.data || [])];
      const meta = json?.meta;
      // 두 API 중 더 많은 페이지 수 사용
      const lastPageReview = meta?.last_page || null;
      const lastPageHighlight = json2?.meta?.last_page || null;
      const lastPage = Math.max(lastPageReview || 0, lastPageHighlight || 0) || null;
      if (lastPage && !ctx.lastPage) {
        ctx.lastPage = lastPage;
        if (!ctx.endPage) ctx.totalPagesPlanned = lastPage - ctx.startPage + 1;
      }
      if (!list.length) break;

      let hitStopDate = false;
      for (const v of list) {
        const titleNo = v.title_no;
        if (!titleNo || seenNos.has(String(titleNo))) continue;
        const dateText = (v.reg_date || '').slice(0, 10);
        // stopAtDate 이전 VOD → 수집 중단
        // stopAtDate: 증분 검색 시 이전 기록 이전 VOD 중단
        if (stopAtDate && dateText && dateText < stopAtDate) { hitStopDate = true; break; }
        // endDate: 이 날짜보다 최신 VOD 스킵 (계속 진행)
        if (endDate && dateText && dateText > endDate) continue;
        // startDate: 이 날짜보다 오래된 VOD → 중단
        if (startDate && dateText && dateText < startDate) { hitStopDate = true; break; }
        seenNos.add(String(titleNo));
        const thumbUrl = v.ucc?.thumb || '';
        const fileInfoKeys = extractKeysFromThumb(thumbUrl);
        const duration = Math.floor((v.ucc?.total_file_duration || 0) / 1000);
        const vodItem = {
          titleNo: String(titleNo),
          playerUrl: `https://vod.sooplive.com/player/${titleNo}`,
          title: v.title_name || '(No title)',
          dateText, page, fileInfoKeys, duration,
          _order: ctx.vodItems.length // 동시 처리 중 완료 순서가 뒤섞여도 원래 순서대로 정렬하기 위함
        };
        ctx.vodItems.push(vodItem);
        if (ctx._scanQueue) ctx._scanQueue.push(vodItem);
      }
      ctx.collectedPages++;
      renderState();
      if (hitStopDate) { broadcast(ctx, `Reached last searched date (${stopAtDate}) — stopping.`); break; }
      const done = ctx.endPage ? page >= ctx.endPage : (lastPage ? page >= lastPage : list.length < 60);
      if (done) break;
      page++;
    }
    if (!ctx.vodItems.length) { ctx._noNewVods = true; return; } // VOD 없음 → 에러 아닌 정상 종료
  }

  // ── VOD 스캔 ─────────────────────────────────────────────
  function recordVodResult(ctx, item, result, mySessionId) {
    if (mySessionId !== undefined && mySessionId !== ctx.sessionId) return; // 이미 새 스캔으로 넘어감 — 이 결과는 버림
    result._order = item._order ?? 0;
    ctx.results.push(result);
    ctx.results.sort((a, b) => (a._order ?? 0) - (b._order ?? 0));
    if (ctx._tabIdx !== undefined && RESULT_TABS[ctx._tabIdx]) {
      RESULT_TABS[ctx._tabIdx].results.push(result);
      RESULT_TABS[ctx._tabIdx].results.sort((a, b) => (a._order ?? 0) - (b._order ?? 0));
      RESULT_TABS[ctx._tabIdx].vodTotal = ctx.vodItems.length;
    }
    if (result.matchCount > 0) {
      ctx.matchedVodCount += result.matchCount;
      if (ctx._tabIdx !== undefined && RESULT_TABS[ctx._tabIdx]) {
        RESULT_TABS[ctx._tabIdx].matchedCount += result.matchCount;
      }
      renderResultTabs();
    }
    ctx.completedVodCount++;
    renderState();
  }

  async function scanAllVods(ctx) {
    if (soopFetchMode === 'tab') return scanAllVodsTabMode(ctx);
    return scanAllVodsSequential(ctx);
  }

  const API_WORKER_MAX = 12; // 고정 — 자동으로 안 줄어듦
  let _apiFallbackWindow = []; // 최근 완료된 VOD들이 탭 폴백을 썼는지 여부 — 표시 전용, 동시성엔 영향 없음
  let _networkState = 'normal'; // 'healthy' | 'overload' — renderSpeedBanner가 이 값으로 배너 전체 색을 바꿈 (순수 관찰용)

  function recordApiFallback(usedTab) {
    _apiFallbackWindow.push(usedTab);
    if (_apiFallbackWindow.length > 6) _apiFallbackWindow.shift();
    if (_apiFallbackWindow.length < 5) return;
    const fallbackCount = _apiFallbackWindow.filter(Boolean).length;
    const newState = fallbackCount >= 3 ? 'overload' : 'healthy';
    if (newState !== _networkState) {
      _networkState = newState;
      renderSpeedBanner();
    }
  }

  async function scanAllVodsSequential(ctx) {
    const mySessionId = ctx.sessionId;
    _apiFallbackWindow = [];
    _networkState = 'healthy';
    renderSpeedBanner();
    await Promise.all(Array.from({ length: API_WORKER_MAX }, async () => {
      while (true) {
        // 큐에서 VOD 꺼내기 — 없으면 수집 완료될 때까지 대기
        while ((!ctx._scanQueue || !ctx._scanQueue.length) && !ctx._collectDone) {
          await spDelay(50);
        }
        if (!ctx._scanQueue?.length && ctx._collectDone) return;
        checkStop(ctx);
        const item = ctx._scanQueue.shift();
        if (!item) continue;
        try {
          broadcast(ctx, `Scanning (${ctx.completedVodCount}/${ctx.vodItems.length}) · ${item.title}`);
          let result = await scanVodWithTimeout(ctx, item);

          // 매칭 + _needsFix → 렌더링 전에 Fix Time 완료 / _needsFullRescan은 매칭 개수 무관하게 항상 재검증
          // (파일목록 자체가 불완전했을 수 있어서 — 매칭이 0으로 나온 것도 못 믿는 상태이기 때문)
          if ((result.matchCount > 0 && result._needsFix) || result._needsFullRescan) {
            const isFullRescan = !!result._needsFullRescan;
            broadcast(ctx, `${isFullRescan ? 'Incomplete file list detected — re-verifying via tab' : 'Auto-fixing timestamps'}: ${item.title.slice(0, 20)}...`);
            let openedTabForFix = false;
            // _usedTab(=Legacy 배지)은 데이터 자체를 탭에서 다시 가져온 경우에만 표시.
            // 타임스탬프만 보정하는 경우는 발견 방식 자체는 여전히 Combined API라서 배지를 안 바꿈.
            if (isFullRescan) result._usedTab = true;
            try {
              const res = await Promise.race([
                netTabMessage({ type: 'OPEN_VOD_TAB', playerUrl: item.playerUrl }),
                new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 60000))
              ]);
              openedTabForFix = true;
              if (res?.success && res.fileItems?.length) {
                const sortedFiles = res.fileItems
                  .map((f, i) => ({ key: f.file_info_key, duration: f.duration || 0, order: f.file_order || (i + 1) }))
                  .filter(f => f.key).sort((a, b) => a.order - b.order);
                sortedFiles._verified = true; // 이미 탭 기반 실제 파일목록이므로 재귀적으로 또 재검증 트리거하지 않도록 표시
                const fixed = await scanVodWithFileItems(item, sortedFiles, ctx.keywords);
                if (isFullRescan || fixed.matchCount > 0) result = { ...result, ...fixed, _needsFullRescan: undefined, _usedTab: result._usedTab };
              }
            } catch {}
            recordApiFallback(openedTabForFix);
          } else {
            recordApiFallback(!!result._usedTab);
          }

          recordVodResult(ctx, item, result, mySessionId);
        } catch (itemErr) {
          // Stop 버튼으로 인한 중단은 그대로 전파 — 그 외(예상 못한 개별 VOD 에러)는
          // 이 워커만 실패 처리하고 계속 진행, 전체 Promise.all이 통째로 안 멈추도록 함
          if (ctx.stopRequested) throw itemErr;
          console.error('SOOP scanVod item error:', itemErr);
          recordApiFallback(true);
          recordVodResult(ctx, item, { title: item.title, playerUrl: item.playerUrl, dateText: item.dateText, page: item.page, matchCount: 0, matchedLines: [], matchedEntries: [], sample: '', status: `ERROR: ${itemErr?.message || itemErr}` }, mySessionId);
        }
      }
    }));
  }

  const TAB_WORKER_COUNT = 6; // TAB 모드 — 고정 워커 개수, 옛날 버전(V2.7)과 동일하게 Promise.all로 우직하게

  // TAB 모드 — VOD당 탭 하나 열어서 그 안에서 파일목록+채팅+매칭까지 전부 끝냄 (구독 전용 VOD는
  // 예외적으로 기존 api.m 감지 → Thumb→Tab 흐름을 그대로 재사용, 안 그러면 구독 안 한 VOD를 통째로 놓침)
  async function scanAllVodsTabMode(ctx) {
    const mySessionId = ctx.sessionId;
    const parsedKw = splitSoopKeywords(ctx.keywords);
    await Promise.all(Array.from({ length: TAB_WORKER_COUNT }, async () => {
      while (true) {
        while ((!ctx._scanQueue || !ctx._scanQueue.length) && !ctx._collectDone) {
          await spDelay(50);
        }
        if (!ctx._scanQueue?.length && ctx._collectDone) return;
        checkStop(ctx);
        const item = ctx._scanQueue.shift();
        if (!item) continue;
        broadcast(ctx, `Scanning (${ctx.completedVodCount}/${ctx.vodItems.length}) · ${item.title}`);

        const resultBase = { title: item.title, playerUrl: item.playerUrl, dateText: item.dateText, page: item.page };
        let result;
        try {
          // 구독 여부만 가볍게 확인 (api.m 자체는 안 믿고 버림, authRequired 신호만 씀)
          const fileItemsCheck = await fetchFileItems(item.titleNo);
          const isAuthRequired = fileItemsCheck?.authRequired === true;
          if (isAuthRequired) {
            {
              // Thumb 흐름 재사용 (thumb로 부족하면 탭으로 보완)
              result = await scanVodWithTimeout(ctx, item);
              result._subOnly = true;
              if (result._needsFullRescan) {
                broadcast(ctx, `Incomplete file list detected — re-verifying via tab: ${item.title.slice(0, 20)}...`);
                try {
                  const res = await Promise.race([
                    netTabMessage({ type: 'OPEN_VOD_TAB', playerUrl: item.playerUrl }),
                    new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 60000))
                  ]);
                  if (res?.success && res.fileItems?.length) {
                    const sortedFiles = res.fileItems
                      .map((f, i) => ({ key: f.file_info_key, duration: f.duration || 0, order: f.file_order || (i + 1) }))
                      .filter(f => f.key).sort((a, b) => a.order - b.order);
                    sortedFiles._verified = true;
                    const fixed = await scanVodWithFileItems(item, sortedFiles, ctx.keywords);
                    result = { ...result, ...fixed, _needsFullRescan: undefined };
                  }
                } catch {}
              }
            }
          } else {
            const res = await Promise.race([
              netTabMessage({ type: 'SCAN_VOD_IN_TAB_FULL', playerUrl: item.playerUrl, parsedKw, chunkConc: CHAT_CHUNK_CONC, maxConcurrentTabs: TAB_WORKER_COUNT }),
              new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 40000))
            ]);
            if (res?.success) {
              result = { ...resultBase, matchCount: res.matchCount || 0, matchedLines: res.lines || [], matchedEntries: res.matches || [], sample: (res.lines && res.lines[0]) || '', status: 'OK', _usedTab: true };
            } else {
              result = { ...resultBase, matchCount: 0, matchedLines: [], matchedEntries: [], sample: '', status: `ERROR: ${res?.error || 'tab scan failed'}` };
            }
          }
        } catch (err) {
          result = { ...resultBase, matchCount: 0, matchedLines: [], matchedEntries: [], sample: '', status: `ERROR: ${err.message}` };
        }

        recordVodResult(ctx, item, result, mySessionId);
      }
    }));
  }

  async function scanVod(ctx, item) {
    const base = { title: item.title, playerUrl: item.playerUrl, dateText: item.dateText, page: item.page, matchCount: 0, matchedLines: [], matchedEntries: [], sample: '', status: 'OK', _usedTab: false };
    try {
      const titleNo = item.titleNo;
      const vodTotalDur = item.duration || 0; // VOD 목록에서 가져온 전체 길이(초)

      // 1) api.m으로 파일 목록 취득 (빠름) — 구독 전용 여부 판단에도 필요해서 Accuracy Mode에서도 항상 호출
      let fileItems = await fetchFileItems(titleNo);
      console.log('[SOOP KWS] api.m fileItems for', titleNo, JSON.parse(JSON.stringify(fileItems || null)), 'vodTotalDur(listing)=', item.duration);

      // 2) api.m 파일 합산 duration vs VOD 전체 duration 비교
      //    반올림 오차 수준(몇 초)은 무시하고, 그보다 크게 차이 나면 파일 누락으로 보고 vodCore로 보완.
      //    Accuracy Mode에서는 허용 오차를 더 좁혀서(사실상 오차 거의 없이) 항상 재검증.
      //    VOD가 아주 길면(6시간+) 가져와야 할 채팅 조각 수 자체가 많아져서, 그 과정 어딘가에서
      //    하나라도 실패할 누적 확률이 커짐 — 사후 재검증을 기다리지 않고 처음부터 탭으로 보냄
      const SOOP_LONG_VOD_THRESHOLD_SEC = 6 * 3600;
      if (Array.isArray(fileItems) && fileItems.length && vodTotalDur > 0) {
        const apiTotalDur = fileItems.reduce((s, f) => s + (f.duration || 0), 0);
        const missing = vodTotalDur - apiTotalDur;
        const missingRatio = missing / vodTotalDur;
        const ratioThreshold = 0.02; // 2% 이내 반올림 오차는 무시
        const secThreshold = 5;      // 5초 이내 반올림 오차는 무시
        // 6시간+ VOD라고 무조건 탭으로 보내지 않음: api.m.sooplive.com은 긴 VOD도 파일 합계가 정확히 맞고(샘플 확인),
        // 조각 fetch 실패는 아래 재시도/사후 검증이 따로 잡음. 진짜 길이 불일치일 때만 탭으로 감.
        const isGap = soopFetchMode.startsWith('tab') || (missing > secThreshold && missingRatio > ratioThreshold);
        if (isGap) {
          // 가벼운 방법 먼저: 이미 가진 파일 키 패턴("prefix_순서번호")으로 빠진 순서번호들을
          // 추측해서 실제로 존재하는지 가볍게 확인 (탭 열지 않고 XML 요청 몇 개만 함).
          // 구독 전용 VOD의 "thumb" 방식과 같은 원리 — 특정 데이터 전용이 아니라 범용적으로 씀.
          let stillGap = true;
          console.log('[SOOP KWS]', item.titleNo, 'gap detected, trying key-guess recovery...');
          // 예전엔 "prefix_순번"으로 빠진 파일을 추측했지만, 파일마다 8자리 HEX가 달라서(직접 확인) 추측은
          // 항상 실패함 → 제거. 대신 view API를 한 번 더 불러서(일시적 누락 가능성) 목록이 채워지는지만 확인.
          // (api.m.sooplive.com 기준 접근 가능한 VOD는 파일 합계 = 전체 길이가 정확히 맞는 것을 41개 샘플로 확인)
          if (!soopFetchMode.startsWith('tab')) {
            try {
              const again = await fetchFileItems(titleNo);
              if (Array.isArray(again) && again.length) {
                const t2 = again.reduce((s2, f) => s2 + (f.duration || 0), 0);
                const m2 = vodTotalDur - t2;
                if (t2 > apiTotalDur) {
                  fileItems = again;
                  stillGap = m2 > secThreshold && (m2 / vodTotalDur) > ratioThreshold;
                  if (!stillGap) broadcast(ctx, `File list completed on retry — ${item.title.slice(0, 20)}`);
                }
              }
            } catch (e) {}
          }
          if (!stillGap) {
            // 가벼운 방법으로 해결됨 — 탭 열 필요 없음
          } else {
          // duration 차이만 있는 경우 → vodCore 탭 열어서 정확한 목록 취득
          base._usedTab = true; broadcast(ctx, `${soopFetchMode.startsWith('tab') ? 'Tab mode' : 'API unclear, switching to Tab (time mismatch detected)'} — ${item.title.slice(0, 20)}`);
          console.log('[SOOP KWS]', item.titleNo, 'opening tab for recovery...');
          const tabOpenStart = Date.now();
          try {
            const res = await Promise.race([
              netTabMessage({ type: 'OPEN_VOD_TAB', playerUrl: item.playerUrl }),
              new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 60000))
            ]);
            console.log('[SOOP KWS]', item.titleNo, 'tab open result after', Date.now() - tabOpenStart, 'ms:', res?.success, res?.fileItems?.length);
            if (res?.success && res.fileItems?.length) {
              fileItems = res.fileItems
                .map((f, i) => ({ key: f.file_info_key, duration: f.duration || 0, order: f.file_order || (i + 1) }))
                .filter(f => f.key)
                .sort((a, b) => a.order - b.order);
            }
          } catch (e) {
            console.log('[SOOP KWS]', item.titleNo, 'tab open FAILED after', Date.now() - tabOpenStart, 'ms:', e?.message);
          }
          }
        }
      }
      console.log('[SOOP KWS]', item.titleNo, 'proceeding to chat-chunk fetch, fileItems.length=', fileItems?.length);

      // 3) api.m 결과 없음
      if (!Array.isArray(fileItems) || !fileItems.length) {
        const isAuthRequired = fileItems?.authRequired === true;

        if (isAuthRequired) {
          base._subOnly = true; // 1.2.5: subscriber-only VOD — not counted as a fetch failure
          // 3a) 구독 전용 VOD → thumb 먼저 (빠름 — 검색 대상 스트리머 대부분은 구독 안 했을
          // 확률이 높아서, 매번 탭부터 열면 그 경우 다 느려짐). thumb로 찾은 결과가 불완전해
          // 보이면(진짜 구독 중이라 더 볼 게 있는 경우) 그때 탭으로 보완.
          broadcast(ctx, `Subscription-only VOD — checking access: ${item.title.slice(0, 20)}`);
          // 구독 여부 판정(view.subscribed): 구독 중이면 thumb 추측은 건너뛰고 바로 vodCore 탭,
          // 구독 안 했으면 탭을 열어도 소용없으니 thumb만으로 끝냄. 플래그가 없으면(undefined) 예전처럼 thumb→탭.
          const _subscribed = fileItems?.subscribed;
          console.log('[SOOP KWS]', titleNo, 'subscription-only: subscribed=', _subscribed);
          let baseKeys = _subscribed === true ? [] : (item.fileInfoKeys || []);
          const _hadPrefetchedKeys = baseKeys.length > 0;
          if (!baseKeys.length && _subscribed !== true) baseKeys = await fetchKeysFromApi(ctx.streamerId, titleNo);
          console.log('[SOOP KWS]', titleNo, 'subscription-only: baseKeys source=', _hadPrefetchedKeys ? 'item.fileInfoKeys(thumb, free)' : 'fetchKeysFromApi', 'count=', baseKeys.length, baseKeys.slice(0, 3));
          if (baseKeys.length) {
            const validResults = await filterValidChatKeys(baseKeys, ctx.keywords, 0);
            console.log('[SOOP KWS]', titleNo, 'subscription-only: filterValidChatKeys validated', validResults.length, 'of', baseKeys.length, '(this is what should light up the Thumb dot)');
            if (validResults.length) {
              const partDur = item.duration > 0 ? Math.floor(item.duration / validResults.length) : 10800;
              fileItems = validResults.map((r, i) => ({ key: r.key, duration: partDur, order: i + 1, _prefetched: r.parsed }));
              // 구독 안 한 VOD는 탭을 열어도 실제 파일 목록을 못 받음(플레이어가 미리보기/다른 영상을 로드하거나
              // 동시에 열린 다른 탭의 값이 잡힐 수 있음) → 그 값으로 '시간 보정 재스캔'을 하면 다른 VOD의 채팅이
              // 결과에 덮어써지는 버그가 있었음. subscribed===false면 보정 재스캔을 하지 않고 thumb 결과를 그대로 씀.
              if (_subscribed !== false) base._needsFix = true;
            }
          } else {
            console.log('[SOOP KWS]', titleNo, 'subscription-only: NO candidate keys at all (item.fileInfoKeys empty AND fetchKeysFromApi returned nothing) — filterValidChatKeys never runs, so Thumb dot genuinely has nothing to show; falling straight to tab.');
          }
          // thumb가 아무것도 못 찾았거나, 찾은 것치고 VOD 길이 대비 너무 적으면(진짜 구독중인데
          // thumb 추측 범위가 부족했을 가능성) → 탭으로 보완 시도
          const thumbTotalDur = Array.isArray(fileItems) ? fileItems.reduce((s, f) => s + (f.duration || 0), 0) : 0;
          const thumbLooksIncomplete = _subscribed === true ? true
            : _subscribed === false ? false // 구독 안 함 → 탭으로 가도 못 봄, thumb 결과로 끝
            : (!Array.isArray(fileItems) || !fileItems.length
              || (item.duration > 0 && thumbTotalDur < item.duration * 0.85));
          if (thumbLooksIncomplete) {
            base._usedTab = true; broadcast(ctx, `Subscription-only VOD — opening tab to verify: ${item.title.slice(0, 20)}`);
            try {
              const res = await Promise.race([
                netTabMessage({ type: 'OPEN_VOD_TAB', playerUrl: item.playerUrl }),
                new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 60000))
              ]);
              if (res?.success && res.fileItems?.length) {
                fileItems = res.fileItems
                  .map((f, i) => ({ key: f.file_info_key, duration: f.duration || 0, order: f.file_order || (i + 1) }))
                  .filter(f => f.key)
                  .sort((a, b) => a.order - b.order);
              }
            } catch {}
          }
        } else {
          // 3b) 일반 VOD api.m 실패 → 탭 열기
          base._usedTab = true; broadcast(ctx, `Not in normal file listing — opening tab to check: ${item.title.slice(0, 20)}`);
          try {
            const res = await Promise.race([
              netTabMessage({ type: 'OPEN_VOD_TAB', playerUrl: item.playerUrl }),
              new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 60000))
            ]);
            if (res?.success && res.fileItems?.length) {
              fileItems = res.fileItems
                .map((f, i) => ({ key: f.file_info_key, duration: f.duration || 0, order: f.file_order || (i + 1) }))
                .filter(f => f.key)
                .sort((a, b) => a.order - b.order);
            } else {
              broadcast(ctx, `Tab opened but couldn't read video data: ${titleNo}`);
            }
          } catch(tabErr) { broadcast(ctx, `Failed to open tab: ${tabErr?.message||tabErr}`); }
        }

        // 3c) 여전히 없으면 에러
        if (!Array.isArray(fileItems) || !fileItems.length) {
          broadcast(ctx, `ERROR: no file key for ${item.title.slice(0,25)} (${titleNo})`);
          return { ...base, status: 'ERROR: key 없음' };
        }
      }

      let matchCount = 0;
      const matchedLines = [], matchedEntries = [];
      let fileAccTime = 0;
      let totalChatsSeen = 0;
      let _subtitleAdded = false;
      // 채팅 조각 fetch가 "네트워크 일시 실패"로 끝난 건지, 아니면 실제로 그 시간대에
      // 채팅이 없어서(=정상) 빈 응답이 온 건지 구분하기 위한 플래그. 이 구분이 없으면
      // 네트워크가 잠깐 느려져서 요청 몇 개가 실패한 것뿐인데도 "파일 목록 자체가
      // 틀렸다"고 오판해서(아래 검증 1/2) 매번 무거운 탭 재검증으로 빠지게 됨 —
      // 게다가 탭에서 다시 채팅을 가져올 때도 결국 같은 background pool/네트워크를
      // 쓰므로 네트워크가 진짜로 느린 상황에서는 탭을 열어도 근본적으로 해결이 안 되고
      // 부하(탭 오픈 + 페이지 로드)만 늘어남.
      let hadUnresolvedFetchFailure = false;

      for (const fi of fileItems) {
        const key = fi.key;
        // perFileSec(수집 범위)는 넉넉하게 잡아도 안전하므로 VOD 전체 길이를 참고해도 무방함
        const fetchRangeHint = fi.duration > 0 ? fi.duration : (item.duration > 0 ? item.duration : 10800);
        const isClip = key.includes('clip_');
        const baseUrl = isClip
          ? `https://vod-normal-kr-cdn-z01.sooplive.co.kr/${key.split('_').join('/')}_c.xml?type=clip&rowKey=${key}_c`
          : `https://videoimg.sooplive.com/php/ChatLoadSplit.php?rowKey=${key}_c`;

        // 파일당 duration까지 300초 단위로 fetch (예전엔 12시간 하한이 있어서 짧은 VOD도 항상 144개 조각을 긁었음 — 낭비였음)
        // ⚠ item.duration(=VOD 전체 길이)을 여기 섞으면 안 됨 — 30-932줄 주석과 같은 이유.
        // 예전엔 Math.max(fetchRangeHint+600, item.duration+600)로 "안전하게" 잡는다고 했었는데,
        // 멀티파트 VOD에서 item.duration(예: 29시간)이 개별 파트 길이(예: 3시간)보다 훨씬 크니까
        // 사실상 모든 파트가 전체 VOD 길이만큼 300초 단위로 긁게 되는 버그였음 — 실제 파트 길이를
        // 훨씬 넘는 startTime 요청은 전부 서버에서 400으로 거부되는데, 파트 개수만큼 곱해지니까
        // (16파트 VOD면 요청량이 최대 10배 이상) 실제 스캔 속도 저하 + 실패율 폭증의 큰 원인이었음.
        const perFileSec = fetchRangeHint + 600;
        const startTimes = [];
        for (let t = 0; t <= perFileSec; t += 300) startTimes.push(t);

        const fetchChunk = async (t) => {
          // startTime=0은 filterValidChatKeys에서 이미 fetch했으면 재사용
          if (t === 0 && fi._prefetched) return fi._prefetched;
          const sep = baseUrl.includes('?') ? '&' : '?';
          try {
            return parseChatMatches(await fetchXmlWithRetry(`${baseUrl}${sep}startTime=${t}`), fileAccTime, ctx.keywords);
          } catch { return { matchCount: 0, lines: [], matches: [], maxT: 0, _fetchFailed: true }; }
        };
        const parts = await mapConc(startTimes, CHAT_CHUNK_CONC, fetchChunk);
        dropTailFailures(parts, startTimes, fi.duration > 0 ? fi.duration : fetchRangeHint);

        // fetchXmlWithRetry가 이미 내부적으로 최대 4회(도메인 2개 x 백오프)까지 재시도한
        // 뒤에도 실패한 조각들 — 일시적 혼잡일 가능성이 높으므로, 탭을 열기 전에 잠깐
        // 쉬었다가 그 조각들만 한 번 더 통째로 재시도함 (전체 파일을 다시 돌 필요 없음).
        let failedIdx = parts.reduce((arr, p, i) => { if (p._fetchFailed) arr.push(i); return arr; }, []);
        if (failedIdx.length) {
          await spDelay(1200);
          const retried = await mapConc(failedIdx, CHAT_CHUNK_CONC, (i) => fetchChunk(startTimes[i]));
          retried.forEach((p, j) => { parts[failedIdx[j]] = p; });
          failedIdx = parts.reduce((arr, p, i) => { if (p._fetchFailed) arr.push(i); return arr; }, []);
          if (failedIdx.length) hadUnresolvedFetchFailure = true;
        }

        let fileMaxT = 0;
        for (const p of parts) {
          matchCount += p.matchCount;
          matchedLines.push(...p.lines);
          matchedEntries.push(...p.matches);
          if (p.maxT > fileMaxT) fileMaxT = p.maxT;
          totalChatsSeen += p.totalChats || 0;
        }

        // 자막(CC) 검색 — 옵션이 켜져 있고 클립이 아닐 때만. 자막이 없는 VOD/파일은 첫 요청이 비어서 바로 끝남.
        if (soopSearchSubtitles && !isClip) {
          try {
            const sub = await searchSubtitlesForFile(titleNo, key, fi.duration > 0 ? fi.duration : fetchRangeHint, fileAccTime, ctx.keywords);
            if (sub.matches.length) {
              matchCount += sub.matches.length;
              matchedLines.push(...sub.lines);
              matchedEntries.push(...sub.matches);
              _subtitleAdded = true;
            }
          } catch (e) { console.log('[SOOP KWS] subtitle search failed for', key, e?.message); }
        }

        // 다음 파일 fileAccTime 증분 우선순위:
        // 1) 이 파일 파트 자체의 실제 API duration (가장 정확)
        // 2) 실제로 파싱된 채팅 로그의 최대 타임스탬프(fileMaxT) — VOD 전체 길이를 잘못 쓰는 것보다 훨씬 정확
        // 3) VOD 전체 길이를 파트 개수로 나눈 평균 추정치
        // 4) 최후 fallback
        // ⚠ item.duration(=VOD 전체 길이)을 "이 파트 하나"의 길이로 쓰면 안 됨 — 멀티파트 VOD에서
        //    이후 파트들의 매칭 시각이 전부 크게 밀리는 원인이었음 (예: 3파트 VOD에서 1파트만 duration이
        //    비어있으면 fileAccTime이 전체 길이만큼 점프해버림)
        fileAccTime += fi.duration > 0
          ? fi.duration
          : fileMaxT > 0
            ? fileMaxT
            : (item.duration > 0 && fileItems.length > 0)
              ? Math.floor(item.duration / fileItems.length)
              : perFileSec;
      }

      if (_subtitleAdded) matchedEntries.sort((a, b) => (a.seconds || 0) - (b.seconds || 0));
      console.log('[SOOP KWS] scan summary for', titleNo, { vodTotalDur, fileAccTime, totalChatsSeen, matchCount, fileCount: fileItems?.length, hadUnresolvedFetchFailure });

      // 스캔 후 검증 1: 실제로 커버한 시간(fileAccTime)이 VOD 전체 길이보다 눈에 띄게 짧으면
      // (예: 15% 이상 부족) → api.m이 알려준 파일 목록 자체가 불완전했다는 뜻. 사전 duration
      // 비교로는 못 잡는 경우가 있어서(부분적으로만 짧은 케이스), 스캔 후에 한 번 더 검증함.
      // 탭 모드거나 이미 재검증된 경우는 다시 돌 필요 없음.
      // ⚠ hadUnresolvedFetchFailure(재시도까지 했는데도 요청 자체가 실패)인 경우는 제외함 —
      // 이건 "파일 목록이 틀렸다"가 아니라 "네트워크가 느리다/혼잡하다"는 신호라서, 탭을
      // 열어도 결국 같은 pool로 채팅을 다시 받아와야 해서 근본 해결이 안 되고 탭 오픈 +
      // 페이지 로드 부하만 추가됨. 이런 경우는 있는 그대로의 결과(부분 실패 표시)를 반환.
      if (!base._usedTab && !hadUnresolvedFetchFailure && vodTotalDur > 0 && fileAccTime > 0 && fileAccTime < vodTotalDur * 0.85 && !fileItems._verified) {
        return { ...base, matchCount, matchedLines, matchedEntries, sample: matchedLines[0] || '', _needsFullRescan: true, _usedTab: true };
      }

      // 스캔 후 검증 2: 시간 커버리지는 정상인데도 채팅 자체가 거의(또는 전혀) 안 나온 경우 —
      // 파일 목록/길이는 맞다고 나와도 실제 채팅 조각 응답이 비어있거나 깨진 상태일 수 있음.
      // 매칭 여부와 무관하게 "채팅이 원래 이렇게 적을 리 없다" 싶으면 조용히 스킵되지 않도록
      // 탭으로 재검증 (30분 넘는 VOD에서 채팅이 5개 미만이면 의심스러운 걸로 봄)
      // — 마찬가지로 재시도 후에도 남은 fetch 실패가 원인이면 탭을 열지 않음(검증 1과 동일 이유).
      if (!base._usedTab && !hadUnresolvedFetchFailure && vodTotalDur > 1800 && totalChatsSeen < 5 && !fileItems._verified) {
        return { ...base, matchCount, matchedLines, matchedEntries, sample: matchedLines[0] || '', _needsFullRescan: true, _usedTab: true };
      }

      if (hadUnresolvedFetchFailure) {
        return { ...base, matchCount, matchedLines, matchedEntries, sample: matchedLines[0] || '', status: 'OK (일부 조각 fetch 실패 — 네트워크 혼잡 가능성)', _hadFetchFailure: true };
      }
      return { ...base, matchCount, matchedLines, matchedEntries, sample: matchedLines[0] || '' };
    } catch (err) { return { ...base, status: `ERROR: ${err.message}` }; }
  }

  // scanVod 내부 어디서 멈추든(원인 불문) 한 VOD가 통째로 몇 분씩 잡아먹지 않도록 절대 상한을 걸어둠
  async function scanVodWithTimeout(ctx, item, ms) {
    // VOD가 길수록 채팅 조각을 더 많이 가져와야 해서 고정 90초로는 부족할 수 있음 —
    // 길이에 비례해서 넉넉하게 늘림 (최대 10분 상한)
    // 1.2.5.51: was duration×5 ms — only 90 s for a 5-hour VOD (61 chunks + subtitles + retries, while
    // up to 4 channels share the request pool) → "scanVod watchdog timeout" on long VODs.
    // Now ~50 ms per VOD second: 3 min minimum, 15 min for 5 h, 25 min at most.
    const effectiveMs = ms || Math.min(1500000, Math.max(180000, (item.duration || 0) * 50));
    try {
      return await Promise.race([
        scanVod(ctx, item),
        new Promise((_, reject) => setTimeout(() => reject(new Error('scanVod watchdog timeout')), effectiveMs))
      ]);
    } catch (e) {
      return { title: item.title, playerUrl: item.playerUrl, dateText: item.dateText, page: item.page, matchCount: 0, matchedLines: [], matchedEntries: [], sample: '', status: `ERROR: ${e?.message || e}`, _usedTab: true };
    }
  }

  // ── 유틸 ─────────────────────────────────────────────────
  // 스트리머 닉네임 조회 — 여러 엔드포인트 시도
  async function fetchStreamerNick(streamerId) {
    if (!streamerId) return null;
    // 캐시 사용 안 함 - 항상 최신 닉네임 API에서 조회
    const urls = [
      `https://chapi.sooplive.com/api/${encodeURIComponent(streamerId)}/station`,
      `https://bjapi.sooplive.co.kr/api/${encodeURIComponent(streamerId)}/station`,
      `https://chapi.sooplive.com/api/${encodeURIComponent(streamerId)}/vods/review?page=1`,
    ];
    for (const url of urls) {
      try {
        const resp = await fetchWT(url, { credentials: 'include' }, 8000);
        if (!resp.ok) continue;
        const json = await resp.json();
        const nick =
          json?.data?.user_nick ||
          json?.data?.station?.user_nick ||
          json?.data?.nick ||
          json?.user_nick ||
          // vods/review 응답의 첫 항목 user_nick
          json?.data?.[0]?.user_nick ||
          null;
        if (nick) return nick;
      } catch { continue; }
    }
    return null;
  }

  // 🕐 Fix Time: 탭 열어서 vodCore.fileItems로 정확한 accTime 계산 후 카드 시간 재계산

  // vodCore fileItems를 직접 받아서 스캔
  async function scanVodWithFileItems(item, fileItems, keywords) {
    const base = { matchCount: 0, matchedLines: [], matchedEntries: [] };
    // 여기는 이미 탭까지 열어서 "진짜" 파일 목록을 확보한 마지막 단계라, 더 이상 재검증할
    // 곳이 없음 — scanVod처럼 뒤에서 탭으로 재확인해줄 안전망이 없으므로, 조각 fetch가
    // 실패했는데도 조용히 0건으로 넘어가면 그대로 "매칭 없음"으로 굳어버림. 그래서 여기는
    // 탭 fallback 판단 대신, 실패한 조각만 재시도하고 그래도 남으면 최소한 결과에 표시함.
    let hadUnresolvedFetchFailure = false;
    try {
      let fileAccTime = 0;
      for (const fi of fileItems) {
        const key = fi.key;
        const fileDuration = fi.duration > 0 ? fi.duration : 10800;
        const baseUrl = `https://videoimg.sooplive.com/php/ChatLoadSplit.php?rowKey=${key}_c`;
        // perFileSec: vodCore duration 기준으로 충분히 커버
        const perFileSec = fileDuration + 600;
        const startTimes = [];
        for (let t = 0; t <= perFileSec; t += 300) startTimes.push(t);
        const fetchChunk = async (t) => {
          try {
            return parseChatMatches(await fetchXmlWithRetry(`${baseUrl}&startTime=${t}`), fileAccTime, keywords);
          } catch { return { matchCount: 0, lines: [], matches: [], maxT: 0, _fetchFailed: true }; }
        };
        const parts = await mapConc(startTimes, CHAT_CHUNK_CONC, fetchChunk);
        dropTailFailures(parts, startTimes, fileDuration);

        // fetchXmlWithRetry가 이미 내부적으로 재시도한 뒤에도 실패한 조각들 — 한 번 더
        // 통째로 재시도 (scanVod의 동일 로직과 같은 이유)
        let failedIdx = parts.reduce((arr, p, i) => { if (p._fetchFailed) arr.push(i); return arr; }, []);
        if (failedIdx.length) {
          await spDelay(1200);
          const retried = await mapConc(failedIdx, CHAT_CHUNK_CONC, (i) => fetchChunk(startTimes[i]));
          retried.forEach((p, j) => { parts[failedIdx[j]] = p; });
          failedIdx = parts.reduce((arr, p, i) => { if (p._fetchFailed) arr.push(i); return arr; }, []);
          if (failedIdx.length) { hadUnresolvedFetchFailure = true; console.warn('[SOOP KWS] scanVodWithFileItems: unresolved fetch failures for', key, failedIdx.length, 'of', startTimes.length, 'chunks'); }
        }

        let fileMaxT = 0;
        for (const p of parts) {
          base.matchCount += p.matchCount;
          base.matchedLines.push(...p.lines);
          base.matchedEntries.push(...p.matches);
          if (p.maxT > fileMaxT) fileMaxT = p.maxT;
        }
        // vodCore duration vs 실제 fileMaxT 중 큰 값 사용
        // vodCore duration이 더 정확한 경우(채팅 없는 끝부분)도 커버
        if (fileMaxT > 0) fileAccTime += Math.max(fileMaxT, fileDuration);
        else fileAccTime += fileDuration;
      }
    } catch {}
    if (hadUnresolvedFetchFailure) base._hadFetchFailure = true;
    return base;
  }

  function extractKeysFromThumb(thumbUrl) {
    if (!thumbUrl) return [];
    const m = thumbUrl.match(/rowKey=([^&]+)/);
    if (!m) return [];
    // _2_r → 파트 번호 추출 후 1~N 모두 시도할 수 있도록 base key 반환
    const raw = m[1].replace(/_r$/, '').replace(/_r&.*$/, '');
    if (!raw) return [];
    // 파트 번호가 있으면 (_숫자 패턴) base prefix 추출
    const partMatch = raw.match(/^(.+)_(\d+)$/);
    if (partMatch) {
      const prefix = partMatch[1];
      const partNum = parseInt(partMatch[2]);
      // 파트 번호 주변까지 넉넉하게 추측 (1부터 시작) — 추측 하나당 가벼운 요청 하나라
      // 범위를 넓게 잡아도 비용이 크지 않음
      const keys = [];
      const maxPart = Math.max(partNum + 15, 15, Math.min(partNum * 3, 60));
      for (let i = 1; i <= maxPart; i++) keys.push(`${prefix}_${i}`);
      return keys;
    }
    return [raw];
  }

  // 실제 존재하는 파트만 필터링 + startTime=0 채팅 데이터도 함께 반환
  // → 파트 확인과 첫 번째 채팅 fetch를 한 번의 요청으로 처리
  //
  // fetchXmlWithRetry와 마찬가지로 background.js의 SOOP_CHAT_GLOBAL_POOL에 "지금 나가도
  // 되는지"만 게이트로 물어보고, 실제 fetch는 여기(페이지 컨텍스트)서 직접 함 — 서비스워커
  // 에서 직접 fetch하면 SOOP 서버가 400으로 거부하는 문제가 있었음(fetchXmlWithRetry
  // 주석 참고). "존재하지 않는 파트 추측"은 실패가 정상 흐름이라 재시도는 하지 않음.
  async function filterValidChatKeys(keys, keywords, accTime) {
    const results = [];
    const fetchOnce = async (key) => {
      // 구독 전용 VOD에서 thumb로 추측한 키가 실제로 존재하는지 검증하는 요청 — 이것도
      // 개념적으로는 "Thumb" 단계에 속하는 네트워크 활동이라 네트워크 배너의 Thumb
      // 인디케이터를 켬(예전엔 이 fetchOnce가 아무 카운터에도 안 잡혀서, 구독 전용 VOD를
      // 처리하는 동안 Thumb 표시등이 계속 꺼져 있는 것처럼 보였음).
      netBump('thumb', 1);
      try {
        await new Promise((resolve) => {
          chrome.runtime.sendMessage({ type: 'SOOP_POOL_ACQUIRE' }, resolve);
        });
        let text = null, status = null;
        try {
          const r = await fetchWT(
            `https://videoimg.sooplive.com/php/ChatLoadSplit.php?rowKey=${key}_c&startTime=0`,
            {}, 5000
          );
          if (r && r.ok) text = await r.text();
          else status = r?.status;
        } catch (e) {}
        chrome.runtime.sendMessage({ type: 'SOOP_POOL_DONE', ok: !!text, status }).catch(() => {});
        if (!text) return null;
        const xml = new DOMParser().parseFromString(text, 'text/xml');
        const parsed = (keywords && accTime != null) ? parseChatMatches(xml, accTime, keywords) : null;
        return { key, parsed };
      } finally {
        netBump('thumb', -1);
      }
    };
    await Promise.all(keys.map(async key => {
      // 네트워크 순간 지연/실패로 유효한 파트를 놓치는 걸 줄이기 위해 재시도.
      // ⚠ 이 함수는 구조상 "그 키가 진짜로 존재하지 않음"과 "요청 자체가 실패함"을 서버
      // 응답만으로는 구분할 수 없음(둘 다 not-ok로 옴) — 애초에 key 추측(guessing) 용도라
      // 대부분의 키가 진짜로 존재하지 않는 게 정상이라, 실패 카운트를 추적해도 깨끗한
      // 신호가 안 됨. 대신 2회→3회로 재시도 횟수만 늘려서 순간 네트워크 실패로 실제
      // 존재하는 파트를 "없다"고 오판할 확률을 낮춤.
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          const res = await fetchOnce(key);
          if (res) { results.push(res); return; }
          if (attempt < 2) await spDelay(400 * (attempt + 1));
        } catch {
          if (attempt < 2) await spDelay(400 * (attempt + 1));
        }
      }
    }));
    return results.sort((a, b) => {
      const na = parseInt(a.key.match(/(\d+)$/)?.[1] || 0);
      const nb = parseInt(b.key.match(/(\d+)$/)?.[1] || 0);
      return na - nb;
    });
  }

  // api.m.sooplive.co.kr/station/video/a/view 로 정확한 파일 목록 취득
  // 반환: [{ key, duration(초), order }] — file_order 순 정렬
  // nApiLevel=11: SOOP 자체 공식 VOD 플레이어(main.js 번들, 함수 S8)가 실제로 이 값으로
  // 이 엔드포인트를 호출하는 것을 라이브 코드에서 직접 확인함 — 예전엔 10을 썼는데,
  // 공식 클라이언트와 동일하게 맞춰서 혹시 있을 수 있는 레벨별 응답 차이(특히 긴 VOD의
  // 파일 목록 누락) 가능성을 줄이기 위해 11로 통일.
  async function fetchFileItems(titleNo) {
    try {
      // 호스트: 공식 플레이어는 api.m.sooplive.com을 씀. 로그인 세션(구독 포함)은 .com 쪽에서만
      // 인식됨 — .co.kr로 부르면 구독 중이어도 subscribed=false/files=[]로 나옴(직접 확인).
      // 그래서 .com 우선, 실패하면 .co.kr로 폴백.
      let json = null;
      for (const host of ['api.m.sooplive.com', 'api.m.sooplive.co.kr']) {
        try {
          const resp = await fetchWT(`https://${host}/station/video/a/view`, {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `nTitleNo=${titleNo}&nApiLevel=11`
          }, 8000);
          if (!resp.ok) continue;
          const j = await resp.json();
          if (j?.data) { json = j; break; }
        } catch {}
      }
      if (!json) return null;
      // auth_no=107: 구독 전용 VOD → files 비어있음
      const authNo = json?.data?.auth_no;
      const files = json?.data?.files || [];
      if (!files.length) {
        if (authNo && authNo > 101) {
          // view 응답의 subscribed 플래그: 이 계정이 해당 스트리머를 구독 중인지 (true/false, 없으면 undefined=모름)
          const sub = json?.data?.subscribed;
          return { authRequired: true, authNo, subscribed: typeof sub === 'boolean' ? sub : undefined };
        }
        return null;
      }
      const sorted = files
        .sort((a, b) => (a.file_order || 0) - (b.file_order || 0))
        .map(f => ({
          key: f.file_info_key,
          duration: (() => {
            const raw = f.duration || 0;
            // api.m은 항상 ms 단위
            return Math.floor(raw / 1000);
          })(),
          order: f.file_order
        }))
        .filter(f => f.key);
      // 파일 order 번호에 갭이 있으면 needsFix 표시
      const orders = sorted.map(f => f.order);
      const hasGap = orders.some((o, i) => i > 0 && o - orders[i-1] > 1);
      if (hasGap) sorted._hasGap = true;
      return sorted;
    } catch { return null; }
  }

  const _streamerVodThumbCache = new Map(); // streamerId -> Map(titleNo -> thumbUrl)
  const _streamerVodThumbInFlight = new Map(); // streamerId -> in-flight Promise (동시 워커들이 같이 기다림)

  async function buildStreamerVodThumbMap(streamerId) {
    if (_streamerVodThumbCache.has(streamerId)) return _streamerVodThumbCache.get(streamerId);
    if (_streamerVodThumbInFlight.has(streamerId)) return _streamerVodThumbInFlight.get(streamerId);
    netBump('thumb', 1); // 네트워크 배너의 "Thumb" 원형 인디케이터 — VOD 목록/썸네일 조회가 나가있는 동안만 켜짐
    const promise = (async () => {
      const map = new Map();
      const fetchKindPages = async (kind) => {
        let page = 1;
        const BATCH = 3;
        while (page <= 10) {
          const batchPages = [];
          for (let i = 0; i < BATCH && page <= 10; i++, page++) batchPages.push(page);
          const results = await Promise.all(batchPages.map(p =>
            fetchWT(`https://chapi.sooplive.com/api/${encodeURIComponent(streamerId)}/vods/${kind}?page=${p}`, { credentials: 'include' }, 8000)
              .then(resp => resp.ok ? resp.json() : null)
              .catch(() => null)
          ));
          let hitEmpty = false;
          for (const json of results) {
            const list = Array.isArray(json?.data) ? json.data : [];
            if (!list.length) { hitEmpty = true; continue; }
            for (const v of list) {
              const key = String(v.title_no);
              if (!map.has(key)) map.set(key, v.ucc?.thumb || '');
            }
          }
          if (hitEmpty) break; // 이 배치 안에서 빈 페이지 나오면 그 뒤로는 더 없다고 보고 중단
        }
      };
      await Promise.all(['review', 'highlight'].map(kind => fetchKindPages(kind).catch(() => {})));
      _streamerVodThumbCache.set(streamerId, map);
      return map;
    })();
    _streamerVodThumbInFlight.set(streamerId, promise);
    try {
      return await promise;
    } finally {
      _streamerVodThumbInFlight.delete(streamerId);
      netBump('thumb', -1);
    }
  }

  async function fetchKeysFromApi(streamerId, titleNo) {
    const map = await buildStreamerVodThumbMap(streamerId);
    const thumb = map.get(String(titleNo));
    if (!thumb) return [];
    return extractKeysFromThumb(thumb);
  }

  // 채팅 조각(ChatLoadSplit.php) fetch.
  // background.js의 SOOP_CHAT_GLOBAL_POOL(동시성 상한 + 429 공유 쿨다운)에 "지금 나가도
  // 되는지"만 물어보고, 실제 fetch는 여기(콘텐츠 스크립트, sooplive.com 페이지 컨텍스트)
  // 에서 직접 함 — 한때 fetch 자체를 서비스워커로 옮겼다가, 서비스워커의
  // chrome-extension:// 오리진으로 나간 요청을 SOOP 서버가 전부 400으로 거부하는
  // 회귀를 겪음(2026-09, 실측: ChatLoadSplit.php 요청 1718건 중 대다수가 400/실패).
  // 페이지 컨텍스트에서 쏴야 정상적인 sooplive.com Referer/Origin이 자동으로 붙음.
  // 파일 끝 뒤쪽 실패 무시: SOOP은 채팅 마지막 조각 뒤 구간을 500으로 답함(직접 확인, 같은 요청이 3/3 500).
  // "마지막으로 성공한 조각 이후" + "파일 길이-600초 이후 구간"의 실패는 데이터가 없는 것이지 유실이 아니므로
  // 빈 결과로 바꿔서 재시도/'일부 누락' 표시 대상에서 뺌. 중간 구간 실패는 그대로 실패로 남김.
  function dropTailFailures(parts, startTimes, durationSec) {
    let lastOk = -1;
    for (let i = parts.length - 1; i >= 0; i--) if (!parts[i]._fetchFailed) { lastOk = i; break; }
    if (lastOk < 0) return;
    for (let i = lastOk + 1; i < parts.length; i++) {
      if (parts[i]._fetchFailed && startTimes[i] >= durationSec - 600) {
        parts[i] = { matchCount: 0, lines: [], matches: [], maxT: 0, totalChats: 0 };
      }
    }
  }

  async function fetchXmlWithRetry(url, attempt = 0) {
    netBump('api', 1); // 네트워크 배너의 "API" 원형 인디케이터 — 채팅 조각 요청이 실제로 나가있는 동안만 켜짐
    try {
      await new Promise((resolve) => {
        chrome.runtime.sendMessage({ type: 'SOOP_POOL_ACQUIRE' }, resolve);
      });

      // .com / .co.kr 둘 다 시도 (SOOP 도메인 수시 변경 대응)
      const urls = [url];
      if (url.includes('videoimg.sooplive.com')) urls.push(url.replace('videoimg.sooplive.com', 'videoimg.sooplive.co.kr'));
      else if (url.includes('videoimg.sooplive.co.kr')) urls.push(url.replace('videoimg.sooplive.co.kr', 'videoimg.sooplive.com'));

      let lastErr = null, text = null, sawStatus = null, retryAfter = null, non404 = false;
      for (let ui = 0; ui < urls.length; ui++) {
        const u = urls[ui];
        try {
          const res = await fetchWT(u, {}, 10000);
          if (res.ok) { text = await res.text(); break; }
          // 1.2.5.33: the other domain (videoimg.sooplive.co.kr) now answers 400 to everything (checked
          // 2026-10). That 400 used to overwrite the main domain's 404 "no chat in this 5 min" answer,
          // so every quiet stretch turned into a failed chunk (4 retries each) and whole VODs were
          // reported as "couldn't fetch". A 400 from the fallback domain says nothing — ignore it.
          if (ui > 0 && res.status === 400) continue;
          sawStatus = res.status;
          if (res.status !== 404 && res.status !== 500) non404 = true; // 404/500 = 서버가 '그 구간 데이터 없음'으로 답하는 정해진 응답(직접 확인), 429/타임아웃 등과 구분
          if (res.status === 429) retryAfter = res.headers.get('retry-after');
          lastErr = new Error(`HTTP ${res.status}`);
          // the main domain's 404/500 is a definite "nothing here" — no need to ask the other one
          if (ui === 0 && (res.status === 404 || res.status === 500)) break;
        } catch (e) {
          lastErr = e; non404 = true;
        }
      }
      chrome.runtime.sendMessage({ type: 'SOOP_POOL_DONE', ok: !!text, status: sawStatus, retryAfter }).catch(() => {});

      if (text) return new DOMParser().parseFromString(text, 'text/xml');
      // 두 도메인 모두 404 = 파일 끝을 넘은 startTime(직접 확인: 실제 길이 이후 조각은 404). 장애가 아니라
      // "더 이상 채팅 없음"이라서 재시도/실패 처리하지 않고 빈 문서로 돌려줌 — 예전엔 이게 파일마다
      // 최대 20번씩 재시도된 뒤 "일부 누락"으로 잘못 표시되는 원인이었음. 일시 오류 대비 1번만 재확인.
      if (!non404 && (sawStatus === 404 || sawStatus === 500)) {
        // 1.2.5.38: a 500 is mostly SOOP's server under load (seen ×200+ in one run, while chunks past the
        // end answer 404 now) — give it a few spaced retries; a 404 still gets just one quick re-check.
        if (sawStatus === 500 && attempt < 3) { await spDelay(700 * (attempt + 1)); return fetchXmlWithRetry(url, attempt + 1); }
        if (sawStatus === 404 && attempt < 1) { await spDelay(300); return fetchXmlWithRetry(url, attempt + 1); }
        if (sawStatus === 404) return new DOMParser().parseFromString('<chats/>', 'text/xml');
        // 500이 반복되면(직접 확인: 채팅 마지막 조각 뒤 구간은 500으로 답함) 더 재시도하지 않고 실패로 올림.
        // 파일 끝 뒤쪽 실패인지는 호출쪽에서 "마지막 성공 조각 이후"로 판단해서 무시함.
        soopNoteFail((lastErr && lastErr.message) || 'HTTP 500');
        throw lastErr || new Error('HTTP 500');
      }
      if (attempt < 4) { await spDelay(400 * (attempt + 1)); return fetchXmlWithRetry(url, attempt + 1); }
      soopNoteFail((lastErr && (lastErr.name === 'AbortError' ? 'timeout' : lastErr.message)) || 'fetch failed');
      throw lastErr || new Error('fetch failed on all domains');
    } finally {
      netBump('api', -1);
    }
  }

  // ── 자막(CC) 검색 ────────────────────────────────────────
  // translate-api.sooplive.com/subtitle/vod/{titleNo}?lang=&fileInfoKey=&startTime= → { threshold, list:[{msg,pos}] }
  // pos = 파일 시작 기준 초, 한 번에 threshold(기본 1800초) 구간. 로그인/쿠키 불필요(credentials 넣으면 CORS로 막힘).
  // 자막은 롤링 형태라(앞 문장이 조금씩 겹쳐서 연속으로 나옴) 같은 키워드가 인접 줄에 반복 매칭됨 → 12초 안 중복은 합침.
  async function searchSubtitlesForFile(vodNo, fileKey, durationSec, accTime, keywords, lang = 'ko_KR') {
    const out = { matches: [], lines: [] };
    if (!vodNo) return out; // URL 경로에는 채팅 키의 방송ID가 아니라 VOD title_no가 들어감
    const parsedKw = splitSoopKeywords(keywords);
    let step = 1800;
    let lastHit = new Map(); // keyword set -> 마지막 매칭 초
    for (let t = 0; t <= durationSec + 60; t += step) {
      let json = null;
      try {
        const resp = await fetchWT(`https://translate-api.sooplive.com/subtitle/vod/${vodNo}?lang=${encodeURIComponent(lang)}&fileInfoKey=${encodeURIComponent(fileKey)}&startTime=${t}`, {}, 10000);
        if (!resp.ok) break;
        json = await resp.json();
      } catch { break; }
      const list = Array.isArray(json?.list) ? json.list : [];
      if (Number(json?.threshold) > 0) step = Number(json.threshold);
      if (!list.length && t === 0) break; // 자막 없는 VOD/파일
      for (const it of list) {
        const m = String(it.msg || '');
        const lowerM = m.toLowerCase();
        if (parsedKw.exclude.some(x => x && lowerM.includes(x))) continue;
        const hit = parsedKw.include.filter(k => k.word && (k.substring ? lowerM.includes(k.word) : soopWholeWord(lowerM, k.word))).map(k => k.word);
        if (!hit.length) continue;
        const rawPos = Number(it.pos) || 0;
        const hk = hit.join('|');
        if (lastHit.has(hk) && rawPos - lastHit.get(hk) < 12 && rawPos >= lastHit.get(hk)) continue;
        lastHit.set(hk, rawPos);
        const secs = Math.max(0, Math.floor(rawPos + accTime));
        const label = toHMS(secs);
        out.lines.push(`${label} [CC] ${m} {매칭: ${hit.join(', ')}}`);
        out.matches.push({ seconds: secs, timeLabel: label.replace(/^\[|\]$/g, ''), userId: 'subtitle', nickname: 'Subtitle (CC)', message: m, matchedKeywords: hit, _subtitle: true });
      }
    }
    return out;
  }

  // xmlToJson 방식 대신 querySelector 직접 사용 (정확한 <t> 값 파싱)
  let _lastParsedKwSrc = null, _lastParsedKw = null;
  function parseChatMatches(xmlDoc, accTime, keywords) {
    // xmlDoc: DOMParser로 파싱된 XML Document
    const chats = xmlDoc?.querySelectorAll ? xmlDoc.querySelectorAll('chat') : [];
    let matchCount = 0, maxT = 0;
    const lines = [], matches = [];
    // 키워드 파싱은 스캔 내내 동일하므로, 같은 참조면 재사용 (매 300초 청크마다 208개 단어를
    // 다시 split/정규화하던 게 대량 스캔에서 큰 병목이었음)
    let parsedKw;
    if (keywords === _lastParsedKwSrc) {
      parsedKw = _lastParsedKw;
    } else {
      parsedKw = splitSoopKeywords(keywords);
      _lastParsedKwSrc = keywords;
      _lastParsedKw = parsedKw;
    }
    for (const c of chats) {
      const rawT = parseFloat(c.querySelector('t')?.textContent || '0') || 0;
      if (rawT > maxT) maxT = rawT;
      const u = (c.querySelector('u')?.textContent || '').split('(')[0];
      const n = c.querySelector('n')?.textContent || '';
      const m = c.querySelector('m')?.textContent || '';
      const lowerM = m.toLowerCase();
      if (parsedKw.exclude.some(x => x && lowerM.includes(x))) continue;
      const hit = parsedKw.include.filter(k => k.word && (k.substring ? lowerM.includes(k.word) : soopWholeWord(lowerM, k.word))).map(k => k.word);
      if (!hit.length) continue;
      const secs = Math.max(0, Math.floor(rawT + accTime));
      const label = toHMS(secs);
      matchCount++;
      lines.push(`${label} ${n}(${u}): ${m} {매칭: ${hit.join(', ')}}`);
      matches.push({ seconds: secs, timeLabel: label.replace(/^\[|\]$/g, ''), userId: u, nickname: n, message: m, matchedKeywords: hit });
    }
    return { matchCount, lines, matches, maxT, totalChats: chats.length };
  }

  function xmlToJson(xml) {
    let obj = {};
    if (xml.nodeType === 1) {
      if (xml.attributes.length) { obj['@attributes'] = {}; for (let j = 0; j < xml.attributes.length; j++) { const a = xml.attributes.item(j); obj['@attributes'][a.nodeName] = a.nodeValue; } }
    } else if (xml.nodeType === 3 || xml.nodeType === 4) return xml.nodeValue;
    if (xml.hasChildNodes()) { for (let i = 0; i < xml.childNodes.length; i++) { const item = xml.childNodes.item(i), name = item.nodeName; if (typeof obj[name] === 'undefined') obj[name] = xmlToJson(item); else { if (typeof obj[name].push === 'undefined') { const old = obj[name]; obj[name] = [old]; } obj[name].push(xmlToJson(item)); } } }
    return obj;
  }

  function toHMS(s) { s = Math.max(0, Math.floor(s)); return `[${p2(Math.floor(s / 3600))}:${p2(Math.floor((s % 3600) / 60))}:${p2(s % 60)}]`; }
  function p2(n) { return String(n).padStart(2, '0'); }
  function normalizeKeywords(s) { return String(s || '').split(',').map(v => v.trim()).filter(Boolean); }
  function safeKwStrings(kws) {
    const arr = Array.isArray(kws) ? kws : normalizeKeywords(kws);
    return arr.map(k => {
      if (k && typeof k === 'object' && k.word) return k.word;
      return String(k || '').replace(/^[~+]/, '');
    }).filter(Boolean);
  }
  function kwPreview(kws, max = 3) {
    const words = safeKwStrings(kws).filter(w => !String(w).startsWith('-'));
    if (!words.length) return 'default keywords';
    const shown = words.slice(0, max).join(', ');
    const more = words.length - max;
    return more > 0 ? `${shown} +${more} more` : shown;
  }
  function splitSoopKeywords(keywords){
    const arr = Array.isArray(keywords) ? keywords : normalizeKeywords(keywords);
    const include = [], exclude = [];
    for (const raw of arr) {
      const v = String(raw||'').trim(); if (!v) continue;
      if (v.startsWith('-')) exclude.push(v.replace(/^-+/, '').toLowerCase());
      else include.push({ word: v.replace(/^[~+]+/, '').toLowerCase(), substring: v.startsWith('~') });
    }
    return { include, exclude };
  }
  const _wholeWordRegexCache = new Map();
  function soopWholeWord(text, word){
    let cached = _wholeWordRegexCache.get(word);
    if (cached === undefined) {
      // CJK 한자/카나, 태국어만 substring 취급 (띄어쓰기 관습이 없어서 "단어 경계" 개념 자체가 안 맞음).
      // 그 외 전부(영어/독일어/체코어·슬로바키아어 같은 악센트 붙은 라틴 문자/러시아어/한국어/
      // 아랍어 등)는 유니코드 인식 단어 경계로 통일 처리 — 예전엔 순수 ASCII만 경계 체크하고
      // 나머지는 전부 substring 폴백이라 "čká"가 "počkať" 안에서도 매칭되는 버그가 있었음.
      if (/[\u4E00-\u9FFF\u3040-\u30FF\u0E00-\u0E7F]/i.test(word)) {
        cached = null; // 플레인 텍스트로 처리 (includes 사용)
      } else {
        const esc = word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        try { cached = new RegExp(`(?<![\\p{L}\\p{N}])${esc}(?![\\p{L}\\p{N}])`, 'iu'); }
        catch (e) { cached = null; }
      }
      _wholeWordRegexCache.set(word, cached);
    }
    return cached ? cached.test(text) : text.includes(word);
  }
  function checkStop(ctx) { if (ctx.stopRequested) throw new Error('Stopped'); }
  async function mapConc(items, n, fn) {
    const res = new Array(items.length); let cur = 0;
    await Promise.all(Array.from({ length: Math.min(n, items.length || 1) }, async () => { while (cur < items.length) { const i = cur++; res[i] = await fn(items[i], i); } }));
    return res;
  }
  // ── 사이트 배지 주입 ──────────────────────────────────────
  let _badgeTimer = null;
  let _soopBadgeObserver = null;
  function updateActiveBadges() {
    const badges = document.querySelectorAll('.soop-search-badge');
    // 스캔 중인 스트리머 배지들 — Twitch KWS와 동일한 오렌지색 (동시 실행 중인 모든 ctx 반영)
    for (const ctx of Object.values(SCAN_STATES)) {
      if (!ctx.running || !ctx.streamerId) continue;
      const pct = ctx.vodItems?.length ? Math.round((ctx.completedVodCount / Math.max(ctx.vodItems.length, 1)) * 100) : 0;
      badges.forEach(badge => {
        if (badge.dataset.streamerId === ctx.streamerId) {
          badge.textContent = ctx.phase === 'finished' ? 'Done' : `⏳${pct}%`;
          badge.style.background = 'rgba(251,146,60,0.15)';
          badge.style.borderColor = 'rgba(251,146,60,0.35)';
          badge.style.color = '#fb923c';
        }
      });
    }
    // 대기열 배지 — Cyan
    if (SCAN_QUEUE.length) {
      const queuedIds = new Set(SCAN_QUEUE.map(q => q.streamerId));
      badges.forEach(badge => {
        if (queuedIds.has(badge.dataset.streamerId)) {
          badge.textContent = 'queued';
          badge.style.background = 'rgba(6,182,212,0.12)';
          badge.style.borderColor = 'rgba(6,182,212,0.35)';
          badge.style.color = '#22d3ee';
        }
      });
    }
  }

  function injectSiteBadges() {
    // 디바운스
    clearTimeout(_badgeTimer);
    _badgeTimer = setTimeout(_doInjectBadges, 400);
  }

  function _doInjectBadges() {
    if (!Object.keys(HISTORY).length) return;
    // 배지 자체를 새로 만드는 게 DOM mutation이라, observer가 그걸 감지해서
    // 다시 injectSiteBadges()를 호출하는 무한루프가 됐었음 — 작업 중엔 감시 끄기
    _soopBadgeObserver?.disconnect();
    try {
      _doInjectBadgesInner();
      if (SP_MODE) spUpdateBadges();
    } finally {
      _soopBadgeObserver?.observe(document.body, { childList: true, subtree: true });
    }
  }

  // 1.2.5.42: Catch cards (vod.sooplive.com/player/{no}/catch) — the uploader is often a manager or
  // fan; the streamer the clip is from is the VOD's copyright owner (view API: data.copyright_id).
  // Resolved once per clip (cached), then put on the card's title link as data-bjid, so the normal
  // badge code below picks it up.
  const CATCH_OWNER_KEY = 'kwsSoopCatchOwner';
  let CATCH_OWNER = null;            // titleNo → owner id ('' = none)
  const CATCH_PENDING = new Set();
  let catchActive = 0;
  const catchQueue = [];
  let catchSaveTimer = null;
  async function catchOwnerLoad() {
    if (CATCH_OWNER) return;
    try { CATCH_OWNER = (await chrome.storage.local.get(CATCH_OWNER_KEY))[CATCH_OWNER_KEY] || {}; } catch (_) { CATCH_OWNER = {}; }
  }
  function catchOwnerSave() {
    clearTimeout(catchSaveTimer);
    catchSaveTimer = setTimeout(() => {
      const keys = Object.keys(CATCH_OWNER);
      if (keys.length > 5000) keys.slice(0, keys.length - 4000).forEach((k) => delete CATCH_OWNER[k]); // keep it small
      try { chrome.storage.local.set({ [CATCH_OWNER_KEY]: CATCH_OWNER }); } catch (_) {}
    }, 1500);
  }
  async function catchFetchOwner(no) {
    try {
      const r = await fetch('https://api.m.sooplive.com/station/video/a/view', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `nTitleNo=${encodeURIComponent(no)}&nApiLevel=11`,
      });
      const j = await r.json();
      const d = (j && j.data) || {};
      return String(d.copyright_id || (d.copyright && d.copyright.user_id) || d.bj_id || '').toLowerCase();
    } catch (_) { return null; }
  }
  function catchPump() {
    while (catchActive < 3 && catchQueue.length) {
      const no = catchQueue.shift();
      catchActive++;
      catchFetchOwner(no).then((id) => {
        if (id !== null) { CATCH_OWNER[no] = id; catchOwnerSave(); }
      }).finally(() => { catchActive--; CATCH_PENDING.delete(no); catchPump(); if (!catchActive && !catchQueue.length) injectSiteBadges(); });
    }
  }
  function tagCatchCards() {
    if (!CATCH_OWNER) { catchOwnerLoad().then(() => injectSiteBadges()); return; }
    const byNo = new Map();
    document.querySelectorAll('a[href*="/catch"]').forEach((a) => {
      const m = (a.getAttribute('href') || '').match(/\/player\/(\d+)\/catch/);
      if (!m) return;
      if (!byNo.has(m[1])) byNo.set(m[1], []);
      byNo.get(m[1]).push(a);
    });
    for (const [no, anchors] of byNo) {
      // the title link (the one with text, not just the thumbnail) carries the badge
      const title = anchors.filter((a) => (a.textContent || '').trim()).pop();
      if (!title) continue;
      const owner = CATCH_OWNER[no];
      if (owner === undefined) { if (!CATCH_PENDING.has(no)) { CATCH_PENDING.add(no); catchQueue.push(no); } continue; }
      if (owner && title.dataset.bjid !== owner) title.dataset.bjid = owner;
    }
    catchPump();
  }

  function _doInjectBadgesInner() {
    try { tagCatchCards(); } catch (e) { console.warn('[SOOP KWS] catch badges', e); }

    // 배지 스타일 한번만 주입
    if (!document.getElementById('soop-badge-style')) {
      const s = document.createElement('style');
      s.id = 'soop-badge-style';
      s.textContent = `
        .soop-search-badge {
          display: inline-flex; align-items: center;
          padding: 1px 5px; border-radius: 99px;
          background: rgba(34,197,94,0.12);
          border: 1px solid rgba(34,197,94,0.35);
          color: #4ade80; /* default, overridden dynamically */ font-size: 9px; font-weight: 700;
          white-space: nowrap; vertical-align: middle;
          margin-left: 4px; cursor: default;
          font-family: -apple-system, sans-serif;
          line-height: 1.5; letter-spacing: 0.01em;
        }
        .soop-search-badge:hover {
          background: rgba(34,197,94,0.22);
        }
      `;
      document.head.appendChild(s);
    }

    // 이미 배지 달린 요소 제거 후 재주입
    document.querySelectorAll('.soop-search-badge').forEach(el => el.remove());

    // 페이지에서 유저 ID가 담긴 요소 탐색
    const selectors = [
      'a[href*="/station/"]',
      'a[href*="bjid="]',
      'a[href*="bj_id="]',
      'a[href*="play.sooplive.com/"]',
      '[data-bjid]', '[data-userid]', '[data-bj-id]', '[data-user-id]',
    ];

    const seen = new Set();

    for (const sel of selectors) {
      document.querySelectorAll(sel).forEach(el => {
        if (seen.has(el)) return;
        seen.add(el);

        // URL에서 ID 추출
        let userId = null;
        const href = el.getAttribute('href') || '';
        // /station/ID 또는 /station/ID/ 패턴
        const stationMatch = href.match(/\/station\/([^/?#"'\s]+)/);
        // bjid= 또는 bj_id= 파라미터
        const bjidMatch = href.match(/(?:bjid|bj_id|user_id)=([^&"'\s]+)/i);
        // play.sooplive.com/ID/숫자 패턴
        const playMatch = href.match(/play\.sooplive\.com\/([^/?#"'\s\/]+)/);
        if (stationMatch) userId = decodeURIComponent(stationMatch[1]).toLowerCase().replace(/\/$/, '');
        else if (bjidMatch) userId = decodeURIComponent(bjidMatch[1]).toLowerCase();
        else if (playMatch) userId = decodeURIComponent(playMatch[1]).toLowerCase();

        // data 속성에서 추출 (다양한 케이스 커버)
        if (!userId) {
          const raw = el.dataset.bjid || el.dataset.userid || el.dataset.bjId || el.dataset.userId
            || el.dataset.id || el.dataset.streamerId || el.closest('[data-bjid]')?.dataset.bjid || '';
          if (raw) userId = raw.toLowerCase().trim();
        }

        // 시스템/공통 ID 제외
        if (!userId || userId.length < 2 || userId === 'undefined' || userId === 'null') return;
        if (['vod','live','search','explore','main','station','replay','highlight'].includes(userId)) return;
        // 숫자만 있는 경우 제외 (내부 ID)
        if (/^\d+$/.test(userId)) return;

        // 이미 배지 있으면 스킵
        if (el.querySelector('.soop-search-badge')) return;
        if (el.nextElementSibling?.classList?.contains('soop-search-badge')) return;

        // 이력 조회 — lowercase 키로만 저장되므로 lowercase로 조회
        const h = HISTORY[userId];

        // 이력 없는 스트리머 → 빨간 배지
        if (!h) {
          const badge = document.createElement('span');
          badge.className = 'soop-search-badge soop-badge-unsearched';
          badge.dataset.streamerId = userId;
          badge.textContent = 'Not searched';
          badge.style.cssText = `background:rgba(239,68,68,0.1);border-color:rgba(239,68,68,0.3);color:#f87171;cursor:pointer;`;
          badge.title = 'Not in search history · Click to search';
          badge.addEventListener('mouseenter', () => badge.style.background = 'rgba(239,68,68,0.2)');
          badge.addEventListener('mouseleave', () => badge.style.background = 'rgba(239,68,68,0.1)');
          badge.addEventListener('click', async (e) => {
            e.preventDefault(); e.stopPropagation();
            if (SP_MODE) return spBadgeScan(userId);
            // 이미 스캔 중이거나 큐에 있는지 확인
            if (isRunningId(userId)) return; // 통일 규칙: 이미 검색 중이면 무시
            if (SCAN_QUEUE.some(q => q.streamerId === userId)) return; // 대기 중이어도 무시
            const idInput = document.getElementById('soop-streamer-id');
            if (idInput) { idInput.value = userId; idInput.dispatchEvent(new Event('input')); const dd=document.getElementById('soop-id-dropdown'); if(dd) dd.style.display='none'; }
            // streamerId를 고정하고 Start Scan 버튼 클릭
            const _wasRunning = runningCount() > 0;
            const _fixedUserId = userId; // 클로저로 고정
            setTimeout(() => {
              const inp = document.getElementById('soop-streamer-id');
              if (inp) { inp.value = _fixedUserId; }
              // 100ms 후 버튼 클릭 (자동완성 등 간섭 방지)
              setTimeout(() => {
                const inp2 = document.getElementById('soop-streamer-id');
                if (inp2) inp2.value = _fixedUserId; // 재확인
                document.getElementById('soop-start-btn')?.click();
                if (!_wasRunning) {
                  setTimeout(() => {
                    const newTabIdx = RESULT_TABS.findIndex(t => t.streamerId === _fixedUserId && !t.pending);
                    if (newTabIdx >= 0) { ACTIVE_TAB = newTabIdx; renderResultTabs(); }
                  }, 200);
                }
              }, 100);
            }, 50);
          });
          if (el.tagName === 'A') el.insertAdjacentElement('afterend', badge);
          else el.appendChild(badge);
          return;
        }

        // 날짜 계산
        const daysAgo = h.searchedAt
          ? Math.floor((Date.now() - new Date(h.searchedAt)) / 86400000)
          : null;
        const isUpToDate = daysAgo !== null && daysAgo <= 1;
        const isStale = daysAgo !== null && daysAgo > (globalThis.__kwsRedDays || 14);
        const label = daysAgo === 0 ? 'Today'
          : daysAgo === 1 ? 'Yesterday'
          : daysAgo !== null ? `${daysAgo}d ago`
          : 'Searched';
        // 색상: 최신(1일 이내)=초록, 오래됨(90일 이내)=노랑, 아주 오래됨(90일 초과)=빨강 — Twitch와 동일
        const badgeColor = isStale
          ? { bg: 'rgba(239,68,68,0.1)', border: 'rgba(239,68,68,0.3)', text: '#f87171', hover: 'rgba(239,68,68,0.2)' }
          : isUpToDate
            ? { bg: 'rgba(34,197,94,0.12)', border: 'rgba(34,197,94,0.35)', text: '#4ade80', hover: 'rgba(34,197,94,0.22)' }
            : { bg: 'rgba(234,179,8,0.12)', border: 'rgba(234,179,8,0.35)', text: '#fbbf24', hover: 'rgba(234,179,8,0.22)' };

        const badge = document.createElement('span');
        badge.className = 'soop-search-badge';
        badge.dataset.streamerId = userId;
        badge.textContent = label;
        badge.style.background = badgeColor.bg;
        badge.style.borderColor = badgeColor.border;
        badge.style.color = badgeColor.text;
        badge.dataset.hoverBg = badgeColor.hover;
        badge.addEventListener('mouseenter', () => { badge.style.background = badge.dataset.hoverBg; });
        badge.addEventListener('mouseleave', () => { badge.style.background = badgeColor.bg; });
        badge.title = `${h.matchedCount || 0} matches · up to ${h.lastDate || '?'} · Click to refresh`;

        // 배지 클릭 시 이 스트리머 재검색 (최신화)
        badge.title += ' · Click to refresh search';
        badge.style.cursor = 'pointer';
        badge.addEventListener('click', async (e) => {
          e.preventDefault(); e.stopPropagation();
          if (SP_MODE) return spBadgeScan(userId);
          if (isRunningId(userId)) return; // 통일 규칙: 이미 검색 중이면 무시
          if (SCAN_QUEUE.some(q => q.streamerId === userId)) return; // 대기 중이어도 무시
          const idInput = document.getElementById('soop-streamer-id');
          const body = document.getElementById('soop-panel-body');
          const kwInput = document.getElementById('soop-keyword');
          let kw = kwInput?.value?.trim() || '';
          if (!kw && window.KWSSharedKeywordEditor) kw = window.KWSSharedKeywordEditor.defaultValue() || '';
          if (!kw) { alert('⚠ No keywords set!\n\nPlease click the keyword button to set keywords first.'); document.getElementById('soop-keyword-btn')?.click(); return; }
          const stopAtDate = h.lastDate || null;

          if (runningCount() >= MAX_CONCURRENT_SCANS) {
            // 스캔 중 → 팝업 띄우고 선택 후 큐에 추가
            if (body) body.style.display = 'block';
            const addToQueue = (withStopDate) => {
              const pendingTabIdx = RESULT_TABS.length;
              RESULT_TABS.push({ streamerId: userId, nick: h.nickname || userId, results: [], matchedCount: 0, timestamp: Date.now(), pending: true });
              SCAN_QUEUE.push({ streamerId: userId, keyword: kw, startPage: 1, endPage: null, stopAtDate: withStopDate, nick: h.nickname || null, _tabIdx: pendingTabIdx });
              renderQueueUI(); renderResultTabs();
              broadcast(null, `Queued: ${h.nickname || userId}`);
            };
            if (stopAtDate) {
              showRescanPopup(userId, kw, h.nickname, stopAtDate,
                () => addToQueue(null),
                () => addToQueue(stopAtDate)
              );
            } else {
              addToQueue(null);
            }
            return;
          }

          if (idInput) { idInput.value = userId; idInput.dispatchEvent(new Event('input')); const dd=document.getElementById('soop-id-dropdown'); if(dd) dd.style.display='none'; }
          if (body) body.style.display = 'block';
          if (stopAtDate) {
            // 새 VOD 있는지 먼저 확인
            badge.textContent = '⏳';
            const newVodCount = await checkNewVods(userId, stopAtDate);
            if (newVodCount === 0) {
              // 새 VOD 없음 → History 최신화 + 배지 업데이트
              await saveHistory(userId, { lastDate: h.lastDate, lastPage: h.lastPage, keywords: h.keywords, matchedCount: h.matchedCount });
              badge.textContent = 'Today';
              badge.style.background = 'rgba(34,197,94,0.12)';
              badge.style.borderColor = 'rgba(34,197,94,0.35)';
              badge.style.color = '#4ade80';
              badge.dataset.hoverBg = 'rgba(34,197,94,0.22)';
              // 토스트 표시
              const toast = document.createElement('div');
              toast.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:rgba(30,30,40,0.95);color:#4ade80;border:1px solid rgba(34,197,94,0.35);border-radius:10px;padding:8px 16px;font-size:12px;font-weight:700;z-index:99999;pointer-events:none;';
              toast.textContent = `✅ No new VODs for ${h.nickname || userId}`;
              document.body.appendChild(toast);
              setTimeout(() => toast.remove(), 3000);
              return;
            }
            showRescanPopup(userId, kw, h.nickname, stopAtDate,
              // Full rescan
              () => { resetScanUI(); startScan({ streamerId: userId, keyword: kw, startPage: 1, endPage: null, stopAtDate: null, nick: h.nickname || null }); setTimeout(() => { const i = RESULT_TABS.findIndex(t => t.streamerId === userId && !t.pending); if (i >= 0) { ACTIVE_TAB = i; renderResultTabs(); } }, 200); },
              // Incremental
              () => { broadcast(null, `Searching new VODs since ${stopAtDate}...`); resetScanUI(); startScan({ streamerId: userId, keyword: kw, startPage: 1, endPage: null, stopAtDate, nick: h.nickname || null }); setTimeout(() => { const i = RESULT_TABS.findIndex(t => t.streamerId === userId && !t.pending); if (i >= 0) { ACTIVE_TAB = i; renderResultTabs(); } }, 200); }
            );
          } else {
            resetScanUI();
            startScan({ streamerId: userId, keyword: kw, startPage: 1, endPage: null, stopAtDate: null, nick: h.nickname || null });
            setTimeout(() => { const i = RESULT_TABS.findIndex(t => t.streamerId === userId && !t.pending); if (i >= 0) { ACTIVE_TAB = i; renderResultTabs(); } }, 200);
          }
        });

        // 배지 삽입 위치
        // 메모가 있으면 배지 텍스트에 포함
        if (h?.memo) {
          const short = h.memo.length > 15 ? h.memo.slice(0, 15) + '…' : h.memo;
          const _prevText = badge.textContent;
          badge.textContent = '';
          const _t1 = document.createElement('span'); _t1.textContent = _prevText; badge.appendChild(_t1);
          const _t2 = document.createElement('span'); _t2.textContent = ' · ' + short; _t2.style.cssText = 'color:#f87171;font-weight:800;'; badge.appendChild(_t2);
          badge.title = (badge.title || '') + '\n📝 ' + h.memo;
        }
        if (el.tagName === 'A') {
          el.insertAdjacentElement('afterend', badge);
        } else {
          el.appendChild(badge);
        }
      });
    }
  }

  // 페이지 전체를 통째로 멈춰야 할 때(예: 언로드) 쓰는 전역 폴백 — 개별 스캔 중지는
  // 이제 각 ctx.abortCtrl로 하므로, 특정 스트리머 스캔을 멈춰도 동시에 도는 다른 스캔들의
  // fetch까지 같이 끊기지 않음 (예전엔 이게 전역 하나뿐이라 "이 스트리머만 중지"가 사실상
  // 불가능했음 — 4개 동시 스캔을 지원하려면 반드시 스캔별로 분리돼야 하는 부분이었음).
  let _scanAbortCtrl = new AbortController();
  function fetchWT(url, opts = {}, ms = 10000, extraSignal) {
    // 예전엔 매 호출마다 _scanAbortCtrl.signal에 addEventListener('abort', ..., {once:true})를
    // 새로 등록했는데, 이 signal은 스캔 세션 내내 살아있고 Stop 안 누르면 abort가 안 터지니까
    // 리스너가 영원히 안 지워지고 쌓이기만 했음 (수십만 개까지) — 이게 3GB 메모리 누수의 원인.
    // AbortSignal.timeout/any는 내부적으로 리스너를 새지 않게 관리해줌.
    const signals = [AbortSignal.timeout(ms), _scanAbortCtrl.signal];
    if (extraSignal) signals.push(extraSignal);
    const combinedSignal = AbortSignal.any(signals);
    return fetch(url, { ...opts, signal: combinedSignal });
  }

  // ══════════════════════════════════════════════════════════
  //  UI
  // ══════════════════════════════════════════════════════════

  let _globalMessage = '';
  function broadcast(ctx, msg = '') { if (ctx) ctx.message = msg; else _globalMessage = msg; renderState(); }

  // showRescanPopup은 sharedRescanPopup.js (공용 모듈)에서 제공됨

  // 랭킹 페이지(afevent2.sooplive.com)에서 배지 클릭 → 이 탭으로 전달됨
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type !== 'KWS_SET_STREAMER_AND_SCAN') return;
    if (SP_MODE) { spBadgeScan(msg.streamerId); return; }
    handleSetStreamerAndScan(msg).catch(e => console.error('[SOOP KWS] KWS_SET_STREAMER_AND_SCAN failed:', e));
  });

  async function handleSetStreamerAndScan(msg) {
    const { streamerId } = msg;
    if (!streamerId) return;
    console.log('[SOOP KWS] received KWS_SET_STREAMER_AND_SCAN', streamerId);

    // 패널/키워드/히스토리가 아직 로딩 중일 수 있어서 최대 5초까지 재시도하며 기다림
    let idInput = null, kw = '';
    for (let i = 0; i < 25; i++) {
      idInput = document.getElementById('soop-streamer-id');
      kw = document.getElementById('soop-keyword')?.value?.trim() || '';
      if (idInput && kw) break;
      await spDelay(200);
    }
    console.log('[SOOP KWS] panel ready:', !!idInput, 'keyword ready:', !!kw);

    if (idInput) { idInput.value = streamerId; idInput.dispatchEvent(new Event('input')); }
    if (!kw) { document.getElementById('soop-keyword-btn')?.click(); console.warn('[SOOP KWS] no keyword set — opened keyword editor instead of scanning'); return; }

    const panel = document.getElementById(PANEL_ID);
    if (panel && panel.style.display === 'none') panel.style.display = '';

    // hasHistory는 호출자(streamrecorder.io 뱃지 등) 쪽에서 항상 안 보내거나 false로만 와서
    // 이 분기가 사실상 죽은 코드였음 — 대신 이 탭이 실제로 갖고 있는 HISTORY로 직접 판단함.
    // 혹시 히스토리 로딩이 아직 안 끝났을 수 있어서 최대 3초까지 재조회하며 기다림.
    let h = HISTORY[streamerId.toLowerCase()];
    if (!h?.lastDate) {
      for (let i = 0; i < 15 && !h?.lastDate; i++) {
        await spDelay(200);
        h = HISTORY[streamerId.toLowerCase()];
      }
    }
    const stopAtDate = h?.lastDate || '';
    console.log('[SOOP KWS] history lookup:', streamerId.toLowerCase(), '→', h ? `found (lastDate=${stopAtDate})` : 'not found');

    const doStart = (withStopDate) => {
      // SOOP은 Twitch/Kick과 다르게(60일 기본값) — 히스토리가 있으면 "이어서(기록 이후부터)"
      // 또는 "전체 재검색"을 팝업으로 물어보고, "전체 재검색"이나 히스토리 자체가 없는
      // 최초 검색인 경우엔 예전처럼 제한 없이(최초 영상부터) 스캔함. 패널에 남아있는 시작
      // 날짜(다른 스트리머를 스캔했을 때 입력된 값일 수 있음)는 참고하지 않음.
      // withStopDate("이어서")든 아니든 startDate는 null — "이어서"는 stopAtDate가 실제
      // 시작점 역할을 하고, "전체 재검색"/최초 검색은 제한 없이 최초 영상부터 훑음.
      const startDate = null;
      const endDate = document.getElementById('soop-end-date')?.value || null;

      if (runningCount() >= MAX_CONCURRENT_SCANS) {
        const pendingTabIdx = RESULT_TABS.length;
        RESULT_TABS.push({ streamerId, nick: h?.nickname || streamerId, results: [], matchedCount: 0, timestamp: Date.now(), pending: true });
        SCAN_QUEUE.push({ streamerId, keyword: kw, startPage: 1, endPage: null, startDate, endDate, stopAtDate: withStopDate, nick: h?.nickname || null, _tabIdx: pendingTabIdx });
        renderQueueUI(); renderResultTabs();
        broadcast(null, `Queued: ${h?.nickname || streamerId}`);
      } else {
        startScan({ streamerId, keyword: kw, startDate, endDate, stopAtDate: withStopDate || null, nick: h?.nickname || null });
      }
    };

    if (stopAtDate) {
      console.log('[SOOP KWS] showing rescan popup for', streamerId);
      showRescanPopup(streamerId, kw, h?.nickname, stopAtDate,
        () => doStart(null),
        () => doStart(stopAtDate)
      );
    } else {
      console.log('[SOOP KWS] no history match — starting fresh scan for', streamerId);
      doStart(null);
    }
  }

  // 랭킹 페이지 배지에 진행률/큐 상태를 실시간으로 보여주기 위한 중계
  function broadcastSoopStatusToRanking(ctx, state, percent) {
    if (!ctx?.streamerId) return;
    chrome.runtime.sendMessage({ type: 'KWS_SOOP_STATE', streamerId: ctx.streamerId, state, percent }).catch(() => {});
  }

  // 다른 탭이 soopSharedQueue에 추가하면 감지해서 로컬 Queue에 반영
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    // soopSearchHistory 변경 시 HISTORY 갱신 (다른 탭/플랫폼에서 Import 시)
    if (changes.soopSearchHistory) {
      const newH = changes.soopSearchHistory.newValue || {};
      Object.assign(HISTORY, newH);
      injectSiteBadges();
      if (window._soopHistoryRender) window._soopHistoryRender();
    }
    // soopKeyword 변경 시 preview 업데이트
    if (area === 'local' && changes.soopKeyword) {
      const kw = changes.soopKeyword.newValue || '';
      const el = document.getElementById('soop-keyword');
      if (el && kw) { el.value = kw; updateKeywordPreview(); }
    }
    if (changes.soopAutoCloseNoResult) {
      soopAutoCloseNoResult = !!changes.soopAutoCloseNoResult.newValue;
      const cb = document.getElementById('soop-auto-close-no-result');
      if (cb) cb.checked = soopAutoCloseNoResult;
    }
    if (area !== 'local' || !changes.soopSharedQueue) return;
    const q = changes.soopSharedQueue.newValue || [];
    if (!q.length) return;
    // 이 탭이 마스터(실행 중)일 때만 처리
    if (!runningCount() && !SCAN_QUEUE.length) return;
    q.forEach(sp => {
      if (!sp?.streamerId) return;
      const already = SCAN_QUEUE.some(x => x.streamerId === sp.streamerId);
      if (!already) {
              const pendingTabIdx = RESULT_TABS.length;
              RESULT_TABS.push({ streamerId: sp.streamerId, nick: sp.nick || sp.streamerId, results: [], matchedCount: 0, timestamp: Date.now(), pending: true });
              SCAN_QUEUE.push({ ...sp, _tabIdx: pendingTabIdx }); renderQueueUI(); renderResultTabs(); broadcast(null, `Queued: ${sp.streamerId}`);
            }
    });
    // 처리 후 shared queue 비우기
    chrome.storage.local.remove('soopSharedQueue').catch(()=>{});
  });

  const TRANSLATE_CACHE = new Map();

  function getTranslateLang() {
    const sel = document.getElementById('soop-translate-lang');
    return (sel?.value || localStorage.getItem(TRANSLATE_LANG_KEY) || 'en').trim() || 'en';
  }









  async function translateTextAuto(text, targetLang) {
    const src = String(text || '').trim();
    if (!src) return '';
    const lang = targetLang || getTranslateLang();
    const cacheKey = `${lang}\n${src}`;
    if (TRANSLATE_CACHE.has(cacheKey)) return TRANSLATE_CACHE.get(cacheKey);
    const data = await globalThis.KWSGTranslate(src, lang); // 1.2.5.46: rotates gtx / dict-chrome-ex / at (platform.js)
    const translated = (data?.[0] || []).map(x => x?.[0] || '').join('').trim();
    if (!translated) throw new Error('empty translation');
    TRANSLATE_CACHE.set(cacheKey, translated);
    return translated;
  }

  function openGoogleTranslate(text, targetLang) {
    const lang = targetLang || getTranslateLang();
    const url = `https://translate.google.com/?sl=auto&tl=${encodeURIComponent(lang)}&text=${encodeURIComponent(text || '')}&op=translate`;
    window.open(url, '_blank');
  }

  function renderResultTabs() {
    const tabBar = document.getElementById('soop-result-tabs');
    const wrap = document.getElementById('soop-preview-list');
    const summary = document.getElementById('soop-preview-summary');
    if (!tabBar || !wrap) return;

    // 탭 바 렌더링
    tabBar.innerHTML = RESULT_TABS.map((t, i) => {
      const isActive = i === ACTIVE_TAB;
      const matched = t.matchedCount || 0;
      const nick = esc(t.nick || t.streamerId || '?');
      const tabCtx = SCAN_STATES[(t.streamerId || '').toLowerCase()];
      const running = !!tabCtx?.running;
      const isPending = t.pending;
      let bg, color, border;
      if (isPending) {
        // 🔴 대기 (active면 cyan 테두리)
        bg = 'rgba(239,68,68,0.12)'; color = 'rgba(248,113,113,0.85)'; border = isActive ? 'rgba(6,182,212,0.8)' : 'rgba(239,68,68,0.3)';
      } else if (running) {
        // 🟠 검색중 (active면 cyan 테두리)
        bg = 'rgba(251,146,60,0.15)'; color = '#fb923c'; border = isActive ? 'rgba(6,182,212,0.8)' : 'rgba(251,146,60,0.35)';
      } else if (isActive) {
        // 🔵 완료, 활성 탭 (cyan 테두리)
        bg = 'rgba(59,130,246,0.25)'; color = '#bfdbfe'; border = 'rgba(6,182,212,0.8)';
      } else {
        // ⚫ 완료, 비활성
        bg = 'rgba(255,255,255,0.05)'; color = 'rgba(148,163,184,0.6)'; border = 'rgba(255,255,255,0.07)';
      }
      const pct = running ? Math.round((tabCtx.completedVodCount / Math.max(tabCtx.vodItems.length, 1)) * 100) : 0;
      return `<div style="display:inline-flex;align-items:center;gap:0;border-radius:8px;overflow:hidden;border:1px solid ${border};">
        <button data-tab="${i}" style="
          padding:5px 10px;border:none;cursor:pointer;font-size:11px;font-weight:700;
          white-space:nowrap;transition:all 0.15s;
          background:${bg};color:${color};
          ${isPending ? 'opacity:0.75;' : ''}
        ">${nick}${matched ? ` <span style="color:#4ade80;">(${matched})</span>` : ''}${running ? ` <span style="font-size:9px;margin-left:2px;">⏳${pct}%</span>` : ''}${isPending ? ' <span style="font-size:9px;opacity:0.7;">queued</span>' : ''}</button>
        ${running
          ? `<button data-close="${i}" data-stop-scan="1" style="padding:4px 6px;border:none;cursor:pointer;font-size:11px;background:rgba(239,68,68,0.15);color:#f87171;border-left:1px solid rgba(239,68,68,0.3);">×</button>`
          : `<button data-close="${i}" style="padding:4px 6px;border:none;cursor:pointer;font-size:11px;background:${bg};color:${color};opacity:0.5;border-left:1px solid ${border};">×</button>`
        }
      </div>`;
    }).join('');

    // 탭 클릭 이벤트
    tabBar.querySelectorAll('[data-tab]').forEach(btn => {
      btn.addEventListener('click', () => {
        ACTIVE_TAB = parseInt(btn.dataset.tab);
        renderResultTabs();
        // Twitch와 동일: 탭을 누르면 그 스트리머 ID가 입력칸에 들어가서 복사/재검색이 쉬움
        const _sid = RESULT_TABS[ACTIVE_TAB]?.streamerId;
        const _inp = document.getElementById('soop-streamer-id');
        if (_inp && _sid) { _inp.value = _sid; try { renderHistoryHint(_sid); } catch {} }
      });
    });
    // 탭 닫기
    tabBar.querySelectorAll('[data-close]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const i = parseInt(btn.dataset.close);
        const tab = RESULT_TABS[i];
        const isStopScan = btn.dataset.stopScan === '1';
        const hasResults = (tab?.matchedCount || 0) > 0;
        if (isStopScan || hasResults) {
          const name = esc(tab?.nick || tab?.streamerId || '?');
          const reason = isStopScan ? 'is still scanning' : `has ${tab.matchedCount} matched result(s)`;
          if (!confirm(`"${name}" tab ${reason}.\n\nClose this tab anyway?`)) return;
        }
        // 스캔 중인 탭 X → 그 스트리머의 스캔만 중지 (다른 동시 스캔들은 영향 없음)
        if (isStopScan) {
          const stopCtx = SCAN_STATES[(tab?.streamerId || '').toLowerCase()];
          if (stopCtx?.running) {
            stopCtx.stopRequested = true;
            stopCtx._stopCurrentOnly = true; // 이 스캔만 중지 — 대기열은 유지하고 다음 스캔 자동 진행
            stopCtx._tabIdx = undefined;     // 탭이 곧 삭제되므로 인덱스 연결 해제 (엉뚱한 탭 건드리지 않게)
            stopCtx.abortCtrl.abort();
          }
        }
        // 대기 중(pending)인 탭을 X로 닫으면 — 네트워크 배너의 대기열 목록/Cancel 버튼이
        // 없어졌으므로, 여기서 SCAN_QUEUE의 짝인 항목도 같이 제거해야 나중에 몰래 시작되지 않음.
        if (tab?.pending) {
          const qIdx = SCAN_QUEUE.findIndex(q => q._tabIdx === i);
          if (qIdx !== -1) SCAN_QUEUE.splice(qIdx, 1);
        }
        RESULT_TABS.splice(i, 1);
        if (ACTIVE_TAB >= RESULT_TABS.length) ACTIVE_TAB = RESULT_TABS.length - 1;
        if (ACTIVE_TAB > i) ACTIVE_TAB--;
        for (const s of Object.values(SCAN_STATES)) { if (s._tabIdx !== undefined && s._tabIdx > i) s._tabIdx--; }
        SCAN_QUEUE.forEach(q => { if (q._tabIdx !== undefined && q._tabIdx > i) q._tabIdx--; });
        renderResultTabs();
      });
    });

    // 활성 탭 결과 표시
    if (ACTIVE_TAB < 0 || !RESULT_TABS[ACTIVE_TAB]) {
      wrap.innerHTML = `<div style="padding:14px;border-radius:14px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.05);color:rgba(100,116,139,0.6);font-size:12px;text-align:center;">Results will appear here after scanning.</div>`;
      if (summary) summary.textContent = 'No results';
      return;
    }
    // pending 탭
    if (RESULT_TABS[ACTIVE_TAB].pending) {
      wrap.innerHTML = `<div style="padding:14px;border-radius:14px;background:rgba(239,68,68,0.05);border:1px solid rgba(239,68,68,0.15);color:rgba(248,113,113,0.7);font-size:12px;text-align:center;">⏳ Queued — will start after current scan completes.</div>`;
      if (summary) summary.textContent = 'Queued';
      return;
    }

    const tab = RESULT_TABS[ACTIVE_TAB];
    const matched = tab.results.filter(r => r.matchCount > 0);
    if (summary) summary.textContent = window.KWSHitsText(matched.reduce((a, r) => a + (r.matchCount || 0), 0), false);

    // 결과 렌더링
    wrap.innerHTML = '';
    for (const item of matched) {
      const card = document.createElement('div');
      card.style.cssText = 'padding:11px 13px;border-radius:14px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);margin-bottom:8px;backdrop-filter:blur(4px);';
      const entries = (item.matchedEntries || []);
      const meta = [item.dateText, item.page ? `p${item.page}` : '', `${item.matchCount}hits`].filter(Boolean).join(' · ');
      const usedTab = !!item._usedTab;
      const sourceBadge = `<span title="${usedTab ? 'Found via Legacy Mode (tab-based scraping)' : 'Found via Native API'}" style="flex-shrink:0;font-size:9px;font-weight:800;padding:2px 7px;border-radius:99px;letter-spacing:0.02em;${usedTab ? 'background:rgba(251,146,60,0.14);color:#fb923c;border:1px solid rgba(251,146,60,0.3);' : 'background:rgba(34,197,94,0.14);color:#4ade80;border:1px solid rgba(34,197,94,0.3);'}">${usedTab ? 'Legacy' : 'Native'}</span>`;
      const fetchWarnBadge = item._hadFetchFailure ? `<span title="네트워크 혼잡으로 일부 채팅 조각을 못 받아옴 — 매칭 개수가 실제보다 적을 수 있음" style="flex-shrink:0;font-size:9px;font-weight:800;padding:2px 7px;border-radius:99px;letter-spacing:0.02em;background:rgba(239,68,68,0.14);color:#f87171;border:1px solid rgba(239,68,68,0.3);">⚠ 일부 누락</span>` : '';
      const _hdrLabel = '📅 ' + (item.dateText || item.title || '(No date)') + '  (' + item.matchCount + ' hits)';
      const _hdrTip = [item.title || '(No title)', item.page ? 'p' + item.page : ''].filter(Boolean).join(' · ');
      card.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;font-weight:800;font-size:12px;line-height:1.4;color:#7dd3fc;margin-bottom:7px;padding-bottom:5px;border-bottom:1px solid rgba(255,255,255,0.06);">
          <span class="hl" title="${esc(_hdrTip)}" style="cursor:help;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${esc(_hdrLabel)}</span>
          <span class="hr" style="flex-shrink:0;display:flex;align-items:center;gap:4px;">${fetchWarnBadge}${sourceBadge}</span>
        </div>
        <div class="el" style="display:flex;flex-direction:column;gap:5px;"></div>
      `;
      const list = card.querySelector('.el');

      // 클러스터 감지: 인접 쌍 간격 < 180초면 같은 클러스터, 이상이면 새 클러스터
      const clusterSet = new Set();
      const clusterGroup = new Map();
      let groupId = 0;
      let ci2 = 0;
      while (ci2 < entries.length) {
        let cj2 = ci2 + 1;
        while (cj2 < entries.length && (entries[cj2].seconds||0) - (entries[cj2-1].seconds||0) < 180) cj2++;
        if (cj2 - ci2 >= 2) {
          for (let ck2 = ci2; ck2 < cj2; ck2++) {
            clusterSet.add(ck2);
            clusterGroup.set(ck2, groupId);
          }
          groupId++;
        }
        ci2 = cj2;
      }

      const _trRows = [];
      for (let _ei = 0; _ei < entries.length; _ei++) {
        const e = entries[_ei];
        const isCluster = clusterSet.has(_ei);
        const row = document.createElement('div');
        const _gid = clusterGroup.get(_ei);
        const _isFirst = isCluster && (clusterGroup.get(_ei - 1) !== _gid);
        const _isLast  = isCluster && (clusterGroup.get(_ei + 1) !== _gid);
        const _br = isCluster
          ? `${_isFirst?'9px 9px':'0 0'} ${_isLast?'9px 9px':'0 0'}`
          : '9px';
        const _mt = (isCluster && _isFirst && _ei > 0) ? 'margin-top:6px;' : '';
        row.style.cssText = `display:grid;grid-template-columns:auto 1fr;gap:8px;align-items:start;padding:6px 9px;border-radius:${_br};background:${isCluster?'rgba(6,182,212,0.06)':'rgba(255,255,255,0.03)'};border:1px solid ${isCluster?'rgba(6,182,212,0.45)':'rgba(255,255,255,0.06)'};border-bottom:${isCluster&&!_isLast?'1px solid rgba(6,182,212,0.2)':'1px solid '+(isCluster?'rgba(6,182,212,0.45)':'rgba(255,255,255,0.06)')};${isCluster&&_isFirst?'box-shadow:0 0 8px rgba(6,182,212,0.15);':''}${_mt}`;
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.textContent = '▶ ' + (e.timeLabel || fmtTime(e.seconds || 0));
        btn.style.cssText = window.KWS_TBTN.base + window.KWS_TBTN.off;
        // 클릭 상태 복원 (메모리 또는 HISTORY에서)
        const _tab = RESULT_TABS[ACTIVE_TAB];
        const _sid = _tab?.streamerId?.toLowerCase();
        const _titleNo = item.titleNo || (new URL(item.playerUrl).pathname.match(/\/player\/(\d+)/)||[])[1] || '';
        const _savedClicks = _sid && _titleNo ? (HISTORY[_sid]?.clickedTimes?.[_titleNo] || []) : [];
        if (e._clicked || _savedClicks.includes(e.seconds || 0)) {
          e._clicked = true;
          btn.style.cssText = window.KWS_TBTN.base + window.KWS_TBTN.on;
        }
        btn.addEventListener('click', () => {
          e._clicked = true;
          btn.style.cssText = window.KWS_TBTN.base + window.KWS_TBTN.on;
          const secs = e.seconds || 0;
          // HISTORY에 클릭 기록 저장
          const tab = RESULT_TABS[ACTIVE_TAB];
          const sid = tab?.streamerId?.toLowerCase();
          if (sid) {
            if (!HISTORY[sid]) HISTORY[sid] = {};
            if (!HISTORY[sid].clickedTimes) HISTORY[sid].clickedTimes = {};
            const titleNo = item.titleNo || (new URL(item.playerUrl).pathname.match(/\/player\/(\d+)/)||[])[1] || '';
            if (titleNo) {
              if (!HISTORY[sid].clickedTimes[titleNo]) HISTORY[sid].clickedTimes[titleNo] = [];
              if (!HISTORY[sid].clickedTimes[titleNo].includes(secs))
                HISTORY[sid].clickedTimes[titleNo].push(secs);
              chrome.storage.local.set({ [HISTORY_KEY]: HISTORY }).catch(()=>{});
            }
          }
          const u = new URL(item.playerUrl);
          const _activeTab2 = RESULT_TABS[ACTIVE_TAB];
          openSoopInlinePlayer({ playerUrl: item.playerUrl, seekSecs: secs, title: item.title || '', dateText: item.dateText || '', streamerId: _activeTab2?.streamerId || '', nick: _activeTab2?.nick || '' });
        });
        const txt = document.createElement('div');
        txt.style.cssText = 'min-width:0;';
        // 통일 레이아웃: [검색된 키워드 칩] / "닉네임: 메시지 🌐" / 번역
        const metaLine = document.createElement('div');
        metaLine.style.cssText = 'display:inline-block;margin-bottom:3px;padding:1px 6px;background:rgba(234,179,8,0.15);color:#fde047;border:1px solid rgba(234,179,8,0.25);border-radius:5px;font-size:9px;font-weight:700;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;vertical-align:top;';
        metaLine.textContent = kwPreview(e.matchedKeywords || [], 3) || (e._subtitle ? 'CC' : '');
        if (!metaLine.textContent) metaLine.style.display = 'none';
        const msgLine = document.createElement('div');
        msgLine.style.cssText = 'font-size:12px;color:#cbd5e1;word-break:break-word;line-height:1.45;';
        msgLine.innerHTML = `<span style="color:#a5b4fc;font-weight:600;" title="${esc(e.userId||'')}">${esc(e.nickname||'anonymous')}</span>: ${hlKw(esc(e.message||''),e.matchedKeywords||[])}`;
        const translatedLine = document.createElement('div');
        translatedLine.style.cssText = 'display:none;margin-top:4px;padding:5px 7px;border-radius:7px;background:rgba(14,165,233,0.07);border:1px solid rgba(14,165,233,0.14);color:#bae6fd;font-size:11px;line-height:1.45;word-break:break-word;';
        _trRows.push({ text: e.message || '', box: translatedLine, cached: e._kwsTranslation, onDone: (l, t) => { e._kwsTranslation = { lang: l, text: t }; }, onHide: () => { e._kwsTranslation = null; } });
        txt.appendChild(metaLine);
        txt.appendChild(msgLine);
        txt.appendChild(translatedLine);
        row.appendChild(btn); row.appendChild(txt); list.appendChild(row);
      }

      if (_trRows.length) {
        const _gBtn = document.createElement('button');
        _gBtn.style.cssText = 'flex-shrink:0;font-size:9px;font-weight:800;padding:2px 7px;border-radius:99px;letter-spacing:0.02em;cursor:pointer;font-family:inherit;line-height:1.3;background:rgba(14,165,233,0.14);color:#7dd3fc;border:1px solid rgba(14,165,233,0.3);';
        const _hr = card.querySelector('.hr'); _hr.insertBefore(_gBtn, _hr.firstChild);
        window.KWSBatchTranslate(_gBtn, _trRows, getTranslateLang, translateTextAuto, openGoogleTranslate);
      }
      wrap.appendChild(card);
    }
    if (!matched.length) {
      const _activeCtx = SCAN_STATES[(tab?.streamerId || '').toLowerCase()];
      wrap.innerHTML = `<div style="padding:14px;border-radius:14px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.05);color:rgba(100,116,139,0.6);font-size:12px;text-align:center;">${_activeCtx?.running ? 'Scanning...' : 'No matches found.'}</div>`;
    }
    // 세션에 저장 (새로고침 복원용)
    try { chrome.storage.session.set({ [TABS_SESSION_KEY]: RESULT_TABS.map(t => ({...t, results: t.results?.slice(-50)})) }).catch(()=>{}); } catch {}
  }

  function renderQueueUI() {
    renderSpeedBanner();
    const area = document.getElementById('soop-queue-area');
    if (area) area.style.display = 'none';
    if (!SCAN_QUEUE.length) { return; }
  }


  function createPanel() {
    if (document.getElementById(PANEL_ID)) return;
    const panel = document.createElement('div');
    // ── Liquid Glass CSS 주입 ──
    if (!document.getElementById('soop-panel-style')) {
      const _s = document.createElement('style');
      _s.id = 'soop-panel-style';
      _s.textContent = `
        #${PANEL_ID} * { box-sizing:border-box; font-family:-apple-system,'SF Pro Display','SF Pro Text',BlinkMacSystemFont,sans-serif; }
        #${PANEL_ID} input { transition:border-color 0.2s,background 0.2s,box-shadow 0.2s; }
        #${PANEL_ID} input:focus { border-color:rgba(147,197,253,0.55)!important; background:rgba(255,255,255,0.1)!important; box-shadow:0 0 0 3px rgba(59,130,246,0.13)!important; }
        #${PANEL_ID} input::placeholder { color:rgba(255,255,255,0.35); }
        #${PANEL_ID} button:hover { filter:brightness(1.12); }
        #${PANEL_ID} button:active { transform:scale(0.95)!important; }
        #${PANEL_ID} ::-webkit-scrollbar { width:8px; }
        #${PANEL_ID} ::-webkit-scrollbar-track { background:transparent; }
        #${PANEL_ID} ::-webkit-scrollbar-thumb { background:rgba(255,255,255,0.15);border-radius:99px; }
        .soop-time-btn { padding:4px 9px;border:none;border-radius:8px;cursor:pointer;background:rgba(59,130,246,0.18);color:rgba(191,219,254,0.9);font-weight:700;font-size:11px;white-space:nowrap;border:1px solid rgba(59,130,246,0.28);transition:all 0.15s; }
        .soop-time-btn:hover { background:rgba(59,130,246,0.32); }
        .soop-time-btn.visited { background:rgba(16,185,129,0.15);color:rgba(110,231,183,0.85);border-color:rgba(16,185,129,0.22); }
      `;
      document.head.appendChild(_s);
    }

    panel.id = PANEL_ID;

    Object.assign(panel.style, {
      position: 'fixed', right: `${DEFAULT_POS.right}px`, bottom: `${DEFAULT_POS.bottom}px`,
      zIndex: String(topZIndexer()), width: '420px', maxWidth: 'calc(100vw - 20px)', maxHeight: 'calc(100vh - 20px)',
      overflow: 'hidden', color: 'rgba(255,255,255,0.95)', borderRadius: '26px',
      border: '1px solid rgba(255,255,255,0.16)',
      background: 'rgba(16,16,26,0.82)',
      backdropFilter: 'saturate(150%) blur(24px)', WebkitBackdropFilter: 'saturate(150%) blur(24px)',
      boxShadow: '0 40px 80px rgba(0,0,0,0.55), inset 0 1px 0 rgba(255,255,255,0.14)',
      fontSize: '13px', lineHeight: '1.5', userSelect: 'none'
    });
    panel.innerHTML = `
      <!-- ── HEADER ── -->
      <div id="soop-panel-header" style="
        display:flex;align-items:center;justify-content:space-between;
        padding:14px 16px 13px;cursor:move;
        border-bottom:1px solid rgba(255,255,255,0.06);
        background:linear-gradient(180deg,rgba(255,255,255,0.07) 0%,rgba(255,255,255,0) 100%);
      ">
        <div>
          <div style="font-size:13px;font-weight:700;letter-spacing:-0.01em;color:#fff;line-height:1.2;">SOOP KWS</div>
          <div style="display:flex;align-items:center;gap:6px;margin-top:2px;"><span id="soop-version-badge" style="font-size:10px;font-weight:700;letter-spacing:0.04em;color:rgba(96,165,250,0.95);background:rgba(37,99,235,0.16);border:1px solid rgba(96,165,250,0.30);border-radius:5px;padding:1px 6px;">KWS</span></div>
        </div>
        <div style="display:flex;gap:6px;align-items:center;">
          <button id="soop-settings-btn" title="Settings" style="
            width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:14px;
            background:rgba(37,99,235,0.14);border:1px solid rgba(96,165,250,0.28);
            color:rgba(147,197,253,0.9);display:flex;align-items:center;justify-content:center;
            transition:all 0.15s;
          ">⚙</button>
          <button id="soop-discover-btn" title="Find more streamers to search" style="
            width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:13px;
            background:rgba(37,99,235,0.14);border:1px solid rgba(96,165,250,0.28);
            color:rgba(147,197,253,0.9);display:flex;align-items:center;justify-content:center;
            transition:all 0.15s;
          ">🔍</button>
          <button id="soop-player-btn" title="Play a VOD by URL or ID" style="
            width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:13px;
            background:rgba(96,165,250,0.16);border:1px solid rgba(96,165,250,0.32);
            color:#93c5fd;display:flex;align-items:center;justify-content:center;
            transition:all 0.15s;
          ">▶</button>
          <button id="soop-history-btn" title="Search History" style="
            width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:13px;
            background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);
            color:rgba(255,255,255,0.7);display:flex;align-items:center;justify-content:center;
            transition:all 0.15s;
          ">📋</button>
          <button id="soop-toggle-btn" style="
            width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:16px;
            background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);
            color:rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;
            transition:all 0.15s;
          ">⇔</button>
        </div>
      </div>

      <!-- ── BODY ── -->
      <div id="soop-secondary-banner" style="display:none;padding:7px 14px;background:rgba(234,179,8,0.12);border-bottom:1px solid rgba(234,179,8,0.2);font-size:11px;color:rgba(234,179,8,0.85);text-align:center;">
        ⚠️ Another tab is scanning. Results show there. You can still queue searches here.
      </div>
      <div id="soop-panel-body" style="padding:14px 16px 16px;overflow-y:auto;max-height:calc(100vh - 80px);">

        <div id="soop-queue-area" style="display:none;margin-bottom:6px;"></div>
        <div id="soop-speed-banner" style="margin-bottom:10px;padding:9px 12px;border-radius:10px;background:rgba(59,130,246,0.12);border:1px solid rgba(59,130,246,0.3);font-size:11px;line-height:1.4;display:flex;align-items:center;justify-content:space-between;gap:8px;"><span style="font-weight:700;color:rgba(255,255,255,0.9);">🔵 Normal</span><span style="color:rgba(255,255,255,0.5);font-size:10px;">VOD×6 Chat×6</span></div>

        <div id="soop-settings-inline" style="display:none;margin-bottom:12px;padding:12px 14px;border-radius:12px;background:rgba(37,99,235,0.06);border:1px solid rgba(96,165,250,0.16);">
          <div style="font-size:10px;font-weight:800;letter-spacing:0.07em;text-transform:uppercase;color:rgba(147,197,253,0.86);margin-bottom:9px;text-align:center;">API Source</div>
          <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:6px;">
            <button id="soop-fetch-api" class="soop-fetch-btn" data-mode="api" title="Native API — uses SOOP's own API." style="flex:1;min-width:70px;height:36px;border-radius:10px;border:1px solid rgba(96,165,250,0.5);background:rgba(96,165,250,0.18);color:#bfdbfe;font-size:11px;font-weight:800;cursor:pointer;display:flex;align-items:center;justify-content:center;text-align:center;">Native API</button>
            <button id="soop-fetch-tab" class="soop-fetch-btn" data-mode="tab" title="Legacy Mode — opens each VOD one by one and scrapes it manually. Slow." style="flex:1;min-width:70px;height:36px;border-radius:10px;border:1px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.05);color:rgba(255,255,255,0.62);font-size:11px;font-weight:800;cursor:pointer;display:flex;align-items:center;justify-content:center;text-align:center;">Legacy Mode</button>
          </div>
          <div style="font-size:10px;line-height:1.5;color:rgba(255,255,255,0.4);text-align:left;margin-bottom:9px;">
            <b style="color:rgba(255,255,255,0.55);">Native API</b> — uses SOOP's own API.<br>
            <b style="color:rgba(255,255,255,0.55);">Legacy Mode</b> — opens each VOD one by one and scrapes it manually. ⚠️ Slow.<br>
            Subscription-only VODs use their own access flow regardless of this setting.
          </div>
          <div style="font-size:10px;font-weight:800;letter-spacing:0.07em;text-transform:uppercase;color:rgba(147,197,253,0.86);margin:13px 0 9px;text-align:center;">Options</div>
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;padding:7px 0;border-bottom:1px solid rgba(255,255,255,0.07);margin-bottom:9px;">
            <input type="checkbox" id="soop-auto-close-no-result" style="width:14px;height:14px;accent-color:#60a5fa;cursor:pointer;">
            <span style="font-size:11px;font-weight:600;color:rgba(255,255,255,0.8);">Auto-close tab if no results</span>
          </label>
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;padding:7px 0;border-bottom:1px solid rgba(255,255,255,0.07);margin-bottom:9px;" title="Also search the VOD's subtitles (CC), when the streamer has them. Subtitle hits are labeled "Subtitle (CC)".">
            <input type="checkbox" id="soop-search-subtitles" style="width:14px;height:14px;accent-color:#60a5fa;cursor:pointer;">
            <span style="font-size:11px;font-weight:600;color:rgba(255,255,255,0.8);">Also search subtitles (CC)</span>
          </label>
          <div style="font-size:10px;font-weight:800;letter-spacing:0.07em;text-transform:uppercase;color:rgba(147,197,253,0.86);margin:13px 0 9px;text-align:center;" title="Chat messages are translated with Google Translate (free)">Translate to</div>
          <select id="soop-translate-lang" title="Translate result messages to this language (Google Translate)" style="width:100%;height:36px;border-radius:10px;border:1px solid rgba(96,165,250,0.28);background:#14101d;color:#ffffff;font-size:11px;font-weight:700;padding:0 12px;outline:none;font-family:inherit;box-sizing:border-box;color-scheme:dark;cursor:pointer;"><option value="en" style="background:#14101d;color:#ffffff;">English</option><option value="ko" style="background:#14101d;color:#ffffff;">한국어</option><option value="ja" style="background:#14101d;color:#ffffff;">日本語</option><option value="zh-CN" style="background:#14101d;color:#ffffff;">中文</option><option value="es" style="background:#14101d;color:#ffffff;">Español</option><option value="ru" style="background:#14101d;color:#ffffff;">Русский</option><option value="de" style="background:#14101d;color:#ffffff;">Deutsch</option><option value="fr" style="background:#14101d;color:#ffffff;">Français</option><option value="pt" style="background:#14101d;color:#ffffff;">Português</option><option value="id" style="background:#14101d;color:#ffffff;">Bahasa Indonesia</option><option value="th" style="background:#14101d;color:#ffffff;">ไทย</option><option value="vi" style="background:#14101d;color:#ffffff;">Tiếng Việt</option></select>
        </div>

        <div id="soop-input-area">
        <!-- Streamer ID -->
        <div style="margin-bottom:12px;">
          <div style="font-size:10px;font-weight:600;letter-spacing:0.08em;text-transform:uppercase;color:rgba(255,255,255,0.55);margin-bottom:6px;">Streamer ID</div>
          <div style="position:relative;">
            <input id="soop-streamer-id" type="text" placeholder="e.g. wkdalgusrla or 닉네임"
              style="width:100%;box-sizing:border-box;height:40px;padding:0 14px;
              border-radius:12px;border:1px solid rgba(255,255,255,0.2);
              background:rgba(255,255,255,0.1);color:#fff;
              font-size:13px;outline:none;transition:border-color 0.2s,background 0.2s;
              font-family:inherit;">
            <div id="soop-id-dropdown" style="
              display:none;position:absolute;top:calc(100% + 5px);left:0;right:0;z-index:9999;
              border-radius:12px;overflow:hidden;max-height:200px;overflow-y:auto;
              background:rgba(20,20,35,0.95);border:1px solid rgba(255,255,255,0.1);
              box-shadow:0 16px 40px rgba(0,0,0,0.5);backdrop-filter:blur(20px);
            "></div>
          </div>
          <div id="soop-history-hint" style="
            margin-top:6px;padding:7px 11px;border-radius:9px;
            background:rgba(37,99,235,0.08);border:1px solid rgba(37,99,235,0.15);
            font-size:11px;color:rgba(147,197,253,0.8);display:none;line-height:1.5;
          "></div>
        </div>

        <!-- Keywords -->
        <div style="margin-bottom:12px;">
          <div style="font-size:10px;font-weight:600;letter-spacing:0.08em;text-transform:uppercase;color:rgba(255,255,255,0.55);margin-bottom:6px;">Keywords</div>
          <button id="soop-keyword-btn" type="button" style="width:100%;box-sizing:border-box;height:40px;padding:0 14px;border-radius:12px;border:1px solid rgba(96,165,250,0.35);background:rgba(255,255,255,0.07);color:rgba(255,255,255,0.9);font-size:13px;text-align:left;display:flex;align-items:center;justify-content:space-between;gap:8px;cursor:pointer;font-family:inherit;"><span id="soop-keyword-preview" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:rgba(255,255,255,0.65);"></span><span style="font-size:10px;color:rgba(96,165,250,0.85);flex-shrink:0;">✏️ Edit</span></button>
          <input id="soop-keyword" type="hidden" value="">
        </div>

        <!-- Date Range -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px;">
          <div>
            <div style="font-size:10px;font-weight:600;letter-spacing:0.08em;text-transform:uppercase;color:rgba(255,255,255,0.55);margin-bottom:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">From Date <span style="opacity:.62;font-size:9px;letter-spacing:0.02em;">(blank = oldest)</span></div>
            <input id="soop-start-date" type="date"
              style="width:100%;box-sizing:border-box;height:40px;padding:0 12px;
              border-radius:12px;border:1px solid rgba(255,255,255,0.2);
              background:rgba(255,255,255,0.1);color:#fff;
              font-size:12px;outline:none;color-scheme:dark;font-family:inherit;">
          </div>
          <div>
            <div style="font-size:10px;font-weight:600;letter-spacing:0.08em;text-transform:uppercase;color:rgba(255,255,255,0.55);margin-bottom:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">To Date <span style="opacity:.62;font-size:9px;letter-spacing:0.02em;">(blank = now)</span></div>
            <input id="soop-end-date" type="date"
              style="width:100%;box-sizing:border-box;height:40px;padding:0 12px;
              border-radius:12px;border:1px solid rgba(255,255,255,0.2);
              background:rgba(255,255,255,0.1);color:#fff;
              font-size:12px;outline:none;color-scheme:dark;font-family:inherit;">
          </div>
        </div>

        <!-- Buttons -->
        <div style="display:flex;gap:8px;margin-bottom:14px;">
          <button id="soop-start-btn" style="
            flex:1;height:42px;border:none;border-radius:13px;cursor:pointer;
            font-size:13px;font-weight:700;color:#fff;letter-spacing:0.01em;
            background:linear-gradient(135deg,#1d6fe0 0%,#2f8cf0 45%,#4fb0f7 100%);
            box-shadow:0 4px 16px rgba(56,150,240,0.35),inset 0 1px 0 rgba(255,255,255,0.3);
            transition:all 0.15s;font-family:inherit;
          ">▶ Start Scan</button>
          <button id="soop-stop-btn" style="
            width:78px;height:42px;border:none;border-radius:13px;cursor:pointer;
            font-size:13px;font-weight:700;color:#fff;
            background:linear-gradient(135deg,rgba(220,38,38,0.85),rgba(239,68,68,0.85));
            box-shadow:0 4px 16px rgba(220,38,38,0.3),inset 0 1px 0 rgba(255,255,255,0.1);
            transition:all 0.15s;font-family:inherit;
          ">■ Stop</button>
        </div>
        </div><!-- /soop-input-area -->

        <!-- Status -->
        <div style="
          margin-bottom:10px;padding:10px 13px;border-radius:12px;
          background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07);
        ">
          <div style="font-size:9px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:rgba(255,255,255,0.5);margin-bottom:4px;">Status</div>
          <div id="soop-status-text" style="
            color:rgba(255,255,255,0.9);font-size:12px;
            white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
          ">Idle</div>
        </div>

        <!-- Progress -->
        <div style="margin-bottom:10px;">
          <div style="display:flex;justify-content:space-between;margin-bottom:5px;">
            <span style="font-size:10px;color:rgba(255,255,255,0.5);">Progress</span>
            <span id="soop-progress-label" style="font-size:10px;color:rgba(255,255,255,0.6);">0%</span>
          </div>
          <div style="height:4px;background:rgba(255,255,255,0.06);border-radius:99px;overflow:hidden;">
            <div id="soop-progress-bar" style="
              width:0%;height:100%;border-radius:99px;
              background:linear-gradient(90deg,#2f8cf0,#4fb0f7 60%,#7dd3fc);
              transition:width 0.4s cubic-bezier(0.4,0,0.2,1);
            "></div>
          </div>
        </div>

        <!-- Metrics -->
        <div id="soop-metrics" style="
          white-space:pre-wrap;font-size:11px;line-height:1.8;
          color:rgba(255,255,255,0.5);padding:8px 12px;border-radius:11px;
          background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.05);
          margin-bottom:12px;font-variant-numeric:tabular-nums;
        "></div>



        <!-- Results -->
        ${window.KWSResultsHeaderHTML('soop-preview-summary','soop-results-clear')}
        <div id="soop-result-tabs" style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:8px;"></div>
        <div id="soop-preview-list" style="display:flex;flex-direction:column;gap:8px;"></div>

      </div>
    `;

    document.body.appendChild(panel);
    const $d = id => document.getElementById(id);

    try {
      const vBadge = $d('soop-version-badge');
      if (vBadge) vBadge.textContent = 'KWS ' + (chrome.runtime.getManifest().version || '');
    } catch(e) {}

    // 패널이 DOM에 추가된 후 배너 체크
    (async () => {
      const masterData = await chrome.storage.local.get(MASTER_KEY).catch(()=>({}));
      const masterInfo = masterData[MASTER_KEY];
      const masterActive = masterInfo && masterInfo.id !== TAB_SESSION_ID && (Date.now() - (masterInfo.ts||0)) < 30000;
      const isSecondary = !runningCount() && masterActive;
      const banner = $d('soop-secondary-banner');
      if (banner) banner.style.display = isSecondary ? 'block' : 'none';
    })();

    $d('soop-streamer-id').value = guessStreamerIdFromUrl();
    enableDragging(panel, $d('soop-panel-header'));
    bindCollapse(panel, $d('soop-panel-body'), $d('soop-toggle-btn'));

    // Streamer ID 입력 시 드롭다운 + 힌트 업데이트
    const idInput = $d('soop-streamer-id');
    const dropdown = $d('soop-id-dropdown');

    function renderIdDropdown(query) {
      const q = query.toLowerCase().trim();
      const entries = Object.entries(HISTORY)
        .filter(([id, h]) => !q || id.includes(q) || (h.nickname || '').toLowerCase().includes(q) || (h.nickname || '').includes(query.trim()))
        .sort((a, b) => (b[1].searchedAt || '').localeCompare(a[1].searchedAt || ''))
        .slice(0, 8);

      if (!entries.length || !q) { dropdown.style.display = 'none'; return; }

      dropdown.innerHTML = entries.map(([id, h]) => {
        const nick = h.nickname ? `<span style="color:#a5b4fc;font-weight:700;">${esc(h.nickname)}</span> <span style="color:#4b5563;">/ ${esc(id)}</span>` : `<span style="color:#e5e7eb;">${esc(id)}</span>`;
        const info = h.lastDate ? `<span style="color:#4b5563;font-size:10px;"> · 최신 ${esc(h.lastDate)} · 매칭 ${h.matchedCount||0}건</span>` : '';
        return `<div data-id="${esc(id)}" style="padding:8px 12px;cursor:pointer;border-bottom:1px solid rgba(255,255,255,0.05);font-size:12px;" onmouseenter="this.style.background='rgba(59,130,246,0.15)'" onmouseleave="this.style.background=''">${nick}${info}</div>`;
      }).join('');
      dropdown.style.display = 'block';
    }

    idInput.addEventListener('input', () => {
      const val = idInput.value.trim();
      renderHistoryHint(val);
      renderIdDropdown(val);
    });
    idInput.addEventListener('focus', () => {
      renderIdDropdown(idInput.value.trim());
    });
    idInput.addEventListener('blur', () => {
      setTimeout(() => { dropdown.style.display = 'none'; }, 150);
    });
    dropdown.addEventListener('click', e => {
      const item = e.target.closest('[data-id]');
      if (!item) return;
      idInput.value = item.dataset.id;
      dropdown.style.display = 'none';
      renderHistoryHint(item.dataset.id);
    });

    $d('soop-start-btn').addEventListener('click', async () => {
      const streamerId = $d('soop-streamer-id').value.trim();
      if (!streamerId) { alert('Please enter a Streamer ID.'); return; }
      let keyword = $d('soop-keyword').value.trim();
      if (!keyword) {
        // storage에서 키워드 로드 시도
        try {
          const kwData = await chrome.storage.local.get(['twitchKwsKeywordProfile','soopKeyword']);
          keyword = kwData.twitchKwsKeywordProfile?.keyword || kwData.soopKeyword || '';
          if (keyword) { $d('soop-keyword').value = keyword; updateKeywordPreview(); }
        } catch {}
      }
      if (!keyword && window.KWSSharedKeywordEditor) keyword = window.KWSSharedKeywordEditor.defaultValue() || '';
      if (!keyword) { alert('⚠ No keywords set!\n\nPlease click the keyword button to set keywords first.'); $d('soop-keyword-btn')?.click(); return; }
      if (keyword && $d('soop-keyword')) { $d('soop-keyword').value = keyword; updateKeywordPreview(); }
      const startDate = $d('soop-start-date')?.value || null;
      const endDate   = $d('soop-end-date')?.value || null;
      // 저장 실패(용량 초과 등)가 스캔 시작 자체를 막으면 안 됨 — 예전엔 quota exceeded 예외가 그대로 터져서 버튼이 아무 반응 없이 죽었음
      try {
        await chrome.storage.local.set({ soopStreamerId: streamerId, soopKeyword: keyword, soopStartDate: startDate||'', soopEndDate: endDate||'', soopDatesSavedDay: (() => { const d = new Date(), p = n => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`; })() });
      } catch (e) { console.warn('[SOOP KWS] could not save panel inputs:', e?.message); }
      const scanParams = { streamerId, keyword, startPage: 1, endPage: null,
        startDate, endDate, nick: HISTORY[streamerId?.toLowerCase()]?.nickname || null };
      if (isRunningId(streamerId)) {
        // 통일 규칙(4개 KWS 공통): 이미 스캔 중이면 확인 팝업 — OK: 중지 후 처음부터 다시, Cancel: 유지
        window.KWSRestartDialog?.({
          name: streamerId,
          onRestart: () => window.KWSStopAndRestart({
            stop: () => {
              const oldCtx = SCAN_STATES[(streamerId || '').toLowerCase()];
              if (oldCtx?.running) { oldCtx.stopRequested = true; oldCtx._stopCurrentOnly = true; oldCtx.abortCtrl.abort(); }
            },
            isRunning: () => isRunningId(streamerId),
            start: () => { resetScanUI(); startScan(scanParams); }
          })
        });
      } else if (runningCount() >= MAX_CONCURRENT_SCANS) {
        // 동시 스캔 한도(4개) 도달 → 로컬 Queue에 추가
        const alreadyInQueue = SCAN_QUEUE.some(q => q.streamerId === streamerId);
        if (!alreadyInQueue) {
          const pendingTabIdx2 = RESULT_TABS.length;
          RESULT_TABS.push({ streamerId: scanParams.streamerId, nick: scanParams.nick || scanParams.streamerId, results: [], matchedCount: 0, timestamp: Date.now(), pending: true });
          SCAN_QUEUE.push({ ...scanParams, _tabIdx: pendingTabIdx2 }); renderResultTabs();
          renderQueueUI();
          broadcast(null, `Added to queue: ${streamerId}`);
        } else {
          broadcast(null, `Already in queue: ${streamerId}`);
        }
      } else {
        // 다른 탭이 마스터인지 확인
        const masterData = await chrome.storage.local.get(MASTER_KEY).catch(() => ({}));
        const masterInfo = masterData[MASTER_KEY];
        const masterActive = masterInfo && masterInfo.id !== TAB_SESSION_ID && (Date.now() - (masterInfo.ts||0)) < 30000;
        if (masterActive && !runningCount()) {
          // 다른 탭이 실행 중 → shared storage queue에 추가
          const sharedQ = await chrome.storage.local.get('soopSharedQueue').catch(() => ({}));
          const q = sharedQ.soopSharedQueue || [];
          if (!q.some(x => x.streamerId === scanParams.streamerId)) {
            q.push(scanParams);
            await chrome.storage.local.set({ soopSharedQueue: q }).catch(()=>{});
            broadcast(null, `Queued to active scanner: ${scanParams.streamerId}`);
          } else {
            broadcast(null, `Already queued: ${scanParams.streamerId}`);
          }
        } else {
          resetScanUI();
          startScan(scanParams);
        }
      }
    });

    $d('soop-stop-btn').addEventListener('click', () => {
    // 현재 보고 있는 탭의 스캔만 중지 — 동시에 도는 다른 스트리머 스캔은 그대로 유지
    const viewedTab = RESULT_TABS[ACTIVE_TAB];
    const viewedCtx = SCAN_STATES[(viewedTab?.streamerId || '').toLowerCase()];
    if (viewedCtx?.running) {
      viewedCtx.stopRequested = true;
      viewedCtx.abortCtrl.abort();
      broadcast(viewedCtx, 'Stopping...');
    }
  });

    // Performance preset removed — replaced by auto speed control

    // 📋 History window
    $d('soop-history-btn').addEventListener('click', createHistoryWindow);

    $d('soop-player-btn').addEventListener('click', () => {
      showKwsUrlPrompt({
        title: 'Play SOOP VOD',
        placeholder: 'vod.sooplive.com/player/123456789 or just the ID',
        onSubmit: (raw) => {
          const idMatch = /player\/(\d+)/.exec(raw) || /^(\d{5,})$/.exec(raw.trim());
          const titleNo = idMatch?.[1];
          if (!titleNo) { alert('Could not find a SOOP VOD ID in that input.'); return; }
          openSoopInlinePlayer({ playerUrl: `https://vod.sooplive.com/player/${titleNo}`, seekSecs: 0, title: '', dateText: '', streamerId: '', nick: '' });
        }
      });
    });

    renderHistoryHint($d('soop-streamer-id').value.trim());

    const trLang = $d('soop-translate-lang');
    if (trLang) {
      trLang.value = localStorage.getItem(TRANSLATE_LANG_KEY) || 'en';
      trLang.addEventListener('change', () => localStorage.setItem(TRANSLATE_LANG_KEY, trLang.value));
    }
    const settingsBtn = $d('soop-settings-btn');
    const settingsInline = $d('soop-settings-inline');
    if (settingsBtn && settingsInline) settingsBtn.addEventListener('click', () => { settingsInline.style.display = settingsInline.style.display === 'none' ? 'block' : 'none'; });

    $d('soop-discover-btn')?.addEventListener('click', () => window.showKwsDiscoverPopup?.());

    // Results 전체 Clear
    $d('soop-results-clear')?.addEventListener('click', () => {
      if (!RESULT_TABS.length) { broadcast(null, 'No results to clear.'); return; }
      const currentTab = (ACTIVE_TAB >= 0 && RESULT_TABS[ACTIVE_TAB]) ? RESULT_TABS[ACTIVE_TAB] : null;
      window.KWSClearDialog({
        running: runningCount() ? ['A scan'] : [],
        currentLabel: currentTab ? (currentTab.streamerId || currentTab.nick || '') : null,
        tabCount: RESULT_TABS.length,
        onCurrent: () => {
          const idx = RESULT_TABS.indexOf(currentTab);
          if (idx >= 0) RESULT_TABS.splice(idx, 1);
          ACTIVE_TAB = RESULT_TABS.length ? Math.min(idx, RESULT_TABS.length - 1) : -1;
          renderResultTabs();
          broadcast(null, 'Tab cleared.');
        },
        onAll: () => {
          RESULT_TABS.length = 0;
          ACTIVE_TAB = -1;
          renderResultTabs();
          broadcast(null, 'Results cleared.');
        },
      });
    });

    // 키워드 변경 시 자동 저장 (blur 시) — local + HISTORY JSON
    // 키워드 동기화 이벤트 수신 (다른 KWS에서 키워드 변경 시)
    window.addEventListener('kws-keyword-synced', (e) => {
      const val = e.detail?.val || '';
      if (val) {
        $d('soop-keyword').value = val;
        updateKeywordPreview();
        chrome.storage.local.set({ soopKeyword: val }).catch(()=>{});
      }
    });

    $d('soop-keyword-btn')?.addEventListener('click', () => {
      if (document.getElementById('soop-kw-modal')) return; // duplicate guard
      createKeywordEditor();
    });
    $d('soop-keyword').addEventListener('blur', () => {
      const kw = $d('soop-keyword').value.trim();
      chrome.storage.local.set({ soopKeyword: kw }).catch(()=>{});
      if (kw) {
        HISTORY._globalKeyword = kw;
        chrome.storage.local.set({ [HISTORY_KEY]: HISTORY }).catch(()=>{});
      }
    });
  }


  function updateKeywordPreview(){
    if (window.KWSSharedKeywordEditor) return window.KWSSharedKeywordEditor.updatePreview('soop-keyword','soop-keyword-preview');
    const el=$d('soop-keyword'), pr=$d('soop-keyword-preview'); if(!el||!pr) return;
    pr.textContent=(el.value||'').trim()?'Custom keywords — click to edit':'✦ Default keywords active — click to edit';
  }
  function createKeywordEditor(){
    if (window.KWSSharedKeywordEditor) return window.KWSSharedKeywordEditor.open({
      modalId:'soop-kw-modal', inputId:'soop-keyword', previewId:'soop-keyword-preview',
      accent:'linear-gradient(135deg,rgba(37,99,235,.92),rgba(96,165,250,.86))',
      storageKey:'soopKeyword', historyKey:HISTORY_KEY,
      onSaved:(val,profile)=>{ HISTORY._globalKeyword=val; KWSSharedKeywordEditor.saveToAllPlatforms(val,profile).then(()=>chrome.storage.local.set({[HISTORY_KEY]:HISTORY})).catch(()=>{}); }
    });
  }

  function createHistoryWindow() {
    if (!window.KWSHistoryUI) return;
    window.KWSHistoryUI.open({
      platform: 'soop',
      HISTORY,
      HISTORY_KEY,
      accentColor: '#60a5fa',
      onImport: () => { injectSiteBadges(); },
      onScanComplete: (renderFn) => { window._soopHistoryRender = renderFn; },
      onGetScanState: (id) => {
        if (isRunningId(id)) return 'running';
        if (SCAN_QUEUE.some(q => q.streamerId?.toLowerCase() === id?.toLowerCase())) return 'queued';
        return 'idle';
      },
      onIdClick: (id, h) => {
        const idInput = document.getElementById('soop-streamer-id');
        if (idInput) { idInput.value = id; idInput.dispatchEvent(new Event('input')); renderHistoryHint(id); }
      },
      onScan: (id, h) => {
        const idInput = document.getElementById('soop-streamer-id');
        if (idInput) idInput.value = id;
        const kwInput = document.getElementById('soop-keyword');
        let kw = kwInput?.value?.trim() || '';
        if (!kw && window.KWSSharedKeywordEditor) kw = window.KWSSharedKeywordEditor.defaultValue() || '';
        if (!kw) { alert('\u26a0 No keywords set!'); document.getElementById('soop-keyword-btn')?.click(); return; }
        const stopAtDate = h.lastDate || null;
        if (stopAtDate) {
          showRescanPopup(id, kw, h.nickname, stopAtDate,
            () => { resetScanUI(); startScan({ streamerId: id, keyword: kw, startPage: 1, endPage: null, stopAtDate: null, nick: h.nickname || null }); },
            () => { broadcast(null, `Searching new VODs since ${stopAtDate}...`); resetScanUI(); startScan({ streamerId: id, keyword: kw, startPage: 1, endPage: null, stopAtDate, nick: h.nickname || null }); }
          );
        } else {
          resetScanUI();
          startScan({ streamerId: id, keyword: kw, startPage: 1, endPage: null, stopAtDate: null, nick: h.nickname || null });
        }
      }
    });
  }

  function renderHistoryHint(streamerId) {
    const hint = document.getElementById('soop-history-hint');
    if (!hint) return;
    const h = streamerId ? HISTORY[streamerId.toLowerCase()] : null;
    if (!h) { hint.style.display = 'none'; return; }
    const nick = h.nickname || streamerId;
    const daysAgo = h.searchedAt ? Math.floor((Date.now()-new Date(h.searchedAt))/86400000) : null;
    const when = daysAgo === 0 ? 'Today' : daysAgo === 1 ? 'Yesterday' : daysAgo !== null ? `${daysAgo}d ago` : '';
    hint.innerHTML = `<span style="font-weight:700;">${nick}</span> · Last searched: ${when}${h.lastDate ? ' · up to ' + h.lastDate : ''} · ${h.matchedCount||0} matches`;
    hint.style.display = 'block';
  }


  function resetScanUI() {
    const $d = id => document.getElementById(id);
    // preview-list는 탭 방식으로 관리하므로 직접 비우지 않음
    $d('soop-preview-summary').textContent = 'No results';
    $d('soop-progress-bar').style.width = '0%';
    $d('soop-progress-label').textContent = '0%';

  }


  function renderHistoryHint(streamerId) {
    const hint = document.getElementById('soop-history-hint');
    if (!hint) return;
    const text = streamerId ? getHistoryText(streamerId) : null;
    if (text) {
      hint.textContent = '🕐 ' + text;
      hint.style.display = 'block';
    } else {
      hint.style.display = 'none';
    }
  }



  function renderState() {
    const $d = id => document.getElementById(id);
    kwsSetPageGuard(runningCount() > 0 || SCAN_QUEUE.length > 0); // 스캔이 다 끝나면 이탈 경고도 해제 (예전엔 한 번 켜지면 계속 남았음)
    if (!$d('soop-status-text')) return;
    // 실행 상태 변경 시 배너 갱신
    const _banner = $d('soop-secondary-banner');
    if (_banner) {
      if (runningCount() > 0) {
        _banner.style.display = 'none'; // 내 탭이 실행 중 → 배너 숨김
      } else {
        // 다른 탭이 실행 중인지 재확인
        chrome.storage.local.get(MASTER_KEY).then(d => {
          const mi = d[MASTER_KEY];
          const active = mi && mi.id !== TAB_SESSION_ID && (Date.now() - (mi.ts||0)) < 30000;
          _banner.style.display = active ? 'block' : 'none';
        }).catch(()=>{});
      }
    }
    // ACTIVE_TAB이 현재 스캔 중인 탭이면 그 ctx 기준, 아니면 해당 탭의 snapshot 기준
    const viewTab = RESULT_TABS[ACTIVE_TAB];
    const viewCtx = SCAN_STATES[(viewTab?.streamerId || '').toLowerCase()];
    const isViewingActiveTab = !!viewCtx?.running;
    const snap = !isViewingActiveTab && viewTab?.snapshot;

    let pct = 0;
    if (isViewingActiveTab) {
      if (viewCtx.phase === 'collecting') pct = viewCtx.totalPagesPlanned > 0 ? Math.min(30, Math.floor((viewCtx.collectedPages / viewCtx.totalPagesPlanned) * 30)) : 5;
      else if (viewCtx.phase === 'scanning' && viewCtx.vodItems.length > 0) pct = 30 + Math.min(70, Math.floor((viewCtx.completedVodCount / viewCtx.vodItems.length) * 70));
      else if (viewCtx.phase === 'finished') pct = 100;
    } else if (snap) {
      pct = snap.pct || 0;
    } else if (!viewCtx || viewCtx.phase === 'finished') {
      pct = 100;
    }

    $d('soop-progress-bar').style.width = `${pct}%`;
    $d('soop-progress-label').textContent = `${pct}%`;

    if (isViewingActiveTab) {
      $d('soop-status-text').textContent = viewCtx.message || humanPhase(viewCtx.phase);
    } else if (snap) {
      $d('soop-status-text').textContent = snap.message;
    } else if (viewTab && !viewTab.pending) {
      const r = viewTab.results || [];
      const matched = r.filter(x=>x.matchCount>0).length;
      $d('soop-status-text').textContent = matched ? `Done! ${matched} VOD(s) matched` : 'Done';
    } else {
      $d('soop-status-text').textContent = _globalMessage || humanPhase('idle');
    }

    // 현재 스캔 중인 스트리머 배지 실시간 업데이트
    updateActiveBadges();
    if (isViewingActiveTab) broadcastSoopStatusToRanking(viewCtx, 'running', pct);

    // metrics: 보고 있는 탭 기준
    let nickLabel, metricsKeywords, metricsDates, metricsVods;
    if (isViewingActiveTab) {
      nickLabel = viewCtx.streamerNick ? `${viewCtx.streamerNick} (${viewCtx.streamerId})` : (viewCtx.streamerId || '-');
      metricsKeywords = kwPreview(viewCtx.keywords, 3);
      metricsDates = `${viewCtx.startDate || 'any'} ~ ${viewCtx.endDate || 'now'}`;
      metricsVods = `${viewCtx.vodItems.length} collected  |  ${viewCtx.completedVodCount}/${viewCtx.vodItems.length} scanned  |  ${viewCtx.matchedVodCount} matched`;
    } else if (snap) {
      nickLabel = snap.streamerNick ? `${snap.streamerNick} (${snap.streamerId})` : (snap.streamerId || '-');
      metricsKeywords = kwPreview(snap.keywords, 3);
      metricsDates = `${snap.startDate || 'any'} ~ ${snap.endDate || 'now'}`;
      metricsVods = `${snap.vodTotal} collected  |  ${snap.vodScanned}/${snap.vodTotal} scanned  |  ${snap.matchedVodCount} matched`;
    } else if (viewTab) {
      // snapshot 없어도 탭에 저장된 정보 표시
      nickLabel = viewTab.nick ? `${viewTab.nick} (${viewTab.streamerId})` : (viewTab.streamerId || '-');
      metricsKeywords = viewTab.keywords ? kwPreview(viewTab.keywords, 3) : '-';
      metricsDates = viewTab.startDate || viewTab.endDate
        ? `${viewTab.startDate || 'any'} ~ ${viewTab.endDate || 'now'}`
        : '-';
      const r = viewTab.results || [];
      const total = viewTab.vodTotal || r.length;
      metricsVods = `${total} collected  |  ${r.length} scanned  |  ${r.filter(x=>x.matchCount>0).length} matched`;
    } else {
      nickLabel = '-';
      metricsKeywords = '-';
      metricsDates = '-';
      metricsVods = '0 collected  |  0/0 scanned  |  0 matched';
    }
    $d('soop-metrics').textContent = [
      `Streamer : ${nickLabel}`,
      `Keywords : ${metricsKeywords}`,
      `Dates    : ${metricsDates}`,
      `VODs     : ${metricsVods}`,
    ].join('\n');

    renderResultTabs();
    renderSpeedBanner();
  }


  // Auto-close 설정
  const SOOP_AUTO_CLOSE_KEY = 'soopAutoCloseNoResult';
  let soopAutoCloseNoResult = false;
  const SOOP_SUBTITLE_KEY = 'soopSearchSubtitles';
  let soopSearchSubtitles = false; // true면 채팅뿐 아니라 VOD 자막(CC)도 같은 키워드로 검색
  const SOOP_FETCH_MODE_KEY = 'soopFetchMode';
  let soopFetchMode = 'api'; // 'api' | 'tab' — 구독 전용 VOD는 이 설정과 무관하게 항상 Thumb→Tab 흐름 유지

  async function restoreUiValues() {
    const data = await chrome.storage.local.get(['soopStreamerId', 'soopKeyword', 'soopStartDate', 'soopEndDate', 'soopDatesSavedDay', 'soopStartPage', 'soopEndPage', 'soopSaveTxt', 'soopPanelCollapsed', 'soopPanelPosition']);
    const $d = id => document.getElementById(id);
    if (data.soopStreamerId) { $d('soop-streamer-id').value = data.soopStreamerId; renderHistoryHint(data.soopStreamerId); }
    // 키워드 복원: twitchKwsKeywordProfile 우선 (공용 키워드), 없으면 soopKeyword
    let savedKw = '';
    try {
      const profileData = await chrome.storage.local.get(['twitchKwsKeywordProfile','soopKeyword']);
      savedKw = profileData.twitchKwsKeywordProfile?.keyword
             || profileData.soopKeyword
             || HISTORY._globalKeyword
             || '';
    } catch { savedKw = data.soopKeyword || HISTORY._globalKeyword || ''; }
    if (savedKw) {
      $d('soop-keyword').value = savedKw;
    }
    // 키워드 유무 관계없이 항상 preview 업데이트
    updateKeywordPreview();
    // 날짜: To는 실제 기본값(오늘)을 채우고, From은 비움(=가장 오래된 VOD부터). 저장된 값은 "오늘 저장한 것"만 복원
    // (To 기본값이 '오늘'이라 예전 값을 그대로 쓰면 며칠 뒤 To가 과거로 굳어 최신 VOD가 빠짐).
    {
      const _p2 = n => String(n).padStart(2, '0');
      const _fd = d => `${d.getFullYear()}-${_p2(d.getMonth() + 1)}-${_p2(d.getDate())}`;
      const _today = _fd(new Date());
      const _fresh = data.soopDatesSavedDay === _today;
      // From은 비워두면 '가장 오래된 VOD부터'라서(SOOP 고유 동작) 기본값을 채우지 않음 — 오늘 저장한 값만 복원
      $d('soop-start-date').value = (_fresh && data.soopStartDate) || '';
      $d('soop-end-date').value = (_fresh && data.soopEndDate) || _today;
    }
    
    const panel = document.getElementById(PANEL_ID), body = $d('soop-panel-body'), tb = $d('soop-toggle-btn');
    if (panel && data.soopPanelPosition?.left != null) { panel.style.left = `${data.soopPanelPosition.left}px`; panel.style.top = `${data.soopPanelPosition.top}px`; panel.style.right = 'auto'; panel.style.bottom = 'auto'; }
    if (panel && body && tb && data.soopPanelCollapsed) setCollapsed(panel, body, tb, true);
  }

  function humanPhase(p) { return { collecting: 'Collecting VODs...', scanning: 'Scanning chats...', finished: 'Finished ✓', stopped: 'Stopped', failed: 'Failed', idle: 'Idle' }[p] || 'Idle'; }
  function guessStreamerIdFromUrl() { const m = location.pathname.match(/\/station\/([^/]+)/i); return m ? decodeURIComponent(m[1]) : ''; }
  function bindCollapse(panel, body, tb) {
    tb.addEventListener('click', async e => {
      e.stopPropagation();
      const slim = panel.dataset.slim === 'true';
      setSlim(panel, tb, !slim);
      await chrome.storage.local.set({ soopPanelSlim: !slim });
    });
  }
  function setCollapsed(panel, body, tb, c) { /* legacy - no-op */ }
  function setSlim(panel, tb, slim) {
    panel.dataset.slim = slim ? 'true' : 'false';
    const inputArea = document.getElementById('soop-input-area');
    if (inputArea) inputArea.style.display = slim ? 'none' : '';
    tb.innerHTML = slim ? '&#x21D4;' : '&#x21D4;';
    tb.title = slim ? 'Expand' : 'Slim mode';
    tb.style.background = slim ? 'rgba(59,130,246,0.3)' : '';
    panel.style.width = slim ? '280px' : '420px';
  }
  function enableDragging(panel, handle) {
    let drag = false, ox = 0, oy = 0;
    handle.addEventListener('mousedown', e => { if (e.target.closest('button,input,textarea,select,label')) return; drag = true; panel.style.zIndex = topZIndexer(); const r = panel.getBoundingClientRect(); ox = e.clientX - r.left; oy = e.clientY - r.top; panel.style.left = `${r.left}px`; panel.style.top = `${r.top}px`; panel.style.right = 'auto'; panel.style.bottom = 'auto'; document.body.style.userSelect = 'none'; });
    panel.addEventListener('mousedown', () => { panel.style.zIndex = topZIndexer(); });
    window.addEventListener('mousemove', e => { if (!drag) return; panel.style.left = `${Math.min(Math.max(8, e.clientX - ox), Math.max(8, window.innerWidth - panel.offsetWidth - 8))}px`; panel.style.top = `${Math.min(Math.max(8, e.clientY - oy), Math.max(8, window.innerHeight - panel.offsetHeight - 8))}px`; });
    window.addEventListener('mouseup', async () => { if (!drag) return; drag = false; document.body.style.userSelect = ''; await chrome.storage.local.set({ soopPanelPosition: { left: parseFloat(panel.style.left), top: parseFloat(panel.style.top) } }); });
  }
  function fmtTime(s) { s = Math.max(0, Math.floor(s)); return [Math.floor(s / 3600), Math.floor((s % 3600) / 60), s % 60].map(v => String(v).padStart(2, '0')).join(':'); }
  function fmtDateForFile(dateStr) {
    // "2026-05-09" → "9-May-2026"
    if (!dateStr) return 'soop';
    try {
      const [y,m,d] = dateStr.split('-').map(Number);
      const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      return `${d} ${months[m-1]} ${y}`;
    } catch(e) { return dateStr; }
  }

  // ── 독립 다운로드 창 (Twitch의 kwsOpenClipDownloaderLegacy와 동일한 목적) ──
  // VOD 플레이어와 완전히 분리된 별도 팝업에서 다운로드를 진행 — VOD 창을 닫아도
  // 이 팝업(과 다운로드 자체)은 안 닫힘. cfg는 순수 데이터/함수 참조만 담아서
  // 살아있는 video/cont DOM에 전혀 의존하지 않음.
  async function soopFetchBuf(url, tries = 6) {
    for (let a = 0; a < tries; a++) {
      try {
        const r = await fetch(url);
        if (r.ok) { const b = await r.arrayBuffer(); if (b.byteLength) return b; }
      } catch (_) {}
      await spDelay(500 * (a + 1));
    }
    return null;
  }

  function soopStartStandaloneDownload(cfg) {
    const { fileItems, partOffsets, cs, ce, dlQuality, selectedQuality, dlFragments, soopFragments,
            nick, streamerId, titleNo, dateStr, getAvailQualities, collectFragments, fmt } = cfg;

    const popId = 'soop_download_progress_' + Date.now();
    // Twitch/Kick의 Clip Downloader 진행 팝업(.kws-inline-download-pop)과 동일한 CSS/구조/문구 사용
    if (!document.getElementById('soop-dl-pop-style')) {
      const st = document.createElement('style');
      st.id = 'soop-dl-pop-style';
      st.textContent = `
        .kws-inline-download-pop { position:fixed; z-index:2147483000; right:24px; bottom:24px; width:min(760px, calc(100vw - 48px)); max-height:min(78vh,720px); overflow:hidden; border-radius:24px; background:rgba(9,11,18,.94); border:1px solid rgba(255,255,255,.16); box-shadow:0 28px 90px rgba(0,0,0,.62), inset 0 1px 0 rgba(255,255,255,.10); color:#e5e7eb; backdrop-filter:blur(22px) saturate(150%); -webkit-backdrop-filter:blur(22px) saturate(150%); font-size:13px; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; }
        .kws-inline-download-head { position:sticky; top:0; z-index:2; display:flex; align-items:center; justify-content:space-between; gap:10px; padding:12px 14px; background:rgba(14,17,27,.88); border-bottom:1px solid rgba(255,255,255,.10); cursor:grab; user-select:none; }
        .kws-inline-download-head:active { cursor:grabbing; }
        .kws-inline-download-title { font:900 13px/1.2 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; color:#fff; }
        .kws-inline-download-close { border:1px solid rgba(255,255,255,.18); background:linear-gradient(135deg,rgba(255,255,255,.18),rgba(255,255,255,.07)); color:#fff; width:30px; height:30px; border-radius:999px; cursor:pointer; font-size:15px; line-height:1; display:flex; align-items:center; justify-content:center; box-shadow:0 8px 18px rgba(0,0,0,.35), inset 0 1px 0 rgba(255,255,255,.18); transition:transform .14s ease, background .14s ease, border-color .14s ease; flex-shrink:0; }
        .kws-inline-download-close:hover { background:linear-gradient(135deg,rgba(248,113,113,.95),rgba(220,38,38,.88)); border-color:rgba(255,255,255,.28); transform:scale(1.06); }
        .kws-inline-download-pop #download_view_holder { background:transparent; border-radius:0; box-shadow:none; padding:14px; color:#e5e7eb; }
      `;
      document.head.appendChild(st);
    }
    const pop = document.createElement('div');
    pop.id = popId;
    pop.className = 'kws-inline-download-pop';
    pop.dataset.soopDl = '1';
    pop.innerHTML = `
      <div id="${popId}_head" class="kws-inline-download-head">
        <div class="kws-inline-download-title">Clip Downloader</div>
        <button id="${popId}_close" type="button" class="kws-inline-download-close">×</button>
      </div>
      <div id="download_view_holder">
        <div id="${popId}_body" style="display:grid;grid-gap:10px;font-size:1em;padding:14px 16px;color:#e5e7eb;">
          <div id="warning_container" style="display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:12px;background:rgba(251,191,36,0.10);border:1px solid rgba(251,191,36,0.28);color:#fde68a;font-size:0.85em;font-weight:600;"><span style="font-size:1.1em;">⚠️</span><span>Keep this tab active — navigating away may interrupt the download.</span></div>
          <div style="display:grid;gap:8px;">
            <div id="${popId}_section" style="font-size:0.82em;color:rgba(255,255,255,0.52);font-weight:600;letter-spacing:0.02em;"></div>
            <div id="${popId}_statusbar" style="border-radius:10px;padding:8px 12px;font-size:0.9em;font-weight:700;color:#ffffff;border:1px solid rgba(37,99,235,0.45);background:linear-gradient(90deg, rgba(2,52,181,0.9) 0%, rgba(2,52,181,0.5) 0.5%, rgba(2,52,181,0.04) 1%, rgba(2,52,181,0.04) 100%);">initiating download</div>
          </div>
          <div style="display:grid;gap:6px;">
            <div style="display:grid;gap:3px;font-size:0.82em;color:rgba(255,255,255,0.65);font-weight:600;">
              <div id="${popId}_filesize"></div>
              <div id="${popId}_duration"></div>
              <div id="${popId}_position"></div>
            </div>
            <button id="${popId}_stop" class="gen_btn" style="width:100%;text-align:center;color:#ffffff;cursor:pointer;background:rgba(37,99,235,0.55);border:1px solid rgba(99,137,255,0.35);backdrop-filter:blur(8px);padding:9px 12px;border-radius:12px;font-size:0.9em;font-weight:700;box-shadow:inset 0 1px 0 rgba(255,255,255,0.10);">Stop and Download Progress</button>
          </div>
        </div>
      </div>`;
    document.body.appendChild(pop);
    { const n = document.querySelectorAll('[data-soop-dl="1"]').length - 1; if (n > 0) { pop.style.right = (24 + n * 22) + 'px'; pop.style.bottom = (24 + n * 22) + 'px'; } };

    const $ = (suffix) => document.getElementById(popId + suffix);
    const setStatus = (t) => { const el = $('_statusbar'); if (el) el.textContent = t; };
    const setProgress = (pct, label) => {
      const bar = $('_statusbar');
      if (!bar) return;
      bar.textContent = label || `${pct}% complete`;
      const sb = $('_stop'); if (sb && sb.textContent === 'Stop and Download Progress') sb.textContent = 'Click to Stop and Download Progress';
      bar.style.background = `linear-gradient(90deg, #00237d ${pct-0.5}%, #0234b5 ${pct+1}%, #0234b501 ${pct+1.5}%, #0234b501 100%)`;
    };
    const closeBtn = $('_close');
    closeBtn.addEventListener('click', () => pop.remove());
    let stopRequested = false;
    let dlFailed = false;
    const doneStatus = (okMsg) => dlFailed
      ? '⚠️ Incomplete — a segment failed after retries. File saved up to that point.'
      : (stopRequested ? '✅ Stopped — progress saved' : okMsg);
    let failMsg = null;
    // Twitch/Kick과 동일: 끝나면 패널 내용을 "✅ Download Complete" + 빨간 Close 버튼으로 교체
    const finishPanel = (msg, isErr, extra) => {
      const cont = $('_body'); if (!cont) return;
      cont.innerHTML = '';
      cont.style.cssText += 'display:flex;align-items:center;justify-content:center;flex-direction:column;gap:12px;padding:24px;';
      const m = document.createElement('div');
      m.textContent = msg;
      m.style.cssText = isErr ? 'font-size:0.95em;font-weight:800;color:#fca5a5;text-align:center;' : 'font-size:1em;font-weight:800;color:#86efac;';
      cont.appendChild(m);
      if (extra) cont.appendChild(extra);
      const btn = document.createElement('button');
      btn.textContent = 'Close';
      btn.style.cssText = 'display:flex;align-items:center;justify-content:center;text-align:center;padding:10px 32px;border-radius:12px;background:rgba(220,38,38,0.75);color:#fff;border:1px solid rgba(239,68,68,0.5);cursor:pointer;font-size:0.95em;font-weight:800;box-shadow:inset 0 1px 0 rgba(255,255,255,0.15);';
      btn.addEventListener('click', () => pop.remove());
      cont.appendChild(btn);
    };
    const addCloseBtn = (extra) => {
      if (failMsg) finishPanel(failMsg, true, extra);
      else if (dlFailed) finishPanel('⚠️ Incomplete — a segment failed after retries. File saved up to that point.', true, extra);
      else finishPanel('✅ Download Complete', false, extra);
    };
    $('_stop').addEventListener('click', () => { stopRequested = true; $('_stop').remove(); setStatus('⏳ Stopping — saving progress so far...'); });
    // 드래그
    {
      let dg = false, ox = 0, oy = 0;
      const hd = $('_head');
      hd.addEventListener('mousedown', e => { if (e.target.closest('button')) return; dg = true; const r = pop.getBoundingClientRect(); pop.style.left = r.left + 'px'; pop.style.top = r.top + 'px'; pop.style.right = 'auto'; pop.style.bottom = 'auto'; pop.style.position = 'fixed'; ox = e.clientX - r.left; oy = e.clientY - r.top; document.body.style.userSelect = 'none'; });
      window.addEventListener('mousemove', e => { if (!dg) return; pop.style.left = e.clientX - ox + 'px'; pop.style.top = e.clientY - oy + 'px'; });
      window.addEventListener('mouseup', () => { dg = false; document.body.style.userSelect = ''; });
    }
    const section = $('_section');
    if (section) section.textContent = `Downloading ${fmt(cs)} to ${fmt(ce)}`;

    if (globalThis.KWSDl) KWSDl.begin(); // keep the tab alive while this download runs
    (async () => {
      try {
        const quality = dlQuality || selectedQuality || 'hd4k';
        let _soopFragments = soopFragments.slice();
        let _dlFragments = dlFragments ? dlFragments.slice() : dlFragments;

        for (let pi = 0; pi < fileItems.length; pi++) {
          const pStart = partOffsets[pi];
          const pEnd = pStart + (fileItems[pi].duration || Infinity);
          if (pEnd > cs && pStart < ce) {
            const alreadyHas = _soopFragments.some(f => !f.isInit && f._part === pi);
            if (!alreadyHas) {
              setStatus(`⏳ Loading part ${pi+1}...`);
              const avail = await getAvailQualities(fileItems[pi].url, true);
              const hlsUrl = avail.find(a => a.name === quality)?.url || avail[0]?.url;
              if (hlsUrl) {
                const frags = await collectFragments(hlsUrl, partOffsets[pi], pi, quality);
                _soopFragments = _soopFragments.filter(f => f._part !== pi);
                _soopFragments.push(...frags);
                _soopFragments.sort((a,b) => a.offset - b.offset);
              }
            }
          }
        }
        setStatus('⏳ Preparing...');

        if (_dlFragments?.length) {
          for (let pi = 0; pi < fileItems.length; pi++) {
            const pStart = partOffsets[pi];
            const pEnd = pStart + (fileItems[pi].duration || Infinity);
            if (pEnd > cs && pStart < ce) {
              const alreadyHas = _dlFragments.some(f => !f.isInit && f._part === pi);
              if (!alreadyHas) {
                setStatus(`⏳ Loading part ${pi+1}...`);
                const avail = await getAvailQualities(fileItems[pi].url, true);
                const hlsUrl = avail.find(a => a.name === quality)?.url || avail[0]?.url;
                if (hlsUrl) {
                  const frags = await collectFragments(hlsUrl, partOffsets[pi], pi, quality);
                  _dlFragments.push(...frags);
                  _dlFragments.sort((a,b) => a.offset - b.offset);
                }
              }
            }
          }
        }
        const usedFrags = _dlFragments?.length ? _dlFragments : _soopFragments;
        const initFrags = usedFrags.filter(f=>f.isInit);
        const dataFrags = usedFrags.filter(f=>!f.isInit&&f.offset+f.dur>cs&&f.offset<ce);
        if (!dataFrags.length) { failMsg = '❌ No segments in the selected range'; addCloseBtn(); return; }
        const fileId = nick ? `${nick} (${streamerId||titleNo})` : (streamerId||titleNo);
        const sn = `${fileId} ${fmtDateForFile(dateStr)}.mp4`;

        setStatus('⏳ Preparing...');
        const allQualsForDl = await getAvailQualities(fileItems[0].url, true);
        const isLegacyVod = allQualsForDl[0]?.hasSeparateAudio || false;
        const needsMux = isLegacyVod;
        const _prePartIds = [...new Set(dataFrags.map(f=>f._part))].sort((a,b)=>a-b);
        const isMultiPart = !needsMux && _prePartIds.length > 1;

        let _dlFh = null, _dlFhV = null, _dlFhA = null;
        try {
          if (needsMux) {
            _dlFhV = await window.showSaveFilePicker({ suggestedName: sn.replace('.mp4','') + ' (Video).mp4', types:[{description:'MP4',accept:{'video/mp4':['.mp4']}}] });
            _dlFhA = await window.showSaveFilePicker({ suggestedName: sn.replace('.mp4','') + ' (Audio).mp4', types:[{description:'MP4',accept:{'video/mp4':['.mp4']}}] });
          } else {
            _dlFh = await window.showSaveFilePicker({ suggestedName: sn, types:[{description:'MP4 Video',accept:{'video/mp4':['.mp4']}}] });
            if (isMultiPart) {
              _dlFh._multiParts = [_dlFh];
              for (let i=1;i<_prePartIds.length;i++){
                const pfh = await window.showSaveFilePicker({ suggestedName: sn.replace('.mp4',` (Part ${i+1} of ${_prePartIds.length}).mp4`), types:[{description:'MP4',accept:{'video/mp4':['.mp4']}}] });
                _dlFh._multiParts.push(pfh);
              }
            }
          }
        } catch(e) {
          if (e.name === 'AbortError') failMsg = 'Cancelled';
          else { console.error('SOOP dl picker:', e); failMsg = '❌ Download failed'; }
          addCloseBtn();
          return;
        }

        if (needsMux) {
          setStatus('⏳ Loading audio track...');
          const audioFrags = [];
          for (let pi = 0; pi < fileItems.length; pi++) {
            const r = await fetch(fileItems[pi].url);
            const t = await r.text();
            const audioLine = t.split('\n').find(l => l.includes('TYPE=AUDIO') && l.includes('URI='));
            const audioUri = audioLine?.match(/URI="([^"]+)"/)?.[1];
            if (audioUri) {
              const audioUrl = new URL(audioUri, fileItems[pi].url).href;
              const frags = await collectFragments(audioUrl, partOffsets[pi], pi, 'audio');
              audioFrags.push(...frags);
            }
          }
          const audioDataFrags = audioFrags.filter(f => !f.isInit && f.offset + f.dur > cs && f.offset < ce);
          const audioInitFrags = audioFrags.filter(f => f.isInit);

          const vFh = _dlFhV || _dlFh;
          const vWs = await vFh.createWritable();
          const vInitFrag = initFrags.find(f=>f._part===dataFrags[0]._part);
          if (vInitFrag) { const _b=await soopFetchBuf(vInitFrag.path); if(!_b) dlFailed=true; else await vWs.write(_b); }
          let vd=0;
          for (const f of dataFrags) {
            if (stopRequested) break;
            const _b=await soopFetchBuf(f.path); if(!_b){ dlFailed=true; break; } await vWs.write(_b); vd++;
            setProgress(Math.round(vd/dataFrags.length*100), `⏳ Video ${Math.round(vd/dataFrags.length*100)}%`);
          }
          await vWs.close();

          let aFh = null;
          if (audioDataFrags.length) {
            try {
              aFh = await window.showSaveFilePicker({ suggestedName: sn.replace('.mp4','') + ' (Audio).mp4', types:[{description:'MP4',accept:{'video/mp4':['.mp4']}}] });
            } catch(e) { console.warn('audio picker cancelled'); }
          }
          if (aFh && audioDataFrags.length) {
            const aWs = await aFh.createWritable();
            const aInitFrag = audioInitFrags.find(f=>f._part===dataFrags[0]._part);
            if (aInitFrag) { const _b=await soopFetchBuf(aInitFrag.path); if(!_b) dlFailed=true; else await aWs.write(_b); }
            let ad=0;
            for (const f of audioDataFrags) {
              if (stopRequested) break;
              const _b=await soopFetchBuf(f.path); if(!_b){ dlFailed=true; break; } await aWs.write(_b); ad++;
              setProgress(Math.round(ad/audioDataFrags.length*100), `⏳ Audio ${Math.round(ad/audioDataFrags.length*100)}%`);
            }
            await aWs.close();
          }

          $('_stop')?.remove();
          const guide = document.createElement('div');
          guide.style.cssText = 'margin-top:10px;padding:10px 12px;background:rgba(250,204,21,0.08);border:1px solid rgba(250,204,21,0.25);border-radius:10px;font-size:10px;line-height:1.6;color:rgba(255,255,255,0.75);';
          guide.innerHTML = `<div style="font-weight:800;color:#fde68a;margin-bottom:5px;">⚠️ This is an old VOD — audio is separate</div><div style="margin-bottom:4px;">Two files were saved:</div><div style="margin:4px 0 6px 8px;color:rgba(255,255,255,0.5);">📹 <span style="color:#e2e8f0;">${sn.replace('.mp4','') + ' (Video).mp4'}</span><br>🔊 <span style="color:#e2e8f0;">${sn.replace('.mp4','') + ' (Audio).mp4'}</span></div><div style="color:rgba(255,255,255,0.6);line-height:1.7;">To merge into one file:<br>1. Download <a href="https://mkvtoolnix.download/downloads.html" target="_blank" style="color:#93c5fd;text-decoration:underline;">MKVToolNix</a> and install it<br>2. Open <b style="color:#fff;">MKVToolNix GUI</b><br>3. Drag both files into the window<br>4. Click <b style="color:#fff;">Start multiplexing</b></div>`;
          addCloseBtn(guide);
          return;
        }

        const fh = _dlFh;
        if (!fh) { failMsg = '❌ No file handle'; addCloseBtn(); return; }
        let bytesSaved = 0, durSaved = 0;
        const ws = await fh.createWritable();
        const partIds = [...new Set(dataFrags.map(f=>f._part))].sort((a,b)=>a-b);
        if (partIds.length === 1) {
          const fi = initFrags.find(f=>f._part===partIds[0]);
          if (fi) { const _b=await soopFetchBuf(fi.path); if(!_b) dlFailed=true; else await ws.write(_b); }
          let done=0;
          const sortedDataFrags = dataFrags.slice().sort((a,b)=>a.offset-b.offset);
          for (const frag of sortedDataFrags) {
            if (stopRequested) break;
            const buf = await soopFetchBuf(frag.path); if(!buf){ dlFailed=true; break; }
            await ws.write(buf); bytesSaved += buf.byteLength; done++;
            const pct = Math.round(done/sortedDataFrags.length*100);
            setProgress(pct);
            const mb = (bytesSaved/1000000).toFixed(2);
            const fsEl = $('_filesize'); if (fsEl) fsEl.textContent = `Current File Size: ${mb}mb`;
            const posEl = $('_position'); if (posEl) posEl.textContent = `Current VOD Position: ${fmt(frag.offset)}`;
            durSaved += (frag.dur || 0); const duEl = $('_duration'); if (duEl) duEl.textContent = `Current File Duration: ${fmt(durSaved)}`;
          }
          await ws.close();
          setStatus(doneStatus('✅ Done!'));
        } else {
          setStatus('⏳ Multi-part download...');
          const multiParts = _dlFh._multiParts || [_dlFh];
          outer:
          for (let pi=0;pi<partIds.length;pi++) {
            const pid = partIds[pi];
            const pFrags = dataFrags.filter(f=>f._part===pid).sort((a,b)=>a.offset-b.offset);
            const pInit = initFrags.find(f=>f._part===pid);
            const partLabel = `Part ${pi+1} of ${partIds.length}`;
            const pfh = multiParts[pi] || multiParts[multiParts.length-1];
            let pws;
            if (pi === 0) pws = ws;
            else pws = await pfh.createWritable();
            if (pInit) { const _b=await soopFetchBuf(pInit.path); if(!_b) dlFailed=true; else await pws.write(_b); }
            let done=0;
            for (const frag of pFrags) {
              if (stopRequested) { await pws.close(); break outer; }
              const buf = await soopFetchBuf(frag.path); if(!buf){ dlFailed=true; await pws.close(); break outer; }
              await pws.write(buf); bytesSaved += buf.byteLength; done++;
              setProgress(Math.round(done/pFrags.length*100), `⏳ ${partLabel}: ${Math.round(done/pFrags.length*100)}%`);
              const fsEl = $('_filesize'); if (fsEl) fsEl.textContent = `Current File Size: ${(bytesSaved/1000000).toFixed(2)}mb`;
              durSaved += (frag.dur || 0); const duEl = $('_duration'); if (duEl) duEl.textContent = `Current File Duration: ${fmt(durSaved)}`;
              const poEl = $('_position'); if (poEl) poEl.textContent = `Current VOD Position: ${fmt(frag.offset)}`;
            }
            await pws.close();
          }
          setStatus(doneStatus(`✅ Done! (${partIds.length} files saved)`));
        }
        $('_stop')?.remove();
        addCloseBtn();
      } catch(e) {
        if (e.name !== 'AbortError') { console.error('SOOP dl:', e); failMsg = '❌ Download failed'; } else failMsg = 'Cancelled';
        $('_stop')?.remove();
        addCloseBtn();
      } finally {
        if (globalThis.KWSDl) KWSDl.end();
      }
    })();
  }

  // ══════════════════════════════════════════════════════════════
  //  SOOP Inline VOD Player  (Twitch 인라인 플레이어와 동일 방식)
  // ══════════════════════════════════════════════════════════════
  const SOOP_INLINE_ID = 'soop-inline-vod-player';

  // Twitch kwsEnsureInlineVodSkin과 동일한 CSS를 SOOP 컨테이너에 적용
  function soopEnsureInlinePlayerCSS() {
    document.getElementById('soop-inline-vod-skin')?.remove();
    const style = document.createElement('style');
    style.id = 'soop-inline-vod-skin';
    style.textContent = `
      #${SOOP_INLINE_ID} { box-sizing:border-box; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; }
      #${SOOP_INLINE_ID} video { width:100%; height:100%; display:block; object-fit:contain; background:#000; }
      #${SOOP_INLINE_ID} .soop-glassbar { position:absolute; left:12px; right:12px; top:12px; z-index:7; display:flex; align-items:center; justify-content:space-between; gap:10px; padding:9px 10px; border-radius:18px; background:rgba(20,24,34,.58); border:1px solid rgba(255,255,255,.14); backdrop-filter:blur(18px); -webkit-backdrop-filter:blur(18px); opacity:0; transform:translateY(-6px); transition:opacity .16s ease, transform .16s ease; pointer-events:none; }
      #${SOOP_INLINE_ID}:hover .soop-glassbar { opacity:1; transform:translateY(0); pointer-events:auto; }
      #${SOOP_INLINE_ID} .soop-glassbar.visible { opacity:1; transform:translateY(0); pointer-events:auto; }
      #${SOOP_INLINE_ID} .soop-vod-title { min-width:0; color:#fff; font:800 12px/1.25 -apple-system,sans-serif; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      #${SOOP_INLINE_ID} .soop-vod-subtitle { color:rgba(255,255,255,.52); font:600 10px/1.2 -apple-system,sans-serif; margin-top:2px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      #${SOOP_INLINE_ID} .soop-actions { display:flex; align-items:center; gap:6px; flex-wrap:wrap; justify-content:flex-end; }
      #${SOOP_INLINE_ID} .soop-pill, #${SOOP_INLINE_ID} .soop-iconbtn { border:1px solid rgba(255,255,255,.16); background:rgba(255,255,255,.10); color:rgba(255,255,255,.86); border-radius:999px; min-height:28px; padding:0 10px; font:800 11px/1 -apple-system,sans-serif; cursor:pointer; display:inline-flex; align-items:center; justify-content:center; gap:5px; box-shadow:inset 0 1px 0 rgba(255,255,255,.08); }
      #${SOOP_INLINE_ID} .soop-pill:hover, #${SOOP_INLINE_ID} .soop-iconbtn:hover { background:rgba(255,255,255,.20); color:#fff; border-color:rgba(255,255,255,.30); }
      #${SOOP_INLINE_ID} .soop-pill.checked { background:rgba(250,204,21,.22) !important; color:#facc15 !important; border-color:rgba(250,204,21,.5) !important; }
      #${SOOP_INLINE_ID} .soop-iconbtn { width:30px; padding:0; font-size:13px; }
      #${SOOP_INLINE_ID} .soop-res-group { display:flex; gap:5px; align-items:center; max-width:42vw; overflow:auto; scrollbar-width:none; }
      #${SOOP_INLINE_ID} .soop-res-group::-webkit-scrollbar { display:none; }
      #${SOOP_INLINE_ID} video { cursor:pointer; }
      #${SOOP_INLINE_ID} .kws-unified-close { width:30px; height:30px; border-radius:999px; background:linear-gradient(135deg,rgba(255,255,255,.18),rgba(255,255,255,.07)); border:1px solid rgba(255,255,255,.18); box-shadow:0 8px 18px rgba(0,0,0,.35),inset 0 1px 0 rgba(255,255,255,.18); display:flex; align-items:center; justify-content:center; font-size:15px; color:#fff; cursor:pointer; transition:transform .14s,background .14s,border-color .14s; }
      #${SOOP_INLINE_ID} .kws-unified-close:hover { background:linear-gradient(135deg,rgba(248,113,113,.95),rgba(220,38,38,.88)); border-color:rgba(255,255,255,.28); transform:scale(1.06); }
      /* 컨트롤바 override - css.js의 visibility:hidden 무력화 */
      #${SOOP_INLINE_ID} .custom_video_controls_cont { height:auto !important; display:flex !important; flex-direction:column !important; gap:6px !important; visibility:visible !important; opacity:0; background:rgba(12,15,23,.66) !important; border:1px solid rgba(255,255,255,.12) !important; border-radius:18px !important; padding:7px 10px !important; backdrop-filter: blur(14px) !important; -webkit-backdrop-filter: blur(14px) !important; transform:translateY(6px); transition:opacity .16s ease, transform .16s ease; pointer-events:none; box-sizing:border-box !important; }
      #${SOOP_INLINE_ID}:hover .custom_video_controls_cont { opacity:1 !important; transform:translateY(0); pointer-events:auto; }
      #${SOOP_INLINE_ID} .custom_video_controls_cont > div { max-width:100% !important; box-sizing:border-box !important; flex-shrink:0 !important; flex-grow:0 !important; }
      #${SOOP_INLINE_ID} .custom_video_controls_cont > div:first-child { display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:nowrap; }
      #${SOOP_INLINE_ID} .custom_video_controls_cont .speed_cont,
      #${SOOP_INLINE_ID} .custom_video_controls_cont .volume_cont { background:rgba(255,255,255,.07) !important; border-radius:999px !important; padding:3px 8px !important; height:32px !important; box-sizing:border-box !important; display:flex !important; align-items:center !important; }
      #${SOOP_INLINE_ID} .custom_video_controls_cont .volume_bar { visibility:visible !important; width:86px !important; transform:none !important; accent-color:#facc15 !important; }
      #${SOOP_INLINE_ID} .custom_video_controls_cont .speed_bar { visibility:visible !important; width:70px !important; transform:none !important; accent-color:#facc15 !important; }
      #${SOOP_INLINE_ID} .custom_video_controls_cont .speed_display { visibility:visible !important; width:42px !important; }
    `;
    document.head.appendChild(style);
  }


  // ── 클립 다운로드 구간 표시 (드래그 가능한 오버레이) — Twitch KWS의 updateRangeOverlay와 동일한 디자인 ──
  let _soopRangeDragCb = null;
  function soopUpdateRangeOverlay(parent, total, startSec, endSec, onChangeCb) {
    const OVERLAY_ID = 'soop_range_overlay';
    let overlay = document.getElementById(OVERLAY_ID);
    if (onChangeCb !== undefined) _soopRangeDragCb = onChangeCb;
    if (startSec == null) { overlay?.remove(); _soopRangeDragCb = null; return; }
    if (!parent || !total) return;

    const fmtT = sec => {
      if (sec == null || isNaN(sec)) return '--:--:--';
      sec = Math.max(0, sec);
      const h = Math.floor(sec/3600), m = Math.floor((sec%3600)/60), s = Math.floor(sec%60);
      return String(h).padStart(2,'0') + ':' + String(m).padStart(2,'0') + ':' + String(s).padStart(2,'0');
    };

    const render = (s, en) => {
      overlay.dataset.curStart = s; overlay.dataset.curEnd = en;
      const sp = Math.max(0, Math.min(100, (s/total)*100));
      const ep = Math.max(0, Math.min(100, (en/total)*100));
      const stripe = overlay.querySelector('.kws-range-stripe');
      stripe.style.left = sp + '%';
      stripe.style.width = Math.max(0, ep - sp) + '%';
      const hs = overlay.querySelector('.kws-range-handle-start');
      const he = overlay.querySelector('.kws-range-handle-end');
      hs.style.left = 'calc(' + sp + '% - 8px)';
      he.style.left = 'calc(' + ep + '% - 8px)';
      hs.querySelector('.kws-range-label').textContent = fmtT(s);
      he.querySelector('.kws-range-label').textContent = fmtT(en);
    };

    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = OVERLAY_ID;
      overlay.style.cssText = 'position:absolute;top:-8px;bottom:-8px;left:0;right:0;pointer-events:none;z-index:6;';
      parent.style.position = 'relative';
      parent.appendChild(overlay);

      // Start=노랑, End=파랑 — 스트라이프/라인은 시각 표시만, 시크바 조작을 막지 않도록 pointer-events:none
      const stripe = document.createElement('div');
      stripe.className = 'kws-range-stripe';
      stripe.style.cssText = 'position:absolute;top:-2px;bottom:-2px;left:0;width:0;box-sizing:border-box;border-radius:3px;pointer-events:none;' +
        'background:repeating-linear-gradient(135deg,rgba(255,255,255,0.12) 0px 6px,transparent 6px 12px),linear-gradient(90deg,rgba(250,204,21,0.42),rgba(96,165,250,0.42));' +
        'border-top:1px solid rgba(255,255,255,0.28);border-bottom:1px solid rgba(255,255,255,0.28);';
      overlay.appendChild(stripe);

      const mkHandle = (side, color) => {
        const h = document.createElement('div');
        h.className = 'kws-range-handle kws-range-handle-' + side;
        // 드래그 hit area는 시크바 위쪽 라벨 영역에만 — 시크바 자체는 안 가림
        h.style.cssText = 'position:absolute;top:-16px;height:16px;width:16px;cursor:ew-resize;pointer-events:auto;' +
          'display:flex;align-items:center;justify-content:center;z-index:2;';

        const line = document.createElement('div');
        line.style.cssText = 'position:absolute;top:16px;bottom:-2px;left:50%;width:3px;margin-left:-1.5px;border-radius:2px;pointer-events:none;' +
          'background:' + color + ';box-shadow:0 0 5px ' + color + ',0 0 0 1px rgba(0,0,0,0.5);';
        h.appendChild(line);

        const tri = document.createElement('div');
        const triCss = side === 'start'
          ? 'border-width:5px 0 5px 7px;border-color:transparent transparent transparent ' + color + ';'
          : 'border-width:5px 7px 5px 0;border-color:transparent ' + color + ' transparent transparent;';
        tri.style.cssText = 'position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:0;height:0;pointer-events:none;' +
          'border-style:solid;' + triCss + 'filter:drop-shadow(0 1px 2px rgba(0,0,0,0.6));';
        h.appendChild(tri);

        const label = document.createElement('div');
        label.className = 'kws-range-label';
        label.style.cssText = 'position:absolute;bottom:100%;left:50%;transform:translateX(-50%);margin-bottom:6px;pointer-events:none;' +
          'padding:3px 7px;border-radius:6px;background:rgba(12,8,22,0.94);border:1px solid ' + color + '88;' +
          'color:' + color + ';font-size:10px;font-weight:700;font-family:monospace;white-space:nowrap;';
        h.appendChild(label);
        overlay.appendChild(h);
        return h;
      };
      mkHandle('start', '#facc15');
      mkHandle('end', '#60a5fa');

      // ── 드래그로 구간 조절 (양 끝 핸들만 — 구간 전체 드래그 이동 기능은 제거) ──
      let dragMode = null;
      const secAt = (clientX) => {
        const rect = parent.getBoundingClientRect();
        const pct = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
        return pct * total;
      };
      const startDrag = (mode) => (e) => {
        e.preventDefault(); e.stopPropagation();
        dragMode = mode;
        document.body.style.userSelect = 'none';
      };
      const onMove = (e) => {
        if (!dragMode) return;
        let s = parseFloat(overlay.dataset.curStart), en = parseFloat(overlay.dataset.curEnd);
        if (dragMode === 'start') s = Math.max(0, Math.min(secAt(e.clientX), en - 1));
        else if (dragMode === 'end') en = Math.min(Math.max(secAt(e.clientX), s + 1), total);
        render(Math.round(s), Math.round(en));
        if (_soopRangeDragCb) _soopRangeDragCb(Math.round(s), Math.round(en));
      };
      const onUp = () => { dragMode = null; document.body.style.userSelect = ''; };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
      overlay.querySelector('.kws-range-handle-start').addEventListener('mousedown', startDrag('start'));
      overlay.querySelector('.kws-range-handle-end').addEventListener('mousedown', startDrag('end'));
    }

    render(startSec, endSec);
  }

  async function openSoopInlinePlayer({ playerUrl, seekSecs = 0, title = '', dateText = '', streamerId = '', nick = '' }) {
    soopEnsureInlinePlayerCSS();

    const titleNo = (new URL(playerUrl).pathname.match(/\/player\/(\d+)/) || [])[1] || '';

    // 같은 VOD가 이미 열려 있으면 통째로 다시 만들지 않고 시간만 이동
    const existingCont = document.getElementById(SOOP_INLINE_ID);
    if (existingCont && titleNo && existingCont.dataset.titleNo === titleNo && typeof existingCont._soopSeekTo === 'function') {
      await existingCont._soopSeekTo(seekSecs);
      return;
    }
    document.getElementById(SOOP_INLINE_ID)?.remove();
    document.getElementById('soop_dl_pop')?.remove(); document.getElementById('soop_range_overlay')?.remove(); // the old player's range UI

    const dateStr = dateText || (title ? title.slice(0, 10) : '');
    const initW = Math.min(900, Math.max(520, Math.round(window.innerWidth * 0.52)));
    const initH = Math.round(initW * 9 / 16);

    // ── 컨테이너 ──
    const cont = document.createElement('div');
    cont.id = SOOP_INLINE_ID;
    // 1.2.5.22: the clip-range popup and the seek-bar range overlay belong to this player — whatever
    // removes the player (✕, Esc, opening another VOD, page scripts), they go with it, like on
    // Twitch / Kick. A download already running keeps its own progress popup.
    {
      const dropRangeUi = () => { document.getElementById('soop_dl_pop')?.remove(); document.getElementById('soop_range_overlay')?.remove(); };
      const watch = new MutationObserver(() => { if (!document.contains(cont)) { watch.disconnect(); dropRangeUi(); } });
      setTimeout(() => { if (document.contains(cont)) watch.observe(document.body, { childList: true, subtree: false }); else dropRangeUi(); }, 0);
    }
    cont.dataset.titleNo = titleNo;
    cont.style.cssText = `position:fixed;top:22px;left:${Math.max(18,Math.round(window.innerWidth*0.30))}px;width:${initW}px;z-index:${topZIndexer()};background:rgba(10,12,18,.88);border:3px solid rgba(255,255,255,.22);border-radius:24px;box-shadow:0 22px 70px rgba(0,0,0,.55),inset 0 1px 0 rgba(255,255,255,.14);backdrop-filter:blur(22px) saturate(150%);-webkit-backdrop-filter:blur(22px) saturate(150%);min-width:420px;min-height:270px;overflow:hidden;display:flex;flex-direction:column;`;
    document.body.appendChild(cont);
    cont.addEventListener('mousedown', () => { cont.style.zIndex = topZIndexer(); });

    // ESC
    const escH = e => { if (e.key==='Escape') { window.dispatchEvent(new CustomEvent('__soop_hls_cmd',{detail:{cmd:'destroy'}})); cont.remove(); document.getElementById('soop_dl_pop')?.remove(); document.getElementById('soop_range_overlay')?.remove(); document.removeEventListener('keydown',escH); } };
    document.addEventListener('keydown', escH);

    // ── 드래그 헤더 (18px 상단 투명 영역) + 영상 아무 곳이나 눌러도 창 이동 (일정 거리 이상 움직여야 드래그로 인식) ──
    const dragHead = document.createElement('div');
    dragHead.style.cssText = 'height:18px;cursor:grab;flex-shrink:0;';
    cont.appendChild(dragHead);
    let _dragState = { on:false, startX:0, startY:0, moved:false, origLeft:0, origTop:0 };
    const DRAG_THRESH = 6;
    const startContDrag = e => {
      _dragState.on = true; _dragState.moved = false;
      _dragState.startX = e.clientX; _dragState.startY = e.clientY;
      const r = cont.getBoundingClientRect();
      _dragState.origLeft = r.left; _dragState.origTop = r.top;
      cont.style.left = r.left + 'px'; cont.style.top = r.top + 'px';
      document.body.style.userSelect = 'none';
    };
    dragHead.addEventListener('mousedown', e => { startContDrag(e); e.preventDefault(); });
    window.addEventListener('mousemove', e => {
      if (!_dragState.on) return;
      const dx = e.clientX - _dragState.startX, dy = e.clientY - _dragState.startY;
      if (!_dragState.moved && Math.hypot(dx, dy) > DRAG_THRESH) { _dragState.moved = true; cont.style.zIndex = topZIndexer(); }
      if (_dragState.moved) {
        cont.style.left = Math.max(8, _dragState.origLeft + dx) + 'px';
        cont.style.top = Math.max(8, _dragState.origTop + dy) + 'px';
      }
    });
    window.addEventListener('mouseup', () => {
      if (_dragState.on && _dragState.moved) video._kwsSuppressNextClick = true;
      _dragState.on = false;
      document.body.style.userSelect = '';
    });

    // ── body (video 영역) ──
    const body = document.createElement('div');
    body.id = SOOP_INLINE_ID + '_body';
    body.style.cssText = `position:relative;background:#05070b;margin:0 18px 18px 18px;border-radius:16px;overflow:hidden;height:${initH}px;flex-shrink:0;`;
    cont.appendChild(body);

    // ── 리사이즈 핸들 (Twitch와 완전히 동일한 커스텀 리사이즈 — 드래그해도 비율 항상 유지) ──
    const footResizer = document.createElement('div');
    footResizer.setAttribute('data-resize-id', `${SOOP_INLINE_ID},${body.id}`);
    footResizer.setAttribute('data-parent_dimensions', btoaJSON({ header_height: 18, left_panel_width: 18, right_panel_width: 18, footer_height: 18, shift_col_px: 0, close_btn_px: 14 }));
    footResizer.style.cssText = 'position:absolute;right:10px;bottom:10px;width:16px;height:16px;cursor:nw-resize;z-index:9;color:rgba(255,255,255,.42);display:flex;align-items:flex-end;justify-content:flex-end;font:900 15px/1 -apple-system,sans-serif;text-shadow:0 1px 8px rgba(0,0,0,.8);pointer-events:auto;';
    footResizer.textContent = '◢';
    footResizer.onmouseover = adjustElementSize;
    cont.appendChild(footResizer);

    // 비율 유지 — 컨트롤바가 이제 video 위에 오버레이라 flow 공간을 안 차지하므로,
    // Twitch 인라인 플레이어와 동일하게 "너비 기준으로 높이만 계산"하면 됨
    let _ratio = 9/16;
    if (window.ResizeObserver) {
      const ro = new ResizeObserver(()=>{
        const cw = cont.getBoundingClientRect().width;
        if (!cw) return;
        const bodyW = cw - 36; // 좌우 18px 마진
        if (bodyW > 0) body.style.height = (window.KWSFitPlayerHeight ? window.KWSFitPlayerHeight(cont, _ratio, 36, false) : Math.round(bodyW * _ratio)) + 'px';
      });
      ro.observe(cont);
      new MutationObserver((_,mo)=>{ if(!document.contains(cont)){ro.disconnect();mo.disconnect();} }).observe(document.body,{childList:true,subtree:true});
    }

    // video
    const video = document.createElement('video');
    video.className = 'pop_out_video';
    video.id = '__soop_inline_video';
    video.setAttribute('playsinline',''); video.setAttribute('webkit-playsinline','');
    // 영상 아무 곳이나 클릭+드래그해도 창 전체가 움직이도록 (팟플레이어 스타일)
    video.addEventListener('mousedown', startContDrag);
    video.style.cssText = 'width:100%;height:100%;display:block;object-fit:contain;background:#000;';
    body.appendChild(video);

    // 로딩
    const loadEl = document.createElement('div');
    loadEl.style.cssText = 'position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#94a3b8;font-size:13px;font-weight:700;background:rgba(5,7,11,.8);z-index:5;';
    body.appendChild(loadEl);
    let loadSpinner = (typeof addSpinner === 'function') ? addSpinner({ rect: body.getBoundingClientRect(), text: 'Loading VOD info...' }) : null;
    if (!loadSpinner) loadEl.textContent = '⏳ Loading VOD info...'; // addSpinner 로드 실패 시 폴백

    // ── 글래스바 (hover) ──
    const bar = document.createElement('div'); bar.className='soop-glassbar';
    const meta = document.createElement('div'); meta.style.cssText='min-width:0;flex:1;cursor:move;';
    meta.addEventListener('mousedown', startContDrag);
    const titleEl2 = document.createElement('div'); titleEl2.className='soop-vod-title'; titleEl2.textContent=title||'SOOP VOD';
    const subEl = document.createElement('div'); subEl.className='soop-vod-subtitle';
    const _nickLabel = nick ? `${nick} (${streamerId||titleNo})` : (streamerId||titleNo);
    subEl.textContent=[_nickLabel, dateStr].filter(Boolean).join(' · ');
    meta.append(titleEl2,subEl);
    const actions = document.createElement('div'); actions.className='soop-actions';
    const resGroup = document.createElement('div'); resGroup.className='soop-res-group';
    const vodLinkBtn = document.createElement('button'); vodLinkBtn.type='button'; vodLinkBtn.className='soop-iconbtn'; vodLinkBtn.textContent='🔗'; vodLinkBtn.title='Open original VOD';
    // 1.2.5.29: open the original at the current play position (whole-VOD seconds across parts) — SOOP's ?change_second=
    vodLinkBtn.title='Open original VOD at this time';
    vodLinkBtn.addEventListener('click',()=>{
      let sec=0; try{ sec=Math.max(0,Math.floor((partOffsets[currentPartIdx]||0)+(video.currentTime||0))); }catch(_){}
      let url=playerUrl; try{ const u=new URL(playerUrl); if(sec>0)u.searchParams.set('change_second',String(sec)); else u.searchParams.delete('change_second'); url=u.href; }catch(_){}
      window.open(url,'_blank');
    });
    const dlBtn = document.createElement('button'); dlBtn.type='button'; dlBtn.className='soop-iconbtn'; dlBtn.textContent='⬇'; dlBtn.title='Download'; dlBtn.disabled=true; dlBtn.style.opacity='0.4';
    const fsBtn = document.createElement('button'); fsBtn.type='button'; fsBtn.className='soop-iconbtn'; fsBtn.textContent='⛶'; fsBtn.title='Fullscreen';
    fsBtn.addEventListener('click',()=>{ try{video.requestFullscreen();}catch(e){} });
    const closeBtn = document.createElement('button'); closeBtn.type='button'; closeBtn.className='kws-unified-close'; closeBtn.textContent='✕';
    closeBtn.addEventListener('click',()=>{ window.dispatchEvent(new CustomEvent('__soop_hls_cmd',{detail:{cmd:'destroy'}})); cont.remove(); document.getElementById('soop_dl_pop')?.remove(); document.getElementById('soop_range_overlay')?.remove(); });
    actions.append(resGroup,vodLinkBtn,dlBtn,fsBtn,closeBtn);
    bar.append(meta,actions); body.appendChild(bar);

    // ── 커스텀 컨트롤 (Twitch 스타일) — video 영역 위에 절대위치로 오버레이 ──
    const ctrlWrap = document.createElement('div');
    ctrlWrap.style.cssText = 'position:absolute;left:12px;right:12px;bottom:12px;z-index:7;';
    const ctrlCont = document.createElement('div'); ctrlCont.className='custom_video_controls_cont';

    // 시크바 (하단 버튼 행 다음에 붙임 — Twitch와 동일하게 버튼이 위, 시크바가 아래)
    const seekCont = document.createElement('div'); seekCont.style.cssText='position:relative;';
    const seeker = document.createElement('input');
    seeker.type='range'; seeker.min='0'; seeker.max='1000'; seeker.value='0';
    seeker.style.cssText='width:100%;accent-color:#60a5fa;';
    seekCont.appendChild(seeker);

    // 하단 컨트롤 행
    const infoCont = document.createElement('div'); infoCont.style.cssText='display:flex;flex-wrap:wrap;';
    const leftCtrl = document.createElement('div'); leftCtrl.style.cssText='display:grid;grid-template-columns:20px 20px 20px 150px;grid-gap:4px;place-items:center start;';
    const rightCtrl = document.createElement('div'); rightCtrl.style.cssText='margin:auto;display:flex;flex-wrap:wrap;gap:4px;place-items:end center;';

    // 플레이/일시정지
    const playEl = document.createElement('div'); playEl.style.cssText='cursor:pointer;display:flex;align-items:center;';
    playEl.innerHTML = '<svg id="pause_svg" xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 16 16"><path fill="white" d="M2 2h4v12h-4v-4z"/><path fill="white" d="M8 2h4v12h-4v-4z"/></svg>';

    // 뒤로/앞으로 (Twitch 아이콘)
    const backEl = document.createElement('div'); backEl.style.cssText='cursor:pointer;display:flex;align-items:center;';
    backEl.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 16 16"><text fill="white" x="4" y="11" font-size="8">30</text><path fill="white" d="M8 0c-3 0-5.6 1.6-6.9 4.1l-1.1-1.1v4h4l-1.5-1.5c1-2 3.1-3.5 5.5-3.5 3.3 0 6 2.7 6 6s-2.7 6-6 6c-1.8 0-3.4-0.8-4.5-2.1l-1.5 1.3c1.4 1.7 3.6 2.8 6 2.8 4.4 0 8-3.6 8-8s-3.6-8-8-8z"/></svg>';
    const fwdEl = document.createElement('div'); fwdEl.style.cssText='cursor:pointer;display:flex;align-items:center;';
    fwdEl.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 16 16"><text fill="white" x="4" y="11" font-size="8">30</text><path fill="white" d="M16 7v-4l-1.1 1.1c-1.3-2.5-3.9-4.1-6.9-4.1-4.4 0-8 3.6-8 8s3.6 8 8 8c2.4 0 4.6-1.1 6-2.8l-1.5-1.3c-1.1 1.3-2.7 2.1-4.5 2.1-3.3 0-6-2.7-6-6s2.7-6 6-6c2.4 0 4.5 1.5 5.5 3.5l-1.5 1.5h4z"/></svg>';

    // 시간 표시
    const timeEl = document.createElement('div');
    timeEl.style.cssText='width:fit-content;text-align:left;color:#fff;font-size:11px;font-weight:700;font-variant-numeric:tabular-nums;white-space:nowrap;';
    timeEl.textContent='00:00:00 / --:--:--';
    leftCtrl.append(playEl,backEl,fwdEl,timeEl);

    // 속도 (우측) — x1/x2/x3/x4 버튼만
    const speedCont = document.createElement('div'); speedCont.className='speed_cont';
    speedCont.style.cssText='display:flex;gap:3px;align-items:center;color:#fff;';
    const speedStepBtns = [1,2,3,4].map(n => {
      const b = document.createElement('button');
      b.type='button'; b.dataset.speed=String(n); b.className='soop-pill soop-speed-pill'+(n===1?' checked':'');
      b.textContent = n+'x';
      speedCont.appendChild(b);
      return b;
    });

    // 볼륨 (우측)
    const volCont = document.createElement('div'); volCont.className='volume_cont';
    volCont.style.cssText='display:grid;grid-template-columns:20px 120px;grid-gap:4px;place-items:center;';
    const volIcon = document.createElement('div'); volIcon.style.cssText='cursor:pointer;display:flex;align-items:center;';
    volIcon.innerHTML = '<svg id="volume_on" xmlns="http://www.w3.org/2000/svg" fill="white" height="20px" width="20px" viewBox="0 0 24 24"><g><g><path d="M13,23.1L5.6,17H0V7h5.6L13,0.9C13,0.9,13,23.1,13,23.1z M2,15h4.4l4.6,3.9V5.1L6.4,9H2V15z M15,21v-2c3.9,0,7-3.1,7-7s-3.1-7-7-7V3c5,0,9,4,9,9S20,21,15,21z M15,17v-2c1.7,0,3-1.3,3-3s-1.3-3-3-3V7c2.8,0,5,2.2,5,5S17.8,17,15,17z"/></g></g></svg>';
    const volBar = document.createElement('input'); volBar.type='range'; volBar.className='volume_bar'; volBar.min='0'; volBar.max='100'; volBar.value='80';
    volBar.style.cssText='width:86px;flex-shrink:0;accent-color:#facc15;';
    volCont.append(volIcon,volBar);

    rightCtrl.append(speedCont,volCont);
    infoCont.append(leftCtrl,rightCtrl);
    ctrlCont.appendChild(infoCont);
    ctrlCont.appendChild(seekCont);
    ctrlWrap.appendChild(ctrlCont);
    body.appendChild(ctrlWrap);

    // resize hint


    // ── 볼륨 초기화 ──
    const savedVol = await chrome.storage.local.get(['soopPlayerVolume']);
    const initVol = savedVol?.soopPlayerVolume ?? 100;
    video.volume=initVol/100; video.muted=false; volBar.value=String(initVol);

    // ── VOD 로드 ──
    let fileItems=[], partOffsets=[], totalDuration=0, currentPartIdx=0, soopFragments=[], selectedQuality='';

    try {
      const res = await Promise.race([
        chrome.runtime.sendMessage({type:'OPEN_VOD_TAB',playerUrl}),
        new Promise((_,rej)=>setTimeout(()=>rej(new Error('timeout')),60000))
      ]);
      if (!res?.success||!res.fileItems?.length) throw new Error(res?.error||'no fileItems');
      fileItems = res.fileItems.map((f,i)=>({url:f.url||'',duration:f.duration||0,order:f.file_order||(i+1)})).filter(f=>f.url).sort((a,b)=>a.order-b.order);
    } catch(err) {
      // 구독 전용 VOD 또는 로드 실패 처리
      loadSpinner?.remove();
      loadEl.innerHTML = '';
      loadEl.style.cssText = 'position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;background:rgba(5,7,11,.9);z-index:5;padding:20px;text-align:center;';
      const lockIcon = document.createElement('div');
      lockIcon.textContent = '🔒';
      lockIcon.style.cssText = 'font-size:36px;';
      const lockTitle = document.createElement('div');
      lockTitle.textContent = 'Subscribe Only VOD';
      lockTitle.style.cssText = 'color:#fff;font-size:14px;font-weight:800;';
      const lockDesc = document.createElement('div');
      lockDesc.textContent = 'This VOD requires a subscription. Open the original link to watch.';
      lockDesc.style.cssText = 'color:rgba(255,255,255,.5);font-size:11px;line-height:1.5;max-width:260px;';
      const openBtn = document.createElement('button');
      openBtn.type = 'button';
      openBtn.textContent = '🔗 Open Original VOD';
      openBtn.style.cssText = 'padding:8px 18px;border-radius:999px;background:linear-gradient(135deg,rgba(37,99,235,.8),rgba(59,130,246,.8));color:#fff;border:1px solid rgba(99,137,255,.4);font-size:12px;font-weight:800;cursor:pointer;';
      openBtn.addEventListener('click', () => window.open(playerUrl, '_blank'));
      loadEl.append(lockIcon, lockTitle, lockDesc, openBtn);
      // 1.2.6.0: StreamRecorder connected → its recording of that broadcast instead
      try {
        const d = await chrome.storage.local.get(['kwsSrUse', 'kwsSrWatch']);
        const on = typeof d.kwsSrUse === 'boolean' ? d.kwsSrUse : !!d.kwsSrWatch;
        if (on && streamerId) {
          const srBtn = document.createElement('button');
          srBtn.type = 'button';
          srBtn.textContent = '▶ ' + (chrome.i18n.getMessage('srOpenBtn') || 'StreamRecorder');
          srBtn.style.cssText = 'padding:8px 18px;border-radius:999px;background:linear-gradient(135deg,rgba(124,58,237,.85),rgba(145,70,255,.85));color:#fff;border:1px solid rgba(167,139,250,.45);font-size:12px;font-weight:800;cursor:pointer;';
          srBtn.addEventListener('click', () => {
            chrome.runtime.sendMessage({ type: 'KWS_SR_OPEN', req: { platform: 'soop', channel: String(streamerId).toLowerCase(), date: String(dateStr || '').slice(0, 10), off: Math.max(0, seekSecs || 0), title } }).catch(() => {});
          });
          loadEl.append(srBtn);
        }
      } catch (_) {}
      return;
    }

    if (!fileItems.length) { loadSpinner?.remove(); loadEl.textContent='❌ No video parts found.'; return; }
    let acc=0; for (const f of fileItems){partOffsets.push(acc);acc+=f.duration;} totalDuration=acc;
    seeker.max=String(Math.round(totalDuration)); loadSpinner?.remove(); loadEl.remove();

    async function getAvailQualities(manifestUrl, includeOriginal=false) {
      const r=await fetch(manifestUrl); const t=await r.text(); const lines=t.split('\n'); const avail=[];
      // 오래된 VOD: EXT-X-MEDIA:TYPE=AUDIO 분리 구조 감지
      const hasSeparateAudio = t.includes('EXT-X-MEDIA:TYPE=AUDIO');
      // \r 제거 후 재파싱
      const cleanLines = lines.map(l => l.replace(/\r/g, ''));
      let levelIndex = 0;
      for(let i=0;i<cleanLines.length;i++){
        const line = cleanLines[i];
        if(!line.startsWith('#EXT-X-STREAM-INF')) continue;
        const m=line.match(/NAME="([^"]+)"/);
        if(!m) continue;
        const name=m[1];
        if(name==='original' && !includeOriginal) { levelIndex++; continue; }
        const res=line.match(/RESOLUTION=(\d+x\d+)/);
        const height=res?parseInt(res[1].split('x')[1]):0;
        const label=height?`${height}p`:name;
        const u=cleanLines[i+1]?.trim();
        if(u&&!u.startsWith('#')){
          const url = hasSeparateAudio ? manifestUrl : new URL(u,manifestUrl).href;
          avail.push({name,label,url,levelIndex:hasSeparateAudio?levelIndex:null,hasSeparateAudio});
          levelIndex++;
        }
      }
      avail.sort((a,b)=>(parseInt(b.label)||0) - (parseInt(a.label)||0));
      // 화질 목록이 없으면 (직접 세그먼트 m3u8) URL 자체를 단일 항목으로
      if (!avail.length) {
        avail.push({name:'source',label:'Source',url:manifestUrl,levelIndex:null,hasSeparateAudio:false});
      }
      return avail;
    }

    async function collectFragments(hlsUrl,partOffset,partIdx,quality) {
      try {
        const r=await fetch(hlsUrl);const t=await r.text();const lines=t.split('\n');
        // 오래된 VOD: master playlist인 경우 화질별 video.m3u8 URL 추출 후 재귀
        if(t.includes('EXT-X-MEDIA:TYPE=AUDIO')||t.includes('EXT-X-STREAM-INF')&&!t.includes('EXT-X-TARGETDURATION')){
          // master playlist에서 해당 화질 URL 찾기
          let targetUrl=null;
          for(let i=0;i<lines.length;i++){
            const m=lines[i].match(/NAME="([^"]+)"/);
            if(m&&lines[i].startsWith('#EXT-X-STREAM-INF')){
              const name=m[1];
              const u=lines[i+1]?.trim();
              if(u&&!u.startsWith('#')){
                const absUrl=new URL(u,hlsUrl).href;
                if(!targetUrl)targetUrl=absUrl; // fallback: 첫번째
                if(name===(quality||'hd4k')||name===(quality||'hd'))targetUrl=absUrl;
              }
            }
          }
          if(targetUrl) return collectFragments(targetUrl,partOffset,partIdx,quality);
          return [];
        }
        const frags=[];
        const initLine=lines.find(l=>l.includes('EXT-X-MAP'));
        if(initLine){const uri=initLine.match(/URI="([^"]+)"/)?.[1];if(uri)frags.push({path:new URL(uri,hlsUrl).href,dur:0,offset:partOffset,isInit:true,_part:partIdx});}
        let cum=0;
        for(let i=0;i<lines.length;i++){const m=lines[i].match(/#EXTINF:([\d.]+)/);if(m){const dur=parseFloat(m[1]);const seg=lines[i+1]?.trim();if(seg&&!seg.startsWith('#')){frags.push({path:new URL(seg,hlsUrl).href,dur,offset:partOffset+cum,isInit:false,_part:partIdx});cum+=dur;}}}
        return frags;
      }catch(e){return [];}
    }

    async function buildResButtons() {
      const avail=await getAvailQualities(fileItems[0].url, true); resGroup.innerHTML='';
      if(!selectedQuality && avail.length) {
        // 1.2.5.17: default quality from the KWS settings ('last' = the one picked last time, else the best)
        const pref = globalThis.KWSQuality ? await KWSQuality.pref() : 'last';
        const hOf = q => parseInt(q.label) || (q.name === 'original' ? Infinity : 0);
        let chosen = pref !== 'last' && globalThis.KWSQuality ? KWSQuality.pick(avail, hOf, pref) : null;
        if (!chosen) { try { const d = await chrome.storage.local.get('soopLastQuality'); chosen = avail.find(q => q.name === d.soopLastQuality) || null; } catch (_) {} }
        selectedQuality = (chosen || avail[0]).name;
      }
      avail.forEach(q=>{
        const btn=document.createElement('button');btn.type='button';btn.className='soop-pill'+(q.name===selectedQuality?' checked':'');
        btn.textContent=q.label||q.name;
        btn.addEventListener('click',()=>{selectedQuality=q.name;try{chrome.storage.local.set({soopLastQuality:q.name});}catch(_){}resGroup.querySelectorAll('.soop-pill').forEach(b=>b.classList.remove('checked'));btn.classList.add('checked');loadPart(currentPartIdx,video.currentTime||0);});
        resGroup.appendChild(btn);
      });
    }

    async function loadPart(partIdx,seekInPart=0) {
      if(partIdx>=fileItems.length)return;
      currentPartIdx=partIdx;
      subEl.textContent=[(nick?`${nick} (${streamerId||titleNo})`:(streamerId||titleNo)), dateStr].filter(Boolean).join(' · ');
      const avail=await getAvailQualities(fileItems[partIdx].url, true);
      const hlsUrl=avail.find(q=>q.name===selectedQuality)?.url||avail[0]?.url;
      if(!hlsUrl)return;
      video.id='__soop_inline_video';
      const selQual = avail.find(q=>q.name===selectedQuality)||avail[0];
      window.dispatchEvent(new CustomEvent('__soop_hls_cmd',{detail:{cmd:'load',url:hlsUrl,seekSecs:seekInPart,volume:parseFloat(volBar.value)/100,levelIndex:selQual?.levelIndex??null}}));
      const onEvt=e=>{
        const{type}=e.detail||{};
        if(type==='manifest_parsed'){
          video.addEventListener('loadedmetadata',()=>{if(video.videoWidth&&video.videoHeight){_ratio=video.videoHeight/video.videoWidth;const w=cont.getBoundingClientRect().width-36;if(w>0)body.style.height=(window.KWSFitPlayerHeight?window.KWSFitPlayerHeight(cont,_ratio,36,true):Math.round(w*_ratio))+'px';}},{once:true});
          collectFragments(hlsUrl,partOffsets[partIdx],partIdx,selectedQuality).then(frags=>{soopFragments=soopFragments.filter(f=>f._part!==partIdx);soopFragments.push(...frags);soopFragments.sort((a,b)=>a.offset-b.offset);dlBtn.disabled=false;dlBtn.style.opacity='1';});
          window.removeEventListener('__soop_hls_evt',onEvt);
        }
        if(type==='fatal_error')window.removeEventListener('__soop_hls_evt',onEvt);
      };
      window.addEventListener('__soop_hls_evt',onEvt);
      video.onended=()=>{if(currentPartIdx+1<fileItems.length){const sr=video.playbackRate;loadPart(currentPartIdx+1,0).then(()=>{video.playbackRate=sr;setSoopSpeed(sr,true);});}};
    }

    // ── 이벤트 ──
    playEl.addEventListener('click',()=>{ video.paused?video.play():video.pause(); });
    video.addEventListener('click',()=>{
      if (video._kwsSuppressNextClick) { video._kwsSuppressNextClick = false; return; }
      video.paused?video.play():video.pause();
    });
    video.addEventListener('play',()=>{ playEl.innerHTML='<svg id="pause_svg" xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 16 16"><path fill="white" d="M2 2h4v12h-4v-4z"/><path fill="white" d="M8 2h4v12h-4v-4z"/></svg>'; });
    video.addEventListener('pause',()=>{ playEl.innerHTML='<svg id="play_svg" xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 16 16"><path fill="white" d="M2 1v14l12-7z"/></svg>'; });
    try { globalThis.KWSDblSeek && globalThis.KWSDblSeek(video); } catch (_) {} // 1.2.5.45: dbl-click left/right = -/+10 s
    video.addEventListener('dblclick',()=>{ try{video.requestFullscreen();}catch(e){} });
    backEl.addEventListener('click',()=>{ video.currentTime=Math.max(0,video.currentTime-30); });
    fwdEl.addEventListener('click',()=>{ video.currentTime=video.currentTime+30; });
    function setSoopSpeed(n, skipRateSet) {
      if (!skipRateSet) video.playbackRate = n;
      speedStepBtns.forEach(b => b.classList.toggle('checked', parseInt(b.dataset.speed,10) === Math.round(n)));
    }
    speedStepBtns.forEach(b => b.addEventListener('click', () => setSoopSpeed(parseInt(b.dataset.speed,10))));
    function updateVolIcon() {
      const muted = video.muted || parseFloat(volBar.value) === 0;
      const svg = typeof svgs === 'function' ? (muted ? svgs()?.muted : svgs()?.volume) : null;
      if (svg) volIcon.innerHTML = svg;
    }
    volBar.addEventListener('input',()=>{ const v=parseFloat(volBar.value)/100;video.volume=v;video.muted=false;chrome.storage.local.set({soopPlayerVolume:parseFloat(volBar.value)}).catch(()=>{}); updateVolIcon(); });
    volIcon.addEventListener('click',()=>{ video.muted=!video.muted;volBar.value=video.muted?'0':String(Math.round(video.volume*100)); updateVolIcon(); });
    video.addEventListener('timeupdate',()=>{
      const global=partOffsets[currentPartIdx]+(video.currentTime||0);
      timeEl.innerHTML=`<span>${fmtTime(global)} / </span><span>${fmtTime(totalDuration)}</span>`;
      if(!seeker._drag)seeker.value=String(Math.round(global));
    });
    seeker.addEventListener('mousedown',()=>seeker._drag=true);
    seeker.addEventListener('mouseup',()=>{
      seeker._drag=false;
      const target=parseInt(seeker.value);
      let pIdx=0; for(let i=fileItems.length-1;i>=0;i--){if(target>=partOffsets[i]){pIdx=i;break;}}
      const sip=target-partOffsets[pIdx];
      if(pIdx!==currentPartIdx)loadPart(pIdx,sip);else video.currentTime=sip;
    });

    // ── 다운로드 ──
    dlBtn.addEventListener('click',()=>{
      const POP_ID='soop_dl_pop'; document.getElementById(POP_ID)?.remove();
      const cg=Math.floor(partOffsets[currentPartIdx]+(video.currentTime||0));
      let cs=cg, ce=Math.min(cg+300,Math.floor(totalDuration));
      const fmt=s=>{s=Math.max(0,Math.floor(s));return[Math.floor(s/3600),Math.floor((s%3600)/60),s%60].map(v=>String(v).padStart(2,'0')).join(':');};
      const pf=s=>{const p=s.split(':').map(Number);return p.length===3?p[0]*3600+p[1]*60+p[2]:p.length===2?p[0]*60+p[1]:parseFloat(s)||0;};
      const pop=document.createElement('div');pop.id=POP_ID;
      pop.style.cssText='position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:9999999;width:340px;background:rgba(8,10,16,.92);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,.14);border-radius:18px;box-shadow:0 16px 50px rgba(0,0,0,.6);font-family:-apple-system,sans-serif;color:#e2e8f0;font-size:12px;overflow:hidden;';
      pop.innerHTML=`<div id="${POP_ID}_head" style="display:flex;align-items:center;justify-content:space-between;padding:11px 14px;border-bottom:1px solid rgba(255,255,255,.07);cursor:move;background:rgba(255,255,255,.04);"><span style="font-size:11px;font-weight:800;letter-spacing:.05em;color:rgba(255,255,255,.55);text-transform:uppercase;">Clip Downloader</span><button id="${POP_ID}_close" style="width:22px;height:22px;border-radius:999px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.18);color:#fff;font-size:12px;cursor:pointer;">✕</button></div><div style="padding:12px 14px;display:flex;flex-direction:column;gap:10px;"><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;"><div style="background:rgba(250,204,21,.07);border:1px solid rgba(250,204,21,.2);border-radius:10px;padding:8px 10px;"><div style="font-size:9px;font-weight:700;text-transform:uppercase;color:rgba(250,204,21,.6);margin-bottom:4px;">Start</div><input id="${POP_ID}_start" type="text" value="${fmt(cs)}" style="width:100%;box-sizing:border-box;background:transparent;border:none;outline:none;font-size:13px;font-weight:800;color:#facc15;margin-bottom:6px;font-family:inherit;"/><button id="${POP_ID}_set_start" style="width:100%;padding:4px;border-radius:7px;font-size:10px;font-weight:800;background:rgba(250,204,21,.25);border:1px solid rgba(250,204,21,.4);color:#fde68a;cursor:pointer;">Set to Current</button></div><div style="background:rgba(96,165,250,.07);border:1px solid rgba(96,165,250,.2);border-radius:10px;padding:8px 10px;"><div style="font-size:9px;font-weight:700;text-transform:uppercase;color:rgba(96,165,250,.6);margin-bottom:4px;">End</div><input id="${POP_ID}_end" type="text" value="${fmt(ce)}" style="width:100%;box-sizing:border-box;background:transparent;border:none;outline:none;font-size:13px;font-weight:800;color:#60a5fa;margin-bottom:6px;font-family:inherit;"/><button id="${POP_ID}_set_end" style="width:100%;padding:4px;border-radius:7px;font-size:10px;font-weight:800;background:rgba(96,165,250,.25);border:1px solid rgba(96,165,250,.4);color:#93c5fd;cursor:pointer;">Set to Current</button></div></div><div style="display:flex;align-items:center;justify-content:space-between;padding:6px 10px;border-radius:9px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);"><span style="font-size:9px;font-weight:700;text-transform:uppercase;color:rgba(255,255,255,.3);">Duration</span><span id="${POP_ID}_dur" style="font-size:13px;font-weight:800;color:rgba(255,255,255,.75);">${fmt(ce-cs)}</span></div><div id="${POP_ID}_quality_row" style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;padding:4px 0;"><span style="font-size:9px;font-weight:700;text-transform:uppercase;color:rgba(255,255,255,.35);">Quality:</span></div><div style="display:flex;align-items:center;gap:5px;padding:6px 9px;border-radius:9px;background:rgba(251,191,36,.08);border:1px solid rgba(251,191,36,.22);color:#fde68a;font-size:10px;">⚠️ Keep this tab open while downloading.</div><button id="${POP_ID}_dl" style="width:100%;padding:9px;border-radius:11px;font-size:12px;font-weight:800;background:linear-gradient(135deg,rgba(37,99,235,.7),rgba(59,130,246,.7));color:#fff;border:1px solid rgba(99,137,255,.4);cursor:pointer;">💾 Download</button></div>`;
      // Same size as the Twitch/Kick downloader: undo any page zoom the SOOP site applies.
      { let z = 1; for (const el of [document.documentElement, document.body]) { const v = parseFloat(getComputedStyle(el).zoom); if (v > 0) z *= v; } if (Math.abs(z - 1) > 0.01) pop.style.zoom = String(1 / z); }
      document.body.appendChild(pop);
      {let dg=false,ox=0,oy=0;const hd=document.getElementById(POP_ID+'_head');hd.addEventListener('mousedown',e=>{dg=true;const r=pop.getBoundingClientRect();pop.style.transform='none';pop.style.left=r.left+'px';pop.style.top=r.top+'px';ox=e.clientX-r.left;oy=e.clientY-r.top;document.body.style.userSelect='none';});window.addEventListener('mousemove',e=>{if(!dg)return;pop.style.left=e.clientX-ox+'px';pop.style.top=e.clientY-oy+'px';});window.addEventListener('mouseup',()=>{dg=false;document.body.style.userSelect='';});}
      const uui=()=>{
        document.getElementById(POP_ID+'_dur').textContent=fmt(Math.max(0,ce-cs));
        soopUpdateRangeOverlay(seekCont, totalDuration, cs, ce, (s, e) => {
          cs = s; ce = e;
          document.getElementById(POP_ID+'_start').value = fmt(cs);
          document.getElementById(POP_ID+'_end').value = fmt(ce);
          document.getElementById(POP_ID+'_dur').textContent = fmt(Math.max(0, ce - cs));
        });
      };
      document.getElementById(POP_ID+'_close').addEventListener('click',()=>{pop.remove();soopUpdateRangeOverlay(seekCont, totalDuration, null, null);});

      // 화질 선택 버튼 (original 1080p 포함)
      let dlQuality = selectedQuality;
      let dlFragments = soopFragments;
      const qualRow = document.getElementById(POP_ID+'_quality_row');
      getAvailQualities(fileItems[0].url, true).then(allQualities => {
        allQualities.forEach(q => {
          const qBtn = document.createElement('button');
          qBtn.type = 'button';
          qBtn.textContent = q.label;
          qBtn.style.cssText = `padding:3px 10px;border-radius:999px;font-size:10px;font-weight:800;cursor:pointer;border:1px solid ${q.name===dlQuality?'rgba(250,204,21,.6)':'rgba(255,255,255,.15)'};background:${q.name===dlQuality?'rgba(250,204,21,.18)':'rgba(255,255,255,.06)'};color:${q.name===dlQuality?'#facc15':'rgba(255,255,255,.7)'};transition:all .12s;`;
          qBtn.addEventListener('click', async () => {
            dlQuality = q.name;
            qualRow.querySelectorAll('button').forEach(b => { b.style.background='rgba(255,255,255,.06)'; b.style.border='1px solid rgba(255,255,255,.15)'; b.style.color='rgba(255,255,255,.7)'; });
            qBtn.style.background='rgba(250,204,21,.18)'; qBtn.style.border='1px solid rgba(250,204,21,.6)'; qBtn.style.color='#facc15';
            if (q.name === selectedQuality) {
              dlFragments = soopFragments;
            } else {
              const de = document.getElementById(POP_ID+'_dl');
              if (!de) return;
              de.textContent = '⏳ Loading quality...'; de.disabled = true;
              const newFrags = [];
              for (let pi = 0; pi < fileItems.length; pi++) {
                const avail = await getAvailQualities(fileItems[pi].url, true);
                const hlsUrl = avail.find(a => a.name === q.name)?.url;
                if (hlsUrl) { const frags = await collectFragments(hlsUrl, partOffsets[pi], pi, q.name); newFrags.push(...frags); }
              }
              dlFragments = newFrags;
              de.textContent = '💾 Download'; de.disabled = false;
            }
          });
          qualRow.appendChild(qBtn);
        });
      });
      document.getElementById(POP_ID+'_start').addEventListener('change',e=>{cs=pf(e.target.value);uui();});
      document.getElementById(POP_ID+'_end').addEventListener('change',e=>{ce=pf(e.target.value);uui();});
      document.getElementById(POP_ID+'_set_start').addEventListener('click',()=>{cs=Math.floor(partOffsets[currentPartIdx]+(video.currentTime||0));document.getElementById(POP_ID+'_start').value=fmt(cs);uui();});
      document.getElementById(POP_ID+'_set_end').addEventListener('click',()=>{ce=Math.floor(partOffsets[currentPartIdx]+(video.currentTime||0));document.getElementById(POP_ID+'_end').value=fmt(ce);uui();});
      // offscreen ffmpeg mux (오래된 VOD 비디오+오디오 합치기)

      document.getElementById(POP_ID+'_dl').addEventListener('click',()=>{
        // 실제 다운로드는 VOD 플레이어랑 독립된 별도 창에서 진행 (Twitch와 동일한 방식) —
        // 이 설정 팝업은 값만 넘겨주고 바로 닫혀도 다운로드 자체는 계속 진행됨
        soopStartStandaloneDownload({
          fileItems, partOffsets, cs, ce, dlQuality, selectedQuality,
          dlFragments, soopFragments, nick, streamerId, titleNo, dateStr,
          getAvailQualities, collectFragments, fmt
        });
        // 시간 선택 창은 닫지 않음 (Twitch/Kick과 동일) — 구간을 잘못 골랐어도 바로 고쳐서 다시 다운로드 가능
      });
      uui();
    });


        // ── 첫 파트 로드 ──
    await buildResButtons();
    let startPart=0, startSeek=seekSecs>30?seekSecs-30:Math.max(0,seekSecs);
    for(let i=fileItems.length-1;i>=0;i--){if(startSeek>=partOffsets[i]){startPart=i;startSeek=startSeek-partOffsets[i];break;}}
    await loadPart(startPart,startSeek);

    // 같은 VOD를 다시 열 때(다른 타임스탬프) 재사용할 수 있도록 seek 함수를 컨테이너에 노출
    cont._soopSeekTo = async (secs) => {
      let sp = 0, ss = secs > 30 ? secs - 30 : Math.max(0, secs);
      for (let i = fileItems.length - 1; i >= 0; i--) { if (ss >= partOffsets[i]) { sp = i; ss = ss - partOffsets[i]; break; } }
      if (sp === currentPartIdx) {
        // 같은 파일 파트 안이면 굳이 재로딩 안 하고 currentTime만 이동
        const v = document.getElementById('__soop_inline_video');
        if (v && v.readyState >= 1) { v.currentTime = ss; return; }
      }
      await loadPart(sp, ss);
    };
  }


  function esc(t) { return String(t || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;'); }
  function hlKw(html, kws) { let o = String(html || ''); for (const k of [...new Set((kws || []).filter(Boolean))].sort((a, b) => b.length - a.length)) o = o.replace(new RegExp(k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), '<mark style="background:rgba(250,204,21,0.28);color:#fde68a;padding:0 2px;border-radius:3px;">$&</mark>'); return o; }
})();
