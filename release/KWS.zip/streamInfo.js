async function getAvailableVODinfo(params){
    var tokens = getTokensFromCookies();
    // console.log({...params,...tokens});
    var vods = await requestFromBackground({cmd:'getAvailableVODinfo',params:{...params,...tokens}});
    return vods;
}

async function searchTwitch(params){
    var tokens = getTokensFromCookies();
    let results = await requestFromBackground({cmd:'searchTwitch',params:{...params,...tokens}});
    return results;
}
async function searchKick(params){
    return await requestFromBackground({cmd:'searchKick',params:params});
}
async function getKickChannelV1(params){
    return await requestFromBackground({cmd:'getKickChannelV1',params:params});
}
async function getKickVODs(params){
    return await requestFromBackground({cmd:'getKickVODs',params:params});
}
function mergeVODsWithSullyGnome(params){
    var {sully_data,vods}=params;
    var sully = sully_data?.map(sd=> {
        let match = vods?.filter(v=> v.stream_id == sd.stream_id)?.[0];
        return {
            ...sd,
            ...match
        }
    })
    var tvod = vods?.map(sd=> {
        let match = sully_data?.filter(v=> v.stream_id == sd.stream_id)?.[0];
        return {
            ...sd,
            ...match
        }
    });
    var sixty_days_ago = new Date().getTime() - 5270400000;
    return unqKey([...(sully||[]),...(tvod||[])].flat(),'stream_id').sort((a,b)=> a.timestamp > b.timestamp ? -1 : 0).filter(r=> r.timestamp > sixty_days_ago);
}

async function getClipSlugFromHref(){
    var x = /twitch.tv\/(\w+)\/clip\/(.+?)(?=\?|$)/.exec(window.location.href);
    var params = x?.[2] ? {
        channel_login:x?.[1],
        slug:x?.[2],
    } : null;
    if(params?.slug){
      let tokens = getTokensFromCookies();
      let url = await requestFromBackground({ cmd: 'getClipSig', params: { ...tokens, ...params } });
      return {
        url:url,
        channel_login:x?.[1],
        slug:x?.[2],
      };
    }else{
      return null;
    }
}


function getHighlightSourceFromDOM(){
    let channel_login = getChannelLogin();
    let id = /(?<=\.tv\/videos\/)\d+/.exec(window.location.href)?.[0];
    let x = new RegExp(`cf_vods\\/(\\w+)\\/([\\w_]+)\\/\\/thumb\\/thumb(${id})`);
    var extractPath = (elms,key)=> elms?.filter(r=> x.test(r[key]))?.map(r=> {
        let m = x.exec(r[key]);
        return {
            source:`https://${m?.[1]}.cloudfront.net/${m?.[2]}/chunked/highlight-${m?.[3]}.m3u8`,
            channel_login:channel_login,
        }
    })?.[0];
    let vod_path = extractPath(Array.from(document.getElementsByTagName('img') || []),'src');
    let vod_path2 = extractPath(Array.from(document.getElementsByTagName('meta') || []),'content');
    let vod_path3 = extractPath(Array.from(document.querySelectorAll('[type="application/ld+json"]') ||[]),'innerHTML');
    return vod_path || vod_path2 || vod_path3;
}

async function getCurrentVODHighlightSource(){
    let channel_login = getChannelLogin();
    let id = /(?<=\.tv\/videos\/)\d+/.exec(window.location.href)?.[0];
    let vod_path = getHighlightSourceFromDOM();
    // console.log(vod_path);
    if(vod_path?.source){
        return vod_path;
    }else{

        let tokens = getTokensFromCookies();
        let highlights = await requestFromBackground({
            cmd: 'getAllHighlights',
            params: { ...tokens, ...{ channel_login: channel_login } }
        });
        // console.log(highlights);
        return highlights?.filter(r=> r.highlight_id == id)?.[0];
    }
}


async function getStreamrecorderAvailabilty(params){
  var { channel_name, channel_login, slug, channel_slug, service } = params;
  var s = service == 'twitch' ? 1 : service == 'kick' ? 5 : null;
  var c = channel_login || channel_name || slug || channel_slug;
  console.log(s, c);
  if(s && c){
    var channel_info = await requestFromBackground({ cmd: 'fetchJSON', params: { url: `https://streamrecorder.io/api/pub/target/${s}/${c}`, opt: {} } });
    console.log('channel_info',channel_info)
    if(channel_info?.id){
      var rec = await requestFromBackground({ cmd: 'fetchJSON', params: {url:`https://streamrecorder.io/api/pub/latestrecordings/${channel_info?.id}`, opt: {} } });
      console.log('rec,', rec);
      return rec?.latestRecordings;
    }
  }
  return null;
}

function filterRecorderVODsWithin24h(params){
    var {target,latest_recordings} =params;
    var thresh = 84600000;
    var timestamp = target.timestamp ? target.timestamp : target.timestamp_seconds ? (target.timestamp_seconds * 1000) : 0;
    var bottom_thresh = timestamp - thresh;
    var top_thresh = timestamp + thresh;

    return latest_recordings?.filter(r=> new Date(r?.recorded_at).getTime() >= bottom_thresh && new Date(r?.recorded_at).getTime() <= top_thresh);
}

// getStreamrecorderAvailabilty({channel_name:'',service:''})
