
(function(){
  if (window.KWSUnifiedHistory) return;
  const nowIso = () => new Date().toISOString();
  const safeArr = v => Array.isArray(v) ? v.filter(Boolean).map(String) : (v ? String(v).split(',').map(s=>s.trim()).filter(Boolean) : []);
  const SETTINGS_KEYS = ['kickKwsSettings','kwsLogSource','kwsJustlogUrl','kwsAutoCloseNoResult','kickKwsAutoCloseNoResult','soopSearchSubtitles','soopAutoCloseNoResult','soopFetchMode','twitchKwsKeywordProfile','kwsKeyword','soopKeyword','soopStartDate','soopEndDate','soopSaveTxt'];
  const sanitizeSettings = o => { const out = {}; o = o && typeof o === 'object' ? o : {}; for (const k of SETTINGS_KEYS) if (Object.prototype.hasOwnProperty.call(o,k)) out[k] = o[k]; return out; };
  const pickNewest = (a,b) => ((b?.searchedAt||b?.savedAt||'') > (a?.searchedAt||a?.savedAt||'')) ? b : a;
  function normalize(platform, raw){
    raw = raw && typeof raw === 'object' ? raw : {};
    const out = { schema:'vod-kws-history.v2', version:2, exportedAt:nowIso(), records:[] };
    for (const [id, h] of Object.entries(raw)) {
      if (!h || typeof h !== 'object' || id.startsWith('__') || id.startsWith('_global')) continue;
      out.records.push({
        platform: String(platform||h.platform||'').toLowerCase(),
        id: String(id).toLowerCase(),
        displayName: h.nickname || h.displayName || h.name || '',

        lastDate: h.lastDate || '',
        searchedAt: h.searchedAt || h.savedAt || nowIso(),
        savedAt: h.savedAt || h.searchedAt || nowIso(),
        matchedCount: Number(h.matchedCount ?? h.matchedLines ?? 0) || 0,
        matchedDays: Number(h.matchedDays ?? 0) || 0,
        endPage: h.endPage ?? h.lastPage ?? null,
        memo: h.memo || '',
        clickedTimes: h.clickedTimes || {},
        source: h
      });
    }
    return out;
  }
  function toPlatformObject(unified, platform){
    const out = {};
    const docs = unified && unified.records ? unified.records : [];
    docs.filter(r => !platform || String(r.platform).toLowerCase() === platform).forEach(r => {
      const base = {
        lastDate: r.lastDate || '',
        searchedAt: r.searchedAt || r.savedAt || nowIso(),
        savedAt: r.savedAt || r.searchedAt || nowIso(),
        memo: r.memo || ''
      };
      if (r.displayName) base.nickname = r.displayName;
      if (platform === 'soop') {
        base.endPage = r.endPage || 1;
        base.matchedCount = Number(r.matchedCount||0);
      } else {
        base.matchedLines = Number(r.matchedCount||0);
        base.matchedDays = Number(r.matchedDays||0);
      }
      // 1.2.5: restore "already clicked" timestamps on every platform (1.2.4 only kept SOOP's)
      if (r.clickedTimes && typeof r.clickedTimes === 'object' && Object.keys(r.clickedTimes).length) base.clickedTimes = r.clickedTimes;
      out[r.id] = pickNewest(out[r.id], base);
    });
    return out;
  }
  function stripRecord(r){
    const o = Object.assign({}, r || {});
    delete o.source;
    o.platform = String(o.platform || '').toLowerCase();
    o.id = String(o.id || '').toLowerCase();

    o.clickedTimes = o.clickedTimes || {};
    return o;
  }
  function asUnified(doc, fallbackPlatform){
    if (doc && Array.isArray(doc.records)) return { schema:'vod-kws-history.v2', version:2, exportedAt:doc.exportedAt||nowIso(), settings:sanitizeSettings(doc.settings), records:doc.records.map(stripRecord).filter(r=>r.platform&&r.id) };
    return normalize(fallbackPlatform || doc?.platform || '', doc || {});
  }
  function mergeUnified(){
    const merged = { schema:'vod-kws-history.v2', version:2, exportedAt:nowIso(), settings:{}, records:[] };
    const byKey = new Map();
    for (const doc of arguments) {
      const u = asUnified(doc, doc?.platform || '');
      if (u.settings) Object.assign(merged.settings, sanitizeSettings(u.settings));
      for (const rr of (u.records||[])) {
        const r = stripRecord(rr);
        if (!r.platform || !r.id) continue;
        const key = r.platform+':'+r.id;
        const prev = byKey.get(key);
        byKey.set(key, !prev || (r.searchedAt||r.savedAt||'') > (prev.searchedAt||prev.savedAt||'') ? r : prev);
      }
    }
    merged.records = Array.from(byKey.values()).sort((a,b)=>(b.searchedAt||'').localeCompare(a.searchedAt||''));
    return merged;
  }
  async function importToAll(unified){
    const u = unified && Array.isArray(unified.records) ? mergeUnified(unified) : mergeUnified(normalize('twitch', unified||{}));
    const map = { twitch:'twitchKwsHistory', kick:'kickKwsHistory', soop:'soopSearchHistory', youtube:'ytKwsHistory' };
    const setObj = {}; const counts = {};
    if (u.settings && typeof u.settings === 'object') Object.assign(setObj, sanitizeSettings(u.settings));
    for (const [platform, key] of Object.entries(map)) {
      const got = await chrome.storage.local.get([key]);
      const cur = got[key] || {};
      // 키워드는 3플랫폼 공통 — 어느 플랫폼이든 동일 프로필로 복원
      const sharedProfile = u.settings?.twitchKwsKeywordProfile
        || (u.settings?.kickKwsSettings?.keyword ? { keyword: u.settings.kickKwsSettings.keyword } : null)
        || (u.settings?.soopKeyword ? { keyword: u.settings.soopKeyword } : null);
      if (sharedProfile) {
        if (platform === 'twitch') cur.__keyword_profile__ = sharedProfile;
        if (platform === 'kick')   cur.__keyword_profile__ = sharedProfile;
        if (platform === 'soop')   cur._globalKeyword = sharedProfile.keyword || '';
        // twitchKwsKeywordProfile 직접 저장 — KWS 패널이 이 키를 직접 읽음
        if (platform === 'twitch' && sharedProfile.keyword) {
          // keyword 문자열에서 plus/minus 배열도 생성해서 저장
          const allParts = sharedProfile.keyword.split(/[\n,]/).map(x => x.trim()).filter(Boolean);
          const plus = allParts.filter(p => !p.startsWith('-'));
          const minus = allParts.filter(p => p.startsWith('-')).map(p => p.replace(/^-+/, ''));
          setObj['twitchKwsKeywordProfile'] = { keyword: sharedProfile.keyword, plus, minus };
          setObj['kickKwsSettings'] = Object.assign({}, u.settings?.kickKwsSettings || {}, { keyword: sharedProfile.keyword });
        }
      }
      const inc = toPlatformObject(u, platform);
      for (const [id,h] of Object.entries(inc)) cur[id] = pickNewest(cur[id], h);
      setObj[key] = cur; counts[platform] = Object.keys(inc).length;
    }
    await chrome.storage.local.set(setObj);
    return counts;
  }
  async function exportAll(){
    const got = await chrome.storage.local.get(['twitchKwsHistory','kickKwsHistory','soopSearchHistory','ytKwsHistory'].concat(SETTINGS_KEYS));
    const u = mergeUnified(normalize('twitch', got.twitchKwsHistory || {}), normalize('kick', got.kickKwsHistory || {}), normalize('soop', got.soopSearchHistory || {}), normalize('youtube', got.ytKwsHistory || {}));
    u.settings = sanitizeSettings(got);
    // 키워드는 3플랫폼 공통 — twitchKwsKeywordProfile 우선, 없으면 다른 플랫폼에서 보완
    const profile = got.twitchKwsKeywordProfile
      || got.twitchKwsHistory?.__keyword_profile__
      || (got.kickKwsHistory?.__keyword_profile__)
      || (got.soopSearchHistory?._globalKeyword ? { keyword: got.soopSearchHistory._globalKeyword } : null);
    if (profile) {
      u.settings.twitchKwsKeywordProfile = profile;
      u.settings.kwsKeyword = profile.keyword || got.kwsKeyword || '';
      u.settings.soopKeyword = profile.keyword || got.soopKeyword || '';
      if (got.kickKwsSettings) u.settings.kickKwsSettings = Object.assign({}, got.kickKwsSettings, { keyword: profile.keyword || '' });
    }
    return u;
  }

  function download(obj, name){
    const blob = new Blob([JSON.stringify(obj,null,2)], {type:'application/json'});
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name || 'vod-kws-history.json'; a.click(); setTimeout(()=>URL.revokeObjectURL(a.href), 1000);
  }
  window.KWSUnifiedHistory = { normalize, mergeUnified, toPlatformObject, importToAll, exportAll, download };
})();

// ── 채널명 클릭 → 클립보드 복사 (Twitch/SOOP/Kick/YouTube KWS 공통) ──
(function(){
  if (window.__kwsCopyBound) return;
  window.__kwsCopyBound = true;
  const INPUT_IDS = new Set(['kws-channel','kkws-channel','soop-streamer-id']);
  function toast(anchor, text){
    try{
      const r = anchor.getBoundingClientRect();
      const t = document.createElement('div');
      t.textContent = text;
      t.style.cssText = 'position:fixed;z-index:2147483647;pointer-events:none;padding:3px 9px;border-radius:8px;background:rgba(20,22,32,.96);color:#fff;font:600 11px -apple-system,BlinkMacSystemFont,sans-serif;border:1px solid rgba(255,255,255,.18);box-shadow:0 4px 14px rgba(0,0,0,.5);transition:opacity .25s;'
        + 'left:' + Math.max(4, r.left) + 'px;top:' + Math.max(4, r.top - 26) + 'px;';
      document.documentElement.appendChild(t);
      setTimeout(function(){ t.style.opacity = '0'; }, 900);
      setTimeout(function(){ t.remove(); }, 1250);
    }catch(_){}
  }
  async function copy(text){
    try{ await navigator.clipboard.writeText(text); return true; }catch(_){}
    try{
      const ta = document.createElement('textarea');
      ta.value = text; ta.style.cssText = 'position:fixed;opacity:0;left:-9999px;';
      document.documentElement.appendChild(ta); ta.select();
      const ok = document.execCommand('copy'); ta.remove(); return ok;
    }catch(_){ return false; }
  }
  document.addEventListener('click', function(e){
    const t = e.target;
    if (!t || !t.closest) return;
    let el = null, text = '';
    const inp = t.closest('input');
    if (inp && INPUT_IDS.has(inp.id)) {
      el = inp; text = (inp.value || '').trim();
    } else {
      const yt = t.closest('#yt-kws-channel');
      if (yt) {
        el = yt;
        const h = (document.getElementById('yt-kws-channel-handle')?.textContent || '').trim();
        const n = (document.getElementById('yt-kws-channel-nick')?.textContent || '').trim();
        text = h || n;
      }
    }
    if (!el || !text) return;
    copy(text).then(function(ok){ toast(el, ok ? 'Copied: ' + text : 'Copy failed'); });
  }, true);
})();

// ── 묶음(VOD/날짜) 단위 일괄 번역 버튼 (모든 KWS 공통) ──
// rows: [{ text, box, cached?:{lang,text}, onDone?:(lang,text)=>void }]
//  - 버튼 1번 클릭: 그 묶음의 모든 메시지를 번역해서 각 box에 표시 (동시 4개)
//  - 다시 클릭: 번역 숨김 / 숨김 상태에서 클릭: 다시 표시 (언어가 바뀌었으면 재번역)
window.KWSBatchTranslate = function(btn, rows, getLang, translate, openGoogle){
  const todoAll = rows.filter(r => (r.text || '').trim());
  const showLabel = '🌐';
  const hideLabel = '🌐';
  const setActive = on => { btn.style.background = on ? 'rgba(14,165,233,0.35)' : 'rgba(14,165,233,0.10)'; btn.title = on ? 'Hide translations' : 'Translate every message in this group (' + todoAll.length + ')'; };
  let visible = false, busy = false;
  btn.type = 'button';
  btn.textContent = showLabel;
  setActive(false);
  // 이미 번역돼 있던 항목(재렌더로 복원)이 있으면 그대로 보여줌
  const lang0 = getLang();
  todoAll.forEach(r => {
    if (r.cached && r.cached.lang === lang0 && r.cached.text) {
      r.box.dataset.loaded = lang0; r.box.textContent = '🌐 ' + r.cached.text; r.box.style.display = 'block'; visible = true;
    }
  });
  if (visible) { btn.textContent = hideLabel; setActive(true); }
  function fail(r, lang){
    r.box.dataset.loaded = '';
    r.box.textContent = '❌ translation failed ';
    const b = document.createElement('button');
    b.type = 'button'; b.textContent = 'open';
    b.style.cssText = 'margin-left:6px;padding:1px 5px;border:1px solid rgba(255,255,255,0.15);border-radius:5px;background:rgba(255,255,255,0.06);color:#e0f2fe;font-size:10px;cursor:pointer;';
    b.addEventListener('click', ev => { ev.stopPropagation(); try{ openGoogle(r.text, lang); }catch(_){} });
    r.box.appendChild(b);
  }
  btn.addEventListener('click', async ev => {
    ev.preventDefault(); ev.stopPropagation();
    if (busy || !todoAll.length) return;
    const lang = getLang();
    const allLoaded = todoAll.every(r => r.box.dataset.loaded === lang);
    if (visible && allLoaded) {
      todoAll.forEach(r => { r.box.style.display = 'none'; if (r.onHide) { try{ r.onHide(); }catch(_){} } });
      visible = false; btn.textContent = showLabel; setActive(false); return;
    }
    visible = true; busy = true; btn.disabled = true; btn.style.opacity = '0.6';
    let done = 0;
    const upd = () => { btn.textContent = '⏳'; btn.title = 'Translating ' + done + '/' + todoAll.length; };
    upd();
    todoAll.forEach(r => {
      r.box.style.display = 'block';
      if (r.box.dataset.loaded !== lang) r.box.textContent = '⏳ translating to ' + lang + '...';
    });
    let idx = 0;
    async function worker(){
      while (idx < todoAll.length) {
        const r = todoAll[idx++];
        if (r.box.dataset.loaded === lang) { done++; upd(); continue; }
        try {
          const t = await translate(r.text, lang);
          r.box.dataset.loaded = lang; r.box.textContent = '🌐 ' + t;
          if (r.onDone) { try{ r.onDone(lang, t); }catch(_){} }
        } catch (_) { fail(r, lang); }
        done++; upd();
      }
    }
    await Promise.all([worker(), worker(), worker(), worker()]);
    busy = false; btn.disabled = false; btn.style.opacity = '';
    btn.textContent = hideLabel; setActive(true);
  });
};

// ── Results 헤더(Results · X hits · Clear)와 Clear 확인창 — 모든 KWS 공통 ──
window.KWSResultsHeaderHTML = function(summaryId, clearId){
  return '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:7px;">'
    + '<div style="display:flex;align-items:center;gap:8px;">'
    +   '<div style="font-size:12px;font-weight:700;color:rgba(255,255,255,0.9);">Results</div>'
    +   '<div id="' + summaryId + '" style="font-size:11px;color:rgba(255,255,255,0.45);">No results</div>'
    + '</div>'
    + '<div style="display:flex;align-items:center;gap:4px;">'
    +   '<button id="' + clearId + '" title="Clear all" style="height:22px;padding:0 7px;border:1px solid rgba(255,255,255,0.07);border-radius:5px;cursor:pointer;display:flex;align-items:center;gap:2px;background:transparent;color:rgba(248,113,113,0.6);font-size:10px;font-weight:600;font-family:inherit;white-space:nowrap;">Clear</button>'
    + '</div>'
    + '</div>';
};
window.KWSHitsText = function(hits, scanning){
  hits = hits || 0;
  return hits ? (hits + ' hit' + (hits === 1 ? '' : 's') + (scanning ? ' · scanning...' : '')) : (scanning ? 'Scanning...' : 'No results');
};
// opts: { running:[채널...], currentLabel:string|null, tabCount:number, onCurrent(), onAll() }
window.KWSClearDialog = function(opts){
  opts = opts || {};
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  document.querySelectorAll('[id^="kws-clear-overlay-"]').forEach(el => el.remove());
  const overlay = document.createElement('div');
  overlay.id = 'kws-clear-overlay-' + Date.now();
  overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,0.55);display:flex;align-items:center;justify-content:center;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;';
  const running = opts.running || [];
  overlay.innerHTML = `
    <div style="width:min(360px, calc(100vw - 40px));border-radius:18px;background:#12141c;border:1px solid rgba(255,255,255,0.14);box-shadow:0 28px 90px rgba(0,0,0,0.6);padding:20px;color:#e5e7eb;">
      <div style="font-size:14px;font-weight:800;color:#fff;margin-bottom:8px;">Clear results</div>
      <div style="font-size:12.5px;line-height:1.6;color:rgba(255,255,255,0.7);margin-bottom:16px;">${running.length ? '⚠️ ' + esc(running.join(', ')) + ' still scanning.<br>' : ''}What would you like to clear?</div>
      <div style="display:flex;flex-direction:column;gap:8px;">
        ${opts.currentLabel ? `<button data-act="current" style="padding:11px 14px;border-radius:12px;border:1px solid rgba(96,165,250,0.5);background:rgba(96,165,250,0.18);color:#bfdbfe;font-size:13px;font-weight:700;cursor:pointer;text-align:left;">Current tab only <span style="opacity:0.6;font-weight:500;">— ${esc(opts.currentLabel)}</span></button>` : ''}
        <button data-act="all" style="padding:11px 14px;border-radius:12px;border:1px solid rgba(248,113,113,0.4);background:rgba(248,113,113,0.12);color:#fca5a5;font-size:13px;font-weight:700;cursor:pointer;text-align:left;">All tabs <span style="opacity:0.6;font-weight:500;">— ${opts.tabCount || 1} tab(s)</span></button>
        <button data-act="cancel" style="padding:8px 14px;border-radius:12px;border:none;background:transparent;color:rgba(255,255,255,0.45);font-size:12px;cursor:pointer;">Cancel</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  const close = () => overlay.remove();
  overlay.addEventListener('click', e => { if (e.target === overlay) close(); });
  overlay.querySelector('[data-act="current"]')?.addEventListener('click', () => { close(); if (opts.onCurrent) opts.onCurrent(); });
  overlay.querySelector('[data-act="all"]').addEventListener('click', () => { close(); if (opts.onAll) opts.onAll(); });
  overlay.querySelector('[data-act="cancel"]').addEventListener('click', close);
};

// ── 이미 스캔 중인 ID를 다시 검색할 때의 확인 팝업 (4개 KWS 공통) ──
// OK → opts.onRestart() (호출한 쪽에서 기존 스캔 중지 후 처음부터 다시), Cancel → 기존 스캔 유지
window.KWSRestartDialog = function(opts){
  opts = opts || {};
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  document.querySelectorAll('[id^="kws-restart-overlay-"]').forEach(el => el.remove());
  const overlay = document.createElement('div');
  overlay.id = 'kws-restart-overlay-' + Date.now();
  overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,0.55);display:flex;align-items:center;justify-content:center;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;';
  overlay.innerHTML = `
    <div style="width:min(360px, calc(100vw - 40px));border-radius:18px;background:#12141c;border:1px solid rgba(255,255,255,0.14);box-shadow:0 28px 90px rgba(0,0,0,0.6);padding:20px;color:#e5e7eb;">
      <div style="font-size:14px;font-weight:800;color:#fff;margin-bottom:8px;">Already scanning</div>
      <div style="font-size:12.5px;line-height:1.6;color:rgba(255,255,255,0.7);margin-bottom:16px;"><b style="color:#fff;">${esc(opts.name || '')}</b> is already being scanned.<br>Stop it and start over from the beginning?</div>
      <div style="display:flex;flex-direction:column;gap:8px;">
        <button data-act="ok" style="padding:11px 14px;border-radius:12px;border:1px solid rgba(248,113,113,0.4);background:rgba(248,113,113,0.12);color:#fca5a5;font-size:13px;font-weight:700;cursor:pointer;text-align:left;">OK <span style="opacity:0.6;font-weight:500;">— stop &amp; restart</span></button>
        <button data-act="cancel" style="padding:8px 14px;border-radius:12px;border:none;background:transparent;color:rgba(255,255,255,0.45);font-size:12px;cursor:pointer;">Cancel <span style="opacity:0.7;">— keep current scan</span></button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  const close = () => overlay.remove();
  overlay.addEventListener('click', e => { if (e.target === overlay) close(); });
  overlay.querySelector('[data-act="ok"]').addEventListener('click', () => { close(); if (opts.onRestart) opts.onRestart(); });
  overlay.querySelector('[data-act="cancel"]').addEventListener('click', close);
};

// ── 인라인 VOD 플레이어 높이 계산 (Twitch/Kick/SOOP 공통) ──
// 가로 영상은 '너비 × 비율'이면 되지만, 세로 영상(비율 > 1)은 그대로 하면 화면보다 훨씬 커져서
// 컨트롤이 화면 밖으로 나감 → 높이를 화면에 맞춰 제한. allowNarrow면 창 너비도 그 비율에 맞게 좁힘.
window.KWSFitPlayerHeight = function(cont, ratio, side, allowNarrow){
  const maxH = Math.max(240, window.innerHeight - 140);
  const w = cont.getBoundingClientRect().width - side;
  let h = Math.round(w * ratio);
  if (h > maxH) {
    h = maxH;
    if (allowNarrow && ratio > 0) cont.style.width = Math.round(h / ratio + side) + 'px';
  }
  return h;
};

// ── 중지 후 재시작 공통 흐름 (4개 KWS 공통) ──
// stop() 호출 → isRunning()이 false가 될 때까지(= 이전 스캔이 실제로 끝나 슬롯이 반환될 때까지)
// 기다림 → start(). timeoutMs 안에 안 끝나면 그냥 진행(멈춘 채로 영영 안 시작되는 것 방지).
window.KWSStopAndRestart = function(o){
  o = o || {};
  const limit = o.timeoutMs || 10000;
  try { o.stop && o.stop(); } catch (e) {}
  const t0 = Date.now();
  (function wait(){
    let running = false;
    try { running = !!(o.isRunning && o.isRunning()); } catch (e) {}
    if (!running || Date.now() - t0 >= limit) { try { o.start && o.start(); } catch (e) { console.warn('[KWS] restart failed', e); } return; }
    setTimeout(wait, 100);
  })();
};

// ── 타임스탬프(▶ 시간) 버튼 공통 스타일 ──
window.KWS_TBTN = {
  base: 'padding:5px 8px;border-radius:8px;font-weight:700;font-size:11px;font-family:monospace;min-width:66px;display:flex;align-items:center;justify-content:center;white-space:nowrap;cursor:pointer;flex-shrink:0;',
  off:  'border:1px solid rgba(37,99,235,0.4);background:rgba(37,99,235,0.2);color:#bfdbfe;',
  on:   'border:1px solid rgba(16,185,129,0.45);background:rgba(16,185,129,0.18);color:#86efac;',
};
