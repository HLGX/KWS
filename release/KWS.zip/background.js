// KWS 1.2.5: side panel wiring
try { importScripts('sidepanel_bg.js', 'chzzk_bg.js', 'scan_hub.js', 'overnight_bg.js', 'kickfind_bg.js', 'data_folder.js', 'data_folder_bg.js'); } catch (e) { console.error('[KWS SP] failed to load side panel scripts', e); }

// ── MV3 서비스워커 강제 종료 방지 (keep-alive) ──────────────────────────────
// Chrome은 MV3 서비스워커가 ~30초 동안 "활동"(대기 중인 extension API 호출/이벤트)이
// 없으면 그냥 강제로 죽여버림. 문제는 Kick처럼 채널을 여러 개 동시에 스캔하다가
// 429(레이트리밋)를 맞으면 kws_kickChatCooldownUntil 공유 쿨다운 때문에 전체가 그냥
// await로 몇 초~몇십 초씩 가만히 있는 구간이 생기는데, 이 "가만히 있는 시간"엔 Chrome
// 입장에선 활동이 하나도 없는 걸로 보여서 그 사이에 서비스워커가 통째로 종료돼버릴 수
// 있음. 서비스워커가 죽으면 지금 돌고 있던 kick_scanChannelRange 함수(전부 이 파일의
// 메모리 안 클로저 상태: doneChunks, groups, KICK_GLOBAL_POOL 등)가 흔적도 없이
// 사라지고, 콘텐츠 스크립트 쪽은 그 이후로 progress 메시지를 영원히 못 받게 됨 —
// 동시에 돌던 채널들의 퍼센트가 전부 한꺼번에 딱 멈춰서 다시는 안 움직이는 증상이
// 정확히 이거였을 가능성이 큼(2026-09, "퍼센트가 모두 멈췄어" 리포트).
// 해결: chrome.alarms는 서비스워커가 자고 있어도 예약된 시각에 다시 깨워주는
// 유일한 방법이라, 30초보다 짧은 주기(24초)로 빈 알람을 계속 걸어둬서 서비스워커가
// 스스로를 "활동 중"으로 계속 갱신하게 만듦 — 알람 콜백 자체는 아무 일도 안 해도
// 됨(그냥 깨어나서 실행되는 것 자체가 idle 타이머를 리셋시켜줌).
const KWS_KEEPALIVE_ALARM = 'kws-keepalive';
try {
  // chrome.alarms의 실제 최소 주기는 (개발자 모드가 아니면) 1분으로 강제 클램프됨 —
  // 그래도 이건 "서비스워커가 진짜로 죽어버렸을 때" 다시 깨워주는 최후의 안전망 역할.
  chrome.alarms?.create(KWS_KEEPALIVE_ALARM, { periodInMinutes: 1 });
  chrome.alarms?.onAlarm?.addListener((alarm) => {
    if (alarm.name === KWS_KEEPALIVE_ALARM) {
      // no-op — 이 콜백이 실행된다는 사실 자체가 서비스워커를 깨워(또는 계속 살려)둠.
    }
  });
} catch (e) {
  console.warn('[KWS] keepalive alarm setup failed (alarms permission missing?)', e);
}
// alarms의 1분 주기는 30초 idle 타임아웃보다 느려서, 서비스워커가 "이미 죽는 걸 막는"
// 용도로는 부족함(죽은 뒤에 다시 깨우는 용도일 뿐). 그래서 실제로 30초 안에 걸리는
// 진짜 예방책은 이 setInterval — 서비스워커가 살아있는 동안 15초마다 진짜 extension
// API 호출(chrome.storage.local.get)을 하나 날려서 "활동 중"으로 계속 갱신시킴.
// 이 setInterval 자체는 서비스워커가 이미 죽어있으면 당연히 못 돌지만, 스크립트가
// 로드될 때마다(최초 로드든, 메시지로 깨어난 직후든, 위 알람으로 재기동된 직후든)
// 매번 새로 걸리므로 실질적으로 계속 돌고 있게 됨.
setInterval(() => { try { chrome.storage.local.get('kws_heartbeat_noop', () => {}); } catch (e) {} }, 15000);

// SOOP 채팅 XML fetch 전용 리스너 (별도 분리 - async 채널 닫힘 방지)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== 'SOOP_FETCH_XML') return;
  fetch(msg.url, { cache: 'no-store' })
    .then(r => r.ok ? r.text().then(text => sendResponse({ ok: true, text })) : sendResponse({ ok: false, status: r.status }))
    .catch(e => sendResponse({ ok: false, error: e.message }));
  return true; // 채널 유지
});

// vod_corewatch.js(document_start, MAIN world, vod.sooplive.com/player/*)가 보내는
// "vodCore.fileItems 준비됨" 알림 — openVodTab()이 폴링 없이 바로 반응할 수 있게 함.
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type !== 'VOD_CORE_READY') return;
  const tabId = sender?.tab?.id;
  if (tabId == null) return;
  const w = _vodCoreWaiters.get(tabId);
  if (w) { _vodCoreWaiters.delete(tabId); w.resolve(msg.fileItems || null); }
});

// SOOP 채팅 조각(ChatLoadSplit.php) 동시성 게이트 전용 리스너.
//
// 2026-09 회귀 원인: v1.2.3.96~98에서 "실제 fetch 자체를 background.js(서비스워커)로
// 옮기고 여기서 동시성/쿨다운을 처리"하는 방식으로 바꿨었는데, 그 결과 모든
// ChatLoadSplit.php 요청이 서비스워커(chrome-extension:// 오리진)에서 나가게 됐고,
// SOOP 서버가 이를 거의 전부 400으로 거부함(실측: 필터링된 요청 1718건 중 압도적
// 다수가 400/aborted) — 아마 서버가 Referer/Origin이 sooplive.com 페이지가 아니면
// 막는 걸로 보임. fetch API는 Referer/Origin을 코드로 위조할 수 없어서, 서비스워커에서
// 쏘는 한 이 문제는 풀 크기를 아무리 키워도 해결 불가능함 — 그래서 v98에서 풀을
// 키웠는데도 안 빨라지고 오히려 사실상 다 실패하고 있었던 것.
//
// 수정: 실제 fetch는 다시 콘텐츠 스크립트(soopSearcher.js, sooplive.com 페이지
// 컨텍스트 — 올바른 오리진/Referer가 자동으로 붙음)에서 하고, background.js는
// "언제 나가도 되는지"(동시성 상한 + 429 쿨다운)만 게이트로 관리함:
//   SOOP_POOL_ACQUIRE → 풀 자리 + 쿨다운 대기 끝나면 응답(그때 fetch 시작)
//   SOOP_POOL_DONE    → fetch 끝난 뒤 결과(성공/실패/상태코드) 보고 → 자리 반납 +
//                       성공/실패 카운팅 + (429면) 공유 쿨다운 갱신
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== 'SOOP_POOL_ACQUIRE') return;
  (async () => {
    await SOOP_CHAT_GLOBAL_POOL.acquire();
    const waitMs = kws_soopChatCooldownUntil - Date.now();
    if (waitMs > 0) await kws_sleep(waitMs);
    sendResponse({ ok: true });
  })();
  return true; // 비동기 응답
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type !== 'SOOP_POOL_DONE') return;
  try {
    if (msg.status === 429) {
      const retryAfterSec = parseInt(msg.retryAfter || '', 10);
      const cooldownMs = Number.isFinite(retryAfterSec) && retryAfterSec > 0 ? retryAfterSec * 1000 : 3000;
      kws_soopChatCooldownUntil = Math.max(kws_soopChatCooldownUntil, Date.now() + cooldownMs);
    }
    if (msg.ok) SOOP_CHAT_GLOBAL_POOL.reportSuccess(); else SOOP_CHAT_GLOBAL_POOL.reportFailure();
  } finally {
    SOOP_CHAT_GLOBAL_POOL.release();
  }
  // 응답 불필요 — fire-and-forget
});

chrome.runtime.onMessage.addListener((msg, sender, response) => {
  requestFromClientManager(msg, sender, response).then(result => {
    // KWS_START is handled async, no response needed
    if (result !== undefined && result !== true && typeof response === 'function') {
      try { response(result); } catch(e) {}
    }
  }).catch(err => {
    if (typeof response === 'function') {
      try { response({ ok: false, error: err?.message || String(err) }); } catch(e) {}
    }
  });
  return true;
});

var API_URL = 'https://d72bftb3vdzjo.cloudfront.net/';
var COGNITO_AUTH_URL = 'https://auth.voddownloader.com/oauth2/authorize';
var TOKEN_EXCHANGE_URL = 'https://lgr3wbktwctvs7twjdqqj3kw6i0bpubm.lambda-url.us-east-2.on.aws/'; // Will add after creating Lambda
var CLIENT_ID = '2bfa0uar5rpkq48tcg93rv4b8';
var REDIRECT_URI = chrome.identity.getRedirectURL('callback.html');


var cleanObject = (ob) =>
  Object.entries(ob).reduce((r, [k, v]) => {
    if (v != null && v != undefined && v !== "" && (["string", "number", "boolean", "function", "symbol"].some( (opt) => typeof v == opt,) || (typeof v == "object" && ((Array.isArray(v) && v.length) || Array.isArray(v) != true)))) {
      r[k] = v;
      return r;
    } else {
      return r;
    }
  }, {});
function unqKey(array, key) {
  var q = [];
  var map = new Map();
  for (const item of array) {
    if (!map.has(item[key])) {
      map.set(item[key], true);
      q.push(item);
    }
  }
  return q;
}

async function getLocalStorage(params) {
  return new Promise((res, rej) => {
    chrome.storage.local.get([params.key]).then((data) => {
      if (data?.[params.key]) res(data?.[params.key]);
      else res(null);
    });
  });
}
async function setLocalStorage(params) {
  chrome.storage.local.set({ [params?.key]: params?.data });
}


// ===== AUTHENTICATION =====
async function handleLogout() {
  var tokens = await chrome.storage.local.get(['access_token', 'refresh_token']);
  // Revoke refresh token (invalidates it server-side)
  if (tokens.refresh_token) {
    let tt = await fetch('https://auth.voddownloader.com/oauth2/revoke', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: `token=${tokens.refresh_token}&client_id=2bfa0uar5rpkq48tcg93rv4b8`
    });
    chrome.storage.local.remove(['id_token', 'access_token', 'refresh_token', 'token_expiry'], () => console.log('Logged out'));
    return { tt:tt, success: true };
  }
  chrome.storage.local.remove(['id_token', 'access_token', 'refresh_token', 'token_expiry'], () => console.log('Logged out'));
  return { tt:'no refresh token', success: true };
  // await chrome.storage.local.clear();

  // return true
}

async function handleGetStreams(params) {
  var { channel, service } = params;
  try {
    var token = await getValidToken();
    if (!token) {
      // console.log('null token');
      return null;
      // await launchAuthFlow();
      // token = await getValidToken();
    }

    if (!token) {
      return { success: false, error: 'Authentication failed' };
    }

    var streams = await queryAPI(channel, service, token);
    // console.log({ streams });
    return { success: true, streams: streams?.map(r => {
      return{
        timestamp:r?.timestamp * 1000,
        timestamp_seconds:r?.timestamp,
        channel_id:r?.channel_id,
        channel_login:r?.channel_name?.toLowerCase(),
        game_name:r?.game_name,
        service:r?.service,
        stream_id:r?.stream_id,
        title:r?.title,
        viewer_count:r?.viewer_count,
        vod_path:r?.vod_path,
      }
    }) };

  } catch (error) {
    console.error('Error in handleGetStreams:', error);
    return { success: false, error: error.message };
  }
}


async function launchAuthFlow() {
  return new Promise(async (resolve, reject) => {
    try {
      // Generate PKCE values
      var { code_verifier, code_challenge } = await generatePKCE();

      // Store verifier for token exchange
      await chrome.storage.local.set({ code_verifier: code_verifier });

      // Build authorization URL with PKCE
      var auth_url = `${COGNITO_AUTH_URL}?client_id=${CLIENT_ID}&response_type=code&redirect_uri=${encodeURIComponent(REDIRECT_URI)}&scope=openid+email&code_challenge=${code_challenge}&code_challenge_method=S256`;

      chrome.identity.launchWebAuthFlow({
        url: auth_url,
        interactive: true
      }, async (redirect_url) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }

        try {
          // Extract authorization code from redirect
          var url = new URL(redirect_url);
          var code = url.searchParams.get('code');

          if (!code) {
            reject(new Error('No authorization code in redirect'));
            return;
          }

          // Get stored code_verifier
          var result = await chrome.storage.local.get(['code_verifier']);
          var code_verifier = result.code_verifier;

          // Exchange code for tokens
          var tokens = await exchangeCodeForTokens(code, code_verifier);

          // Store all tokens
          storeTokens(tokens);

          // Clean up verifier
          await chrome.storage.local.remove(['code_verifier']);

          resolve(tokens.id_token);

        } catch (error) {
          reject(error);
        }
      });

    } catch (error) {
      reject(error);
    }
  });
}

async function exchangeCodeForTokens(code, code_verifier) {
  var response = await fetch(TOKEN_EXCHANGE_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      grant_type: 'authorization_code',
      code: code,
      redirect_uri: REDIRECT_URI,
      code_verifier: code_verifier
    })
  });

  if (!response.ok) {
    var error_text = await response.text();
    throw new Error(`Token exchange failed: ${error_text}`);
  }

  var tokens = await response.json();
  return tokens;
}

function storeTokens(tokens) {
  var now = Math.floor(Date.now() / 1000);
  var expiry = now + (tokens.expires_in || 3600);

  chrome.storage.local.set({
    id_token: tokens.id_token,
    access_token: tokens.access_token,
    refresh_token: tokens.refresh_token,
    token_expiry: expiry
  });
}

async function getValidToken() {
  return new Promise(async (resolve) => {
    var result = await chrome.storage.local.get(['id_token', 'token_expiry', 'refresh_token']);
    var now = Math.floor(Date.now() / 1000);

    // Token is still valid (with 5 minute buffer)
    if (result.id_token && result.token_expiry && result.token_expiry > now + 300) {
      resolve(result.id_token);
      return;
    }

    // Token expired but we have refresh token
    if (result.refresh_token) {
      try {
        var new_tokens = await refreshTokens(result.refresh_token);
        storeTokens(new_tokens);
        resolve(new_tokens.id_token);
        return;
      } catch (error) {
        console.error('Token refresh failed:', error);
        // Clear invalid refresh token
        await chrome.storage.local.remove(['id_token', 'access_token', 'refresh_token', 'token_expiry']);
        resolve(null);
        return;
      }
    }

    // No valid token
    resolve(null);
  });
}

async function refreshTokens(refresh_token) {
  var response = await fetch(TOKEN_EXCHANGE_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      grant_type: 'refresh_token',
      refresh_token: refresh_token
    })
  });

  if (!response.ok) {
    throw new Error('Token refresh failed');
  }

  var tokens = await response.json();
  return tokens;
}


// async function handleLogout() {
//   await chrome.storage.local.remove(['id_token', 'access_token', 'refresh_token', 'token_expiry']);
//   return { success: true, message: 'Logged out' };
// }

// ===== PKCE HELPER FUNCTIONS =====

async function generatePKCE() {
  // Generate code verifier (random string)
  var code_verifier = generateRandomString(128);

  // Generate code challenge (SHA256 hash of verifier)
  var encoder = new TextEncoder();
  var data = encoder.encode(code_verifier);
  var hash = await crypto.subtle.digest('SHA-256', data);
  var code_challenge = base64URLEncode(hash);

  return { code_verifier, code_challenge };
}

function generateRandomString(length) {
  var array = new Uint8Array(length);
  crypto.getRandomValues(array);
  return base64URLEncode(array);
}

function base64URLEncode(buffer) {
  var bytes = buffer instanceof ArrayBuffer ? new Uint8Array(buffer) : buffer;
  var str = String.fromCharCode(...bytes);
  return btoa(str)
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=/g, '');
}


async function queryAPI(channel, service, token) {
  var url = `${API_URL}?channel=${encodeURIComponent(channel)}&service=${service}&limit=100`;
  var response = await fetch(url, {
    headers: {
      'Authorization': `Bearer ${token}`
    }
  });
  if (!response.ok) {
    throw new Error(`API error: ${response.status}`);
  }
  var data = await response.json();
  console.log('stream logger data');
  console.log(data);
  return data.streams;
}

async function requestFromClientManager(msg, sender, sendResponse) {
  // KWS messages: handled directly in the first listener
  if (msg.type === "KWS_START") {
    const tabId = sender?.tab?.id;
    if (typeof tabId === "number") kws_run({ ...msg, tabId, logSource: msg.logSource || 'zonian' });
    return;
  }
  if (msg.type === "KWS_STOP") {
    // Twitch 스캔 진짜 중지: 이 탭·이 채널의 실행 중/대기 중 스캔을 취소 (슬롯도 곧 반환됨)
    const tabId = sender?.tab?.id;
    const ch = kws_normalizeChannel(msg.channel || '');
    if (typeof tabId === "number" && ch) kws_stopScansFor(tabId, ch);
    return;
  }
  if (msg.type === "KICK_KWS_START") {
    const tabId = sender?.tab?.id;
    if (typeof tabId === "number") {
      const { channel, keyword, startDate, endDate } = msg;
      (async () => {
        try {
          kws_sendToTab(tabId, { type: "KICK_KWS_RUNNING", channel });
          const scanResult = await kick_scanChannelRange({
            channel, keyword, startDate, endDate,
            onStart: (p) => kws_sendToTab(tabId, { type: "KICK_KWS_STARTED", ...p }),
            onProgress: (p) => kws_sendToTab(tabId, { type: "KICK_KWS_PROGRESS", ...p }),
          });
          kws_sendToTab(tabId, { type: "KICK_KWS_DONE", channel, failedChunks: scanResult?.failedChunks || 0 });
        } catch(e) {
          kws_sendToTab(tabId, { type: "KICK_KWS_ERROR", message: e?.message || String(e), channel });
        }
      })();
    }
    return;
  }
  if (msg.type === "KICK_KWS_STOP") {
    // Kick scan uses a simple flag per channel
    kws_kickStopFlags = kws_kickStopFlags || new Set();
    kws_kickStopFlags.add((msg.channel||'').toLowerCase());
    return;
  }

  // streamrecorder.io 뱃지에서 옴 — Twitch 쪽에 이미 있던 OPEN_TWITCH_AND_SCAN(twitchtracker.com
  // 뱃지용)이랑 같은 패턴을 킥/트위치/숲 셋 다에 씀: 이미 그 플랫폼 탭이 열려있으면 새로 열지
  // 않고 그 탭에 채널만 얹어서 큐에 넣고(각 패널이 MAX_CONCURRENT_SCANS 넘으면 알아서 대기열
  // 처리), 없을 때만 새 탭을 연 다음 로드가 끝나길 기다렸다가 같은 메시지를 보냄. 콘텐츠
  // 스크립트(streamRecorderBadge.js)는 chrome.tabs를 직접 못 쓰니 background를 거쳐야 함.
  if (msg.type === "OPEN_PLATFORM_AND_SCAN") {
    // YouTube는 Kick/Twitch/SOOP와 다르게 "한 탭에 패널 하나" 구조라 기존 탭을 찾아서 채널만
    // 바꿔치기 하는 게 안 맞음(그 탭이 이미 보고 있던 다른 스트리머 패널과 뒤섞임) — 그래서
    // 다른 플랫폼처럼 탭 재사용 없이 뱃지를 누를 때마다 항상 새 탭을 열고, 그 채널의 Live
    // 탭(/streams)으로 바로 이동시킴. 자동 스캔 시작은 youtubeSearcher.js가 URL의
    // ?kws_autoscan=1을 직접 읽어서 처리함 — sendMessage로 콘텐츠 스크립트를 깨우는 것보다
    // 새 탭의 로드 타이밍에 안 흔들리고 더 안정적임.
    if (msg.platform === 'youtube') {
      const slug = (msg.slug || '').trim();
      if (!slug) return { ok: false, reason: 'bad-request' };
      try {
        const handle = slug.replace(/^@/, '');
        await chrome.tabs.create({ url: `https://www.youtube.com/@${encodeURIComponent(handle)}/streams?kws_autoscan=1`, active: true });
        return { ok: true, opened: true };
      } catch (e) {
        return { ok: false, reason: String(e?.message || e) };
      }
    }
    const CONF = {
      kick:      { pattern: 'https://kick.com/*',         openUrl: (s)=>`https://kick.com/${s}`,                 msgType: 'KWS_EXTERNAL_QUEUE_SCAN' },
      twitch:    { pattern: 'https://www.twitch.tv/*',    openUrl: (s)=>`https://www.twitch.tv/${s}`,            msgType: 'KWS_SET_CHANNEL_AND_SCAN' },
      afreecatv: { pattern: 'https://www.sooplive.com/*', openUrl: (s)=>`https://www.sooplive.com/station/${s}`, msgType: 'KWS_SET_STREAMER_AND_SCAN' },
    }[msg.platform];
    const slug = (msg.slug || '').toLowerCase().trim();
    if (!CONF || !slug) return { ok: false, reason: 'bad-request' };
    try {
      const tabs = await chrome.tabs.query({ url: CONF.pattern });
      let targetTab = tabs.find(t => typeof t.id === 'number') || null;
      let opened = false;

      if (!targetTab) {
        targetTab = await chrome.tabs.create({ url: CONF.openUrl(slug), active: true });
        opened = true;
        await new Promise(resolve => {
          const listener = (tabId, info) => {
            if (tabId === targetTab.id && info.status === 'complete') {
              chrome.tabs.onUpdated.removeListener(listener);
              resolve();
            }
          };
          chrome.tabs.onUpdated.addListener(listener);
          setTimeout(resolve, 8000); // 최대 8초 대기
        });
      } else {
        await chrome.tabs.update(targetTab.id, { active: true });
        try { await chrome.windows.update(targetTab.windowId, { focused: true }); } catch (e) {}
      }

      // 필드명이 플랫폼마다 달라서(slug/channel/streamerId) 셋 다 같이 보냄 — 각자 자기가
      // 아는 이름만 읽고 나머지는 무시함.
      // 새로 연 탭은 'complete' 직후엔 콘텐츠 스크립트가 아직 리스너를 안 단 경우가 있어서
      // (Receiving end does not exist) 최대 ~6초간 재시도 — 첫 메시지가 조용히 유실돼
      // 팝업/스캔이 아예 안 뜨던 문제 방지.
      let sent = false, lastErr = null;
      for (let i = 0; i < 12 && !sent; i++) {
        try {
          await chrome.tabs.sendMessage(targetTab.id, {
            type: CONF.msgType,
            slug, channel: slug, streamerId: slug,
          });
          sent = true;
        } catch (e) {
          lastErr = e;
          await new Promise(r => setTimeout(r, 500));
        }
      }
      if (!sent) throw lastErr || new Error('send failed');
      return { ok: true, opened };
    } catch (e) {
      return { ok: false, reason: String(e?.message || e) };
    }
  }

  // ── SOOP handlers ────────────────────────────────────────────────────
  if (msg.type === 'OPEN_TWITCH_AND_SCAN') {
    // twitchtracker에서 배지 클릭 → Twitch 탭 찾거나 열고 스트리머 ID 전달
    const { slug } = msg;
    try {
      // 기존 Twitch 탭 찾기
      let twitchTabs = await chrome.tabs.query({ url: 'https://www.twitch.tv/*' });
      let targetTab = twitchTabs[0] || null;

      if (!targetTab) {
        // Twitch 탭 없으면 새로 열기
        targetTab = await chrome.tabs.create({ url: 'https://www.twitch.tv/', active: !!msg.hasHistory });
        // 페이지 로드 대기
        await new Promise(resolve => {
          const listener = (tabId, info) => {
            if (tabId === targetTab.id && info.status === 'complete') {
              chrome.tabs.onUpdated.removeListener(listener);
              resolve();
            }
          };
          chrome.tabs.onUpdated.addListener(listener);
          setTimeout(resolve, 8000); // 최대 8초 대기
        });
      } else if (msg.focusTab) {
        // 팝업 선택 후 Twitch 탭으로 이동
        await chrome.tabs.update(targetTab.id, { active: true });
        await chrome.windows.update(targetTab.windowId, { focused: true });
      }

      // twitchtracker에 즉시 queued 상태 브로드캐스트
      broadcastToTwitchTracker({ type: 'KWS_TT_STATE', channel: slug, state: 'queued', percent: 0 });

      // KWS에 스트리머 ID + 스캔 타입 전달
      await chrome.tabs.sendMessage(targetTab.id, {
        type: 'KWS_SET_CHANNEL_AND_SCAN',
        slug,
        scanType: msg.scanType || 'full' // 'full' | 'incremental'
      });
      sendResponse({ success: true });
    } catch(e) {
      sendResponse({ success: false, error: e.message });
    }
    return true;
  }

  if (msg.type === 'OPEN_VOD_TAB') {
    openVodTabGated(msg.playerUrl).then(sendResponse).catch(() => sendResponse({ success: false }));
    return true;
  }
  if (msg.type === 'SCAN_VOD_IN_TAB_FULL') {
    scanVodTabFullGated(msg.playerUrl, msg.parsedKw, msg.chunkConc, msg.maxConcurrentTabs)
      .then(sendResponse).catch((e) => sendResponse({ success: false, error: e?.message }));
    return true;
  }
  if (msg.type === 'FETCH_TEXT_BG') {
    // 백그라운드 프로세스 자체 커넥션 풀을 통해 우회 — 콘텐츠 스크립트(페이지) 쪽 커넥션 풀과
    // 별도라서, 채팅 조각 요청 일부를 여기로 나눠 보내면 실질적으로 동시 연결 "문"이 하나 더 생김
    (async () => {
      try {
        const resp = await fetch(msg.url, { cache: 'no-store' });
        if (!resp.ok) { sendResponse({ ok: false }); return; }
        const text = await resp.text();
        sendResponse({ ok: true, text });
      } catch (e) {
        sendResponse({ ok: false, error: e?.message });
      }
    })();
    return true;
  }
  if (msg.type === 'START_VOD_CAPTURE') {
    startVodCapture(msg).then(sendResponse).catch(e => sendResponse({ error: e.message }));
    return true;
  }
  if (msg.type === 'CAPTURE_PROGRESS') {
    const c = SOOP_CAPTURES[msg.captureId];
    if (!c) { sendResponse(null); return; }
    const duration = c.endSec - c.startSec;
    const progress = duration > 0 ? Math.min(99, Math.round(c.captured / duration * 100)) : 0;
    sendResponse({ captured: c.captured, done: c.done, error: c.error, progress });
    return true;
  }
  if (msg.type === 'SAVE_VOD_CAPTURE') {
    saveVodCapture(msg.captureId, msg.filename, sender.tab?.id);
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'STOP_VOD_CAPTURE') {
    if (soop_captureVodTabId) { chrome.tabs.remove(soop_captureVodTabId).catch(()=>{}); soop_captureVodTabId = null; }
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'MS_CHUNK') {
    const c = SOOP_CAPTURES[msg.captureId];
    if (c && !c.done && msg.data) {
      const bin = atob(msg.data);
      const buf = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
      c.chunks.push(buf.buffer);
      c.captured = Math.max(c.captured, Math.max(0, msg.currentTime - c.startSec));
    }
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'MS_ENDED') {
    const c = SOOP_CAPTURES[msg.captureId];
    if (c) { c.done = true; c.captured = c.endSec - c.startSec; }
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'OPEN_CAPTURE_WIN') {
    const url = chrome.runtime.getURL('capture.html') + '?' + msg.params;
    chrome.windows.create({ url, type: 'popup', width: 380, height: 480 });
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === "KWS_CANCEL_QUEUE") {
    const tabId = sender?.tab?.id;
    const ch = kws_normalizeChannel(msg.channel || "");
    const idx = KWS_SCAN_QUEUE.findIndex(q => q.channel === ch && q.tabId === tabId);
    if (idx >= 0) KWS_SCAN_QUEUE.splice(idx, 1);
    kws_broadcastQueueUpdate();
    return;
  }
  if (msg.type === "KWS_TT_GET_STATUS") {
    // twitchtracker가 현재 스캔 상태 조회
    sendResponse({
      activeChannels: Array.from(KWS_ACTIVE_CHANNELS),
      queue: KWS_SCAN_QUEUE.map(q => ({ channel: q.channel })),
    });
    return true;
  }

  if (msg.type === 'KWS_SOOP_STATE') {
    // soopSearcher.js가 진행 상황 보고 → 세션 스토리지 캐시 갱신 + 랭킹페이지로 중계
    (async () => {
      const st = await getSoopLastState();
      if (msg.state === 'done') {
        if (st.activeStreamerId?.toLowerCase() === msg.streamerId?.toLowerCase()) {
          st.activeStreamerId = null; st.percent = 0;
        }
        st.queue = st.queue.filter(q => q.streamerId?.toLowerCase() !== msg.streamerId?.toLowerCase());
      } else if (msg.state === 'running') {
        st.activeStreamerId = msg.streamerId; st.percent = msg.percent || 0;
      } else if (msg.state === 'queued') {
        if (!st.queue.some(q => q.streamerId?.toLowerCase() === msg.streamerId?.toLowerCase())) {
          st.queue.push({ streamerId: msg.streamerId });
        }
      }
      await setSoopLastState(st);
      broadcastToSoopRanking({ type: 'KWS_SOOP_STATE', streamerId: msg.streamerId, state: msg.state, percent: msg.percent });
    })();
    return true;
  }
  if (msg.type === 'KWS_SOOP_GET_STATUS') {
    getSoopLastState().then(st => {
      sendResponse({ activeStreamerId: st.activeStreamerId, percent: st.percent, queue: st.queue });
    });
    return true;
  }
  if (msg.type === 'OPEN_SOOP_AND_SCAN') {
    // 랭킹 페이지 배지 클릭 → SOOP 탭 찾거나 열고 스트리머 ID 전달
    (async () => {
      const { streamerId } = msg;
      try {
        let soopTabs = await chrome.tabs.query({ url: 'https://www.sooplive.com/*' });
        let targetTab = soopTabs[0] || null;

        if (!targetTab) {
          targetTab = await chrome.tabs.create({ url: 'https://www.sooplive.com/', active: !!msg.hasHistory });
          await new Promise(resolve => {
            const listener = (tabId, info) => {
              if (tabId === targetTab.id && info.status === 'complete') {
                chrome.tabs.onUpdated.removeListener(listener);
                resolve();
              }
            };
            chrome.tabs.onUpdated.addListener(listener);
            setTimeout(resolve, 8000);
          });
          // 페이지 로딩 완료(status:complete)가 콘텐츠 스크립트 자체의 초기화(히스토리 로딩 등)
          // 완료를 보장하진 않아서, 약간의 여유를 더 줌 — 안 그러면 재검색 팝업이 "히스토리 없음"으로 오판됨
          await new Promise(r => setTimeout(r, 1200));
        } else if (msg.focusTab) {
          await chrome.tabs.update(targetTab.id, { active: true });
          await chrome.windows.update(targetTab.windowId, { focused: true });
        }

        broadcastToSoopRanking({ type: 'KWS_SOOP_STATE', streamerId, state: 'queued', percent: 0 });

        // 콘텐츠 스크립트 리스너가 아직 등록 전일 수 있어서 짧게 재시도
        let sendOk = false;
        for (let attempt = 0; attempt < 4 && !sendOk; attempt++) {
          try {
            await chrome.tabs.sendMessage(targetTab.id, {
              type: 'KWS_SET_STREAMER_AND_SCAN',
              streamerId,
              hasHistory: !!msg.hasHistory
            });
            sendOk = true;
          } catch {
            await new Promise(r => setTimeout(r, 500));
          }
        }

        sendResponse({ success: true });
      } catch(e) {
        sendResponse({ success: false, error: e.message });
      }
    })();
    return true;
  }

  if (msg.type === "KWS_GET_STATUS") {
    response({
      throttled: KWS_OVERLOAD.throttled,
      throttleUntil: KWS_OVERLOAD.throttleUntil,
      queue: KWS_SCAN_QUEUE.map(q => ({ channel: q.channel, tabId: q.tabId })),
      activeChannels: Array.from(KWS_ACTIVE_CHANNELS),
      avgFetchMs: kws_getAvgFetchMs(),
    });
    return true;
  }
  if (msg.type === "KWS_DIRECTORY_START") {
    return kws_startDirectoryCrawler(msg, sender?.tab?.id);
  }
  if (msg.type === "KWS_DIRECTORY_STOP") {
    return kws_stopDirectoryCrawler();
  }
  if (msg.type === "KWS_DIRECTORY_STATUS_GET") {
    return kws_getDirectoryState();
  }
  if (msg.type === "KWS_DIRECTORY_RESET") {
    return kws_resetDirectoryCrawlerHistory();
  }
  if (msg.type === "KWS_COLLECT_DIRECTORY_CHANNELS_RESULT") {
    return null;
  }

  if (msg.cmd === "handleGetStreams") return await handleGetStreams(msg.params);
  if (msg.cmd === "authComplete") return await handleAuthComplete(msg.params);
  if (msg.cmd === "getValidToken") return await getValidToken();
  if (msg.cmd === "launchAuthFlow") return await launchAuthFlow();
  if (msg.cmd === "handleLogout") return await handleLogout();
  if (msg.cmd === "getSullyStreamsData") return await getSullyStreamsData(msg.params);

  if (msg.cmd === 'fetchJSON') return await fetchJSON(msg.params?.url,msg.params?.opt);

  if (msg.cmd === 'getTwitchChannelInfo') return await getTwitchChannelInfo(msg.params);
  if (msg.cmd === "SHA1") return SHA1(msg.params);
  if (msg.cmd === "getAvailableVODinfo") return await getAvailableVODinfo(msg.params);
  if (msg.cmd === "getOfficialVodM3u8Source") return await getOfficialVodM3u8Source(msg.params);
  if (msg.cmd === "searchTwitch") return await searchTwitch(msg.params);
  if (msg.cmd === "getStreamDetailsFromStreamId") return await getStreamDetailsFromStreamId(msg.params);
  if (msg.cmd === "kwsCdnProbe") return await kwsCdnProbe(msg.params);
  if (msg.cmd === "kwsSullyDiag") return kws_sullyDiag;
  if (msg.cmd === "getValidResolutions") return await getValidResolutions(msg.params);
  if (msg.cmd === "searchKick") return await searchKick(msg.params);
  if (msg.cmd === "getKickVODs") return await getKickVODs(msg.params);
  if (msg.cmd === "getKickChannelV1") return await getKickChannelV1(msg.params);
  if (msg.cmd === "getKickVideoStreamData") return await getKickVideoStreamData(msg.params);
  if (msg.cmd === "getTwitchOrKickManifest") return await getTwitchOrKickManifest(msg.params);

  if (msg.cmd === "getTwitchStreamInformation") return await getTwitchStreamInformation(msg.params);
  if (msg.cmd === "getLivestreamPlaybackToken") return await getLivestreamPlaybackToken(msg.params);
  if (msg.cmd === "getTwitchLivestreamUrl") return await getTwitchLivestreamUrl(msg.params);

  if (msg.cmd === "getTwitchLivestreamManifest") return await getTwitchLivestreamManifest(msg.params);

  if (msg.cmd === "genericGQL") return await genericGQL(msg.params);

  if (msg.cmd === "getLocalStorage") return await getLocalStorage(msg.params);
  if (msg.cmd === "setLocalStorage") return await setLocalStorage(msg.params);
  if (msg.cmd === "getDownloadableArrayBuffer") return await getDownloadableArrayBuffer(msg.params);
  if (msg.cmd === "getAllHighlights") return await getAllHighlights(msg.params);
  if (msg.cmd === "getClipSig") return await getClipSig(msg.params);
  if (msg.cmd === "vodChatExtraction") return await vodChatExtraction(msg.params);
  if (msg.cmd == 'getRobottyChats') return await getRobottyChats(msg.params);
  if (msg.cmd === 'ytGetChatContinuation') return await ytGetChatContinuation(msg.params);
  if (msg.cmd === 'ytFetchChatPage') return await ytFetchChatPage(msg.params);
  if (msg.cmd === 'ytParseInitialData') return ytParseInitialData(msg.params);
  if (msg.cmd === 'ytGetChannelVODs') return await ytGetChannelVODs(msg.params, sender?.tab?.id);

}

/*
  TODO:
  get dev message from server. {id,msg,timestamp,time_boundary}
    check state of notice message.
    has been delivered
*/

async function getDownloadableArrayBuffer(params){
  var { url } = params;
  try{
    var res = await fetch(url);
    if (!res.ok) return params; // 404/403 오류 본문이 영상 조각으로 저장되는 것 방지 (호출부가 재시도)
    var headers = res.headers;
    var content_type = headers.get('content-type');
    var content_length = headers.get('content-length');
    var last_modified = headers.get('last-modified')
    var buffer = await res.arrayBuffer();
    if(buffer?.byteLength){
      var data = {
          data: Array.from(new Uint8Array(buffer)),
          contentType: content_type
      };
      var transport_data = JSON.stringify(data);
      return { ...params, ...{ transport_data,content_type,content_length,last_modified } };
    }else{
      return { ...params, ...{ content_type,content_length,last_modified } };
    }
  }catch(err){
    // console.log(err);
    return params;
  }
}

var rando = (n) => Math.round(Math.random() * n);
var delay = (ms) => new Promise((res) => setTimeout(res, ms));
var everyNth = (i, n) => /\./.test((i / n).toString()) === false && i != 0;
var snakeCaser = (s) =>
  s
    ?.split(/(?<=[a-z])\B(?=[A-Z])/)
    ?.map((i) => i.toLowerCase())
    ?.reduce((a, b) => a + "_" + b);

function snakeCaseObject(obj) {
  // console.log("snakeCaseObject", obj);
  return obj && Object.entries(obj)?.length
    ? Object.entries(obj)
        .map((kv) => {
          let val =
            typeof kv[1] == "object" && Array.isArray(kv[1])
              ? kv[1].map((v) => snakeCaseObject(v))
              : kv[1] && typeof kv[1] == "object"
                ? snakeCaseObject(kv[1])
                : kv[1];
          return {
            ...(/^\$/.test(kv[0])
              ? {}
              : { [snakeCaser(kv[0].replace(/^js/, ""))]: val }),
          };
        })
        .reduce((a, b) => {
          return { ...a, ...b };
        })
    : {}; /*maybe change this to null*/
}

var snakeKeyify = (s) => s?.toLowerCase()?.trim()?.replace(/\W+/g, "_");
var valCleaner = (s) => s?.replace(/^"/, "")?.replace(/"$/, "");

var subArr = (r, n) =>
  r.reduceRight((a, b, c, d) => [...a, d.splice(0, n)], []);
var tryJSON = (s) => {
  try {
    return JSON.parse(s);
  } catch (err) {
    return null;
  }
};

async function fetchTexts(arr) {
  let res = await Promise.all(arr.map((e) => fetch(e)));
  return await Promise.all(
    res.map(async (e) => {
      let text = await e.text();
      return {
        text: text,
        url: e.url,
      };
    }),
  );
}
function SHA1(msg) {
  const rotate_left = (n, s) => (n << s) | (n >>> (32 - s));
  function cvt_hex(val) {
    var str = "";
    var i, v;
    for (i = 7; i >= 0; i--) {
      v = (val >>> (i * 4)) & 0x0f;
      str += v.toString(16);
    }
    return str;
  }
  function Utf8Encode(string) {
    string = string.replace(/\r\n/g, "\n");
    var utftext = "";
    for (var n = 0; n < string.length; n++) {
      var c = string.charCodeAt(n);
      if (c < 128) {
        utftext += String.fromCharCode(c);
      } else if (c > 127 && c < 2048) {
        utftext += String.fromCharCode((c >> 6) | 192);
        utftext += String.fromCharCode((c & 63) | 128);
      } else {
        utftext += String.fromCharCode((c >> 12) | 224);
        utftext += String.fromCharCode(((c >> 6) & 63) | 128);
        utftext += String.fromCharCode((c & 63) | 128);
      }
    }
    return utftext;
  }
  var blockstart;
  var i, j;
  var W = new Array(80);
  var H0 = 0x67452301;
  var H1 = 0xefcdab89;
  var H2 = 0x98badcfe;
  var H3 = 0x10325476;
  var H4 = 0xc3d2e1f0;
  var A, B, C, D, E;
  var temp;
  msg = Utf8Encode(msg);
  var msg_len = msg.length;
  var word_array = new Array();
  for (i = 0; i < msg_len - 3; i += 4) {
    j =
      (msg.charCodeAt(i) << 24) |
      (msg.charCodeAt(i + 1) << 16) |
      (msg.charCodeAt(i + 2) << 8) |
      msg.charCodeAt(i + 3);
    word_array.push(j);
  }
  switch (msg_len % 4) {
    case 0:
      i = 0x080000000;
      break;
    case 1:
      i = (msg.charCodeAt(msg_len - 1) << 24) | 0x0800000;
      break;
    case 2:
      i =
        (msg.charCodeAt(msg_len - 2) << 24) |
        (msg.charCodeAt(msg_len - 1) << 16) |
        0x08000;
      break;
    case 3:
      i =
        (msg.charCodeAt(msg_len - 3) << 24) |
        (msg.charCodeAt(msg_len - 2) << 16) |
        (msg.charCodeAt(msg_len - 1) << 8) |
        0x80;
      break;
  }
  word_array.push(i);
  while (word_array.length % 16 != 14) word_array.push(0);
  word_array.push(msg_len >>> 29);
  word_array.push((msg_len << 3) & 0x0ffffffff);
  for (blockstart = 0; blockstart < word_array.length; blockstart += 16) {
    for (i = 0; i < 16; i++) W[i] = word_array[blockstart + i];
    for (i = 16; i <= 79; i++)
      W[i] = rotate_left(W[i - 3] ^ W[i - 8] ^ W[i - 14] ^ W[i - 16], 1);
    A = H0;
    B = H1;
    C = H2;
    D = H3;
    E = H4;
    for (i = 0; i <= 19; i++) {
      temp =
        (rotate_left(A, 5) + ((B & C) | (~B & D)) + E + W[i] + 0x5a827999) &
        0x0ffffffff;
      E = D;
      D = C;
      C = rotate_left(B, 30);
      B = A;
      A = temp;
    }
    for (i = 20; i <= 39; i++) {
      temp =
        (rotate_left(A, 5) + (B ^ C ^ D) + E + W[i] + 0x6ed9eba1) & 0x0ffffffff;
      E = D;
      D = C;
      C = rotate_left(B, 30);
      B = A;
      A = temp;
    }
    for (i = 40; i <= 59; i++) {
      temp =
        (rotate_left(A, 5) +
          ((B & C) | (B & D) | (C & D)) +
          E +
          W[i] +
          0x8f1bbcdc) &
        0x0ffffffff;
      E = D;
      D = C;
      C = rotate_left(B, 30);
      B = A;
      A = temp;
    }
    for (i = 60; i <= 79; i++) {
      temp =
        (rotate_left(A, 5) + (B ^ C ^ D) + E + W[i] + 0xca62c1d6) & 0x0ffffffff;
      E = D;
      D = C;
      C = rotate_left(B, 30);
      B = A;
      A = temp;
    }
    H0 = (H0 + A) & 0x0ffffffff;
    H1 = (H1 + B) & 0x0ffffffff;
    H2 = (H2 + C) & 0x0ffffffff;
    H3 = (H3 + D) & 0x0ffffffff;
    H4 = (H4 + E) & 0x0ffffffff;
  }
  var temp =
    cvt_hex(H0) + cvt_hex(H1) + cvt_hex(H2) + cvt_hex(H3) + cvt_hex(H4);
  return temp.toLowerCase();
}

var kws_sullyDiag = '';
async function getSullyStreamsData(params) {
  // kws_sullyDiag records WHY it failed (shown in the VOD error's [debug] line)
  kws_sullyDiag = '';
  const sf = async (label, url, type) => {
    const ctrl = new AbortController();
    const tid = setTimeout(() => ctrl.abort(), 8000);
    try {
      const res = await fetch(url, { signal: ctrl.signal });
      if (!res.ok) { kws_sullyDiag = `${label}: HTTP ${res.status}`; return null; }
      return await res[type]();
    } catch (e) {
      kws_sullyDiag = `${label}: ${e?.name === 'AbortError' ? 'timeout(8s)' : (e?.name || 'error')}`;
      return null;
    } finally { clearTimeout(tid); }
  };
  try {
    // url: `https://sullygnome.com/channel/${params?.channel_login}/30/streams`, endpoint changed. fixed 2 Dec 2025.
    var text = await sf('page', `https://sullygnome.com/channel/${params?.channel_login}/streams`, 'text');
    if (text == null) return null;
    var channel_id = /(?<=PageInfo.{1,1000}?"id":)\d+/.exec(text)?.[0];
    if (!channel_id) { kws_sullyDiag = `page OK but channel id not found (len=${text.length}${/cloudflare|just a moment|captcha/i.test(text) ? ', challenge page' : ''})`; return null; }
    var d = await sf('api', `https://sullygnome.com/api/tables/channeltables/streams/90/${channel_id}/%20/1/1/desc/0/100`, 'json');
    if (d == null) return null;
    var parsed = d?.data
      ?.map((r) => {
        return cleanObject({
          ...{
            duration: r?.length ? r?.length * 60000 : 0,
            channel_login: r?.channelurl,
            stream_id:
              /(?<=stream\/)\d+/.exec(r?.streamUrl)?.[0] || r?.streamId,
            timestamp: new Date(r?.startDateTime).getTime(),
            timestamp_seconds: Math.floor(
              new Date(r?.startDateTime).getTime() / 1000,
            ),
          },
          ...r,
        });
      })
      .filter(
        (r) => r.timestamp > new Date().getTime() - 86400000 * 61,
      ); /*filteres to last 60 days of streams*/
    if (!parsed) kws_sullyDiag = 'api OK but no data field';
    return parsed;
  }
  catch(err){
      kws_sullyDiag = 'exception: ' + (err?.message || err);
      return null
  }
}

async function searchKick(params) {
  var { query } = params;
  var res = await fetch("https://search.kick.com/multi_search", {
    headers: {
      accept: "*/*",
      "accept-language": "en-US,en;q=0.5",
      "content-type": "text/plain;charset=UTF-8",
      priority: "u=1, i",
      "sec-ch-ua-mobile": "?0",
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-site",
      "sec-gpc": "1",
      "x-typesense-api-key": "nXIMW0iEN6sMujFYjFuhdrSwVow3pDQu",
    },
    referrer: "https://kick.com/",
    referrerPolicy: "strict-origin-when-cross-origin",
    body: `{\"searches\":[{\"preset\":\"channel_search\",\"q\":\"${query}\"}]}`,
    method: "POST",
    mode: "cors",
    credentials: "omit",
  });
  var d = await res.json();
  var dat = d?.results
    ?.map((s) =>
      s?.hits?.map((r) => {
        return {
          channel_login: r?.document?.slug,
          channel_id: r?.document?.id,
          followers: r?.document?.followers_count,
          is_banned: r?.document?.is_banned,
          is_live: r?.document?.is_live,
          is_verified: r?.document?.verified,
        };
      }),
    )
    ?.flat();
  return dat;
}
async function getGQL(params) {
  var { device_id, client_id, oauth, vod_id, channel_login,token } = params;
  var stored_tokens = await getLocalStorage({ key: "tvd_twitch_tokens" });
  var res = await fetch("https://gql.twitch.tv/gql", {
    headers: {
      ...{
        accept: "*/*",
        "accept-language": "en-US",
        authorization: oauth || stored_tokens?.oauth,
        "client-id": client_id || stored_tokens?.client_id,
      },
      ...(token ? { "client-integrity": token } : {}),
      ...{
        "content-type": "text/plain;charset=UTF-8",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "x-device-id": device_id || stored_tokens?.device_id,
      }
    },
    referrer: "https://www.twitch.tv/",
    referrerPolicy: "strict-origin-when-cross-origin",
    body: params?.body,
    method: "POST",
    mode: "cors",
    credentials: "include",
  });
  var d = await res.json();
  return d;
}

async function getIntegrityToken(params){
  var { device_id, client_id, oauth } = params;
    var res = await fetch("https://gql.twitch.tv/integrity", {
      "headers": {
        "accept": "*/*",
        "accept-language": "en-US,en;q=0.9",
        "client-id": client_id,
        "priority": "u=1, i",
        "sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\", \"Microsoft Edge\";v=\"132\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"macOS\"",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "x-device-id": device_id,
      },
      "referrer": "https://www.twitch.tv/",
      "referrerPolicy": "strict-origin-when-cross-origin",
      "body": null,
      "method": "POST",
      "mode": "cors",
      "credentials": "omit"
    });
    var d = await res.json();
    return d;
}




async function getTwitchChannelInfo(params){
  var {channel_login} = params;
  var d1 = await getGQL({
    ...params,
    ...{
      body: `{\"extensions\":{\"persistedQuery\":{\"version\":1,\"sha256Hash\":\"84e25789b04ac4dcaefd673cfb4259d39d03c6422838d09a4ed2aaf9b67054d8\"}},\"operationName\":\"HomeOfflineCarousel\",\"variables\":{\"channelLogin\":\"${channel_login}\",\"includeTrailerUpsell\":false,\"trailerUpsellVideoID\":\"\"}}`,
    },
  });
// console.log({d1})
  var info = {
      is_partner:d1?.data?.user?.roles?.isPartner,
      is_affiliate:d1?.data?.user?.roles?.isAffiliate,
      is_staff:d1?.data?.user?.roles?.isStaff,
      channel_id:d1?.data?.user?.id,
  }
  var d2 = await getGQL({
    ...params,
    ...{
      body: `{\"operationName\":\"ViewerCard\",\"variables\":{\"channelID\":\"${info?.channel_id}\",\"channelLogin\":\"${channel_login}\",\"hasChannelID\":true,\"giftRecipientLogin\":\"${channel_login}\",\"isViewerBadgeCollectionEnabled\":true,\"withStandardGifting\":true,\"badgeSourceChannelID\":\"${info?.channel_id}\",\"badgeSourceChannelLogin\":\"${channel_login}\"},\"extensions\":{\"persistedQuery\":{\"version\":1,\"sha256Hash\":\"80c53fe04c79a6414484104ea573c28d6a8436e031a235fc6908de63f51c74fd\"}}}`,
    },
  });
  // console.log({d2})
  var badge_ids = d2?.data?.channelViewer?.earnedBadges?.map(r=> (r?.setID));
  var info = {
    ...info, ...{
      badge_ids: badge_ids,
      is_prime: badge_ids?.some(id => id == 'premium'),
      is_turbo: badge_ids?.some(id => id == 'turbo'),
    }
  }
  var vod_keep_days = info?.is_staff === true ? 90 : info?.is_turbo === true || info?.is_prime === true || info?.is_partner === true ? 60 : info?.is_affiliate === true ? 14 : [info?.is_turbo,info?.is_prime,info?.is_partner,info?.is_affiliate].every(i=> i === false) ? 7 : 60;
  var info = {...{vod_keep_days:vod_keep_days},...info};
  // console.log('getTwitchChannelInfo',info);
  return info;
}

async function searchTwitch(params) {
  var { query } = params;
  var d = await getGQL({
    ...params,
    ...{
      body: `[{\"operationName\":\"SearchTray_SearchSuggestions\",\"variables\":{\"requestID\":\"\",\"queryFragment\":\"${query}\",\"withOfflineChannelContent\":true,\"includeIsDJ\":true},\"extensions\":{\"persistedQuery\":{\"version\":1,\"sha256Hash\":\"2749d8bc89a2ddd37518e23742a4287becd3064c40465d8b57317cabd0efe096\"}}}]`,
    },
  });
  // console.log("searchTwitch", d);
  return d?.[0]?.data?.searchSuggestions?.edges
    ?.map((r) => {
      return cleanObject({
        channel_login: r.node?.content?.login,
        channel_id: r.node?.content?.id,
        is_live: r.node?.content?.isLive,
        is_verified: r.node?.content?.isVerified,
        profile_image_url: r.node?.content?.profileImageURL,
        is_dj: r.node?.content?.user?.roles?.isParticipatingDJ,
        stream_id: r.node?.content?.stream?.id,
      });
    })
    ?.filter((r) => r.channel_login);
}

async function getVodPlaybackToken(params) {
  var { vod_id } = params;
  // (기존엔 getGQL()를 썼는데, 이건 저장된 client_id/oauth(tvd_twitch_tokens)가
  // 있어야 하지만 그걸 채워주는 코드가 어디에도 없어서 client-id가 항상 비어
  // 있었고, 게다가 background.js(서비스 워커, chrome-extension:// Origin)에서
  // credentials:'include'로 쏘면 VOD 채팅 쿼리 때와 동일하게 CORS 자체에서
  // 막힘. 실제 브라우저에서 확인한 결과 이 재생 토큰 발급도 채팅 조회와
  // 마찬가지로 쿠키/로그인 없이 공개 client-id 헤더 하나만으로 정상 동작함.)
  try {
    var res = await fetch('https://gql.twitch.tv/gql', {
      method: 'POST',
      headers: { 'client-id': 'kimne78kx3ncx6brgo4mv6wki5h1ko', 'content-type': 'text/plain;charset=UTF-8' },
      body: JSON.stringify({
        operationName: 'PlaybackAccessToken_Template',
        query: 'query PlaybackAccessToken_Template($login: String!, $isLive: Boolean!, $vodID: ID!, $isVod: Boolean!, $playerType: String!, $platform: String!) {  streamPlaybackAccessToken(channelName: $login, params: {platform: $platform, playerBackend: "mediaplayer", playerType: $playerType}) @include(if: $isLive) {    value    signature   authorization { isForbidden forbiddenReasonCode }   __typename  }  videoPlaybackAccessToken(id: $vodID, params: {platform: $platform, playerBackend: "mediaplayer", playerType: $playerType}) @include(if: $isVod) {    value    signature   __typename  }}',
        variables: { isLive: false, login: '', isVod: true, vodID: String(vod_id), playerType: 'site', platform: 'web' },
      }),
    });
    if (!res.ok) return null;
    var d = await res.json();
    var value = d?.data?.videoPlaybackAccessToken?.value;
    var signature = d?.data?.videoPlaybackAccessToken?.signature;
    if (!value || !signature) return null;
    return { value, signature };
  } catch (e) {
    return null;
  }
}

async function getOfficialVodM3u8Source(params) {
  /* 공식 usher.ttvnw.net 엔드포인트 — animatedPreviewURL 파싱과 달리
     썸네일 생성 여부와 무관하게 모든 공개 VOD에서 항상 동작함 */
  try {
    var tok = await getVodPlaybackToken(params);
    if (!tok) return '';
    return `https://usher.ttvnw.net/vod/${params.vod_id}.m3u8?allow_source=true&allow_audio_only=true&supported_codecs=avc1&player=twitchweb&token=${encodeURIComponent(tok.value)}&sig=${tok.signature}`;
  } catch (e) {
    return '';
  }
}

async function getAvailableVODinfo(params) {
  /* retrieves the most recent available vods (up to 75)*/
  var { device_id, client_id, oauth, vod_id, channel_login } = params;

  // var stored_tokens = await getLocalStorage({'key':'tvd_twitch_tokens'});
  var d = await getGQL({
    ...params,
    ...{
      body: `[{\"operationName\":\"FilterableVideoTower_Videos\",\"variables\":{\"limit\":75,\"channelOwnerLogin\":\"${channel_login}\",\"broadcastType\":\"ARCHIVE\",\"videoSort\":\"TIME\"},\"extensions\":{\"persistedQuery\":{\"version\":1,\"sha256Hash\":\"67004f7881e65c297936f32c75246470629557a393788fb5a69d6d9a25a8fd5f\"}}}]`,
    },
  });
  if (!d?.[0]?.data?.user?.videos?.edges?.length && d?.[0]?.errors?.some(r => r.message === 'service error')){
    //retry
    await delay(2000);
    var d = await getGQL({
      ...params,
      ...{
        body: `[{\"operationName\":\"FilterableVideoTower_Videos\",\"variables\":{\"limit\":30,\"channelOwnerLogin\":\"${channel_login}\",\"broadcastType\":\"ARCHIVE\",\"videoSort\":\"TIME\"},\"extensions\":{\"persistedQuery\":{\"version\":1,\"sha256Hash\":\"67004f7881e65c297936f32c75246470629557a393788fb5a69d6d9a25a8fd5f\"}}}]`,
      },
    });
  }

  // oldsha:a937f1d22e269e39a03b509f65a7490f9fc247d7f83d6ac1421523e3b68042cb
  let vods = await Promise.all((d?.[0]?.data?.user?.videos?.edges || []).map(async (r) => {
    let m3u8_path = /\w+\.cloudfront.net\/\w{20}_\w+_\d+_\d+(?=\/)/.exec(
      r?.node?.animatedPreviewURL,
    )?.[0];
    let m3u8_tokens = /(\w{20})_([_\w])+_(\d+)_(\d+)/.exec(
      /(?<=\/)\w{20}_\w+_\d+_\d+(?=\/)/.exec(
        r?.node?.previewThumbnailURL,
      )?.[0] ||
      /(?<=\/)\w{20}_[_\w]+_\d+_\d+(?=\/)/.exec(r?.node?.animatedPreviewURL)?.[0]
    ) || []; // 프리뷰 썸네일이 아직 생성 안 된 VOD는 매칭 실패 → 빈 배열로 방어
    // console.log({m3u8_tokens});
    let m3u8_server = /\w+(?=\.cloudfront.net\/\w{20}_[_\w]+_\d+_\d+\/)/.exec(
      r?.node?.animatedPreviewURL,
    )?.[0];
    let guessedSource = m3u8_path ? `https://${m3u8_path}/chunked/index-dvr.m3u8` : "";
    let finalSource = guessedSource;
    if (!finalSource && r.node?.id) {
      // 썸네일 URL 추측이 실패한 VOD(프리뷰 생성 전/특정 VOD 타입 등) — 공식 토큰 API로 대체
      finalSource = await getOfficialVodM3u8Source({ vod_id: r.node.id, device_id: params?.device_id, client_id: params?.client_id, oauth: params?.oauth });
    }
    return cleanObject({
      channel_id:d?.[0]?.data?.user?.id,
      vod_id: r.node?.id,
      timestamp: r.node?.publishedAt
        ? new Date(r.node?.publishedAt).getTime()
        : m3u8_tokens[4]
          ? m3u8_tokens[4] * 1000
          : null,
      published_at: r.node?.publishedAt,
      title: r.node?.title,
      duration: r.node?.lengthSeconds ? r.node?.lengthSeconds * 1000 : 0,
      animated_preview_url: r?.node?.animatedPreviewURL,
      view_count: r?.node?.viewCount,
      preview_url: r?.node?.previewThumbnailURL,
      m3u8_path: m3u8_path,
      m3u8_tokens: m3u8_tokens,
      stream_id: m3u8_tokens[3],
      hash: m3u8_tokens[1],
      source: finalSource,
      src: finalSource,
      stream_start_seconds: m3u8_tokens[4] ? parseInt(m3u8_tokens[4]) : 0,
      timestamp_seconds: m3u8_tokens[4] ? parseInt(m3u8_tokens[4]) : 0,
      m3u8_server: m3u8_server,
      midpath: `${m3u8_tokens[1]}_${channel_login}_${m3u8_tokens[3]}_${m3u8_tokens[4]}`,
      channel_login: channel_login,
    });
  }));
  // console.log({ vods: vods });
  return vods;
}

async function fetchStreamGuesses(params) {
  var {
    extendby,
    stream_id,
    timestamp,
    timestamp_seconds,
    channel_login,
    end_path,
    server_ids,
  } = params;
  // console.log({ 'fetchStreamGuesses': params });
  var secs_time =
    params?.timestamp_seconds && params?.timestamp_seconds > 160000000
      ? params?.timestamp_seconds
      : Math.floor(params?.timestamp / 1000);
  let biglist = extendby
    ? Array(Math.abs(extendby))
        .fill()
        .map((_, i) => (extendby > 0 ? i : i + extendby))
        .map((i) => {
          var seconds = secs_time + i;
          let hash = SHA1(`${channel_login}_${stream_id}_${seconds}`).slice(
            0,
            20,
          );
          return server_ids.map(
            (id) =>
              `https://${id}.cloudfront.net/${hash}_${channel_login}_${stream_id}_${seconds}/chunked/${end_path ? end_path : "index-dvr"}.m3u8`,
          );
        })
    : server_ids.map(
        (id) =>
          `https://${id}.cloudfront.net/${SHA1(`${channel_login}_${stream_id}_${secs_time}`).slice(0, 20)}_${channel_login}_${stream_id}_${secs_time}/chunked/${end_path ? end_path : "index-dvr"}.m3u8`,
      );
  let bulk_url_list = biglist.flat().flat();
  // console.log({bulk_url_list})
  let chunked = subArr(bulk_url_list, 20);
  //changed from sub(40) - Nov 2024
  let built_by_url = /.+cloudfront.net\/.{20}_[a-zA-Z\d_]+?_\d+_\d+/.exec(
    params?.animated_preview_url,
  )?.[0]
    ? `${/.+cloudfront.net\/.{20}_[a-zA-Z\d_]+?_\d+_\d+/.exec(params?.animated_preview_url)?.[0]}/chunked/${end_path ? end_path : "index-dvr"}.m3u8`
    : null;
  // console.log(built_by_url ? [[built_by_url]] : chunked);
  return await chunkedFetch(built_by_url ? [[built_by_url]] : chunked);
}

async function chunkedFetch(chunked) {
  // console.log({ chunked });
  var data = {};
  for (let i = 0; i < chunked.length; i++) {
    let check_listed = await fetchTexts(chunked[i]);
    let filtered = check_listed?.filter((r) =>
      /[\d\.]+,\n\d+(-\w+|\b)\.ts/.test(r.text),
    );
    if (filtered?.[0]) {
      data = {
        ...parseTsfileInformation(filtered?.[0]?.text),
        ...{ url: filtered?.[0]?.url },
        ...{ source: filtered?.[0]?.url },
      };
      if (data?.url) {
        break;
      }
    }
  }
  return data;
}

async function checkStreamDetailsByServerPriority(params) {
  if(params?.service == "twitch" || params?.is_live === true){
    // console.log('tvd data');
    var check1 = await fetchStreamGuesses({ ...params, ...{ extendby: 0 } });
    if (check1?.url) return check1;
    var check2 = await fetchStreamGuesses({ ...params, ...{ extendby: 1 } });
    if (check2?.url) return check2;
    var check3 = await fetchStreamGuesses({ ...params, ...{ extendby: -1 } });
    if (check3?.url) return check3;
    else return null;
  }else{
    var check1 = await fetchStreamGuesses({ ...params, ...{ extendby: 0 } });
    if (check1?.url) return check1;
    var check2 = await fetchStreamGuesses({ ...params, ...{ extendby: 61 } });
    if (check2?.url) return check2;
    var check3 = await fetchStreamGuesses({ ...params, ...{ extendby: -61 } });
    if (check3?.url) return check3;
    else return null;
  }
}
const KWS_CDN_SERVERS = [
    "d1g1f25tn8m2e6",
    "d1m7jfoe9zdc1j",
    "d1mhjrowxxagfy",
    "d1ndex63qxojbr",
    "d1oca24q5dwo6d",
    "d1w2poirtb3as9",
    "d1xhnb4ptk05mw",
    "d1ymi26ma8va5x",
    "d2aba1wr3818hz",
    "d2dylwb3shzel1",
    "d2e2de1etea730",
    "d2nvs31859zcd8",
    "d2um2qdswy1tb0",
    "d2vjef5jvl6bfs",
    "d2xmjdvx03ij56",
    "d36nr0u3xmc4mm",
    "d3aqoihi2n8ty8",
    "d3c27h4odz752x",
    "d3vd9lfkzbru3h",
    "d6d4ismr40iw",
    "d6tizftlrpuof",
    "ddacn6pr5v0tl",
    "dgeft87wbj63p",
    "dqrpb9wgowsf5",
    "ds0h3roq6wcgc",
    "dykkng5hnh52u",
    "d3fi1amfgojobc",
    "d2v02itv0y9u9t",
    "d1mjs7qzzz669v"
];

// Diagnostics only: why did the CloudFront lookup find nothing? (geo-block vs. no such VOD)
async function kwsCdnProbe(params) {
  try {
    const { channel_login, stream_id } = params || {};
    const secs = params?.timestamp_seconds && params.timestamp_seconds > 160000000
      ? params.timestamp_seconds : Math.floor((params?.timestamp || 0) / 1000);
    const hash = SHA1(`${channel_login}_${stream_id}_${secs}`).slice(0, 20);
    const tally = {};
    let geo = false, okHost = '';
    await Promise.all(KWS_CDN_SERVERS.map(async (id) => {
      try {
        const r = await fetch(`https://${id}.cloudfront.net/${hash}_${channel_login}_${stream_id}_${secs}/chunked/index-dvr.m3u8`, { cache: 'no-store' });
        tally[r.status] = (tally[r.status] || 0) + 1;
        if (r.status === 200) okHost = id;
        if (r.status === 403 && !geo) {
          const t = await r.text();
          if (/block access from your country|geographic|geo/i.test(t)) geo = true;
        }
      } catch (e) { tally['err'] = (tally['err'] || 0) + 1; }
    }));
    return `hosts=${KWS_CDN_SERVERS.length} · ${Object.entries(tally).map(([k, v]) => `${k}×${v}`).join(' ')}${geo ? ' · GEO-BLOCK message' : ''}${okHost ? ' · 200@' + okHost : ''} · id=${stream_id} ts=${secs}`;
  } catch (e) {
    return 'probe failed: ' + (e?.message || e);
  }
}

async function getStreamDetailsFromStreamId(params) {
  // console.log('getStreamDetailsFromStreamId', params);
  var servers = KWS_CDN_SERVERS;

  var server_ids = params?.priority_m3u8_servers?.length ? servers?.filter((ss) => !params?.priority_m3u8_servers?.some((id) => id === ss),) : servers;
  // console.log({ server_ids });
  if (params?.priority_m3u8_servers?.length) {
    let check1 = await checkStreamDetailsByServerPriority({
      ...params,
      ...{ server_ids: params?.priority_m3u8_servers },
    });
    // console.log({ check1 });
    if (check1?.url) {
      return check1;
    }
    if(!check1?.url) {
      let check2 = await checkStreamDetailsByServerPriority({
        ...params,
        ...{ server_ids: server_ids.filter(id=> !params?.priority_m3u8_servers.some(iid=> iid == id)) },
      });
      // console.log({ check2 });
      if (check2?.url) {
        return check2;
      }
    }else{
      return null;
    }
  }
  if (!params?.priority_m3u8_servers?.length) {
    let check1 = await checkStreamDetailsByServerPriority({
      ...params,
      ...{ server_ids: server_ids },
    });
    if (check1?.url) {
      return check1;
    }else{
        return null;
    }
  }else{
    return null;
  }
}


async function getValidResolutions(params) {
  var { url, source } = params;
  if((url || source)){
    var res_opts = [
      "2160","1440","1200","1080","1050","1024","960","936","900","864","810","720","648","616","540","480","432","392","360","160",
    ].map((r) => {
        let fps = ["24", "30", "48", "50", "60"].reverse();
        return fps.map((f) => `${r}p${f}`);
      }).flat();
    var options = [...["chunked"], ...res_opts, ...["audio_only"]].map((opt) => {
      return (url || source)?.replace(/\/\w+\/(?=[\w\d-]+.m3u8)/, `/${opt}/`);
    });
    let responses = await fetchTexts(options);
    // console.log({ responses });
    let mapped = responses?.map((opt) => {
        return {
          ...params,
          ...{
            is_valid: /[\d\.]+,\n\d+(-\w+|\b)\.ts/.test(opt.text) || /\d+.mp4/i.test(opt.text),
            name: /\w+(?=\/[\w\d-]+\.m3u8)/.exec(opt.url)?.[0],
            source: opt.url,
          },
        };
      })?.filter((opt) => opt.is_valid);
    //.filter(opt=> opt.is_valid).map(opt=> {return {[opt.key]:opt.url}});
    // console.log({ mapped });
    return mapped;
  }else{
    return null;
  }
  // ?.length ? mapped.reduce((a,b)=> {return {...a,...b}}) : null;
}


async function getTwitchStreamInformation(params) {
  var { device_id, client_id, oauth, vod_id, channel_login, login } = params;
  var d = await getGQL({
    ...params,
    ...{
      body: `[{\"operationName\":\"UseLive\",\"variables\":{\"channelLogin\":\"${channel_login ? channel_login : ""}\"},\"extensions\":{\"persistedQuery\":{\"version\":1,\"sha256Hash\":\"639d5f11bfb8bf3053b424d9ef650d04c4ebb7d94711d644afb08fe9a0fad5d9\"}}}]`,
    },
  });
  // console.log(d);
  // console.log(['getStreamInformation',d]);Ω
  let timestamp_seconds = d[0]?.data?.user?.stream?.createdAt
    ? Math.floor(
      new Date(d[0]?.data?.user?.stream?.createdAt).getTime() / 1000,
    )
    : null;
  let outob = {
    is_live: d[0]?.data?.user?.stream?.id ? true : false,
    stream_id: d[0]?.data?.user?.stream?.id,
    timestamp: new Date(d[0]?.data?.user?.stream?.createdAt).getTime(),
    start_timestamp_seconds: timestamp_seconds,
    timestamp_seconds:timestamp_seconds,
  };
  return {
    ...params,
    ...outob,
    ...{
      hash: SHA1(
        `${channel_login ? channel_login : login}_${outob.stream_id}_${outob.start_timestamp_seconds}`,
      ).slice(0, 20),
    },
  };
}

var floatString = (s) => parseFloat(/[\d,\.]+/.exec(s)?.[0]?.replace(/,/g, ""));
/*input float, number of desired decimal places, Math function for rounding, 'round','floor','ceil'. 'floor' is default if null parameter */
var nthFloat = (n, m, t) =>
  Math[t ? t : "floor"](
    n *
      parseInt(
        `1${Array(m)
          .fill()
          .map((i) => "0")
          .reduce((a, b) => a + b)}`,
      ),
  ) /
  parseInt(
    `1${Array(m)
      .fill()
      .map((i) => "0")
      .reduce((a, b) => a + b)}`,
  );
var getDecimal = (n, m, t) => nthFloat(n % 1, m || 3, t || "round");
var floatIfFloat = (s) =>
  s &&
  !/^0[1-9]/.test(s) &&
  /^[\d,\.]+$/.test(s) &&
  (!s.match(/\./g) || s.match(/\./g)?.length < 2)
    ? floatString(s)
    : s;


function parseLivestreamManifest(params) {
  var { text, timestamp } = params;
  var playlist_creation_timestamp = floatIfFloat(
    /(?<=#EXT-X-DATERANGE:ID="playlist-creation-)\d+/.exec(text)?.[0],
  );
  var playlist_session_timestamp = floatIfFloat(
    /(?<=#EXT-X-DATERANGE:ID="playlist-session-)\d+/.exec(text)?.[0],
  );
  var media_sequence = floatIfFloat(
    /(?<=#EXT-X-MEDIA-SEQUENCE:)[\d\.]+/.exec(text)?.[0],
  );

  let fragments = Array.from(
    text?.match(
      /#EXT-X-PROGRAM-DATE-TIME:(\d{4}-\d+-\d+\w[\d:\.]+\w)\n#EXTINF:([\d\.]+),live\n(https:.+?\.ts)/gm,
    ) || [],
  ).map((r) => {
    let info =
      /#EXT-X-PROGRAM-DATE-TIME:(\d{4}-\d+-\d+\w[\d:\.]+\w)\n#EXTINF:([\d\.]+),live\n(https:.+?\.ts)/.exec(
        r,
      );
    let dur = floatIfFloat(info?.[2]);
    let frag_time = info?.[1] ? new Date(info?.[1]).getTime() : null;
    /* current fragment timestamp - start of stream timestamp / 1000 to get seconds since start*/
    /*TODO Need to add an expiration timestamp so we know when a livestream url is no longer valid. This can then be used to toss and revert to the VOD segment */
    return {
      dur: dur,
      timestamp: frag_time,
      ts: info?.[3],
      seg_text: info?.[0],
      seconds_mark: Math.floor((frag_time - timestamp) / 1000),
    };
  });
  var next_sn = media_sequence - fragments?.[0]?.dur;
  let remaped_fragments = fragments.map((r, i) => {
    next_sn = next_sn + r.dur;
    return {
      ...r,
      ...{ sn: next_sn },
    };
  });
  return {
    elapsed_secs: floatIfFloat(
      /(?<=#EXT-X-TWITCH-ELAPSED-SECS:)[\d\.]+/.exec(text)?.[0],
    ),
    total_secs: floatIfFloat(
      /(?<=#EXT-X-TWITCH-TOTAL-SECS:)[\d\.]+/.exec(text)?.[0],
    ),
    target_duration: floatIfFloat(
      /(?<=#EXT-X-TWITCH-TARGETDURATION:)[\d\.]+/.exec(text)?.[0],
    ),
    media_sequence: media_sequence,
    live_sequence: floatIfFloat(
      /(?<=#EXT-X-TWITCH-LIVE-SEQUENCE:)[\d\.]+/.exec(text)?.[0],
    ),
    playlist_creation_timestamp: playlist_creation_timestamp
      ? playlist_creation_timestamp * 1000
      : playlist_creation_timestamp,
    playlist_session_timestamp: playlist_session_timestamp
      ? playlist_session_timestamp * 1000
      : playlist_session_timestamp,
    session_id: /(?<=X-TV-TWITCH-SESSIONID=")\d+/.exec(text)?.[0],
    fragments: remaped_fragments,
  };
}
function parseTsfileInformation(text) {
  let fragments = text?.match(/[\d\.]+,\n\d+(-\w+|\b)\.(mp4|ts)/g)?.[0]
    ? Array.from(text.match(/[\d\.]+,\n\d+(-\w+|\b)\.(mp4|ts)/g)).map((r) => {
        return {
          i: /(\d+)[\.-\w]+ts/.exec(r)?.[1],
          path: /\d+[\.-\w]+(mp4|ts)/.exec(r)?.[0],
          dur: /[\d\.]+/.exec(r)?.[0] ? parseFloat(/[\d\.]+/.exec(r)?.[0]) : 0,
        };
      })
    : [];
  let is_mp4 = /\.mp4/.test(text);
  return {
    total_seconds: /(?<=TOTAL-SECS:)[\d\.]+/.test(text)
      ? parseFloat(/(?<=TOTAL-SECS:)[\d\.]+/.exec(text)?.[0])
      : 0,
    fragments: fragments,
    // fMP4(.mp4) 형식은 이 init 세그먼트(ftyp+moov 박스)가 파일 맨 앞에 없으면
    // 재생 불가능한 손상된 파일이 됨 — 예전엔 이 URI를 텍스트로만 캡처해두고 실제로
    // fetch/write는 전혀 안 하고 있었음 (다운로드 파일이 깨지는 원인)
    init_path: is_mp4 ? /URI="([^"]+)"/.exec(text)?.[1] : null,
    head_text:  is_mp4 ? /^[\s\S\n]+?URI="init-0.mp4"/.exec(text)?.[0] : /^[\s\S\n]+?TOTAL-SECS:/.exec(text)?.[0],
    foot_text: is_mp4 ? '' : /#EXT-X-ENDLIST[\s\S\n]+/.exec(text)?.[0],
    is_mp4:is_mp4,
  };
}


async function fetchWithTimeout(params) {
  var { url, options, timeout, type } = params;
  var controller = new AbortController();
  var timeout_id = setTimeout(() => controller.abort(), timeout);
  var res = await tryFetch(url, { ...(options || {}), signal: controller.signal });
  clearTimeout(timeout_id);
  if(res && type){
    return await res[type]();
  }
}

async function tryFetch(url, options) {
  try {
    return await fetch(url, options || {});
  } catch (err) {
    return null;
  }
}

async function fetchTexts(arr, options) {
  let res = await Promise.all(arr.map((e) => tryFetch(e, options || {})));
  return await Promise.all(
    res.map(async (e) => {
      let text = e != null ? await e.text() : null;
      return {
        text: text,
        url: e != null ? e.url : null,
      };
    }),
  );
}

async function fetchText(url, options) {
  try {
    var res = await fetch(url, options || {});
    var text = await res.text();
    return text;
  } catch (err) {
    return null;
  }
}

async function fetchJSON(url, opt) {
  try {
    var res = await fetch(url, opt || {});
    var d = await res.json();
    return d;
  } catch (err) {
    return null;
  }
}

function getResolutions(text) {
  var resolutionSplit = (s) => s.split(/x/)?.map((n) => parseFloat(n));
  var floater = (s) => (/^\d+$|^\d+\.\d+$/.test(s) ? parseFloat(s) : s);
  let matches = text.match(/#EXT-X-MEDIA:.+?\n#EXT-X-[A-Z-]+:.+?\n.+?m3u8/g);
  let resolutions = matches?.length
    ? Array.from(matches).map((m) => {
        let rows = m.split(/\n/);
        let keyed_vals = rows
          .filter((r) => /^.+?:/.test(r))
          .map((row) =>
            row
              ?.replace(/^.+?:/, "")
              ?.split(/[,](?=(?:[^\"]|\"[^\"]*\")*$)/)
              .map((v) => v.split(/=/))
              .map((kv) => ({
                [snakeKeyify(kv[0])]: floater(valCleaner(kv[1])),
              }))
              .reduce((a, b) => {
                return { ...a, ...b };
              }),
          )
          .reduce((a, b) => {
            return { ...a, ...b };
          });
        let split_res = resolutionSplit(keyed_vals?.resolution);

        return {
          ...keyed_vals,
          ...(split_res?.length
            ? {
                resolution_width: split_res?.[0],
                resolution_height: split_res?.[1],
              }
            : {}),
          ...{ path: rows.at(-1) },
        };
      })
    : [];
  return resolutions;
}
async function validateKickEndpoint(url){
    var text = await fetchText(url);
    if(/<Code>AccessDenied<\/Code>/.test(text)){
        var alt_url = url?.replace(/3c81249a5ce0\//,'');
        var alt_text = await fetchText(alt_url);
        if(/playlist.m3u8/.test(alt_text)){
            return alt_url;
        }
    }else{
        return url;
    }
}
async function getKickVideoStreamData(params) {
  let vod_m3u8 = await fetchText(params?.source);
  let resolutions = getResolutions(vod_m3u8);
  let mapped_resolutions = resolutions.map((r) => ({
    ...params,
    ...r,
    ...{
      src: params?.source?.replace(/[a-z-]+\.m3u8/i, r.path),
      source:params?.source?.replace(/[a-z-]+\.m3u8/i, r.path),
    },
  }));
  // ?.map(r=> ({[r.name]:r.src}));
  // console.log(resolutions);
  return mapped_resolutions;
  // ?.length ? mapped_resolutions.reduce((a,b)=>({...a,...b})) : null;
}


// let kick_endpoint = await validateKickEndpoint(kick_m3u8);
async function getKickVODs(params) {
  var { channel_slug, slug, channel_login } = params;
  var d = await fetchJSON(
    `https://kick.com/api/v2/channels/${channel_login || channel_slug || slug}/videos`,
    {},
  );
  return d?.map(r => {
    let kick_thumbnail_ids = /(?<=images.kick.com\/video_thumbnails\/)\w+?\/\w+(?=\/\d)/.exec(r?.thumbnail?.src)?.[0]?.split(/\//);
    let year_month_day_hour_min = r?.start_time?.replace(/-/g, '/')?.replace(/\s+/g, '/')?.replace(/:\d+$/, '')?.replace(/:/g, '/')?.replace(/(?<=\/)0/g,'');
    let kick_m3u8 = year_month_day_hour_min && kick_thumbnail_ids ? `https://stream.kick.com/3c81249a5ce0/ivs/v1/196233775518/${kick_thumbnail_ids?.[0]}/${year_month_day_hour_min}/${kick_thumbnail_ids?.[1]}/media/hls/master.m3u8` : '';

    return {
      ...r,
      ...(kick_m3u8 ? { source: r?.source || kick_m3u8 } : {})
    }
  });
}

async function getKickChannelV1(params) {
  var { slug, channel_slug, channel_login } = params;
  var d = await fetchJSON(
    `https://kick.com/api/v1/channels/${channel_login || slug || channel_slug}`,
    {},
  );
  return d;
}
async function getTwitchLivestreamManifest(params) {
  var text = await fetchText(params?.src || params?.source);
  // console.log("getTwitchLivestreamManifest", text);
  var data = parseLivestreamManifest({
    text: text,
    timestamp: params?.timestamp,
  });
  // console.log({ data, text });
  return { data, text };
}
async function getTwitchOrKickManifest(params) {
  var text = await fetchText(params?.src || params?.source);
  // console.log("getTwitchOrKickManifest", text);
  var data = parseTsfileInformation(text);
  return { data, text };
}
// getLivestreamM3u8({
//     client_id:"kimne78kx3ncx6brgo4mv6wki5h1ko",
//     device_id:"VLyc7v7TsQPTa6qvq1Ryh38SA1J7CmQz",
//     channel_login:'shroud',
// })
//

async function genericGQL(params) {
  var d = await getGQL({
    ...params,
    ...{
      body: `{\"operationName\":\"${atob(
        params?.operation_name
          ?.split("")
          ?.map((t) => (/[A-Z]/.test(t) ? t.toLowerCase() : t.toUpperCase()))
          .reduce((a, b) => a + b),
      )}\",\"variables\":{},\"extensions\":{\"persistedQuery\":{\"version\":1,\"sha256Hash\":\"${params?.op_hash}\"}}}`,
    },
  });
  return snakeCaseObject(parsival(d));
}

function parsival(d) {
  let kvs =
    d?.data && Object.values(d?.data)?.[0]
      ? Object.entries(Object.values(d?.data)?.[0])
      : {};
  let vs = kvs?.length
    ? kvs
        .filter((kv) => !/^_/.test(kv[0]) && typeof kv[1] == "string")
        .map((kv) => ({ [kv[0]]: kv[1] }))
    : null;
  let ss = kvs?.length
    ? kvs.filter(
        (kv) =>
          kv[1] !== null &&
          typeof kv[1] == "object" &&
          Object.values(kv[1])?.some((v) => typeof v == "object"),
      )?.[0]?.[1]
    : null;
  let twof = ss
    ? (
        Object.entries(
          Object.entries(ss)?.filter(
            (kv) => kv[1] !== null && typeof kv[1] == "object",
          )?.[0]?.[1] || {},
        )?.filter((kv) => !/^_/.test(kv[0])) || ["", ""]
      ).map((kv) => ({ [kv[0]]: kv[1] }))
    : null;
  return {
    ...(vs?.length ? vs.reduce((a, b) => ({ ...a, ...b })) : {}),
    ...(twof?.length ? twof.reduce((a, b) => ({ ...a, ...b })) : {}),
  };
}


function parseTwitchPlaylistOptions(params) {
  var { text, playlist_url } = params;
  let options = text.match(/,NAME="(.+?)".+\n.+\n.+/g);
  return options
    ? Array.from(options).map((r) => {
        let name = /,NAME="(.+?)"/.exec(r)?.[1];
        return {
          src: /https:\/\/video-weaver.+?m3u8/.exec(r)?.[0],
          source: /https:\/\/video-weaver.+?m3u8/.exec(r)?.[0],
          name: /source/.test(name)
            ? "chunked"
            : name?.replace(/_.+/, "")?.replace(/\s.+/, ""),
          resolution: name?.replace(/\s.+/, ""),
          playlist_url: playlist_url,
        };
      })
    : [];
  //.reduce((a,b)=> {return {...a,...b}}) : {};
}
async function getTwitchVidResOptions(url) {
  var res = await fetch(url);
  var text = await res.text();
  // console.log("getVidResOptions", text);
  return parseTwitchPlaylistOptions({ text: text, playlist_url: url });
}
async function getTwitchLivestreamUrl(params) {
  // console.log(params);
  var {
    device_id,
    client_id,
    authorization,
    channel_login,
    user_id,
    channel_login,
  } = params;
  var d = await getGQL({
    ...params,
    ...{
      body: `{\"query\":\"query(\\n\\t\\t\\t\\t\\t\\t$login: String!\\n\\t\\t\\t\\t\\t\\t$disableHTTPS: Boolean!\\n\\t\\t\\t\\t\\t) {\\n\\t\\t\\t\\t\\t\\tstreamPlaybackAccessToken(\\n\\t\\t\\t\\t\\t\\t\\tchannelName: $login\\n\\t\\t\\t\\t\\t\\t\\tparams: {\\n\\t\\t\\t\\t\\t\\t\\t\\tdisableHTTPS: $disableHTTPS\\n\\t\\t\\t\\t\\t\\t\\t\\thasAdblock: true\\n\\t\\t\\t\\t\\t\\t\\t\\tplatform: \\\"web\\\"\\n\\t\\t\\t\\t\\t\\t\\t\\tplayerBackend: \\\"mediaplayer\\\"\\n\\t\\t\\t\\t\\t\\t\\t\\tplayerType: \\\"site\\\"\\n\\t\\t\\t\\t\\t\\t\\t}\\n\\t\\t\\t\\t\\t\\t) {\\n\\t\\t\\t\\t\\t\\t\\tvalue\\n\\t\\t\\t\\t\\t\\t\\tsignature\\n\\t\\t\\t\\t\\t\\t}\\n\\t\\t\\t\\t\\t}\",\"variables\":{\"login\":\"${channel_login}\",\"disableHTTPS\":false}}`,
    },
  });

  // console.log("getTwitchLivestreamUrl", d);
  var data = user_id
    ? d?.data?.streamPlaybackAccessToken?.value?.replace(
        /user_id":null/,
        'user_id":' + user_id + "",
      )
    : d?.data?.streamPlaybackAccessToken?.value;
  var jdata = JSON.stringify({
    ...JSON.parse(data),
    ...{
      show_ads: false,
      hide_ads: true,
      server_ads: false,
      user_id: user_id,
    },
  });
  // console.log(JSON.parse(jdata));
  // console.log(JSON.parse(data.replace(/user_id":/, i=> i+user_id+'"')));
  var sig = d?.data?.streamPlaybackAccessToken?.signature;
  var url = `https://usher.ttvnw.net/api/channel/hls/${channel_login}.m3u8?allow_source=true&allow_audio_only=true&supported_codecs=avc1&token=${encodeURIComponent(data)}&sig=${sig}`;
  var resolutions = await getTwitchVidResOptions(url);
  // console.log(resolutions);
  // let is_ad = await checkIfAd(params,jdat['audio_only']);
  // console.log(['is_ad',is_ad]);
  return resolutions;
}
async function getLivestreamPlaybackToken(params) {
  var d = await getGQL({
    ...params,
    ...{
      body: `{\"operationName\":\"PlaybackAccessToken_Template\",\"query\":\"query PlaybackAccessToken_Template($login: String!, $isLive: Boolean!, $vodID: ID!, $isVod: Boolean!, $playerType: String!, $platform: String!) {  streamPlaybackAccessToken(channelName: $login, params: {platform: $platform, playerBackend: \\\"mediaplayer\\\", playerType: $playerType}) @include(if: $isLive) {    value    signature   authorization { isForbidden forbiddenReasonCode }   __typename  }  videoPlaybackAccessToken(id: $vodID, params: {platform: $platform, playerBackend: \\\"mediaplayer\\\", playerType: $playerType}) @include(if: $isVod) {    value    signature   __typename  }}\",\"variables\":{\"isLive\":true,\"login\":\"${params?.channel_login}\",\"isVod\":false,\"vodID\":\"\",\"playerType\":\"site\",\"platform\":\"web\"}}`,
    },
  });
  var signature = d?.data?.streamPlaybackAccessToken?.signature;
  var token = encodeURIComponent(d?.data?.streamPlaybackAccessToken?.value);
  return { signature, token };
}













/*
          CLIPS
*/

async function getClipSig(params){
    // var {authorization,client_id,device_id,slug} = params;
    var d = await getGQL({
      ...params,
      ...{
        body: `{\"operationName\":\"VideoAccessToken_Clip\",\"variables\":{\"slug\":\"${params?.slug}\"},\"extensions\":{\"persistedQuery\":{\"version\":1,\"sha256Hash\":\"36b89d2507fce29e5ca551df756d27c1cfe079e2609642b4390aa4c35796eb11\"}}}`,
      },
    });
    var url = `${d?.data?.clip?.videoQualities?.[0]?.sourceURL}?sig=${d?.data?.clip?.playbackAccessToken?.signature}&token=${encodeURIComponent(d?.data?.clip?.playbackAccessToken?.value)}`;
    return url;
}



/*
          HIGHLIGHTS
*/


async function getHighlights(params){
    var {channel_login,cursor}=params;
    var next_cursor = cursor ? `,\"cursor\":\"${cursor}\"` : `,\"cursor\":null`;
    var d = await getGQL({
      ...params,
      ...{
        body: `{\"operationName\":\"FilterableVideoTower_Videos\",\"variables\":{\"includePreviewBlur\":false,\"limit\":100,\"channelOwnerLogin\":\"${channel_login}\",\"broadcastType\":\"HIGHLIGHT\",\"videoSort\":\"TIME\"${next_cursor}},\"extensions\":{\"persistedQuery\":{\"version\":1,\"sha256Hash\":\"acea7539a293dfd30f0b0b81a263134bb5d9a7175592e14ac3f7c77b192de416\"}}}`,
      },
    });
    return d;
}
function parseHighlights(d){
    var highlights = d?.data?.user?.videos?.edges?.map(r=> {
        var partial_url = /.+cloudfront.net\/\w+\/(?=storyboards)/.exec(r?.node?.animatedPreviewURL)?.[0];
        var highlight_id = r?.node?.id
        return {
            cursor:`${r?.node?.id}|${r?.node?.viewCount}|${r?.node?.publishedAt}|${r?.node?.lengthSeconds}`,
            source:`${partial_url}chunked/highlight-${highlight_id}.m3u8`,
            highlight_id:highlight_id,
            published_at:r?.node?.publishedAt,
            title:r?.node?.title,
            animated_preview_url:r?.node?.animatedPreviewURL,
            thumbnail:r?.node?.previewThumbnailURL,
            channel_login:r?.node?.owner?.login,
        }
    });
    var has_next = d?.data?.user?.videos?.pageInfo?.hasNextPage;
    return {highlights,has_next};
}
async function getAllHighlights(params){
    var integrity_token = await getIntegrityToken(params);
    var d = await getHighlights({...params,...integrity_token});
    var parsed = parseHighlights(d);
    // var cursor = parsed?.highlights?.at(-1)?.cursor;
    var highlights = parsed?.highlights?.length ? parsed?.highlights : [];
    if(parsed?.highlights?.length && parsed?.has_next){
        for(let i=0; i<10; i++){
          // console.log(highlights?.at(-1)?.cursor);
          await delay(rando(611)+511);
            let res = await getHighlights({...params,...{ token: 'twilight.14dc9770d7ce6547cd13f6793c57c2ab' },...{cursor:highlights?.at(-1)?.cursor}});
            let data = parseHighlights(res);
            let next_cursor = data?.highlights?.at(-1)?.cursor;
          if (!data?.highlights) { break; }
            if(data?.highlights?.length){
                if(data?.highlights.some(r=> !highlights.some(h=> h.source == r.source))){
                  data?.highlights?.forEach(r=> highlights.push(r));
                }else{
                  data?.highlights?.forEach(r=> highlights.push(r));
                  // console.log(i);
                  break;
                }
            }
        }
    }
    // console.log(unqKey(highlights,'source'));
    return unqKey(highlights,'source');
}




async function vodChatExtraction(params){
  var {cursor,offset_seconds,vod_id,highlight_id,id} = params;
  var d= await getGQL({
    ...params,
    ...{
      body: `[{\"operationName\":\"VideoCommentsByOffsetOrCursor\",\"variables\":{\"videoID\":\"${(vod_id || highlight_id || id)}\",${offset_seconds ? '\"contentOffsetSeconds\":' + (offset_seconds - 1) : '\"contentOffsetSeconds\":0'}},\"extensions\":{\"persistedQuery\":{\"version\":1,\"sha256Hash\":\"b70a3591ff0f4e0313d126c6a1502d79a1c02baebb288227c582044aa76adf6a\"}}},{\"operationName\":\"VideoCommentsByOffsetOrCursor\",\"variables\":{\"videoID\":\"${(vod_id || highlight_id || id)}\",${offset_seconds && cursor ? '\"cursor\":\"' + cursor + '\"' : '\"contentOffsetSeconds\":0'}},\"extensions\":{\"persistedQuery\":{\"version\":1,\"sha256Hash\":\"b70a3591ff0f4e0313d126c6a1502d79a1c02baebb288227c582044aa76adf6a\"}}}]`
    }
  });
  // console.log('chats',d)
  return d;
}










async function getTwitchTrackerStreams(params){
    var {channel_login}=params;
    var res = await fetch("https://twitchtracker.com/"+channel_login);
    var milsec_offset = ()=> (-(new Date().getTimezoneOffset())) * 60000;
    var text = await res.text();
    var chunks = Array.from(text.match(/<a class="entity entity-line"[\n\s\S]+?<\/a>/g)).map(t=> {
        let timestamp = /(?<=data-dt=").+?(?=")/.exec(t)?.[0] ? new Date(/(?<=data-dt=").+?(?=")/.exec(t)?.[0]).getTime()+(milsec_offset()) : null;
        let duration = /(?<=class="to-time-lg">)\d+/.exec(t)?.[0] ? parseInt(/(?<=class="to-time-lg">)\d+/.exec(t)?.[0]) * 60 : 0;
        return {
            channel_login:channel_login,
            stream_id:/(?<=\/streams\/)\d+/.exec(t)?.[0],
            timestamp:timestamp,
            timestamp_seconds: Math.floor(timestamp/1000),
            duration:duration,
        }
    });
  // console.log(chunks);
  return chunks;
}
// getTwitchTrackerStreams({channel_login:''})


async function getRobottyChats(params){
    var {after,before,channel_login,limit,timestamp}=params;
    var after = after ? `after=${after}` : '';
    var before = before ? `before=${before}` :'';
    var limit = limit ? `limit=${limit}` : '';
    let args = [after,before,limit];
    let q = args.some(r=> r) ? `&${args.filter(r=> r).reduce((a,b)=> a+'&'+b)}` : '';
    let res = await fetch(`https://recent-messages.robotty.de/api/v2/recent-messages/${channel_login}?hide_moderation_messages=true${q}`);
    let d = await res.json();
    return d;
}




// ===== KEYWORD SEARCHER + DIRECTORY CRAWLER =====

const KWS_CONCURRENCY = 3;
const kws_jobs = new Map();
// Per-tab active scan tracking
const kws_activeScans = new Map();

// ── Overload Detection & Global Scan Queue ─────────────────────────────────
// Tracks fetch timing to detect when the system is overwhelmed
const KWS_OVERLOAD = {
  // Rolling window of recent fetch durations (ms)
  recentFetchMs: [],
  maxHistory: 60,
  // Consecutive slow/failed fetch counters
  slowCount: 0,
  failCount: 0,
  // Whether the system is currently throttled (only BLOCKS NEW scans, never stops running ones)
  throttled: false,
  throttleUntil: 0,
  // Max simultaneous channel scans before queuing new ones
  MAX_CONCURRENT_CHANNELS: 4,
  // Thresholds — loosened so normal network variation doesn't trigger throttle
  SLOW_FETCH_MS: 15000,      // A single fetch taking > 15s is "slow"
  SLOW_TRIGGER_COUNT: 8,     // 8 consecutive slow fetches → throttle
  FAIL_TRIGGER_COUNT: 6,     // 6 consecutive fails → throttle
  THROTTLE_DURATION_MS: 20000, // Throttle for 20s then re-check
  // GUARANTEE: even when throttled, at least this many channels can still scan
  MIN_ACTIVE_CHANNELS: 1,
};

// Global scan queue: { tabId, channel, keyword, startDate, endDate, pageDate, scanId }
const KWS_SCAN_QUEUE = [];
// Set of channels currently being actively scanned
const KWS_ACTIVE_CHANNELS = new Set();

function kws_recordFetch(durationMs, failed) {
  KWS_OVERLOAD.recentFetchMs.push(durationMs);
  if (KWS_OVERLOAD.recentFetchMs.length > KWS_OVERLOAD.maxHistory)
    KWS_OVERLOAD.recentFetchMs.shift();

  if (failed) {
    KWS_OVERLOAD.failCount++;
    KWS_OVERLOAD.slowCount = 0;
  } else if (durationMs > KWS_OVERLOAD.SLOW_FETCH_MS) {
    KWS_OVERLOAD.slowCount++;
    KWS_OVERLOAD.failCount = 0;
  } else {
    // Successful fast fetch — reset counters
    KWS_OVERLOAD.slowCount = Math.max(0, KWS_OVERLOAD.slowCount - 1);
    KWS_OVERLOAD.failCount = Math.max(0, KWS_OVERLOAD.failCount - 1);
  }

  const wasThrottled = KWS_OVERLOAD.throttled;
  const shouldThrottle =
    KWS_OVERLOAD.slowCount >= KWS_OVERLOAD.SLOW_TRIGGER_COUNT ||
    KWS_OVERLOAD.failCount >= KWS_OVERLOAD.FAIL_TRIGGER_COUNT;

  if (shouldThrottle && !KWS_OVERLOAD.throttled) {
    KWS_OVERLOAD.throttled = true;
    KWS_OVERLOAD.throttleUntil = Date.now() + KWS_OVERLOAD.THROTTLE_DURATION_MS;
    kws_broadcastOverloadState(true);
  } else if (KWS_OVERLOAD.throttled && Date.now() > KWS_OVERLOAD.throttleUntil) {
    KWS_OVERLOAD.throttled = false;
    KWS_OVERLOAD.slowCount = 0;
    KWS_OVERLOAD.failCount = 0;
    kws_broadcastOverloadState(false);
    // Throttle lifted — drain queue
    setTimeout(kws_drainQueue, 200);
  }
}

function kws_isOverloaded() {
  if (!KWS_OVERLOAD.throttled) return false;
  if (Date.now() > KWS_OVERLOAD.throttleUntil) {
    KWS_OVERLOAD.throttled = false;
    KWS_OVERLOAD.slowCount = 0;
    KWS_OVERLOAD.failCount = 0;
    kws_broadcastOverloadState(false);
    return false;
  }
  return true;
}

function kws_getAvgFetchMs() {
  if (!KWS_OVERLOAD.recentFetchMs.length) return 0;
  return Math.round(KWS_OVERLOAD.recentFetchMs.reduce((a,b)=>a+b,0) / KWS_OVERLOAD.recentFetchMs.length);
}

async function kws_broadcastOverloadState(throttled) {
  try {
    const tabs = await chrome.tabs.query({ url: ['https://www.twitch.tv/*'] });
    const msg = {
      type: 'KWS_OVERLOAD_STATE',
      throttled,
      queueLength: KWS_SCAN_QUEUE.length,
      activeChannels: Array.from(KWS_ACTIVE_CHANNELS),
      avgFetchMs: kws_getAvgFetchMs(),
      throttleUntil: KWS_OVERLOAD.throttleUntil,
    };
    for (const tab of tabs) {
      if (typeof tab.id === 'number') {
        try { chrome.tabs.sendMessage(tab.id, msg); } catch(e) {}
      }
    }
  } catch(e) {}
}

async function kws_broadcastQueueUpdate() {
  try {
    const tabs = await chrome.tabs.query({ url: ['https://www.twitch.tv/*'] });
    const msg = {
      type: 'KWS_QUEUE_UPDATE',
      queue: KWS_SCAN_QUEUE.map(q => ({ channel: q.channel, tabId: q.tabId })),
      activeChannels: Array.from(KWS_ACTIVE_CHANNELS),
    };
    for (const tab of tabs) {
      if (typeof tab.id === 'number') {
        try { chrome.tabs.sendMessage(tab.id, msg); } catch(e) {}
      }
    }
  } catch(e) {}
}

// Drain queue: start queued scans respecting limits.
// Even when overloaded, guarantee at least MIN_ACTIVE_CHANNELS can run.
async function kws_drainQueue() {
  while (KWS_SCAN_QUEUE.length > 0) {
    const active = KWS_ACTIVE_CHANNELS.size;
    const overloaded = kws_isOverloaded();
    const belowMin = active < KWS_OVERLOAD.MIN_ACTIVE_CHANNELS;
    const belowMax = active < KWS_OVERLOAD.MAX_CONCURRENT_CHANNELS;

    // Start if: below minimum guarantee OR (below max AND not overloaded)
    if (!belowMin && (overloaded || !belowMax)) break;

    const next = KWS_SCAN_QUEUE.shift();
    await kws_broadcastQueueUpdate();
    kws_runActual(next);
  }
}

// ── All language keywords (always searched, no language detection) ──────────────────
// 기본 딸꾹질 키워드 목록 — {word, substring} 형태
// substring:true  → ≈ contains mode (Korean/Japanese/Chinese/Arabic/Hindi/Thai/Spanish)
// substring:false → =  exact mode  (English/German/Russian etc. — space-delimited)
const ALL_HICCUP_KEYWORDS = [
  // 🇬🇧 English — word boundary (=)
  {word:"hiccup",     substring:false},
  {word:"hiccups",    substring:false},
  {word:"hicup",      substring:false},
  {word:"hicups",     substring:false},
  {word:"hickup",     substring:false},
  {word:"hickups",    substring:false},
  {word:"hiccuping",  substring:false},
  {word:"hiccupped",  substring:false},
  {word:"hiccupp",    substring:false},
  // 🇰🇷 Korean — particles/endings attach directly, no space (≈ contains)
  {word:"딸꾹",   substring:true},
  {word:"딸국",   substring:true},
  {word:"딱꾹",   substring:true},
  {word:"딱국",   substring:true},
  {word:"꾹질",   substring:true},
  {word:"국질",   substring:true},
  {word:"딸꾹질", substring:true},
  {word:"딸국질", substring:true},
  {word:"딸꾸기", substring:true},
  {word:"딸꾹이", substring:true},
  {word:"딱꾹질", substring:true},
  // 🇷🇺 Russian — Cyrillic word boundary (= exact)
  {word:"икота",  substring:false},
  {word:"икотка", substring:false},
  {word:"икоту",  substring:false},
  {word:"икоты",  substring:false},
  {word:"икотта", substring:false},
  // 🇯🇵 Japanese — no word boundaries in writing system (≈ contains)
  {word:"しゃっくり", substring:true},
  {word:"シャックリ",  substring:true},
  {word:"しゃくり",   substring:true},
  {word:"しゃっく",   substring:true},
  {word:"吃逆",       substring:true},
  // 🇨🇳 Chinese — no word boundaries in writing system (≈ contains)
  {word:"打嗝", substring:true},
  {word:"打咯", substring:true},
  {word:"嗝",   substring:true},
  {word:"呃逆", substring:true},
  {word:"打格", substring:true},
  {word:"打隔", substring:true},
  // 🇪🇸 Spanish hipo — EXCLUDE_REGEX guards it; contains mode catches conjugations (≈)
  {word:"hipo",    substring:true},
  {word:"hipos",   substring:true},
  {word:"hipó",    substring:true},
  {word:"hipando", substring:true},
  {word:"hipar",   substring:true},
  // 🇩🇪 Deutsch — word boundary (=)
  {word:"schluckauf",  substring:false},
  {word:"schluckaif",  substring:false},
  {word:"schluckof",   substring:false},
  {word:"schluck auf", substring:false},
  {word:"hickser",     substring:false},
  {word:"hicks",       substring:false},
  // 🇵🇱 Polski — word boundary (=)
  {word:"czkawka",  substring:false},
  {word:"czkafka",  substring:false},
  {word:"czkawke",  substring:false},
  {word:"czkawki",  substring:false},
  {word:"czakwka",  substring:false},
  // 🇷🇴 Română — word boundary (=)
  {word:"sughiț",   substring:false},
  {word:"sughit",   substring:false},
  {word:"sughitul", substring:false},
  {word:"sughite",  substring:false},
  {word:"sughita",  substring:false},
  {word:"sugit",    substring:false},
  // 🇹🇭 Thai — syllabic script, no spaces (≈ contains)
  {word:"สะอึก", substring:true},
  // 🇻🇳 Vietnamese — syllable-separated; standalone words (= exact)
  {word:"nấc",     substring:false},
  {word:"nấc cụt", substring:false},
  {word:"nac cut", substring:false},
  // 🇮🇩 Indonesia — word boundary (=)
  {word:"cegukan", substring:false},
  // 🇫🇷 Français — word boundary (=)
  {word:"hoquet",  substring:false},
  {word:"hoquets", substring:false},
  // 🇮🇹 Italiano — word boundary (=)
  {word:"singhiozzo",  substring:false},
  {word:"singhiozzi",  substring:false},
  // 🇵🇹 Português — word boundary (=)
  {word:"soluço",  substring:false},
  {word:"soluços", substring:false},
  {word:"soluco",  substring:false},
  {word:"solucos", substring:false},
  // 🇹🇷 Türkçe — word boundary (=)
  {word:"hıçkırık", substring:false},
  {word:"hickirik", substring:false},
  // 🇸🇦 Arabic — heavy root/affix morphology (≈ contains)
  {word:"فواق",    substring:true},
  {word:"حازوقة", substring:true},
  // 🇮🇳 Hindi — heavy root/affix morphology (≈ contains)
  {word:"हिचकी", substring:true},
  // 🇳🇱 Nederlands — word boundary (=)
  {word:"hik",    substring:false},
  {word:"hikken", substring:false},
  {word:"de hik", substring:false},
  // 🇸🇪 Svenska — word boundary (=)
  {word:"hicka",  substring:false},
  {word:"hickan", substring:false},
  // 🇳🇴 Norsk / 🇩🇰 Dansk — word boundary (=)
  {word:"hikke", substring:false},
  // 🇫🇮 Suomi — word boundary (=)
  {word:"hikka", substring:false},
  // 🇬🇷 Ελληνικά — word boundary (=)
  {word:"λόξιγκας", substring:false},
  {word:"loxigas",  substring:false},
  // 🇮🇱 עברית — word boundary (=)
  {word:"שיהוק",   substring:false},
  {word:"שיהוקים", substring:false},
];

// ── Supplemental include regex list ─────────────────────────────────────────────────────
// Replaces substring search for keywords prone to false positives.
// A message is included if it matches any of these patterns.
const INCLUDE_REGEX_LIST = [

  // 🇷🇺 Russian verb forms: match only when not surrounded by Cyrillic
  // prevents false positives like чикает, пикает, тикает
  /(?<![а-яёА-ЯЁ])икает(?![а-яёА-ЯЁ])/i,
  /(?<![а-яёА-ЯЁ])икаю(?![а-яёА-ЯЁ])/i,
  /(?<![а-яёА-ЯЁ])икнул(?![а-яёА-ЯЁ])/i,
  /(?<![а-яёА-ЯЁ])икнула(?![а-яёА-ЯЁ])/i,
  /(?<![а-яёА-ЯЁ])икнёт(?![а-яёА-ЯЁ])/i,
  /(?<![а-яёА-ЯЁ])иканье(?![а-яёА-ЯЁ])/i,

  // 🇪🇸 스페인어 hipo: 앞에 알파벳이 없고 뒤가 딸꾹질 형태일 때만
  // hipoteca, hipócrita etc. are handled by EXCLUDE_REGEX
  // this also catches cases written without spaces
  // only allows: hipo, hipos, hipó, hipando, hipar
  /(?<![a-záéíóúñüa-zA-ZÁÉÍÓÚÑÜ])hipo(?:s|(?!t|c|d|g|l|m|n|b|f|v|x|a|h|p|k|r|q|j|w|y|z))/i,
  /(?<![a-záéíóúñüA-ZÁÉÍÓÚÑÜ])hip[oó](?:ando|ar|)/i,  // hipó, hipando, hipar

  // 🇩🇪 German: hicks, hickser — word boundary
  // hicksville, hickory, hickok are handled by EXCLUDE_REGEX
  /hicks(?:er)?/i,

  // 🇵🇱 Polish: czkawka and variants — word boundary
  // very specific, low false positive risk
  /czkawk[aęiąu]/i,

  // 🇷🇴 Romanian: sughiț and variants
  /sughi[tț]\w*/i,
];

// ── Smart exclude regex list ────────────────────────────────────────────────
// More precise than simple substring exclusion.
// A message is excluded if it matches any of these patterns.
// User-defined exclude words are also checked as substrings.
const EXCLUDE_REGEX_LIST = [

  // 🇪🇸 Spanish: hipo (hypo- prefix) + consonant combinations
  // hipo followed by a non-vowel consonant = medical/scientific prefix
  // hipos, hipó, hipando, hipar are valid targets — not excluded
  /hipot\w*/gi,   // hipoteca, hipotético, hipotiroidismo, hipotenusa, hipotensión
  /hipoc\w*/gi,   // hipocondría, hipócrita, hipocampo, hipocalórico, hipoclorito
  /hipod\w*/gi,   // hipodérmico, hipodermis, hipódromo
  /hipog\w*/gi,   // hipoglucemia, hipoglicemia
  /hipol\w*/gi,   // hipolipemiante
  /hipom\w*/gi,   // hipometabolismo
  /hipon\w*/gi,   // hiponatremia
  /hipob\w*/gi,   // hipobárico
  /hipof\w*/gi,   // hipófisis
  /hipov\w*/gi,   // hipovolemia
  /hipox\w*/gi,   // hipoxia
  /hipoa\w*/gi,   // hipoacusia
  /hipoh\w*/gi,   // hipohidrosis
  /hipop\w*/gi,   // hipopótamo, hipopotamus
  /hipou\w*/gi,   // (rare, kept for safety)
  /hipst\w*/gi,   // hipster, hipsters
  /hipn\w*/gi,    // hipnosis, hipnótico, hipnotismo
  /hipé\w*/gi,    // hipérbole
  /hipè\w*/gi,    // accent variant
  /hiper\w*/gi,   // hipertensión, hipervínculo (hiper also used as hyper-)

  // 🇷🇺 Russian: икотник (plant name) and variants — position-independent
  /икотник\w*/gi,   // икотник, икотника, икотниках, икотники

  // 🇩🇪 German: place/person names containing hicks
  /hicksville/gi,
  /hickory/gi,
  /hickok/gi,

  // 🇯🇵 Japanese: しゃくりあげ family (sobbing) — position-independent
  /しゃくりあ[げがぎぐごっ]/g,  // しゃくりあげ, しゃくりあがる etc.
  /しゃくり上/g,               // kanji mixed form

];

// Default exclude words (user-editable via the keyword modal)
// Applied alongside EXCLUDE_REGEX_LIST
const DEFAULT_EXCLUDE_KEYWORDS = [
  "chipotle",
  "chipo",
  "chipotles",
  "chipotle sauce",
  "chipotle chicken",
  "chipotle bowl",
  "chipotle order",
  "chick",
  "chicks",
  "chicken",
  "chickens",
  "chicky",
  "chickie",
  "chickpea",
  "chickpeas",
  "chickadee",
  "chickadees",
  "chick-fil-a",
  "chickfila",
  "chick fil a",
  "chic",
  "chico",
  "chica",
  "chicas",
  "chicle",
  "hiccup sauce",
  "hiccup drink",
  "hiccup song",
  "hiccup meme",
  "hiccupcup",
  "hiccupcupcup",
  "hippo",
  "hippos",
  "hippopotamus",
  "hippopotamuses",
  "hipoteca",
  "hipotecas",
  "hipódromo",
  "hipodromo",
  "hipopótamo",
  "hipopotamo",
  "hipócrita",
  "hipocrita",
  "hipocondria",
  "hipoglucemia",
  "hipnosis",
  "hipnotizar",
  "hiper",
  "hipster",
  "hipsters",
  "hoquetage",
  "hickory",
  "hickman",
  "hickok",
  "hicksville",
  "hicks",
  "しゃくり上げる",
  "しゃくりあげる",
  "икотник",
  "สะอื้น"
];

// keyword string parsing: "word1, ~word2, -exclude1"
// ~ prefix: contains (substring) mode / default: exact word boundary match
function kws_parseKeywords(rawKeyword) {
  const parts = String(rawKeyword||'').split(',').map(s=>s.trim()).filter(Boolean);
  const include = [], exclude = [];
  for (const p of parts) {
    if (p.startsWith('-')) {
      exclude.push(p.slice(1).trim().toLowerCase());
    } else if (p.startsWith('~')) {
      include.push({ word: p.slice(1).trim().toLowerCase(), substring: true });
    } else {
      include.push({ word: p.toLowerCase(), substring: false });
    }
  }
  return { include, exclude };
}

// Whole-word (word boundary) match helper
// ASCII: matches only when not surrounded by letter/digit/hyphen/apostrophe
// Korean/Cyrillic: matches only when not surrounded by same-script chars
// CJK etc.: no word boundary concept — falls back to simple contains
function kws_matchesWholeWord(lower, keyword) {
  const k = keyword.toLowerCase();
  // CJK 한자/카나, 태국어 — 띄어쓰기 관습이 없는 문자 체계라 "단어 경계"라는 개념 자체가
  // 안 맞아서 처음부터 substring이 맞는 방식. 그 외 전부(영어/독일어/폴란드어/슬로바키아어/
  // 터키어/베트남어/러시아어/한국어/아랍어/히브리어/그리스어 등)는 단어 사이에 공백이 있는
  // 문자 체계라 유니코드 인식 단어 경계(\p{L}\p{N})로 통일 처리.
  // (예전엔 ASCII/한글/키릴만 개별 처리하고 나머지 — 체코어 čká 같은 악센트 붙은 라틴 문자,
  //  아랍어, 그리스어 등 — 는 전부 이 substring 폴백으로 새서, "čká"가 "počkať" 안에서도
  //  매칭되는 등 whole-word로 저장해도 사실상 substring처럼 동작하는 버그가 있었음)
  if (/[\u4E00-\u9FFF\u3040-\u30FF\u0E00-\u0E7F]/.test(k)) {
    return lower.includes(k);
  }
  const escaped = k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  try {
    return new RegExp(`(?<![\\p{L}\\p{N}])${escaped}(?![\\p{L}\\p{N}])`, 'iu').test(lower);
  } catch (e) {
    return lower.includes(k);
  }
}

// Returns true if the message matches any pattern in INCLUDE_REGEX_LIST
function kws_matchesIncludeRegex(message) {
  for (const re of INCLUDE_REGEX_LIST) {
    re.lastIndex = 0;
    if (re.test(message)) return true;
  }
  return false;
}

// Returns true if the message should be excluded
// 1) Check EXCLUDE_REGEX_LIST patterns
// 2) Check user-defined exclude keywords (substring)
function kws_isExcluded(message, userExcludeKeywords) {
  const lower = message.toLowerCase();
  for (const re of EXCLUDE_REGEX_LIST) {
    re.lastIndex = 0;
    if (re.test(lower)) return true;
  }
  for (const ex of userExcludeKeywords) {
    if (kws_matchesWholeWord(lower, ex)) return true;
  }
  return false;
}

// Resolve keyword string into structured include/exclude lists
// Returns keywords as [{word, substring}] array
function kws_resolveKeywords(rawKeyword) {
  const { include, exclude } = kws_parseKeywords(rawKeyword);
  const keywords = include.length
    ? include
    : ALL_HICCUP_KEYWORDS.map(k => ({ word: k.word.toLowerCase(), substring: k.substring }));
  const hasExplicitKeywordConfig = String(rawKeyword||"").trim().length > 0;
  const excludeKeywords = [...new Set([
    ...exclude,
    ...(hasExplicitKeywordConfig ? [] : DEFAULT_EXCLUDE_KEYWORDS.map(k=>k.toLowerCase())),
  ])];
  return { keywords, excludeKeywords };
}


function kws_format(d) {
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}
function kws_sanitizeFilePart(s) {
  return String(s||"").trim().replace(/[\/:*?"<>|]+/g,"_").replace(/\s+/g,"_").slice(0,80)||"scan";
}
function kws_normalizeChannel(channel){return String(channel||"").trim().toLowerCase();}
function kws_sleep(ms){return new Promise(r=>setTimeout(r,ms));}
function kws_maxDateString(...values){
  const valid=values.filter(v=>/^\d{4}-\d{2}-\d{2}$/.test(String(v||"")));
  if(!valid.length)return kws_format(new Date());
  return valid.sort().at(-1);
}
function kws_formatTimestamp(value) {
  if (!value) return "--:--:--";
  const d=new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  // UTC 기준으로 시간 표시 (로컬 시간대 변환 방지)
  return `${String(d.getUTCHours()).padStart(2,"0")}:${String(d.getUTCMinutes()).padStart(2,"0")}:${String(d.getUTCSeconds()).padStart(2,"0")}`;
}
function kws_localDateFromTimestamp(value) {
  const ms=kws_normalizeTimestampMs(value);
  if (!ms) return null;
  const d=new Date(ms);
  // UTC 날짜 기준 (로컬 시간대로 날짜가 바뀌는 문제 방지)
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,'0')}-${String(d.getUTCDate()).padStart(2,'0')}`;
}
function kws_normalizeTimestampMs(value) {
  if (value==null||value==="") return null;
  if (typeof value==="number") return value>1e12?value:value>1e9?value*1000:null;
  const str=String(value).trim();
  if (/^\d{13}$/.test(str)) return parseInt(str,10);
  if (/^\d{10}$/.test(str)) return parseInt(str,10)*1000;
  const p=new Date(str).getTime();
  return Number.isNaN(p)?null:p;
}

function kws_normalizeMessages(payload) {
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.messages)) return payload.messages;
  return [];
}
function kws_getMessageText(item) { return String(item?.message??item?.text??"").trim(); }
function kws_getUsername(item) { return String(item?.username??item?.displayName??item?.user??"unknown").trim(); }
function kws_getTimestamp(item) { return item?.timestamp??item?.time??item?.createdAt??item?.created_at??null; }
// twitchtracker 탭에 KWS 상태 브로드캐스트
async function broadcastToTwitchTracker(payload) {
  try {
    const tabs = await chrome.tabs.query({ url: 'https://twitchtracker.com/*' });
    for (const tab of tabs) {
      chrome.tabs.sendMessage(tab.id, payload).catch(() => {});
    }
  } catch {}
}

const SOOP_STATE_SESSION_KEY = 'soopLastState';
async function getSoopLastState() {
  try {
    const r = await chrome.storage.session.get(SOOP_STATE_SESSION_KEY);
    return r[SOOP_STATE_SESSION_KEY] || { activeStreamerId: null, percent: 0, queue: [] };
  } catch { return { activeStreamerId: null, percent: 0, queue: [] }; }
}
async function setSoopLastState(state) {
  try { await chrome.storage.session.set({ [SOOP_STATE_SESSION_KEY]: state }); } catch {}
}
async function broadcastToSoopRanking(payload) {
  try {
    const tabs = await chrome.tabs.query({ url: 'https://afevent2.sooplive.com/*' });
    for (const tab of tabs) {
      chrome.tabs.sendMessage(tab.id, payload).catch(() => {});
    }
  } catch {}
}

function kws_sendToTab(tabId, payload) {
  if (typeof tabId !== 'number') return;
  try { chrome.tabs.sendMessage(tabId, payload, () => void chrome.runtime.lastError); } catch(e) {}
}

function kws_dedupeMessagesByContent(messages){
  const seen = new Set();
  const out = [];
  for (const item of messages || []) {
    const ts = String(kws_getTimestamp(item) || '').replace(/\.\d{3}Z$/, 'Z');
    const user = kws_getUsername(item).toLowerCase();
    const text = kws_getMessageText(item).toLowerCase().replace(/\s+/g, ' ').trim();
    const key = `${ts}|${user}|${text}`;
    if (!text || seen.has(key)) continue;
    seen.add(key);
    out.push(item);
  }
  return out;
}

// Zonian(logs.zonian.dev) — 무로그인 External API. IVR(logs.ivr.fi)은 사실상
// 방치(1년+ 무업데이트)라 최근 로그를 안 갖고 있어서 완전히 제거함(2026-09).
//
// 동시성을 올린 뒤(1.2.3.69) 429가 나면 각 요청이 "따로따로" 500ms*attempt로만
// 재시도했는데, 이러면 20개 워커가 거의 동시에 각자 짧게 쉬었다가 다시 몰려가서
// 레이트리밋 윈도우가 안 풀린 채로 계속 부딪힘 → 재시도(repass)까지 거쳐도 최종
// 실패하는 날짜가 대량으로 쌓이는 버그였음(예: 101일 중 48일 실패).
// 고침: 429를 한 번이라도 보면 "공유 쿨다운"을 걸어서, 그 순간 진행 중인 모든
// 워커가 같은 시점까지 다 같이 멈췄다가 재개하게 함(서버의 Retry-After가 있으면
// 그 값을 우선 사용).
let kws_zonianCooldownUntil = 0;

async function kws_fetchMessagesForDate(channel,dateStr,attempt=0,logSource='zonian'){
  const nc=kws_normalizeChannel(channel);
  const[y,m,day]=dateStr.split("-");
  const bases=kws_pickLogBases(nc,dateStr);
  const base=bases[attempt%bases.length];
  const isZonian=base===KWS_ZONIAN_BASE;
  const url = `${base}/channel/${encodeURIComponent(nc)}/${y}/${m}/${day}?jsonBasic=1`;
  const cdKey=isZonian?'zonian':base;
  const cdUntil=isZonian?kws_zonianCooldownUntil:(kws_instanceCooldown.get(base)||0);
  const waitMs = cdUntil - Date.now();
  if(waitMs > 0) await kws_sleep(waitMs);
  const controller=new AbortController();
  const tid=setTimeout(()=>controller.abort(),isZonian?12000:6000);
  const t0=Date.now();
  const next=(delay)=>kws_sleep(delay).then(()=>kws_fetchMessagesForDate(nc,dateStr,attempt+1,logSource));
  const markFail=()=>{
    if(isZonian) return;
    const n=(kws_instanceFails.get(base)||0)+1;
    kws_instanceFails.set(base,n);
    if(n>=3) kws_instanceBadUntil.set(base,Date.now()+120000); // 연속 3회 실패 → 2분간 제외
  };
  try{
    const res=await fetch(url,{signal:controller.signal,cache:"no-store"});
    if(!res.ok){
      kws_recordFetch(Date.now()-t0,true);
      if(res.status===429||res.status>=500||(!isZonian&&res.status===404)){
        if(res.status===429){
          const retryAfterSec=parseInt(res.headers.get('retry-after')||'',10);
          const cooldownMs=Number.isFinite(retryAfterSec)&&retryAfterSec>0 ? retryAfterSec*1000 : 4000*(attempt+1);
          if(isZonian) kws_zonianCooldownUntil=Math.max(kws_zonianCooldownUntil, Date.now()+cooldownMs);
          else kws_instanceCooldown.set(base,Math.max(kws_instanceCooldown.get(base)||0,Date.now()+cooldownMs));
        }
        if(res.status!==404) markFail();
        // 다른 인스턴스로 바로 넘어갈 수 있으면 대기 없이 즉시 재시도
        if(attempt<5){return next(!isZonian&&bases.length>1?0:500*(attempt+1));}
      }
      // 1.2.5: Zonian answers 404 for a day it has no log file for (the channel didn't stream /
      // wasn't logged that day). That is "no chat", not a failed fetch — before, every such day
      // was counted as "failed to load" (e.g. "8 days couldn't be fetched" for a 3-day streamer).
      if(isZonian&&res.status===404){kws_recordFetch(Date.now()-t0,false);return [];}
      throw new Error(`HTTP ${res.status}`);
    }
    const msgs=kws_normalizeMessages(await res.json());
    kws_recordFetch(Date.now()-t0,false);
    if(!isZonian){
      const took=Date.now()-t0;
      kws_noteLatency(base,took);
      if(took>5000) markFail(); else kws_instanceFails.set(base,0);
    }
    return msgs;
  }catch(e){
    kws_recordFetch(Date.now()-t0,true);
    if(!isZonian) kws_noteLatency(base,Math.max(Date.now()-t0,6000));
    markFail();
    if(attempt<5){return next(!isZonian&&bases.length>1?0:500*(attempt+1));}
    throw e;
  }finally{clearTimeout(tid);}
}


// ══════════════════════════════════════════════════════════════════════
//  KICK — Keyword Scanner  (official web.kick.com "chat replay" API)
//
//  Kick's VOD player grew a "chat replay" sidebar that scrubs chat in sync
//  with the video. It's powered by an undocumented but public,
//  unauthenticated endpoint (no cookies/headers needed):
//
//    GET https://web.kick.com/api/v1/chat/{chatroom_id}/history?start_time=<ISO8601>
//    GET https://web.kick.com/api/v1/chat/{chatroom_id}/history?cursor=<cursor>
//
//  Verified live via Chrome devtools:
//   - `start_time` snaps DOWN to the containing 5-second bucket and returns
//     only that bucket's messages (a handful, up to ~25) — it's a "seek to
//     here" call, not "give me everything from here on".
//   - `cursor` only walks BACKWARD (older messages) — that's what the
//     player uses to infinite-scroll up through history once you've
//     landed somewhere. No use for a forward scan.
//   - So to walk forward through a VOD without gaps or dupes we must
//     re-request bucket by bucket, each time advancing start_time to the
//     next 5-second boundary strictly after the newest message we just
//     saw (kick_nextBucketDate). Verified against a live stream: zero
//     duplicates, zero gaps across dozens of consecutive buckets.
//   - It's channel/chatroom-based, not VOD-based — works with no cookies
//     and for arbitrary past timestamps, independent of the specific VOD
//     page. But since it's bucketed every 5 seconds, scanning is only
//     efficient over actual broadcast windows: anywhere the channel was
//     off air would otherwise burn one request per 5 seconds for nothing.
//     So we first pull the channel's VOD list to know exactly when it was
//     live (kick_getVodSessions) and only bucket-walk inside those
//     windows, chunked and run through the adaptive pool so multiple
//     parts of a VOD scan in parallel.
// ══════════════════════════════════════════════════════════════════════

let kws_kickStopFlags = new Set();
const KICK_CHAT_BASE = 'https://web.kick.com/api/v1/chat';
const KICK_CHUNK_MS = 3 * 60 * 1000; // 세션을 3분 단위 청크로 쪼개서 병렬 스캔
let kws_kickChatCooldownUntil = 0;
const kws_kickChatroomCache = new Map(); // channel -> {ts, chatroomId}
const KWS_KICK_CHATROOM_TTL = 10 * 60 * 1000;

// 주어진 시각이 속한 5초 버킷의 "다음" 버킷 시작 시각(Date) — 항상 앞으로 전진하도록 보장
function kick_nextBucketDate(date) {
  const BUCKET_MS = 5000;
  const ms = date.getTime();
  const next = Math.floor(ms / BUCKET_MS) * BUCKET_MS + BUCKET_MS;
  return new Date(next);
}

async function kick_getChatroomId(channel) {
  const nc = kws_normalizeChannel(channel);
  const cached = kws_kickChatroomCache.get(nc);
  if (cached && (Date.now() - cached.ts) < KWS_KICK_CHATROOM_TTL) return cached.chatroomId;
  // 1.2.5.3: tell "this channel really does not exist" (404 on both APIs — renamed, deleted or
  // banned) apart from "Kick did not answer properly" (Cloudflare challenge / rate limit), and try
  // twice before giving up — the second case used to look like a vanished ID.
  let d = null, notFound = 0, tries = 0;
  for (let a = 0; a < 2 && !d; a++) {
    for (const url of [`https://kick.com/api/v1/channels/${encodeURIComponent(nc)}`, `https://kick.com/api/v2/channels/${encodeURIComponent(nc)}`]) {
      tries++;
      try {
        const res = await fetch(url, { credentials: 'include' });
        if (res.status === 404) { notFound++; continue; }
        const j = await res.json().catch(() => null);
        if (j && (j.id || j.chatroom)) { d = j; break; }
      } catch (_) {}
    }
    if (!d && notFound >= 2) break;
    if (!d) await kws_sleep(1500);
  }
  if (!d && notFound >= 2) throw new Error('KWS_ID_NOT_FOUND');
  if (!d) throw new Error('KWS_KICK_BLOCKED');
  // 주의: /chat/{id}/history의 {id}는 chatroom.id가 아니라 "채널" id다
  // (= chatroom.channel_id / chatroom.chatable_id, 메시지 자체의 chat_id 필드와도 이 값이 일치함).
  // xqc처럼 오래된 채널은 channel id와 chatroom.id가 우연히 같아서 테스트 때 안 걸렸는데,
  // 최근에 만들어진 채널(예: hyyjoe)은 두 값이 서로 달라서 chatroom.id를 쓰면 항상 빈 결과만 옴 —
  // 라이브로 두 채널 다 찍어보고 실제로 데이터 나오는 쪽(채널 id)으로 확정한 것.
  const chatroomId = d?.id || d?.chatroom?.channel_id || d?.chatroom?.chatable_id;
  if (!chatroomId) throw new Error(`Kick 채널 "${nc}"의 채팅방을 찾을 수 없습니다 (채널명을 확인해주세요).`);
  kws_kickChatroomCache.set(nc, { ts: Date.now(), chatroomId });
  return chatroomId;
}

// [startDate,endDate] (UTC 달력일, inclusive) 범위와 겹치는 실제 방송 세션 목록
async function kick_getVodSessions(channel, startDate, endDate) {
  const nc = kws_normalizeChannel(channel);
  const rangeStartMs = new Date(`${startDate}T00:00:00.000Z`).getTime();
  const rangeEndMs   = new Date(`${endDate}T23:59:59.999Z`).getTime();
  const vods = (await getKickVODs({ channel_slug: nc })) || [];
  return vods.map(v => {
    const startMs = v?.start_time ? new Date(String(v.start_time).replace(' ', 'T') + 'Z').getTime() : null;
    const durMs   = typeof v?.duration === 'number' ? v.duration : 0;
    // duration은 방송 중일 땐 0 — 진행 중으로 보고 "지금"까지로 처리
    const endMs   = startMs != null ? (durMs > 0 ? startMs + durMs : Date.now()) : null;
    if (startMs == null || endMs == null || Number.isNaN(startMs) || Number.isNaN(endMs)) return null;
    // 주의: kick.com/{channel}/videos/{X} 의 X는 숫자 id가 아니라 slug(uuid형 문자열)임 —
    // 숫자 id로 URL 만들면 "Oops, something went wrong" 404로 감. source(m3u8)도 같이 들고가서
    // 인라인 플레이어가 바로 재생할 수 있게 함.
    // 1.2.5.20: subscriber-only VODs (Kick's replay returns nothing for them — see the KickLogz block)
    const subOnly = v?.video?.status === 'subscriber_only';
    return { vodId: v.id != null ? String(v.id) : null, vodSlug: v.slug || null, vodSource: v.source || null, title: v.session_title || '', startMs, endMs, subOnly };
  }).filter(v => v && v.endMs >= rangeStartMs && v.startMs <= rangeEndMs)
    .map(v => ({ ...v, startMs: Math.max(v.startMs, rangeStartMs), endMs: Math.min(v.endMs, rangeEndMs) }))
    .sort((a, b) => a.startMs - b.startMs);
}

async function kick_fetchChatBucket(chatroomId, startTimeDate, attempt = 0) {
  const waitMs = kws_kickChatCooldownUntil - Date.now();
  if (waitMs > 0) await kws_sleep(waitMs);
  const qs = new URLSearchParams({ start_time: startTimeDate.toISOString() }).toString();
  const controller = new AbortController();
  const tid = setTimeout(() => controller.abort(), 12000);
  try {
    const res = await fetch(`${KICK_CHAT_BASE}/${chatroomId}/history?${qs}`, { signal: controller.signal, cache: 'no-store' });
    if (!res.ok) {
      if (res.status === 429 || res.status >= 500) {
        if (res.status === 429) {
          const retryAfterSec = parseInt(res.headers.get('retry-after') || '', 10);
          const cooldownMs = Number.isFinite(retryAfterSec) && retryAfterSec > 0 ? retryAfterSec * 1000 : 4000 * (attempt + 1);
          kws_kickChatCooldownUntil = Math.max(kws_kickChatCooldownUntil, Date.now() + cooldownMs);
        }
        if (attempt < 5) { await kws_sleep(500 * (attempt + 1)); return kick_fetchChatBucket(chatroomId, startTimeDate, attempt + 1); }
      }
      throw new Error(`HTTP ${res.status}`);
    }
    const data = await res.json();
    return Array.isArray(data?.data?.messages) ? data.data.messages : [];
  } catch (e) {
    if (attempt < 5) { await kws_sleep(500 * (attempt + 1)); return kick_fetchChatBucket(chatroomId, startTimeDate, attempt + 1); }
    throw e;
  } finally { clearTimeout(tid); }
}

// A shared, network-wide adaptive concurrency limiter — unlike kws_createAdaptivePool/
// kws_runPool (which hand out a fixed concurrency ceiling to ONE caller's own item list),
// this one is a real semaphore: every caller who does sharedPool.acquire()/release() draws
// from the SAME admitted-count and the SAME adaptive capacity, no matter which channel or
// session queued the work. That's what lets several Kick channels scan at once (front-end's
// MAX_CONCURRENT_SCANS) while still keeping the *total* number of chat-bucket requests in
// flight across ALL of them self-tuned to whatever Kick's API actually tolerates right now —
// growing on sustained success, backing off hard the moment anything fails (429/5xx/etc via
// kick_fetchChatBucket's own retry logic surfacing as a rejection here).
function kws_createSharedAdaptivePool({ initial = 24, min = 6, max = 200, growEvery = 2 } = {}) {
  let capacity = initial;
  let streak = 0;
  let active = 0;
  // 1.2.5.20: fair across callers. Waiters are queued per key (= channel) and admitted round-robin,
  // so the first channel to queue hundreds of chunks no longer makes the others wait at 0% until
  // it is through (total throughput is the same — only the order changes). Callers that pass no
  // key share one queue, i.e. plain FIFO as before.
  const queues = new Map(); // key → [resolve, ...]
  const order = [];         // keys with waiters, in rotation order
  let rr = 0;
  function nextWaiter() {
    for (let i = 0; i < order.length; i++) {
      const idx = (rr + i) % order.length;
      const key = order[idx];
      const q = queues.get(key);
      const fn = q && q.shift();
      if (!fn) continue;
      if (!q.length) { queues.delete(key); order.splice(idx, 1); rr = idx; }
      else rr = idx + 1;
      return fn;
    }
    return null;
  }
  function admit() {
    while (active < capacity) {
      const fn = nextWaiter();
      if (!fn) break;
      active++;
      fn();
    }
  }
  return {
    get concurrency() { return capacity; },
    get active() { return active; },
    acquire(key = '') {
      return new Promise(resolve => {
        if (!queues.has(key)) { queues.set(key, []); order.push(key); }
        queues.get(key).push(resolve);
        admit();
      });
    },
    release() { active = Math.max(0, active - 1); admit(); },
    reportSuccess() {
      streak++;
      if (streak >= growEvery && capacity < max) { capacity++; streak = 0; }
    },
    reportFailure() {
      streak = 0;
      capacity = Math.max(min, Math.floor(capacity * 0.6));
    },
  };
}

// worker(item) returns/resolves falsy (or throws) on failure, anything else counts as success —
// used purely to grow/shrink sharedPool.concurrency, same convention as kws_runPool.
async function kws_runSharedPool(items, sharedPool, worker, key) {
  if (!items.length) return;
  await Promise.all(items.map(async (item) => {
    await sharedPool.acquire(key);
    let ok = true;
    try {
      const r = await worker(item);
      ok = (r !== false);
    } catch (e) { ok = false; }
    if (ok) sharedPool.reportSuccess(); else sharedPool.reportFailure();
    sharedPool.release();
  }));
}

// One shared pool for every concurrently-running Kick channel scan (and every session within
// each of them) — see kws_createSharedAdaptivePool above for why this needs to be shared
// rather than created fresh per call. Cap of 200 matches the live-tested safe ceiling noted
// where it's used below.
// max를 200까지 열어뒀더니 동시에 여러 채널을 스캔할 때(MAX_CONCURRENT_SCANS=6) 실제로 그
// 근처까지 빠르게(growEvery:2) 치고 올라가서, 동시에 나가는 HTTP 요청 수가 너무 많아져
// 네트워크/브라우저 프로세스에 부담을 줘서 컴퓨터 전체가 느려진다는 리포트가 있었음.
// 검색 자체 속도(진짜 병목은 Kick API 응답 지연/레이트리밋)는 60 근처에서도 거의 그대로면서,
// 순간 최대 동시 연결 수만 줄여서 부담을 낮춤 — growEvery도 4로 늦춰서 더 완만하게 올라가게 함.
const KICK_GLOBAL_POOL = kws_createSharedAdaptivePool({ initial: 16, min: 6, max: 60, growEvery: 4 });

// Zonian(logs.zonian.dev)도 Kick과 똑같은 문제가 있었음 — 채널마다 kws_createAdaptivePool로
// 새 풀을 따로 만들다 보니, 동시에 여러 Twitch 채널을 Zonian 모드로 스캔하면(예: 3채널 동시)
// 채널당 최대 12개씩 실제로는 최대 36개까지 동시 요청이 나갈 수 있었음 — max:12라는 상한은
// "한 번에 한 채널만 돌린다"는 가정 하에 튜닝된 값(20으로 올렸다가 101일 중 48일 실패했던
// 이력 있음)이라, 여러 채널 동시 스캔에서는 이 상한이 사실상 지켜지지 않고 있었던 셈.
// Kick처럼 모든 채널·세션이 공유하는 풀 하나로 바꿔서, 몇 개 채널을 동시에 돌리든 logs.zonian.dev로
// 나가는 동시 요청 수가 항상 이 하나의 상한(12) 밑으로 유지되게 함 — 상한 자체는 일단 그대로
// 두고(공유 쿨다운 로직과 별개로 이 "여러 채널이 각자 상한까지 치고 올라가는" 문제만 먼저 해결).
const ZONIAN_GLOBAL_POOL = kws_createSharedAdaptivePool({ initial: 8, min: 2, max: 15, growEvery: 3 });

// ══════════════════════════════════════════════════════════════════════
//  SOOP — VOD 채팅 조각(videoimg.sooplive.com/php/ChatLoadSplit.php) fetch 전용
//  공유 풀 + 쿨다운
//
//  기존엔 soopSearcher.js(콘텐츠 스크립트, sooplive.com 탭 안) 쪽에 고정 동시성
//  (CHAT_CHUNK_CONC=6, VOD당) + "실패하면 400ms 후 반대쪽 fetch 경로로 한 번 더"
//  정도의 얕은 재시도만 있었고, Kick/Zonian처럼 429/5xx를 감지해서 전체가 같이
//  쉬었다가 재개하는 "공유 쿨다운"이나, 성공/실패에 따라 동시성 자체를 키우고
//  줄이는 "적응형 풀"이 전혀 없었음. 여러 스트리머/VOD를 동시에 스캔할 때(탭
//  여러 개 열림) 이 부분이 실제 스캔 불안정성(채팅 조각 fetch 실패 → 잘못된
//  gap 감지 → 불필요한 탭 폴백, 또는 정말로 fetch 실패해서 매치 누락)의 원인
//  중 하나였던 걸 2026-09 실측으로 확인함.
//
//  콘텐츠 스크립트(soopSearcher.js, sooplive.com 페이지 컨텍스트)가 실제 fetch를 하고,
//  여기 서비스워커는 "언제 나가도 되는지"만 게이트로 관리함(SOOP_POOL_ACQUIRE/DONE,
//  위쪽 리스너 참고) — 실제 fetch를 서비스워커로 옮겼다가 SOOP 서버가 그 요청들을
//  400으로 거부하는 회귀를 겪은 뒤(2026-09, "겁나 느리네" 리포트) 되돌린 것. 도메인
//  페일오버(.com/.co.kr)와 429 감지 시 Retry-After 파싱도 이제 콘텐츠 스크립트 쪽에서
//  하고, 그 결과(상태코드)만 SOOP_POOL_DONE으로 여기 보고해서 공유 쿨다운을 갱신함.
// ══════════════════════════════════════════════════════════════════════
// 초기값/최대치 산정: soopSearcher.js는 스트리머 1명 스캔에서 최대 API_WORKER_MAX(12)개
// VOD를 동시에 처리하고, 각 VOD가 CHAT_CHUNK_CONC(12)개씩 조각을 동시 제출함 — 즉
// 공유 풀 도입 전엔 최대 12×6(구 CHAT_CHUNK_CONC)=72개 정도의 실동시성이 나던 구조였음.
// 초기치를 그 실동시성 수준으로, 최대치는 여유 있게 잡음. 429/5xx 감지 시 공유 쿨다운 +
// reportFailure()로 인한 급격한 축소(×0.6)는 그대로라, 서버가 실제로 밀어내면 안전하게 줄어듦.
let kws_soopChatCooldownUntil = 0;
const SOOP_CHAT_GLOBAL_POOL = kws_createSharedAdaptivePool({ initial: 32, min: 8, max: 96, growEvery: 3 });

// ══════════════════════════════════════════════════════════════════════
//  KICK — subscriber-only VODs via KickLogz  (1.2.5.20)
//
//  Kick's chat replay (web.kick.com/api/v1/chat/{id}/history) answers every 5-second bucket
//  of a subscriber-only VOD with 200 + messages: [] — checked on emmastonerr (8 points across
//  a whole VOD, logged out and logged in without a sub). So those VODs used to come back as
//  "0 hits" after thousands of empty requests. They're marked in the VOD list itself
//  (video.status === 'subscriber_only'), so they're now kept out of the bucket walk.
//
//  kicklogz.com captures live chat of the channels it tracks, VOD or no VOD. Its own search
//  page talks to:
//    POST /api/search  {query, username, channelName, dateFrom, dateTo, cursor, ...}
//         (header CSRF-Token = the page form's _csrf)  → {success, jobId, initialPosition}
//    GET  /api/search/status/{jobId} → {status:'completed', data:{total, hits[50], nextCursor}}
//  An empty query + channel + time window returns that window's whole chat, newest first,
//  50 per page; passing nextCursor back gives the next (older) 50. Checked live 2026-10-17.
//  It only answers from its own page (CSRF token + the user's own cookies and daily limit:
//  10/day logged out, 25 logged in), so — like SOOP — it runs inside a kicklogz.com tab via
//  chrome.scripting. Never solves/skips Turnstile or ads: a 429 is the user's limit, we stop.
//  Optional host permission + settings toggle (kwsKickKicklogz), one search at a time for
//  every channel scanning at once.
// ══════════════════════════════════════════════════════════════════════
const KICKLOGZ_ORIGINS = ['https://kicklogz.com/*'];
const KICKLOGZ_SEARCH_URL = 'https://kicklogz.com/search';
const KICKLOGZ_ENABLED_KEY = 'kwsKickKicklogz';
const KICKLOGZ_MAX_PAGES = 200;               // 10,000 messages per VOD — loop guard only
// 1.2.5.20 speed-up (Pro = no daily limit): each sub-only VOD is cut into KICKLOGZ_SLICE_MS windows
// that page through on their own, and every window of every channel draws from ONE adaptive pool
// (starts at 4 searches in flight, grows to 6 on success, shrinks on failures/429).
const KICKLOGZ_SLICE_MS = 20 * 60 * 1000;
const KICKLOGZ_POOL = kws_createSharedAdaptivePool({ initial: 4, min: 1, max: 6, growEvery: 6 });
// Free plan (10–25 searches a day): strictly one search at a time, newest VOD first, no slicing
// (every slice costs one extra first-page search)
const KICKLOGZ_FREE_POOL = kws_createSharedAdaptivePool({ initial: 1, min: 1, max: 1 });
const KICKLOGZ_PLAN_KEY = 'kwsKickKicklogzPlan'; // 'free' (default) | 'pro'
let kws_kicklogzTab = null;                   // { id, users, closeTimer, ready }

// Kick · log source (side panel settings, the same two modes as Twitch):
//   combined_fast  VODs KickLogz has → KickLogz (50 msgs per request instead of one request per 5 s);
//                  the rest, and any VOD KickLogz failed on → Kick's replay API
//   combined       public VODs → Kick; subscriber-only VODs (+ Pro: VOD-less past broadcasts) → KickLogz
// KickLogz itself is on as soon as kicklogz.com access is allowed (optional permission); without it
// both modes read everything from Kick's replay API (subscriber-only VODs are then skipped).
const KICK_SOURCE_KEY = 'kwsKickLogSource';
async function kick_getLogSource() {
  try {
    const v = (await chrome.storage.local.get(KICK_SOURCE_KEY))[KICK_SOURCE_KEY];
    return (v === 'combined_fast' || v === 'kicklogz') ? 'combined_fast' : 'combined'; // (kicklogz/native: earlier test builds)
  } catch (_) { return 'combined'; }
}
async function kicklogz_isEnabled() {
  try { return await chrome.permissions.contains({ origins: KICKLOGZ_ORIGINS }); } catch (_) { return false; }
}

function kicklogz_waitComplete(tabId, timeoutMs = 30000) {
  return new Promise((resolve) => {
    let finished = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      chrome.tabs.onUpdated.removeListener(onUpd);
      clearTimeout(timer);
      resolve();
    };
    const onUpd = (id, info) => { if (id === tabId && info.status === 'complete') finish(); };
    const timer = setTimeout(finish, timeoutMs);
    chrome.tabs.onUpdated.addListener(onUpd);
    chrome.tabs.get(tabId).then((t) => { if (t && t.status === 'complete') finish(); }).catch(finish);
  });
}

async function kicklogz_acquireTab() {
  if (kws_kicklogzTab) {
    try {
      await chrome.tabs.get(kws_kicklogzTab.id);
      clearTimeout(kws_kicklogzTab.closeTimer);
      kws_kicklogzTab.users++;
      await kws_kicklogzTab.ready;
      return kws_kicklogzTab.id;
    } catch (_) { kws_kicklogzTab = null; }
  }
  const tab = await chrome.tabs.create({ url: KICKLOGZ_SEARCH_URL, active: false });
  try { await chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch (_) {}
  const entry = { id: tab.id, users: 1, closeTimer: null, ready: kicklogz_waitComplete(tab.id) };
  kws_kicklogzTab = entry;
  await entry.ready;
  return tab.id;
}

// The kicklogz.com tab was closed (by the user) in the middle of a scan: open a new one, once for
// every slice that notices at the same moment. It takes over the closed tab's single "user" slot,
// so the scan's one releaseTab() at the end still balances.
let kws_kicklogzReviving = null;
function kicklogz_reviveTab() {
  if (!kws_kicklogzReviving) {
    kws_kicklogzReviving = kicklogz_acquireTab().finally(() => { setTimeout(() => { kws_kicklogzReviving = null; }, 0); });
  }
  return kws_kicklogzReviving;
}
const kicklogz_isTabGone = (msg) => /No tab with id|tab was closed|Frame with ID|Cannot access contents of url/i.test(String(msg || ''));

function kicklogz_releaseTab() {
  const entry = kws_kicklogzTab;
  if (!entry) return;
  entry.users = Math.max(0, entry.users - 1);
  if (entry.users) return;
  clearTimeout(entry.closeTimer);
  // kept a little while so the next sub-only VOD / channel in the queue reuses it
  entry.closeTimer = setTimeout(() => {
    if (kws_kicklogzTab !== entry || entry.users) return;
    kws_kicklogzTab = null;
    chrome.tabs.remove(entry.id).catch(() => {});
  }, 20000);
}
chrome.tabs.onRemoved.addListener((tabId) => { if (kws_kicklogzTab && kws_kicklogzTab.id === tabId) kws_kicklogzTab = null; });

// Runs INSIDE kicklogz.com (MAIN world) — must stay self-contained (no outer variables).
// 1.2.5.20: only ONE request per call, no waiting in the page. The tab sits in the background and
// Chrome slows a hidden tab's timers to once a minute after ~5 minutes, which turned every "is the
// search done yet?" check into a one-minute wait (searches looked stuck / overnight crawled). The
// waiting now happens in the service worker (kws_sleep), whose timers aren't throttled.
async function kicklogz_pagePost(a) {
  const csrf = (document.querySelector('#search-form input[name="_csrf"]') || document.querySelector('input[name="_csrf"]') || {}).value
    || (document.querySelector('meta[name="csrf-token"]') || {}).content;
  if (!csrf) return { error: 'no-csrf' };
  let r;
  try {
    r = await fetch('/api/search', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'CSRF-Token': csrf },
      body: JSON.stringify({
        query: a.query || '', username: '', channelName: a.channel || '', dateFrom: a.from, dateTo: a.to, // query: keyword search (kickfind_bg.js)
        oldUsernames: false, excludeEmoteOnly: false, cursor: a.cursor || null, listIds: [], turnstileToken: null,
      }),
    });
  } catch (_) { return { error: 'network' }; }
  if (r.status === 429) return { rateLimited: true, detail: (await r.text().catch(() => '')).slice(0, 300) };
  const q = await r.json().catch(() => null);
  if (!r.ok || !q || !q.jobId) return { error: (q && (q.error || q.message)) || ('HTTP ' + r.status) };
  return { jobId: q.jobId };
}
// Runs INSIDE kicklogz.com — one status check.
async function kicklogz_pageStatus(jobId) {
  try {
    const sr = await fetch('/api/search/status/' + encodeURIComponent(jobId), { credentials: 'same-origin' });
    if (sr.status === 429) return { rateLimited: true, detail: (await sr.text().catch(() => '')).slice(0, 300) };
    if (sr.status === 404) return { error: 'job expired' };
    const s = await sr.json();
    if (s && s.status === 'completed') {
      const d = s.data || {};
      const hits = (Array.isArray(d.hits) ? d.hits : []).map((h) => ({
        id: h.id, username: h.username || h.slug || '?', content: h.content || '', created_at: h.created_at,
        channel_slug: h.channel_slug || '', // needed by the keyword → channels search
      }));
      return { done: true, hits, nextCursor: d.nextCursor || null, total: d.total };
    }
    if (s && s.status === 'failed') return { error: String((s.error && (s.error.message || s.error)) || 'failed') };
    return { pending: true };
  } catch (_) { return { pending: true, net: true }; }
}

// 1.2.5.26: is this browser logged in to kicklogz.com (and on Pro)? Runs INSIDE kicklogz.com (MAIN
// world): re-fetches /search with the current cookies, so it is fresh even when the worker tab was
// opened before the user logged in. Logged in → the header has #auth-dropdown / #dropdown-logout-link;
// logged out → a /login link. The plan is only a hint read from that dropdown ("Upgrade" → free).
async function kicklogz_pageAccount() {
  try {
    const r = await fetch('/search', { credentials: 'same-origin', cache: 'no-store' });
    const doc = new DOMParser().parseFromString(await r.text(), 'text/html');
    const dd = doc.getElementById('auth-dropdown');
    const inMark = !!dd || !!doc.getElementById('dropdown-logout-link');
    const outMark = !!doc.querySelector('a[href^="/login"]');
    const loggedIn = inMark ? true : (outMark ? false : null);
    // The plan: /profile → "My Packages" (#packages-section) lists each subscription as
    // <li class="package-item"><span class="package-name">Pro</span><span class="package-expiry">Active</span>
    let plan = 'unknown';
    if (loggedIn) {
      try {
        const pr = await fetch('/profile', { credentials: 'same-origin', cache: 'no-store' });
        const pd = new DOMParser().parseFromString(await pr.text(), 'text/html');
        const sec = pd.getElementById('packages-section');
        if (sec) {
          const items = [...sec.querySelectorAll('.package-item')].map((li) => ({
            name: ((li.querySelector('.package-name') || {}).textContent || '').trim(),
            state: ((li.querySelector('.package-expiry') || {}).textContent || '').trim(),
          }));
          const live = items.filter((x) => /pro|premium/i.test(x.name) && !/expired|ended|inactive|canceled|cancelled|sona erdi/i.test(x.state));
          plan = live.length ? 'pro' : 'free';
        }
      } catch (_) {}
    }
    return { loggedIn, plan };
  } catch (e) { return { error: String((e && e.message) || e) }; }
}
let kws_klAccount = null; // { at, res }
async function kicklogz_checkAccount(force) {
  let perm = false;
  try { perm = await chrome.permissions.contains({ origins: KICKLOGZ_ORIGINS }); } catch (_) {}
  if (!perm) return { noPerm: true };
  const c = kws_klAccount;
  // a "logged in" answer is trusted for 5 min, anything else re-checked after 20 s (they may be logging in)
  if (!force && c && Date.now() - c.at < (c.res.loggedIn ? 300000 : 20000)) return c.res;
  // 1.2.5.28: never hang — the panel waits on this before a Kick search starts
  const timeout = (ms, what) => new Promise((r) => setTimeout(() => r({ error: 'timeout (' + what + ')' }), ms));
  const run = (async () => {
    let tabId;
    try { tabId = await kicklogz_acquireTab(); } catch (e) { return { error: 'tab: ' + String((e && e.message) || e) }; }
    try {
      return (await Promise.race([kicklogz_exec(tabId, kicklogz_pageAccount), timeout(12000, 'page')])) || { error: 'no result' };
    } catch (e) { return { error: String((e && e.message) || e) }; }
    finally { kicklogz_releaseTab(); }
  })();
  const res = await Promise.race([run, timeout(40000, 'kicklogz.com tab')]);
  if (res.error) console.warn('[KWS] KickLogz account check failed:', res.error);
  else kws_klAccount = { at: Date.now(), res };
  return res;
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'KWS_KL_ACCOUNT') return;
  kicklogz_checkAccount(!!msg.force).then(sendResponse, (e) => sendResponse({ error: String((e && e.message) || e) }));
  return true;
});

async function kicklogz_exec(tabId, func, arg) {
  const [res] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func, args: arg === undefined ? [] : [arg] }); // undefined isn't serializable (1.2.5.30)
  return res && res.result;
}

// POST once, then poll from here (service-worker timers) until the job is done.
async function kicklogz_searchPage(tabId, args) {
  const q = (await kicklogz_exec(tabId, kicklogz_pagePost, args)) || { error: 'no result' };
  if (!q.jobId) return q;
  const deadline = Date.now() + 120000; // its queue can take a while when the site is busy
  let wait = 250;                       // a free slot usually answers on the first look
  while (Date.now() < deadline) {
    await kws_sleep(wait);
    wait = Math.min(1500, Math.round(wait * 1.6));
    const s = (await kicklogz_exec(tabId, kicklogz_pageStatus, q.jobId)) || { pending: true };
    if (s.done) return { hits: s.hits, nextCursor: s.nextCursor, total: s.total };
    if (s.rateLimited || s.error) return s;
  }
  return { error: 'timeout' };
}

// Pro plan: past broadcasts that no longer have a Kick VOD, as far back as StreamRecorder.io keeps
// recordings (premium: 60 days — streamrecorder.io/faq), so a hit there can still be watched/downloaded.
// kicklogz.com lists every broadcast it captured: GET /api/streamer/{slug}/broadcasts?page=N
// → { data: [{ started_at, ended_at, title, message_count, is_live, ... } × 15], totalPages }
const KICKLOGZ_ARCHIVE_DAYS = 60;

// Runs INSIDE kicklogz.com (MAIN world) — self-contained.
async function kicklogz_pageBroadcasts(a) {
  const out = [];
  for (let page = 1; page <= 80; page++) {
    let j;
    try {
      const r = await fetch('/api/streamer/' + encodeURIComponent(a.channel) + '/broadcasts?page=' + page, { credentials: 'same-origin' });
      if (r.status === 404) return { notTracked: true, list: out };
      if (!r.ok) return { error: 'HTTP ' + r.status, list: out };
      j = await r.json();
    } catch (_) { return { error: 'network', list: out }; }
    const d = Array.isArray(j && j.data) ? j.data : [];
    for (const b of d) out.push({ start: b.started_at, end: b.ended_at, title: b.title || '', msgs: b.message_count, live: !!b.is_live });
    const oldest = d.length ? Date.parse(d[d.length - 1].started_at) : null;
    if (!d.length || page >= (j.totalPages || 1) || (oldest != null && oldest < a.sinceMs)) break;
  }
  return { list: out };
}

// Every broadcast KickLogz captured for `channel` since `sinceMs` → [{ startMs, endMs, title, msgs }].
async function kicklogz_fetchBroadcasts(channel, sinceMs) {
  let tabId;
  try { tabId = await kicklogz_acquireTab(); } catch (_) { return []; }
  let res = null;
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: kicklogz_pageBroadcasts, args: [{ channel, sinceMs }] });
    res = r && r.result;
  } catch (e) { console.warn('[KWS Kick] KickLogz broadcast list failed', e?.message); }
  finally { kicklogz_releaseTab(); }
  if (!res) return [];
  if (res.error) console.warn('[KWS Kick] KickLogz broadcast list:', res.error);
  return (res.list || []).map((b) => {
    const startMs = Date.parse(b.start);
    const endMs = b.end ? Date.parse(b.end) : (b.live ? Date.now() : NaN);
    return { startMs, endMs, title: b.title, msgs: b.msgs };
  }).filter((b) => Number.isFinite(b.startMs) && Number.isFinite(b.endMs) && b.endMs > b.startMs);
}

// Broadcasts in [sinceMs, rangeEnd] that no Kick VOD covers (Pro archive) → sessions, newest first.
function kicklogz_archiveFrom(broadcasts, sinceMs, rangeEndMs, vodSessions) {
  return broadcasts.filter((b) => b.endMs >= sinceMs && b.startMs <= rangeEndMs
    && b.msgs !== 0 // nothing said → nothing to search (saves the searches)
    && !vodSessions.some((v) => b.startMs < v.endMs && b.endMs > v.startMs)) // a Kick VOD already covers it
    .map((b) => ({ vodId: null, vodSlug: null, vodSource: null, title: b.title, startMs: Math.max(b.startMs, sinceMs), endMs: Math.min(b.endMs, rangeEndMs), subOnly: false, archive: true }))
    .sort((a, b) => b.startMs - a.startMs);
}

// (kept for callers/tests) broadcasts in range ∩ last KICKLOGZ_ARCHIVE_DAYS that no Kick VOD covers
async function kicklogz_archiveSessions(channel, rangeStartMs, rangeEndMs, vodSessions) {
  const sinceMs = Math.max(rangeStartMs, Date.now() - KICKLOGZ_ARCHIVE_DAYS * 86400000);
  if (sinceMs >= rangeEndMs) return [];
  return kicklogz_archiveFrom(await kicklogz_fetchBroadcasts(channel, sinceMs), sinceMs, rangeEndMs, vodSessions);
}

// Every message kicklogz has for `channel` in [startMs, endMs] (one slice; pages newest → oldest).
// → { status: 'ok' | 'rate_limited' | 'error', messages, error? }  (messages may be partial)
async function kicklogz_fetchSlice({ tabRef, channel, startMs, endMs, shouldStop, onPage }) {
  const messages = [];
  const from = new Date(startMs).toISOString();
  const to = new Date(endMs).toISOString();
  let cursor = null;
  for (let page = 0; page < KICKLOGZ_MAX_PAGES; page++) {
    if (shouldStop && shouldStop()) return { status: 'error', error: 'stopped', messages };
    let r = null;
    for (let attempt = 0; attempt < 3; attempt++) {
      const usedTab = tabRef.id;
      try { r = await kicklogz_searchPage(usedTab, { channel, from, to, cursor }); } catch (e) { r = { error: e?.message || 'script' }; }
      if (r.hits || r.rateLimited) break;
      if (kicklogz_isTabGone(r.error)) { // the user closed the kicklogz tab: carry on in a new one
        tabRef.revived = (tabRef.revived || 0) + 1;
        if (tabRef.revived > 5) break; // never loop forever
        try { if (tabRef.id === usedTab) tabRef.id = await kicklogz_reviveTab(); } catch (_) {}
        attempt--; // a closed tab doesn't count as a failed attempt
      } else if (r.error === 'no-csrf') { // page not ready / Cloudflare check: reload once and retry
        try { await chrome.tabs.reload(tabRef.id); await kicklogz_waitComplete(tabRef.id); } catch (_) {}
      } else {
        await kws_sleep(1500 * (attempt + 1));
      }
    }
    if (r.rateLimited) {
      console.warn('[KWS Kick] KickLogz search limit reached — skipping the remaining subscriber-only VODs of this scan | page', page + 1, '| got', messages.length, 'msgs | server said:', r.detail || '(empty)');
      return { status: 'rate_limited', messages };
    }
    if (!r.hits) { console.warn('[KWS Kick] KickLogz search failed for', channel, from, r.error); return { status: 'error', error: r.error, messages }; }
    messages.push(...r.hits);
    if (typeof onPage === 'function') onPage(r.hits);
    const times = r.hits.map((h) => Date.parse(h.created_at)).filter(Number.isFinite);
    const oldest = times.length ? Math.min(...times) : null;
    if (!r.nextCursor || !r.hits.length || (oldest != null && oldest <= startMs)) return { status: 'ok', messages };
    cursor = r.nextCursor;
  }
  return { status: 'ok', messages };
}

async function kick_scanChannelRange({ channel, keyword, startDate, endDate, onStart, onProgress }) {
  const nc = kws_normalizeChannel(channel);
  kws_kickStopFlags.delete(nc);
  const stopFlag = () => kws_kickStopFlags.has(nc);

  const { keywords, excludeKeywords } = kws_resolveKeywords(keyword);

  // 1.2.5.20: a channel Kick no longer knows (renamed / deleted / banned → 404) may still be in
  // KickLogz under that name — with KickLogz Pro, search its past broadcasts instead of failing.
  let chatroomId = null;
  let kickGone = false;
  try {
    chatroomId = await kick_getChatroomId(nc);
  } catch (e) {
    if (e?.message !== 'KWS_ID_NOT_FOUND') throw e;
    let pro = false;
    try { pro = (await kicklogz_isEnabled()) && (await chrome.storage.local.get(KICKLOGZ_PLAN_KEY))[KICKLOGZ_PLAN_KEY] === 'pro'; } catch (_) {}
    if (!pro) throw e;
    kickGone = true;
    console.warn('[KWS Kick]', nc, 'not found on Kick — trying KickLogz broadcasts');
  }
  const sessions = kickGone ? [] : await kick_getVodSessions(nc, startDate, endDate);

  // 1.2.5.20: which VODs go where (see KICK_SOURCES). Subscriber-only VODs never go through the
  // bucket walk (Kick answers them with nothing). Newest first wherever KickLogz is involved, so a
  // free plan's small daily limit goes to recent VODs.
  const kickSource = await kick_getLogSource();
  const kicklogzEnabled = await kicklogz_isEnabled();
  const subOnlySessions = sessions.filter(v => v.subOnly).sort((a, b) => b.startMs - a.startMs);
  const publicSessions = sessions.filter(v => !v.subOnly);
  const useKicklogz = kicklogzEnabled && subOnlySessions.length > 0;
  let subOnlyMissed = useKicklogz ? 0 : subOnlySessions.length; // sub-only VODs left unchecked
  let kicklogzVods = 0;                                          // sub-only VODs searched via KickLogz
  let archiveVods = 0;                                           // Pro: past broadcasts without a Kick VOD, searched via KickLogz
  let archiveSessions = [];
  let publicKl = [];                                             // public VODs read from KickLogz (fast / KickLogz-only)
  let klPro = false;
  if (kicklogzEnabled) {
    try { klPro = (await chrome.storage.local.get(KICKLOGZ_PLAN_KEY))[KICKLOGZ_PLAN_KEY] === 'pro'; } catch (_) {}
    const rangeStartMs = new Date(`${startDate}T00:00:00.000Z`).getTime();
    const rangeEndMs = new Date(`${endDate}T23:59:59.999Z`).getTime();
    const wantPublic = kickSource === 'combined_fast' && publicSessions.length > 0;
    const archiveSinceMs = klPro ? Math.max(rangeStartMs, Date.now() - KICKLOGZ_ARCHIVE_DAYS * 86400000) : Infinity;
    let sinceMs = archiveSinceMs;
    if (kickSource === 'combined_fast' && wantPublic) sinceMs = Math.min(sinceMs, ...publicSessions.map(v => v.startMs));
    let broadcasts = [];
    if (Number.isFinite(sinceMs) && sinceMs < rangeEndMs) {
      try { broadcasts = await kicklogz_fetchBroadcasts(nc, sinceMs); } catch (_) { broadcasts = []; }
    }
    if (wantPublic) {
      // fast: only VODs KickLogz actually captured (with messages) — the rest stay on Kick's API
      publicKl = publicSessions.filter(v => broadcasts.some(b => b.msgs !== 0 && b.startMs < v.endMs && b.endMs > v.startMs));
      publicKl.sort((a, b) => b.startMs - a.startMs);
    }
    if (klPro && Number.isFinite(archiveSinceMs) && archiveSinceMs < rangeEndMs) {
      archiveSessions = kicklogz_archiveFrom(broadcasts, archiveSinceMs, rangeEndMs, sessions);
    }
  }
  const publicKlSet = new Set(publicKl);
  const nativeSessions = publicSessions.filter(v => !publicKlSet.has(v));
  let nativeBusy = nativeSessions.length > 0;
  let kicklogzBusy = false;

  let totalChunks = 0;
  const nativeChunkCount = (v) => Math.max(1, Math.ceil((v.endMs - v.startMs) / KICK_CHUNK_MS));
  nativeSessions.forEach(v => { totalChunks += nativeChunkCount(v); });
  // KickLogz work units = time slices (Pro) or whole VODs (Free), each paging through on its own
  const klSlices = [];
  if (kicklogzEnabled) {
    const sliceMs = klPro ? KICKLOGZ_SLICE_MS : Infinity;
    for (const session of [...subOnlySessions, ...publicKl, ...archiveSessions]) {
      for (let t = session.startMs; t < session.endMs; t += sliceMs) {
        klSlices.push({ session, start: t, end: Math.min(t + sliceMs, session.endMs) });
      }
    }
    totalChunks += klSlices.length;
  }
  const klFallback = []; // fast mode: public VODs KickLogz failed on → Kick's API afterwards

  if (typeof onStart === 'function') {
    onStart({
      totalDates: Math.max(1, totalChunks),
      channel: nc,
      keywords: keywords.map(k => k.substring ? '~' + k.word : k.word),
      excludeKeywords,
      resolvedEndDate: endDate,
      totalSessions: sessions.length + archiveSessions.length,
    });
  }

  const seenIds = new Set();
  const seenKeys = new Set();
  const groups  = {};      // localDate → group
  const allLines = [];
  let totalMatchedLines = 0;
  let doneChunks = 0;
  let failedChunks = 0;
  let lastProgressAt = 0;

  function handleMessage(m, session, source) {
    const id = m?.id;
    if (!id || seenIds.has(id)) return;
    seenIds.add(id);
    const message = m.content || '';
    if (!message) return;
    const username = m.sender?.username || m.sender?.slug || '?';
    const ts = m.created_at;
    // same message from both sources (KickLogz ids ≠ Kick ids): second + user + text
    const secKey = (ts ? String(Math.floor(Date.parse(ts) / 1000)) : '') + '|' + username.toLowerCase() + '|' + message;
    if (seenKeys.has(secKey)) return;
    seenKeys.add(secKey);

    const lower = message.toLowerCase();
    const hitKeywords = keywords.filter(({ word, substring }) =>
      substring ? lower.includes(word) : kws_matchesWholeWord(lower, word)
    ).map(({ word }) => word);
    const regexHit = kws_matchesIncludeRegex(message);
    if (!(hitKeywords.length || regexHit)) return;
    if (kws_isExcluded(message, excludeKeywords)) return;

    const effectiveHits = hitKeywords.length ? hitKeywords : ['regex'];
    const tsMs = ts ? new Date(ts).getTime() : null;
    const localDate = ts ? ts.slice(0, 10) : startDate;
    const offsetSec = (tsMs != null && session) ? Math.max(0, Math.round((tsMs - session.startMs) / 1000)) : null;
    const playbackTs = offsetSec != null ? kws_formatPlayback(offsetSec) : null;

    const item = {
      ts: ts ? new Date(ts).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }) : '?',
      rawTs: tsMs,
      localDate,
      keywords: effectiveHits,
      username,
      message,
      playback_offset: offsetSec,
      playback_ts: playbackTs,
      vod_id: session?.vodId || null,
      vod_slug: session?.vodSlug || null,
      // 1.2.5.21: subscriber-only VODs can't be played (and the .m3u8 guessed from their thumbnail can
      // point at a different VOD) — keep the VOD id for reference, no source, marked 'subonly'
      vod_source: session?.subOnly ? null : (session?.vodSource || null),
      ...(session?.subOnly ? { vod_state: 'subonly' } : {}),
      vod_channel: nc,
      vod_title: session?.title || null,
      // VOD 시작 시각(ms) — 다운로드 파일명의 "VOD Date" 필드용. 없으면 friendlyDate()가 빈 문자열을
      // 반환해서 "채널명--해상도.ts" 처럼 구분자가 겹쳐 보이는 문제가 생김.
      vod_timestamp: session?.startMs || null,
      // 1.2.5.20: 'kicklogz' for subscriber-only VODs filled in from KickLogz
      log_source: source === 'kicklogz' ? 'kicklogz' : 'kick-native',
      // Pro archive: a past broadcast whose Kick VOD is gone (side panel shows it like Twitch's "VOD expired")
      ...(session?.archive ? { vod_state: 'expired' } : {}),
    };

    allLines.push(`[${item.ts}] [${effectiveHits.join(', ')}] ${username}: ${message}`);
    totalMatchedLines++;
    if (!groups[localDate]) groups[localDate] = { date: localDate, displayDate: localDate, sourceDate: localDate, messages: [], channel: nc };
    const grp = groups[localDate];
    if (!Array.isArray(grp.sourceServices)) grp.sourceServices = [];
    if (!grp.sourceServices.includes(item.log_source)) grp.sourceServices.push(item.log_source);
    grp.messages.push(item);
  }

  function sendProgress(force) {
    if (typeof onProgress !== 'function') return;
    const now = Date.now();
    // 200ms(=채널당 초당 최대 5회)였는데, 채널이 여러 개 동시에 이 속도로 진행 메시지를 보내면
    // 매번 누적된 전체 matchedGroups(지금까지 찾은 모든 메시지)를 통째로 복제해서 보내다 보니
    // 탭/결과가 많아질수록 부담이 커짐 — 400ms로 완화. 화면 갱신 체감 차이는 거의 없음.
    if (!force && now - lastProgressAt < 400) return;
    lastProgressAt = now;
    onProgress({
      done: doneChunks, total: Math.max(1, totalChunks),
      percent: Math.min(100, Math.round(doneChunks / Math.max(1, totalChunks) * 100)),
      matchedDays: Object.keys(groups).length,
      matchedLines: totalMatchedLines,
      matchedGroups: Object.values(groups).sort((a, b) => a.date < b.date ? -1 : 1),
      keywords: keywords.map(k => k.word),
      excludeKeywords, channel: nc, resolvedEndDate: endDate,
      lines: allLines,
      failedChunks,
      subOnly: subOnlyMissed,
      kicklogzVods,
      archiveVods,
      kicklogzOn: useKicklogz,
      net: { native: nativeBusy, kicklogz: kicklogzBusy },
    });
  }

  if (!sessions.length && !archiveSessions.length) {
    if (kickGone) throw new Error('KWS_ID_NOT_FOUND'); // not in KickLogz either
    sendProgress(true); return { failedChunks: 0 };
  }

  // started before the native walk so both run at once; matches land in the same groups
  const klPass = (async () => {
    // 1.2.5.20: KickLogz part (sub-only VODs, fast-mode public VODs, Pro archive) — Free plan: one search at a time, whole VODs;
    // Pro plan: 20-minute slices through the shared adaptive pool (see KICKLOGZ_POOL)
    if (klSlices.length && !stopFlag()) {
      let kicklogzLimited = false;
      const vodState = new Map(); // session → { bad: bool }
      new Set(klSlices.map((sl) => sl.session)).forEach((v) => vodState.set(v, { bad: false }));
      let tabId = null;
      try { tabId = await kicklogz_acquireTab(); } catch (e) { console.warn('[KWS Kick] could not open kicklogz.com tab', e?.message); }
      if (tabId == null) {
        subOnlyMissed += subOnlySessions.length; // (archive broadcasts are a bonus — not counted as missed)
        if (kickSource === 'combined_fast') klFallback.push(...publicKl);
      } else {
        kicklogzBusy = true;
        sendProgress(true);
        const tabRef = { id: tabId }; // swapped for a new tab if the user closes this one
        const shouldStop = () => stopFlag() || kicklogzLimited;
        try {
          await kws_runSharedPool(klSlices, klPro ? KICKLOGZ_POOL : KICKLOGZ_FREE_POOL, async (sl) => {
            const st = vodState.get(sl.session);
            if (shouldStop()) { st.bad = true; doneChunks++; sendProgress(); return true; }
            const r = await kicklogz_fetchSlice({
              tabRef, channel: nc, startMs: sl.start, endMs: sl.end, shouldStop,
              // matches show up page by page instead of at the end of the slice
              onPage: (hits) => {
                for (const h of hits) handleMessage({ id: 'kl:' + h.id, content: h.content, sender: { username: h.username }, created_at: h.created_at }, sl.session, 'kicklogz');
                sendProgress();
              },
            });
            if (r.status === 'rate_limited') kicklogzLimited = true;
            if (r.status !== 'ok') st.bad = true;
            doneChunks++;
            sendProgress();
            return r.status === 'ok' || r.error === 'stopped';
          }, nc); // fair per channel
        } finally {
          kicklogz_releaseTab();
        }
        const stopped = stopFlag();
        for (const [sess, st] of vodState) {
          if (sess.archive) { if (!st.bad) archiveVods++; continue; }
          if (!sess.subOnly) { if (st.bad && !stopped && kickSource === 'combined_fast') klFallback.push(sess); continue; }
          if (!st.bad) kicklogzVods++;
          else if (!stopped) subOnlyMissed++;
        }
      }
      kicklogzBusy = false;
    }
  })().catch((e) => { console.warn('[KWS Kick] KickLogz pass failed', e?.message || e); kicklogzBusy = false; });

  async function walkNative(list) {
    for (const session of list) {
      if (stopFlag()) break;

      const chunks = [];
      for (let t = session.startMs; t < session.endMs; t += KICK_CHUNK_MS) {
        chunks.push({ start: t, end: Math.min(t + KICK_CHUNK_MS, session.endMs) });
      }

      // 5초 버킷 하나하나가 요청 1번이라 총 요청 수가 방송시간에 비례해서 매우 커짐
      // (예: 60일치 · 방송 144시간 ≈ 104,000 요청). 라이브로 동시 200개까지 붙여봐도
      // 전혀 지연/429 없이 다 200으로 응답하는 걸 확인해서 동시성을 공격적으로 높임 —
      // 그래도 kick_fetchChatBucket 쪽에 429/5xx 자동 백오프+재시도가 있어서 안전.
      // KICK_GLOBAL_POOL은 이 채널 하나만이 아니라 "지금 동시에 스캔 중인 모든 채널·세션"이
      // 함께 나눠쓰는 공유 세마포어라서, 여러 채널이 동시에 돌아도 실제 동시 요청 총량은
      // 항상 이 하나의 적응형 상한(성공하면 늘고 실패하면 확 줄어듦) 안에서만 움직임.
      await kws_runSharedPool(chunks, KICK_GLOBAL_POOL, async (chunk) => {
        if (stopFlag()) { doneChunks++; sendProgress(); return true; }
        let ok = true;
        let cursorTime = new Date(chunk.start);
        const guardMax = Math.ceil((chunk.end - chunk.start) / 5000) + 20; // 무한루프 방지용 안전장치
        let guard = 0;
        while (cursorTime.getTime() < chunk.end && guard++ < guardMax) {
          if (stopFlag()) break;
          let msgs;
          try {
            msgs = await kick_fetchChatBucket(chatroomId, cursorTime);
          } catch (e) {
            // kick_fetchChatBucket이 이미 내부적으로 5회 재시도한 뒤에도 실패한 것 — 그래도
            // 바로 포기하고 이 청크(최대 3분)의 나머지를 통째로 유실시키지 않도록, 여기서
            // 한 번 더 쉬었다가 같은 시각부터 재시도함. 예전엔 여기서 바로 break해서 그
            // 이후 시간대의 채팅이 전부 조용히 스킵됐는데(사용자에게 아무 표시도 안 됨),
            // 재시도까지 실패한 경우만 failedChunks로 집계해서 완료 메시지에 드러나게 함.
            await kws_sleep(3000);
            try {
              msgs = await kick_fetchChatBucket(chatroomId, cursorTime);
            } catch (e2) { ok = false; failedChunks++; console.warn('[KWS Kick] chat bucket fetch failed after retry for', nc, 'at', cursorTime.toISOString()); break; }
          }

          let maxMs = cursorTime.getTime() - 1; // sentinel — 메시지가 하나라도 있으면 반드시 갱신됨
          for (const m of msgs) {
            handleMessage(m, session);
            const tMs = m.created_at ? new Date(m.created_at).getTime() : null;
            if (tMs != null && tMs > maxMs) maxMs = tMs;
          }
          const candidate = kick_nextBucketDate(new Date(Math.max(maxMs, cursorTime.getTime())));
          // 항상 앞으로 전진하도록 보장 (메시지가 없거나 타임스탬프가 이상해도 멈추지 않음)
          cursorTime = candidate.getTime() > cursorTime.getTime() ? candidate : new Date(cursorTime.getTime() + 5000);
        }
        doneChunks++;
        sendProgress();
        return ok;
      }, nc); // fair per channel
    }
  }
  await walkNative(nativeSessions);
  nativeBusy = false;

  await klPass; // KickLogz runs alongside the native walk (different servers) — wait for it here

  // fast mode: VODs KickLogz couldn't deliver go through Kick's API after all
  if (klFallback.length && !stopFlag()) {
    console.warn('[KWS Kick]', nc, '— KickLogz failed on', klFallback.length, 'VOD(s); reading them from Kick instead');
    klFallback.sort((a, b) => b.startMs - a.startMs);
    klFallback.forEach((v) => { totalChunks += nativeChunkCount(v); });
    nativeBusy = true;
    sendProgress(true);
    await walkNative(klFallback);
    nativeBusy = false;
  }

  sendProgress(true);
  return { failedChunks, subOnly: subOnlyMissed, kicklogzVods, archiveVods };
}


// Fetch VOD schedule for a channel via Twitch GQL (uses browser credentials).
// Returns an array of {vodId, title, startMs, endMs} sorted by startMs ascending.
// Result is cached for 5 minutes per channel.
const kws_vodScheduleCache = new Map(); // channel -> {ts, vods}
const KWS_VOD_CACHE_TTL = 5 * 60 * 1000;

async function kws_fetchVodScheduleByType(nc, broadcastType, untilMs) {
  let allVods = [];
  let cursor = null;
  let guard = 0;
  const PAGE_GUARD_MAX = 20; // 안전장치 — 이 이상은 거의 나올 일 없음 (VOD 2000개 분량)
  while (guard++ < PAGE_GUARD_MAX) {
    const variables = cursor
      ? { limit: 100, channelOwnerLogin: nc, broadcastType, videoSort: "TIME", cursor }
      : { limit: 100, channelOwnerLogin: nc, broadcastType, videoSort: "TIME" };
    const body = JSON.stringify([{
      operationName: "FilterableVideoTower_Videos",
      variables,
      extensions: { persistedQuery: { version: 1, sha256Hash: "67004f7881e65c297936f32c75246470629557a393788fb5a69d6d9a25a8fd5f" } }
    }]);
    const res = await fetch("https://gql.twitch.tv/gql", {
      method: "POST",
      headers: { "content-type": "text/plain;charset=UTF-8", "client-id": "kimne78kx3ncx6brgo4mv6wki5h1ko" },
      referrer: "https://www.twitch.tv/",
      referrerPolicy: "strict-origin-when-cross-origin",
      credentials: "include",
      body,
    });
    if (!res.ok) { console.error('[KWS] VOD list HTTP error', { nc, broadcastType, status: res.status }); break; }
    const d = await res.json();
    const videosNode = d?.[0]?.data?.user?.videos;
    const edges = videosNode?.edges || [];
    if (!edges.length) {
      if (guard === 1) console.error('[KWS] VOD list: 0 edges on first page', { nc, broadcastType, raw: JSON.stringify(d)?.slice(0, 500) });
      break;
    }
    const pageVods = edges.map(e => {
      const node = e.node;
      const startMs = node?.publishedAt ? new Date(node.publishedAt).getTime() : null;
      const durationMs = node?.lengthSeconds ? node.lengthSeconds * 1000 : 0;
      if (!startMs) return null;
      return { vodId: node.id, title: node.title || '', startMs, endMs: startMs + durationMs, durationMs, broadcastType };
    }).filter(Boolean);
    allVods = allVods.concat(pageVods);

    const oldestOnPage = pageVods.length ? Math.min(...pageVods.map(v => v.startMs)) : null;
    const reachedTarget = untilMs != null && oldestOnPage != null && oldestOnPage <= untilMs;
    if (reachedTarget || !videosNode?.pageInfo?.hasNextPage) break;
    cursor = edges[edges.length - 1]?.cursor;
    if (!cursor) break;
  }
  return allVods;
}

async function kws_fetchVodSchedule(channel, untilMs) {
  const nc = kws_normalizeChannel(channel);
  const cached = kws_vodScheduleCache.get(nc);
  if (cached && Date.now() - cached.ts < KWS_VOD_CACHE_TTL && (!untilMs || cached.untilMs <= untilMs)) return cached.vods;

  try {
    // 일단 ARCHIVE만 (HIGHLIGHT/Sullygnome 추가는 문제 원인 격리 위해 임시로 뺌)
    const allVods = await kws_fetchVodScheduleByType(nc, "ARCHIVE", untilMs);
    const vods = allVods.sort((a, b) => a.startMs - b.startMs);
    kws_vodScheduleCache.set(nc, { ts: Date.now(), vods, untilMs: untilMs || 0 });
    return vods;
  } catch (e) {
    return null;
  }
}

// Given a UTC timestamp in ms, find the matching VOD and return playback offset in seconds.
// Returns null if no matching VOD found.
function kws_resolvePlaybackOffset(tsMs, vods) {
  if (!tsMs || !vods?.length) return null;
  // Allow 5-minute grace before VOD start (stream may start slightly before publishedAt)
  const GRACE = 5 * 60 * 1000;
  for (const vod of vods) {
    if (tsMs >= (vod.startMs - GRACE) && tsMs <= (vod.endMs + GRACE)) {
      const offsetMs = tsMs - vod.startMs;
      return { offsetSec: Math.max(0, Math.floor(offsetMs / 1000)), vodId: vod.vodId, vodTitle: vod.title };
    }
  }
  return null;
}

// Format seconds as H:MM:SS or M:SS
function kws_formatPlayback(sec) {
  if (sec == null || sec < 0) return null;
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  if (h > 0) return `${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  return `${m}:${String(s).padStart(2,'0')}`;
}

// Zonian은 여러 rustlog 인스턴스를 중계하는 집계 서버라서 매 요청이 한 단계 더 거침.
// /api/{channel} 한 번으로 (1) 로그가 존재하는 날짜 목록, (2) 그 채널 로그를 가진 원본
// 인스턴스 주소를 받아서, 날짜별 요청을 원본 인스턴스들에 분산해서 직접 보냄
// (인스턴스별로 레이트리밋이 따로라 총 처리량이 늘어남). 실패하면 Zonian으로 폴백.
const KWS_ZONIAN_BASE='https://logs.zonian.dev';
const kws_instancesByChannel=new Map();   // nc -> [baseUrl,...]
const kws_instanceBadUntil=new Map();     // baseUrl -> ms (일시 제외)
const kws_instanceFails=new Map();        // baseUrl -> 연속 실패 수
const kws_instanceCooldown=new Map();     // baseUrl -> 429 쿨다운 만료 ms
async function kws_fetchZonianChannelInfo(nc){
  const controller=new AbortController();
  const tid=setTimeout(()=>controller.abort(),8000);
  try{
    const res=await fetch(`${KWS_ZONIAN_BASE}/api/${encodeURIComponent(nc)}`,{signal:controller.signal,cache:"no-store"});
    let j=null;
    try{ j=await res.json(); }catch(_){}
    // 어떤 인스턴스에도 이 채널 로그가 없음 → 날짜별 요청이 전부 실패/재시도하며 오래 걸리므로 즉시 알림
    if(res.status===404 && j && /no channel logs/i.test(String(j.error||'')) && !(j?.channelLogs?.count>0)) return {noLogs:true,dates:null,instances:[]};
    if(!res.ok || !j) return null;
    const arr=Array.isArray(j?.loggedData?.list)?j.loggedData.list:null;
    const dates=new Set();
    if(arr) for(const a of arr) dates.add(`${+a.year}-${+a.month}-${+a.day}`);
    const inst=(Array.isArray(j?.channelLogs?.instances)?j.channelLogs.instances:[])
      .map(u=>String(u||'').replace(/\/+$/,'')).filter(u=>/^https:\/\/[a-z0-9.-]+$/i.test(u));
    return {dates:dates.size?dates:null,instances:inst};
  }catch(_){return null;}
  finally{clearTimeout(tid);}
}
const kws_instanceLat=new Map();          // baseUrl -> 지연시간 EWMA(ms)
function kws_noteLatency(base,ms){
  const prev=kws_instanceLat.get(base);
  kws_instanceLat.set(base,prev==null?ms:prev*0.7+ms*0.3);
}
function kws_pickLogBases(nc,dateStr){
  const all=kws_instancesByChannel.get(nc)||[];
  const now=Date.now();
  let good=all.filter(u=>(kws_instanceBadUntil.get(u)||0)<=now);
  if(!good.length) return [KWS_ZONIAN_BASE];
  // 가장 빠른 인스턴스 대비 2.5배 넘게 느린 곳은 후순위(날짜 분산 대상에서 제외)로 보냄
  const lat=u=>kws_instanceLat.has(u)?kws_instanceLat.get(u):0;
  const best=Math.min(...good.map(lat));
  const fast=good.filter(u=>lat(u)<=Math.max(best*2.5,best+1500));
  const slow=good.filter(u=>!fast.includes(u)).sort((a,b)=>lat(a)-lat(b));
  const k=(parseInt(dateStr.replace(/-/g,''),10)||0)%fast.length;
  return [...fast.slice(k),...fast.slice(0,k),...slow,KWS_ZONIAN_BASE];
}

// VOD 목록(GQL)에 없어서 재생 위치를 못 구한("Time error") 채팅을 Sullygnome 방송 기록 +
// Cloudfront 주소 추측으로 복구 시도. 성공하면 playback_offset/ts와 cdn_source(m3u8)를 채워서
// 클릭 즉시 재생되게 하고, 실패하면 vod_state로 이유를 남김:
//   'cdn' = Cloudfront에서 영상 확인됨 / 'expired' = 방송은 있었지만 CDN에 영상 없음(만료·삭제)
//   'nomatch' = Sullygnome 기록에도 없음(60일 이전 등) / 'unknown' = Sullygnome 조회 실패
const kws_cdnResolveCache=new Map(); // stream_id -> {source|null}
async function kws_recoverUnresolvedViaCloudfront(nc, groups, notify){
  const unresolved=[];
  for(const g of groups) for(const m of (g.rawMessages||[])) if(m.playback_offset==null) unresolved.push(m);
  if(!unresolved.length) return;
  if(notify) notify(`Checking Cloudfront for ${unresolved.length} unmatched message(s)...`);
  let streams=null;
  try{ streams=await getSullyStreamsData({channel_login:nc}); }catch(_){}
  if(!streams?.length){ unresolved.forEach(m=>{m.vod_state='unknown';}); return; }
  const byStream=new Map();
  for(const m of unresolved){
    const tsSec=Math.floor((kws_normalizeTimestampMs(m.rawTs)||0)/1000);
    let hit=null;
    if(tsSec){
      for(const st of streams){
        const sStart=st.timestamp_seconds ?? (st.timestamp?Math.floor(st.timestamp/1000):null);
        if(sStart==null) continue;
        const sDur=st.duration?Math.floor(st.duration/1000):18000;
        if(tsSec>=sStart-300 && tsSec<=sStart+sDur+300){ hit={st,sStart}; break; }
      }
    }
    if(!hit){ m.vod_state='nomatch'; continue; }
    const key=String(hit.st.stream_id);
    if(!byStream.has(key)) byStream.set(key,{st:hit.st,sStart:hit.sStart,msgs:[]});
    byStream.get(key).msgs.push({m,tsSec});
  }
  const entries=[...byStream.entries()];
  let i=0;
  async function worker(){
    while(i<entries.length){
      const [key,e]=entries[i++];
      let cached=kws_cdnResolveCache.get(key);
      if(!cached){
        let source=null;
        try{
          const r=await getStreamDetailsFromStreamId({channel_login:nc,stream_id:e.st.stream_id,timestamp:e.st.timestamp,timestamp_seconds:e.st.timestamp_seconds});
          source=r?.source||r?.url||null;
        }catch(_){}
        cached={source};
        if(source) kws_cdnResolveCache.set(key,cached); // 실패는 캐시하지 않음(일시 오류일 수 있음)
      }
      for(const {m,tsSec} of e.msgs){
        if(cached.source){
          const off=Math.max(0,tsSec-e.sStart);
          m.playback_offset=off; m.playback_ts=kws_formatPlayback(off);
          m.vod_id=key; m.vod_title='(CDN recovered)'; m.cdn_source=cached.source; m.vod_state='cdn';
        } else m.vod_state='expired';
      }
    }
  }
  await Promise.all([worker(),worker(),worker()]);
}

async function kws_scanChannelRange({channel,keyword,startDate,endDate,pageDate,logSource,onlyDates,onStart,onProgress,cancelToken}){
  const nc=kws_normalizeChannel(channel);
  if(!nc||!startDate)throw new Error("Channel and start date required.");
  const resolvedEndDate=kws_maxDateString(kws_format(new Date()),endDate,pageDate);
  const start=new Date(`${startDate}T00:00:00`);
  const end=new Date(`${resolvedEndDate}T23:59:59`);
  if(isNaN(start.getTime())||isNaN(end.getTime())||start>end)throw new Error("Invalid date range.");

  const {keywords, excludeKeywords} = kws_resolveKeywords(keyword);

  // Fetch VOD schedule for playback offset calculation (best-effort, non-blocking)
  const vodSchedule = await kws_fetchVodSchedule(nc).catch(() => null);
  if(!keywords.length) throw new Error("No keywords resolved.");

  const dates=[];
  if (Array.isArray(onlyDates)) {
    // Fast 모드에서 넘어온, VOD가 없는(=Native API로 커버 안 되는) 날짜만.
    dates.push(...onlyDates);
  } else {
    const cur=new Date(end);
    while(cur>=start){dates.push(kws_format(cur));cur.setDate(cur.getDate()-1);}
  }
  let kws_noLogsForChannel=false;
  // 로그가 없는 날짜는 요청 자체를 건너뛰고(오늘·어제는 그대로 요청), 원본 인스턴스 목록을 기억.
  {
    try{
      const info=await kws_fetchZonianChannelInfo(nc);
      if(info && info.noLogs){ kws_noLogsForChannel=true; dates.length=0; }
      else if(info){
        if(info.instances.length) kws_instancesByChannel.set(nc,info.instances);
        if(info.dates){
          const keepAfter=Date.now()-2*86400000;
          const filtered=dates.filter(d=>{
            const [y,m,dd]=d.split('-');
            if(info.dates.has(`${+y}-${+m}-${+dd}`)) return true;
            return Date.parse(d+'T00:00:00Z')>keepAfter;
          });
          dates.length=0; dates.push(...filtered);
        }
      }
    }catch(_){}
  }
  if(typeof onStart==="function") onStart({totalDates:dates.length,channel:nc,keywords:keywords.map(k=>k.substring?'~'+k.word:k.word),excludeKeywords,resolvedEndDate});
  if(kws_noLogsForChannel && typeof onProgress==="function") onProgress({done:0,total:0,percent:100,matchedDays:0,matchedLines:0,resolvedEndDate,failedDays:0,newGroups:[],activityNote:`No Zonian logs exist for "${nc}" (channel is not logged by any instance)`});

  const matchedGroups=[];
  const failedDates=[];
  let done=0,matchedDays=0,matchedLines=0,lastProgressAt=0,failedDays=0,lastSentGroupCount=0,currentRepassTotal=0;
  // dates.length만 분모로 쓰면, 실패한 날짜를 재시도(repass)하는 동안 done이 이미
  // dates.length에 도달해서 진행률이 "100%에서 오래 멈춰있는 것처럼" 보임. repass가
  // 필요해지면 그만큼 분모를 늘려서, 재시도 중에도 진행률이 100% 밑에서 계속 움직이게 함.
  let totalUnits=dates.length;

  // Zonian은 날짜당 JSON 하나만 받아오는 가벼운 요청이라(Native API의 VOD당
  // 여러 페이지짜리 채팅 페치보다 훨씬 가벼움) 고정 동시성 3은 너무 보수적이었음.
  // Native API와 같은 AIMD 적응형 풀로 바꿔서 안전하게 더 빠르게 긁어옴 —
  // 429/5xx가 나오면 kws_fetchMessagesForDate 자체 백오프 + 공유 쿨다운(위 참고)에
  // 더해 풀 동시성도 줄어듦. 최대치를 너무 높게(20) 잡았더니 레이트리밋을 세게
  // 유발해서(101일 중 48일 실패) 재시도까지 거쳐도 못 살아나는 사례가 있었음 —
  // 상한을 낮춰서 처음부터 덜 부딪히게 함.
  // 예전엔 여기서 채널마다 새 풀을 만들었는데(kws_createAdaptivePool), 그러면 이 max:12
  // 상한이 "채널 하나"에만 적용돼서 여러 채널을 동시에 Zonian으로 스캔하면 실제 동시 요청
  // 수가 채널 수만큼 곱절로 늘어날 수 있었음(Kick 쪽 과부하 버그와 같은 종류의 문제).
  // Kick처럼 모든 채널이 공유하는 전역 풀(ZONIAN_GLOBAL_POOL)을 쓰도록 바꿔서, 몇 개 채널을
  // 동시에 돌리든 logs.zonian.dev로 나가는 동시 요청 수가 항상 12 밑으로 유지되게 함.

  async function processDate(d, isRepass){
    let ok=true;
    try{
      const data=await kws_fetchMessagesForDate(nc,d,0,logSource);
      const lines=[],rawMessages=[];
      for(const chat of data){
        const message=kws_getMessageText(chat);
        if(!message)continue;
        const lower=message.toLowerCase();
        const hitKeywords=keywords.filter(({word, substring}) =>
          substring ? lower.includes(word) : kws_matchesWholeWord(lower, word)
        ).map(({word})=>word);
        const regexHit = kws_matchesIncludeRegex(message);
        if((hitKeywords.length||regexHit)&&!kws_isExcluded(message,excludeKeywords)){
          const effectiveHits = hitKeywords.length ? hitKeywords : ["икает/икнул"];
          const rawTs=kws_getTimestamp(chat);
          const ts=kws_formatTimestamp(rawTs);
          const localDate=kws_localDateFromTimestamp(rawTs);
          lines.push(`[${ts}] [${effectiveHits.join(", ")}] ${kws_getUsername(chat)}: ${message}`);
          const pbRes = kws_resolvePlaybackOffset(kws_normalizeTimestampMs(rawTs), vodSchedule);
          rawMessages.push({ts,rawTs,localDate,keywords:effectiveHits,username:kws_getUsername(chat),message,
            playback_offset: pbRes?.offsetSec ?? null,
            playback_ts: pbRes ? kws_formatPlayback(pbRes.offsetSec) : null,
            vod_id: pbRes?.vodId ?? null,
            vod_title: pbRes?.vodTitle ?? null,
          });
        }
      }
      if(lines.length){
        matchedDays++;matchedLines+=lines.length;
        const localDates=rawMessages.map(r=>r.localDate).filter(Boolean);
        const displayDate=localDates[0]||d;
        matchedGroups.push({date:displayDate,sourceDate:d,displayDate,lines,rawMessages,source:'external',sourceServices:data._sources||[logSource]});
      }
      if(isRepass){
        const fi=failedDates.indexOf(d);
        if(fi>=0){failedDates.splice(fi,1);failedDays--;}
      }
    }catch(e){failedDays++;failedDates.push(d);ok=false;}
    finally{
      done++;
      const now=Date.now();
      if((now-lastProgressAt>200||done===totalUnits)&&typeof onProgress==="function"){
        lastProgressAt=now;
        // Send newly matched groups since last progress (for real-time display)
        const newGroups=matchedGroups.slice(lastSentGroupCount);
        lastSentGroupCount=matchedGroups.length;
        onProgress({done,total:totalUnits,percent:Math.min(100,Math.round(done/totalUnits*100)),matchedDays,matchedLines,resolvedEndDate,failedDays,newGroups,activityNote:isRepass?`retrying ${currentRepassTotal} failed date(s)...`:undefined});
      }
    }
    return ok;
  }
  await kws_runSharedPool(dates, ZONIAN_GLOBAL_POOL, (d)=>cancelToken?.cancelled ? true : processDate(d,false), nc); // fair per channel
  if(cancelToken?.cancelled) throw new Error('Cancelled');
  // 재시도까지 다 거치고도 실패한 날짜가 있으면, 잠깐 쉬었다가 그 날짜들만 한 번 더 시도
  // (일시적 부하/레이트리밋이었을 가능성이 높아서, 시간을 좀 두면 성공할 때가 많음).
  // 레이트리밋이 심하게 걸렸던 경우 한 번의 재시도로는 부족할 수 있어서, 남은 게
  // 있으면 대기 시간을 늘려가며(2초→5초→10초) 최대 3라운드까지 반복함.
  const REPASS_DELAYS_MS=[2000,5000,10000];
  for(let round=0; round<REPASS_DELAYS_MS.length && failedDates.length; round++){
    const repassDates=failedDates.slice();
    currentRepassTotal=repassDates.length;
    totalUnits+=repassDates.length; // 분모를 늘려서 재시도 중에도 진행률이 100% 밑에서 보이게 함
    if(typeof onProgress==="function"){
      onProgress({done,total:totalUnits,percent:Math.min(100,Math.round(done/totalUnits*100)),matchedDays,matchedLines,resolvedEndDate,failedDays,newGroups:[],activityNote:`retrying ${repassDates.length} failed date(s)... (round ${round+1}/${REPASS_DELAYS_MS.length})`});
    }
    await kws_sleep(REPASS_DELAYS_MS[round]);
    const repassPool = kws_createAdaptivePool({ initial: Math.min(3, repassDates.length), min: 1, max: 6, growEvery: 3 });
    await kws_runPool(repassDates, repassPool, (d)=>cancelToken?.cancelled ? true : processDate(d,true));
    if(cancelToken?.cancelled) throw new Error('Cancelled');
  }
  try{
    await kws_recoverUnresolvedViaCloudfront(nc,matchedGroups,(note)=>{
      if(typeof onProgress==="function") onProgress({done,total:totalUnits,percent:100,matchedDays,matchedLines,resolvedEndDate,failedDays,newGroups:[],activityNote:note});
    });
  }catch(_){}
  matchedGroups.sort((a,b)=>b.date.localeCompare(a.date));

  const header=[`Channel: ${nc}`,`Keywords: ${keywords.slice(0,8).join(", ")}${keywords.length>8?" ...":""}`,`Exclude: ${excludeKeywords.join(", ")||"none"}`,`Range: ${startDate} -> ${resolvedEndDate}`].join("\n");
  const body=matchedGroups.map(g=>`===== ${g.date} =====\n`+g.lines.join("\n")).join("\n\n");
  const text=body?`${header}\n\n${body}`:`${header}\n\nNo matches found.`;
  const filename=`twitch_kws_${kws_sanitizeFilePart(nc)}_${kws_sanitizeFilePart(startDate)}_to_${kws_sanitizeFilePart(resolvedEndDate)}.txt`;

  return{channel:nc,keywords:keywords.map(k=>k.substring?'~'+k.word:k.word),excludeKeywords,resolvedEndDate,total:dates.length,matchedDays,matchedLines,failedDays,filename,text,
    matchedGroups:matchedGroups.map(g=>({date:g.date,lines:g.lines,rawMessages:g.rawMessages,sourceDate:g.sourceDate,displayDate:g.displayDate,source:g.source,sourceServices:g.sourceServices}))};
}

// ══════════════════════════════════════════════════════════════════════
//  KWS — Twitch VOD 채팅 직접 스캔 (Native API)
//
//  Twitch의 VOD 채팅 리플레이(VideoCommentsByOffsetOrCursor)는 Client-Integrity
//  안티봇 체크로 보호되는데, 우리가 직접 토큰을 계산해서 보내면 막힘
//  ("failed integrity check"). 대신 실제 twitch.tv 페이지가 스스로 만들어낸
//  진짜 토큰을 "빌려서" 재사용하면 통과함 (2026-09 실제 브라우저 테스트로 확인).
//
//  흐름:
//   1) 백그라운드 숨김 탭으로 twitch.tv를 잠깐 열어서
//      content script(twitchIntegrityMain.js)가 페이지 자신의 gql 요청에서
//      Client-Integrity 헤더 세트를 가로챔
//   2) postMessage → twitchIntegrityBridge.js → background로 릴레이
//   3) 캐싱해뒀다가 VOD 채팅 페이지네이션 요청에 재사용 (일정 시간 지나면 재채취)
// ══════════════════════════════════════════════════════════════════════

const KWS_VOD_CHAT_QUERY_HASH = 'b70a3591ff0f4e0313d126c6a1502d79a1c02baebb288227c582044aa76adf6a';
const KWS_INTEGRITY_TTL_MS = 20 * 60 * 1000; // 20분 (안전하게 보수적으로)
const KWS_INTEGRITY_HARVEST_TIMEOUT_MS = 20000;
let kws_integrityBundle = null; // {clientId, deviceId, clientVersion, sessionId, integrity, capturedAt}
let kws_integrityWaiters = []; // 채취 대기 중인 resolve 콜백들

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'KWS_INTEGRITY_TOKEN' && msg.bundle) {
    kws_integrityBundle = msg.bundle;
    const waiters = kws_integrityWaiters; kws_integrityWaiters = [];
    waiters.forEach(fn => { try { fn(msg.bundle); } catch(e) {} });
  }
});


// 실제 GQL 요청은 이제 background.js에서 직접 쏘지 않는다 — 실제 브라우저로 재현 테스트한
// 결과, background(service worker)에서 쏘는 fetch에는 브라우저가 강제로
// `Origin: chrome-extension://<id>`를 붙이는데(JS로는 절대 덮어쓸 수 없는 forbidden
// header) Twitch 쪽에서 이 Origin을 보고 요청 자체를 차단하는 것으로 보임 (토큰이
// 진짜여도 100% "failed integrity check"). 반면 같은 토큰을 무관한 사이트의 평범한
// 페이지에서 쏘면 성공 — 즉 문제는 토큰이 아니라 실행 위치(Origin)였음.
// 그래서 채취용 탭을 스캔 끝날 때까지 열어두고, 실제 GQL 요청은 그 탭(진짜
// https://www.twitch.tv Origin) 안에서 실행하도록 바꿈 — background.js는
// chrome.tabs.sendMessage로 "이 VOD, 이 커서로 조회해줘"라고 시키고, 그 탭의
// MAIN-world 스크립트(twitchIntegrityMain.js)가 실제 fetch를 실행해서 결과만
// ISOLATED-world 브릿지(twitchIntegrityBridge.js)를 거쳐 돌려준다.
let kws_harvestTabId = null;

chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === kws_harvestTabId) kws_harvestTabId = null;
});

// 숨김 탭을 열어서 진짜 Client-Integrity 토큰을 채취하고, 그 탭을 계속 열어둔 채로
// tabId를 반환한다 (탭 자체가 이후 VOD 채팅 조회 RPC의 실행 장소가 됨).
// 이미 신선한 토큰 + 열려있는 탭이 있으면 바로 그 tabId를 반환.
//
// 중요: 그냥 twitch.tv 홈페이지를 열면 안 됨 — 실제 브라우저로 확인해보니 홈페이지는
// Client-Integrity가 붙는 gql 요청을 안정적으로/반복적으로 쏘지 않아서 채취 타임아웃 나는
// 경우가 있었음. 반면 VOD 시청 페이지는 로드되자마자 100% 확실하게 우리가 필요로 하는 바로
// 그 쿼리(VideoCommentsByOffsetOrCursor, 채팅 리플레이)를 스스로 호출하기 때문에 훨씬 안정적.
// 그래서 seedVodId가 있으면 그 VOD의 시청 페이지를 열어서 채취한다.

// 스캔 전체가 끝나면 (성공/실패 무관) 호출해서 채취용 탭을 정리

// VOD 채팅 한 페이지 조회 (offset 또는 cursor 기준). 실제 fetch는 background.js가 아니라
// tabId가 가리키는 실제 twitch.tv 탭의 MAIN world 안에서 실행된다.
//
// 처음엔 chrome.tabs.sendMessage로 그 탭의 content script(twitchIntegrityBridge.js)에
// "이 VOD 조회해줘"를 보내고 postMessage로 페이지에 릴레이하는 방식을 썼는데, 실제로
// 매번 "Could not establish connection. Receiving end does not exist" 오류로 실패했음
// (content-script 메시지 리스너 기반이라 타이밍/컨텍스트 문제에 취약). 그래서
// chrome.scripting.executeScript({world:'MAIN', ...})로 그 탭 안에서 직접
// twitchIntegrityMain.js가 노출해둔 window.__kwsFetchVodComments()를 호출하고
// 반환값(Promise)을 그대로 결과로 받는 방식으로 바꿈 — 이 방식은 content-script
// onMessage 리스너에 의존하지 않아서 훨씬 안정적이다 (manifest.json에 "scripting"
// 권한과 https://www.twitch.tv/* host_permissions는 이미 있음).

// ── 적응형 요청 텀 ────────────────────────────────────────────────────
// 실패(특히 "failed integrity check")가 나면 즉시 텀을 확 늘리고, 성공이 계속되면
// 서서히 줄여서 원래 속도로 돌아옴 — 매번 고정된 딜레이를 쓰는 대신 실제 반응을 보고
// 스스로 속도를 조절함. 세션(=background.js 살아있는 동안) 전체에서 공유되는 값이라
// 한 채널 스캔 중에 배운 "안전 속도"가 다음 채널/스캔에도 이어짐.
let kws_twitchThrottleMs = 250;
const KWS_TWITCH_THROTTLE_MIN = 150;
const KWS_TWITCH_THROTTLE_MAX = 15000;

// VOD 하나의 채팅을 전체(또는 지정 구간)까지 페이지네이션해서 다 가져옴.
// untilMs를 넘어서는 시점이 나오면 조기 종료 (더 이상 볼 필요 없음).
// tabId가 중간에 재채취로 바뀔 수 있어서 {messages, tabId}로 최신 tabId도 같이 반환.

// ── 진짜 원인/해결책을 실제 브라우저에서 직접 실험해서 찾음 ──────────────────
// 지금까지 시도한 것들(숨김 탭 토큰 훔치기, 로그인 쿠키+credentials:include)은
// 전부 "failed integrity check"로 막혔는데, 실제 브라우저 콘솔에서 하나씩 떼어보니:
//  - variables에 `cursor`를 넣어서 페이지네이션하는 요청 → integrity 체크 걸림
//  - variables에 `contentOffsetSeconds`(오프셋)만 넣는 요청 → **credentials 없이,
//    client-id 헤더 하나만으로 15번 연속 호출해도 전혀 안 걸리고 정상적으로 채팅이
//    나옴** (실측: VOD 하나에서 15페이지 연속, 676개 메시지, 에러 0개).
// 즉 Twitch는 "cursor 기반 이어보기"만 봇 행위로 의심해서 막고, "특정 시점 오프셋
// 조회"는 그냥 통과시킴. 그래서 cursor를 아예 쓰지 않고, 매번 방금 받은 마지막
// 메시지의 시점(offset) 다음부터 다시 조회하는 방식으로 페이지네이션을 대체함.
// 이러면 Client-Integrity 토큰도, 로그인 쿠키도, 숨김 탭도 전혀 필요 없어짐 —
// background.js에서 바로 fetch 한 번이면 끝.
async function kws_fetchVodCommentsByOffset(vodId, offsetSeconds) {
  const body = JSON.stringify([{
    operationName: 'VideoCommentsByOffsetOrCursor',
    variables: { videoID: String(vodId), contentOffsetSeconds: offsetSeconds || 0 },
    extensions: { persistedQuery: { version: 1, sha256Hash: KWS_VOD_CHAT_QUERY_HASH } },
  }]);
  // fetch() 자체엔 타임아웃이 없어서, 네트워크가 응답을 아예 안 주는 상황(TCP 단에서
  // 조용히 막히거나 서비스 워커가 잠깐 맛이 가는 경우 등)이 오면 이 호출 하나가
  // Promise를 영원히 안 끝내서 스캔 전체가 "멈춘 것처럼" 보일 수 있음. AbortController로
  // 20초 타임아웃을 걸어서, 응답이 안 오면 에러로 떨어지게 하고 재시도/스킵이 가능하게 함.
  const ac = new AbortController();
  const timeoutId = setTimeout(() => ac.abort(), 20000);
  try {
    const res = await fetch('https://gql.twitch.tv/gql', {
      method: 'POST',
      headers: { 'client-id': 'kimne78kx3ncx6brgo4mv6wki5h1ko', 'content-type': 'text/plain;charset=UTF-8' },
      body,
      signal: ac.signal,
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const j = await res.json();
    if (j?.[0]?.errors?.length) {
      const msg = j[0].errors.map(e => e.message).join('; ');
      throw new Error(msg || 'GQL error');
    }
    return j?.[0]?.data?.video?.comments || null;
  } catch (e) {
    if (e?.name === 'AbortError') throw new Error('요청 타임아웃(20초) — 응답 없음');
    throw e;
  } finally {
    clearTimeout(timeoutId);
  }
}

async function kws_fetchVodChatAllViaCookies(tokens, vodId, {untilMs, onPageProgress} = {}) {
  const out = [];
  let offset = 0;
  let guard = 0;
  const PAGE_GUARD_MAX = 3000; // 안전장치 (매우 긴 VOD 대비)
  while (guard++ < PAGE_GUARD_MAX) {
    const page = await kws_fetchVodCommentsByOffset(vodId, offset);
    if (!page) break;
    const edges = page.edges || [];
    if (!edges.length) break;
    for (const edge of edges) {
      const node = edge?.node;
      if (!node) continue;
      const text = (node.message?.fragments || []).map(f => f.text || '').join('');
      out.push({ message: text, username: node.commenter?.displayName || node.commenter?.login || 'unknown', timestamp: node.createdAt });
    }
    // 페이지 하나 끝날 때마다 진행 상황을 알려줌 — 채팅이 아주 많은 VOD는 페이지가
    // 수백 개일 수 있어서, VOD 전체가 끝날 때까지 아무 신호도 없으면 멈춘 것처럼
    // 보이는 문제가 있었음.
    if (typeof onPageProgress === 'function') onPageProgress({ page: guard, offsetSeconds: offset, totalSoFar: out.length });
    const lastEdge = edges[edges.length - 1];
    const lastTs = lastEdge?.node?.createdAt;
    if (untilMs && lastTs && new Date(lastTs).getTime() > untilMs) break;
    if (!page.pageInfo?.hasNextPage) break;
    const lastOffset = lastEdge?.node?.contentOffsetSeconds;
    // 다음 오프셋이 그대로거나 뒤로 가면(이상 데이터) 무한루프 방지로 강제 전진
    offset = (typeof lastOffset === 'number' && lastOffset > offset) ? lastOffset + 1 : offset + 60;
    // (텀 없이 바로 다음 페이지 요청 — offset 기반 쿼리는 credentials/integrity 둘 다
    // 필요 없고 레이트리밋도 안 걸리는 것으로 실측 확인됨. 페이지 자체가 순차적일
    // 수밖에 없어서(다음 offset이 이전 응답에 달려있음) 여기 텀은 순수 낭비 시간이었음)
  }
  return out;
}

// ── 적응형 동시성 풀 ──────────────────────────────────────────────────
// 고정 개수(예: 5개)로 못 박는 대신, 성공이 계속되면 동시성을 계속 늘리고
// (VOD끼리는 서로 완전히 독립적인 요청이라 병렬화해도 안전 — offset 쿼리는
// integrity/레이트리밋 둘 다 안 걸리는 것으로 실측 확인됨), 429/5xx나 네트워크
// 에러가 나면 즉시 확 줄이는 방식(TCP 혼잡회피와 비슷한 AIMD). 채널마다 VOD가
// 몇 개든, 실제로 얼마나 버티는지 스스로 찾아가며 "가능한 최대"로 올라감.
function kws_createAdaptivePool({ initial = 5, min = 2, max = 40, growEvery = 3 } = {}) {
  let concurrency = initial;
  let streak = 0;
  return {
    get concurrency() { return concurrency; },
    reportSuccess() {
      streak++;
      if (streak >= growEvery && concurrency < max) { concurrency++; streak = 0; }
    },
    reportFailure() {
      streak = 0;
      concurrency = Math.max(min, Math.floor(concurrency * 0.6));
    },
  };
}

// worker(item, poolState)는 성공 시 true(또는 undefined), 실패 시 false를
// 반환해야 함 — 그 값으로 풀의 동시성을 늘리거나 줄임. poolState.concurrency /
// poolState.inFlight로 지금 상태를 읽어서 onProgress에 실어 보낼 수 있음.
async function kws_runPool(items, pool, worker) {
  let idx = 0;
  let activeCount = 0;
  const poolState = { inFlight: 0, concurrency: pool.concurrency };
  return new Promise((resolve) => {
    function pump() {
      while (activeCount < pool.concurrency && idx < items.length) {
        const item = items[idx++];
        activeCount++;
        poolState.inFlight = activeCount;
        poolState.concurrency = pool.concurrency;
        Promise.resolve().then(() => worker(item, poolState))
          .then((ok) => { if (ok === false) pool.reportFailure(); else pool.reportSuccess(); })
          .catch(() => pool.reportFailure())
          .finally(() => {
            activeCount--;
            poolState.inFlight = activeCount;
            poolState.concurrency = pool.concurrency;
            if (idx >= items.length && activeCount === 0) resolve();
            else pump();
          });
      }
    }
    pump();
  });
}

// 채널의 지정 기간에 걸친 VOD들을 순회하며 각 VOD의 채팅을 직접 긁어서 키워드 매칭.
// kws_scanChannelRange와 같은 모양의 matchedGroups를 만들어서 합치기 쉽게 함.
async function kws_scanChannelRangeViaTwitch({channel, keyword, startDate, endDate, pageDate, twitchTokens, onStart, onProgress, onSuspectDates, cancelToken}) {
  const nc = kws_normalizeChannel(channel);
  if (!nc || !startDate) throw new Error('Channel and start date required.');
  const resolvedEndDate = kws_maxDateString(kws_format(new Date()), endDate, pageDate);
  const start = new Date(`${startDate}T00:00:00`);
  const end = new Date(`${resolvedEndDate}T23:59:59`);
  if (isNaN(start.getTime()) || isNaN(end.getTime()) || start > end) throw new Error('Invalid date range.');

  const { keywords, excludeKeywords } = kws_resolveKeywords(keyword);
  if (!keywords.length) throw new Error('No keywords resolved.');

  // (더 이상 로그인 쿠키/토큰이 필요 없음 — kws_fetchVodChatAllViaCookies 위쪽 주석 참고)

  const allVods = await kws_fetchVodScheduleByType(nc, 'ARCHIVE', start.getTime());
  const vods = allVods
    .filter(v => v.endMs >= start.getTime() && v.startMs <= end.getTime())
    .sort((a, b) => b.startMs - a.startMs);

  if (typeof onStart === 'function') onStart({ totalDates: vods.length, channel: nc, keywords: keywords.map(k => k.substring ? '~' + k.word : k.word), excludeKeywords, resolvedEndDate, mode: 'twitch' });

  console.log(`[KWS] twitch scan: ${nc} — VOD 목록 ${allVods.length}개 중 기간 내 ${vods.length}개 대상`);
  if (!vods.length) {
    console.log(`[KWS] twitch scan: ${nc} — 해당 기간에 VOD가 없음 (한국 스트리머면 2023-02 이후 VOD 미생성 이슈일 수 있음)`);
    return { channel: nc, keywords: keywords.map(k => k.substring ? '~' + k.word : k.word), excludeKeywords, resolvedEndDate, total: 0, matchedDays: 0, matchedLines: 0, failedDays: 0, matchedGroups: [] };
  }

  const groupsByDate = new Map();
  let done = 0, matchedLines = 0, failedDays = 0;

  // MV3 서비스 워커는 한동안 크롬 API 호출이 없으면 중간에 잠들 수 있음 — 스캔이
  // 긴 VOD 하나를 계속 fetch만 하고 있으면(다른 크롬 API 호출 없이) 안전하다고
  // 보장할 수 없어서, 스캔 도중엔 20초마다 가벼운 storage 호출로 깨어있게 유지함.
  const kwsKeepAliveTimer = setInterval(() => { try { chrome.storage.local.get(['__kws_keepalive'], () => {}); } catch (e) {} }, 20000);

  // VOD를 적응형 동시성 풀로 병렬 처리 — 5개로 시작해서 계속 잘 되면 스스로
  // 계속 늘리고(3연속 성공마다 +1, 최대 40), 에러가 나면 즉시 확 줄임(×0.6).
  // 채널마다 VOD가 몇 개든 "가능한 최대"를 스스로 찾아감.
  const kwsPool = kws_createAdaptivePool({ initial: 15, min: 5, max: 60, growEvery: 2 });
  try {
    await kws_runPool(vods, kwsPool, async (vod, poolState) => {
      if (cancelToken?.cancelled) return true;
      let ok = true;
      let rawMsgCount = 0;
      try {
        const rawMsgs = await kws_fetchVodChatAllViaCookies(twitchTokens, vod.vodId, {
          untilMs: end.getTime(),
          // 채팅이 아주 많은 VOD는 한 VOD 안에서만 페이지가 수백 개일 수 있어서,
          // VOD 전체가 끝날 때까지 아무 신호가 없으면 "멈춘 것처럼" 보이는 문제가
          // 있었음 — 15페이지마다 콘솔 로그 + 화면 STATUS에 진행 중 표시를 남김
          // (matchedLines/결과 목록은 안 건드리고 상태 텍스트만 갱신).
          onPageProgress: (p) => {
            if (p.page % 15 !== 0) return;
            console.log(`[KWS] twitch scan: vod=${vod.vodId} — 진행 중... page ${p.page}, offset ${p.offsetSeconds}s, 누적 ${p.totalSoFar}개`);
            if (typeof onProgress === 'function') {
              onProgress({
                done, total: vods.length, percent: Math.min(100, Math.round(done / Math.max(1, vods.length) * 100)),
                matchedDays: groupsByDate.size, matchedLines, resolvedEndDate, failedDays,
                newGroups: [], replaceGroups: false,
                concurrency: poolState.concurrency, inFlight: poolState.inFlight,
                activityNote: `vod ${vod.vodId}: page ${p.page} (${p.totalSoFar} msgs)`,
              });
            }
          },
        });
        // offset 기반 페이지네이션이 페이지 경계에서 같은 메시지를 두 번 돌려줄 때가
        // 있음(같은 초에 여러 메시지가 몰려있는 경우 등 실제로 확인됨) — VOD 하나
        // 안에서 내용 기준으로 한 번 걸러줌.
        const dedupedMsgs = kws_dedupeMessagesByContent(rawMsgs);
        if (dedupedMsgs.length !== rawMsgs.length) {
          console.log(`[KWS] twitch scan: vod=${vod.vodId} — 페이지 경계 중복 ${rawMsgs.length - dedupedMsgs.length}개 제거`);
        }
        console.log(`[KWS] twitch scan: vod=${vod.vodId} (${vod.title?.slice(0,30)}) — 채팅 ${dedupedMsgs.length}개 수신`);
        rawMsgCount = dedupedMsgs.length;
        for (const chat of dedupedMsgs) {
          const rawTs = kws_getTimestamp(chat);
          const tsMs = kws_normalizeTimestampMs(rawTs);
          if (tsMs == null || tsMs < start.getTime() || tsMs > end.getTime()) continue;
          const message = kws_getMessageText(chat);
          if (!message) continue;
          const lower = message.toLowerCase();
          const hitKeywords = keywords.filter(({word, substring}) => substring ? lower.includes(word) : kws_matchesWholeWord(lower, word)).map(({word}) => word);
          const regexHit = kws_matchesIncludeRegex(message);
          if (!(hitKeywords.length || regexHit) || kws_isExcluded(message, excludeKeywords)) continue;
          const effectiveHits = hitKeywords.length ? hitKeywords : ['икает/икнул'];
          const ts = kws_formatTimestamp(rawTs);
          const localDate = kws_localDateFromTimestamp(rawTs) || kws_format(new Date(tsMs));
          const offsetSec = Math.max(0, Math.floor((tsMs - vod.startMs) / 1000));
          const line = `[${ts}] [${effectiveHits.join(', ')}] ${kws_getUsername(chat)}: ${message}`;
          const rawMessage = {
            ts, rawTs, localDate, keywords: effectiveHits, username: kws_getUsername(chat), message,
            playback_offset: offsetSec, playback_ts: kws_formatPlayback(offsetSec),
            vod_id: vod.vodId, vod_title: vod.title,
          };
          if (!groupsByDate.has(localDate)) groupsByDate.set(localDate, { date: localDate, sourceDate: localDate, displayDate: localDate, lines: [], rawMessages: [], source: 'internal', sourceServices: ['twitch'] });
          const g = groupsByDate.get(localDate);
          g.lines.push(line);
          g.rawMessages.push(rawMessage);
          matchedLines++;
        }
      } catch (e) {
        failedDays++;
        ok = false;
        console.warn(`[KWS] twitch VOD chat fetch failed for ${nc} vod=${vod.vodId}:`, e);
      } finally {
        // VOD 자체는 있는데(fetch가 실패했거나) 채팅이 0개로 나오면, 그게 진짜로
        // 조용한 방송이었는지 아니면 Twitch replay 쪽 데이터가 빠진 건지 알 수 없음
        // — Fast 모드가 이런 날짜를 놓치지 않게, "의심되는 날짜"로 보고함
        // (호출한 쪽이 Zonian으로 한 번 더 확인함).
        if ((!ok || rawMsgCount === 0) && typeof onSuspectDates === 'function') {
          const lo = Math.max(vod.startMs, start.getTime());
          const hi = Math.min(vod.endMs, end.getTime());
          if (hi >= lo) onSuspectDates(kws_datesForRange(lo, hi));
        }
        done++;
        if (typeof onProgress === 'function') {
          // VOD를 병렬로 도는 구조라 "이번 틱에 새로 완성된 날짜"를 계산하기
          // 애매함(한 날짜에 여러 VOD가 걸쳐있을 수 있고 완료 순서도 뒤섞임) —
          // 그래서 매 틱마다 지금까지 모인 전체 그룹 스냅샷을 그대로 보내고,
          // UI 쪽에서 통째로 교체 렌더링하게 함(replaceGroups:true).
          // (이전엔 newGroups를 항상 빈 배열로 보내서 STATUS 숫자는 올라가는데
          // 정작 Results 목록엔 스캔이 끝날 때까지 아무것도 안 뜨던 버그였음)
          const snapshot = Array.from(groupsByDate.values())
            .map(g => {
              const sortedMsgs = [...g.rawMessages].sort((a, b) => (a.rawTs && b.rawTs) ? (new Date(a.rawTs) - new Date(b.rawTs)) : 0);
              return { ...g, rawMessages: sortedMsgs, lines: sortedMsgs.map(r => `[${r.ts}] [${(r.keywords||[]).join(', ')}] ${r.username}: ${r.message}`) };
            })
            .sort((a, b) => b.date.localeCompare(a.date));
          onProgress({ done, total: vods.length, percent: Math.min(100, Math.round(done / Math.max(1, vods.length) * 100)), matchedDays: groupsByDate.size, matchedLines, resolvedEndDate, failedDays, newGroups: snapshot, replaceGroups: true, concurrency: poolState.concurrency, inFlight: poolState.inFlight });
        }
      }
      return ok;
    });
  } finally {
    clearInterval(kwsKeepAliveTimer);
  }
  if (cancelToken?.cancelled) throw new Error('Cancelled');

  const matchedGroups = Array.from(groupsByDate.values()).sort((a, b) => b.date.localeCompare(a.date));

  return { channel: nc, keywords: keywords.map(k => k.substring ? '~' + k.word : k.word), excludeKeywords, resolvedEndDate, total: vods.length, matchedDays: matchedGroups.length, matchedLines, failedDays, matchedGroups };
}

// [startMs, endMs] 구간이 걸치는 달력 날짜들을 전부 나열함 (자정 넘어가는 방송 대비).
function kws_datesForRange(startMs, endMs) {
  const dates = [];
  const cur = new Date(startMs);
  cur.setHours(0, 0, 0, 0);
  const endD = new Date(endMs);
  let guard = 0;
  while (cur.getTime() <= endD.getTime() && guard++ < 400) {
    dates.push(kws_format(cur));
    cur.setDate(cur.getDate() + 1);
  }
  return dates;
}

// Zonian(외부) + Twitch VOD 직접 스캔(내부) 결과를 날짜별로 합침 (같은 날짜면 sourceServices도 합쳐짐)
function kws_mergeMatchedGroups(groupsA, groupsB) {
  const byDate = new Map();
  for (const g of [...(groupsA||[]), ...(groupsB||[])]) {
    if (!byDate.has(g.date)) {
      byDate.set(g.date, { ...g, lines: [...(g.lines||[])], rawMessages: [...(g.rawMessages||[])], sourceServices: [...(g.sourceServices||[])] });
    } else {
      const existing = byDate.get(g.date);
      existing.lines.push(...(g.lines||[]));
      existing.rawMessages.push(...(g.rawMessages||[]));
      for (const s of (g.sourceServices || [])) if (!existing.sourceServices.includes(s)) existing.sourceServices.push(s);
    }
  }
  for (const g of byDate.values()) {
    const deduped = kws_dedupeMessagesByContent(g.rawMessages);
    if (deduped.length !== g.rawMessages.length) {
      g.rawMessages = deduped;
      g.lines = deduped.map(r => `[${r.ts}] [${(r.keywords||[]).join(', ')}] ${r.username}: ${r.message}`);
    }
  }
  return Array.from(byDate.values()).sort((a,b)=>b.date.localeCompare(a.date));
}

// 날짜 범위 안에서 VOD로 커버가 안 되는(=Native API로 못 긁는) 날짜만 골라냄.
// Fast 모드가 Zonian을 "빈 구멍"에만 쓰게 하려고 필요함.
function kws_computeGapDates(vods, start, end) {
  const gaps = [];
  const cur = new Date(end);
  while (cur >= start) {
    const dayStart = new Date(cur); dayStart.setHours(0,0,0,0);
    const dayEnd = new Date(cur); dayEnd.setHours(23,59,59,999);
    const covered = vods.some(v => v.endMs >= dayStart.getTime() && v.startMs <= dayEnd.getTime());
    if (!covered) gaps.push(kws_format(cur));
    cur.setDate(cur.getDate() - 1);
  }
  return gaps;
}

// Zonian(External) + Twitch VOD 직접 스캔(Internal)을 병렬로 돌리고 병합하는 공통 로직.
// zonianOnlyDates가 주어지면 Zonian은 그 날짜들만 스캔함(Fast 모드용) — 빈 배열이면
// Zonian 자체를 건너뜀(모든 날짜가 VOD로 커버된 경우).
async function kws_runCombinedScan({channel,keyword,startDate,endDate,pageDate,twitchTokens,onStart,onProgress,zonianOnlyDates,modeLabel,cancelToken}) {
  // zonianOnlyDates가 빈 배열이면(VOD로 모든 날짜가 커버돼서 Zonian을 아예 안 돌림)
  // total을 0으로 둬서 percent 계산에서 안 잡히지도, 100%를 못 채우게 만들지도 않게 함.
  let extProgress = {done:0,total: zonianOnlyDates ? zonianOnlyDates.length : 1};
  let startedOnce = false;
  let combinedGroupsSoFar = []; // 지금까지의 병합 스냅샷 (zonian 델타 + twitch 전체 스냅샷을 계속 합쳐감)
  const composeStart = (p) => {
    if (startedOnce) return; startedOnce = true;
    if (typeof onStart === 'function') onStart({...p, mode: modeLabel});
  };
  const composeProgress = () => {
    if (typeof onProgress !== 'function') return;
    const doneSum = extProgress.done + twProgress.done;
    const totalSum = Math.max(1, extProgress.total + twProgress.total);
    // extProgress.newGroups는 zonian 쪽의 "이번 틱에 새로 완성된 날짜"(델타),
    // twProgress.newGroups는 twitch 쪽의 "지금까지 전체"(스냅샷) — 둘 다 그냥
    // kws_mergeMatchedGroups로 누적 병합하면 됨. mergeMatchedGroups 안에서
    // 내용 기준 중복 제거를 하기 때문에 twitch 스냅샷을 매번 다시 합쳐도
    // 메시지가 중복되지 않음(약간 낭비지만 정확함).
    if (extProgress.newGroups?.length) combinedGroupsSoFar = kws_mergeMatchedGroups(combinedGroupsSoFar, extProgress.newGroups);
    if (twProgress.newGroups?.length) combinedGroupsSoFar = kws_mergeMatchedGroups(combinedGroupsSoFar, twProgress.newGroups);
    onProgress({
      done: doneSum, total: totalSum, percent: Math.min(100, Math.round(doneSum/totalSum*100)),
      matchedDays: (extProgress.matchedDays||0) + (twProgress.matchedDays||0),
      matchedLines: (extProgress.matchedLines||0) + (twProgress.matchedLines||0),
      failedDays: (extProgress.failedDays||0) + (twProgress.failedDays||0),
      newGroups: combinedGroupsSoFar,
      replaceGroups: true,
      concurrency: twProgress.concurrency,
      inFlight: twProgress.inFlight,
      // Combined 모드는 두 소스가 서로 다른 속도/단위(Zonian=날짜, Twitch=VOD)로
      // 도니까, 합산된 숫자만 보여주면 "지금 뭐가 어떻게 돌고 있는지" 알기 어려움
      // — 소스별로 따로 뜯어서 UI가 각각 표시할 수 있게 함께 실어보냄.
      zonianStatus: { done: extProgress.done||0, total: extProgress.total||0, matchedLines: extProgress.matchedLines||0, activityNote: extProgress.activityNote },
      twitchStatus: { done: twProgress.done||0, total: twProgress.total||0, matchedLines: twProgress.matchedLines||0, concurrency: twProgress.concurrency, inFlight: twProgress.inFlight, activityNote: twProgress.activityNote },
    });
  };

  const zonianPromise = (zonianOnlyDates && zonianOnlyDates.length === 0)
    ? Promise.resolve({ matchedGroups: [], total: 0, matchedLines: 0, failedDays: 0 }) // 빈 구멍이 없으면 Zonian은 아예 안 돌림
    : kws_scanChannelRange({channel,keyword,startDate,endDate,pageDate,logSource:'zonian', onlyDates: zonianOnlyDates || null, cancelToken,
        onStart:composeStart, onProgress:(p)=>{extProgress=p; composeProgress();}});

  const [extResult, twResult] = await Promise.allSettled([
    zonianPromise,
    kws_scanChannelRangeViaTwitch({channel,keyword,startDate,endDate,pageDate,twitchTokens,cancelToken,
      onStart:composeStart, onProgress:(p)=>{twProgress=p; composeProgress();}}),
  ]);

  const ext = extResult.status === 'fulfilled' ? extResult.value : null;
  const tw = twResult.status === 'fulfilled' ? twResult.value : null;
  if (!ext && !tw) throw (extResult.reason || twResult.reason || new Error('Both Zonian and Twitch scans failed'));
  if (!ext) console.warn(`[KWS] ${modeLabel}: zonian scan failed:`, extResult.reason);
  if (!tw) console.warn(`[KWS] ${modeLabel}: twitch scan failed:`, twResult.reason);

  const matchedGroups = kws_mergeMatchedGroups(ext?.matchedGroups, tw?.matchedGroups);
  const matchedLines = matchedGroups.reduce((s,g)=>s+g.rawMessages.length,0);

  return {
    channel: kws_normalizeChannel(channel),
    keywords: (ext||tw)?.keywords || [],
    excludeKeywords: (ext||tw)?.excludeKeywords || [],
    resolvedEndDate: (ext||tw)?.resolvedEndDate,
    total: (ext?.total||0) + (tw?.total||0),
    matchedDays: matchedGroups.length,
    matchedLines,
    failedDays: (ext?.failedDays||0) + (tw?.failedDays||0),
    matchedGroups,
  };
}

// logSource: 'zonian' (External만) | 'twitch' (Internal VOD 채팅만) |
//            'combined_fast' (Internal로 VOD 목록 파악 → VOD 있는 구간은 Internal만,
//             VOD가 없는/삭제된 날짜만 Zonian으로 보충 — Zonian 호출량이 훨씬 줄어서 빠름) |
//            'combined' (Accurate: Zonian은 항상 전체 범위를 다 스캔 + Internal도 병렬로 돌려서 병합, 제일 정확하지만 느림)
async function kws_scanChannelRangeDispatch({channel,keyword,startDate,endDate,pageDate,logSource,twitchTokens,onStart,onProgress,cancelToken}) {
  const mode = logSource || 'zonian';

  if (mode === 'zonian') {
    return kws_scanChannelRange({channel,keyword,startDate,endDate,pageDate,logSource:'zonian',onStart,onProgress,cancelToken});
  }

  if (mode === 'twitch') {
    return kws_scanChannelRangeViaTwitch({channel,keyword,startDate,endDate,pageDate,twitchTokens,onStart,onProgress,cancelToken});
  }

  if (mode === 'combined_fast') {
    return kws_runCombinedFastScan({channel,keyword,startDate,endDate,pageDate,twitchTokens,onStart,onProgress,cancelToken});
  }

  // combined (Accurate)
  return kws_runCombinedScan({channel,keyword,startDate,endDate,pageDate,twitchTokens,onStart,onProgress,zonianOnlyDates:null,modeLabel:'combined',cancelToken});
}

// Combined (Fast): 1단계로 VOD 없는 날짜만 Zonian에 물어보면서 Native API를 동시에
// 돌리고, Internal이 "VOD는 있는데 채팅이 0개 나왔거나 fetch가 실패한" 날짜를
// 알려주면(onSuspectDates) — 그 VOD가 replay 데이터 누락일 수도 있으니 — 2단계로
// 그 날짜들만 추가로 Zonian에 재확인함. VOD가 멀쩡히 커버하는 대부분의 날짜는
// 처음부터 끝까지 Zonian을 아예 안 거치니 Accurate보다 훨씬 빠르면서도, VOD가
// 있어도 놓칠 수 있는 날짜를 그냥 버리지 않고 보충함.
async function kws_runCombinedFastScan({channel,keyword,startDate,endDate,pageDate,twitchTokens,onStart,onProgress,cancelToken}) {
  const nc = kws_normalizeChannel(channel);
  const resolvedEndDate = kws_maxDateString(kws_format(new Date()), endDate, pageDate);
  const start = new Date(`${startDate}T00:00:00`);
  const end = new Date(`${resolvedEndDate}T23:59:59`);
  if (isNaN(start.getTime()) || isNaN(end.getTime()) || start > end) throw new Error('Invalid date range.');

  const allVods = await kws_fetchVodScheduleByType(nc, 'ARCHIVE', start.getTime());
  const vods = allVods.filter(v => v.endMs >= start.getTime() && v.startMs <= end.getTime());
  const staticGapDates = kws_computeGapDates(vods, start, end);
  const staticGapSet = new Set(staticGapDates);
  console.log(`[KWS] combined-fast: ${nc} — VOD ${vods.length}개로 커버됨, VOD 없는 날짜 ${staticGapDates.length}개는 처음부터 Zonian으로 보충`);

  const recoveryDates = new Set();
  let startedOnce = false;
  let zonian1Progress = {done:0,total: staticGapDates.length};
  let zonian2Progress = {done:0,total:0}; // twitch 스캔이 끝나야 필요 여부/개수가 확정됨
  let twProgress = {done:0,total:1};
  let combinedGroupsSoFar = [];
  const composeStart = (p) => { if (startedOnce) return; startedOnce = true; if (typeof onStart === 'function') onStart({...p, mode:'combined_fast'}); };
  const composeProgress = () => {
    if (typeof onProgress !== 'function') return;
    if (zonian1Progress.newGroups?.length) combinedGroupsSoFar = kws_mergeMatchedGroups(combinedGroupsSoFar, zonian1Progress.newGroups);
    if (zonian2Progress.newGroups?.length) combinedGroupsSoFar = kws_mergeMatchedGroups(combinedGroupsSoFar, zonian2Progress.newGroups);
    if (twProgress.newGroups?.length) combinedGroupsSoFar = kws_mergeMatchedGroups(combinedGroupsSoFar, twProgress.newGroups);
    const zDone = zonian1Progress.done + zonian2Progress.done;
    const zTotal = zonian1Progress.total + zonian2Progress.total;
    const doneSum = zDone + twProgress.done;
    const totalSum = Math.max(1, zTotal + twProgress.total);
    onProgress({
      done: doneSum, total: totalSum, percent: Math.min(100, Math.round(doneSum/totalSum*100)),
      matchedDays: (zonian1Progress.matchedDays||0) + (zonian2Progress.matchedDays||0) + (twProgress.matchedDays||0),
      matchedLines: (zonian1Progress.matchedLines||0) + (zonian2Progress.matchedLines||0) + (twProgress.matchedLines||0),
      failedDays: (zonian1Progress.failedDays||0) + (zonian2Progress.failedDays||0) + (twProgress.failedDays||0),
      newGroups: combinedGroupsSoFar,
      replaceGroups: true,
      concurrency: twProgress.concurrency,
      inFlight: twProgress.inFlight,
      // zonianPhase: 1 = 처음부터 VOD 없는 날짜 찾는 중, 2 = Native API가 끝난 뒤
      // "VOD는 있는데 채팅이 비었거나 실패한(=삭제됐을 수도 있는)" 날짜를 재확인하는 중.
      // UI에서 이 둘을 다른 문구로 보여줌.
      zonianStatus: { done: zDone, total: zTotal, matchedLines: (zonian1Progress.matchedLines||0) + (zonian2Progress.matchedLines||0), phase: zonian2Progress.total > 0 ? 2 : 1, activityNote: zonian2Progress.activityNote || zonian1Progress.activityNote },
      twitchStatus: { done: twProgress.done||0, total: twProgress.total||0, matchedLines: twProgress.matchedLines||0, concurrency: twProgress.concurrency, inFlight: twProgress.inFlight, activityNote: twProgress.activityNote },
    });
  };

  const zonian1Promise = staticGapDates.length
    ? kws_scanChannelRange({channel,keyword,startDate,endDate,pageDate,logSource:'zonian', onlyDates: staticGapDates, cancelToken,
        onStart: composeStart, onProgress: (p)=>{zonian1Progress=p; composeProgress();}})
    : Promise.resolve({matchedGroups:[],total:0,matchedLines:0,failedDays:0});

  const twPromise = kws_scanChannelRangeViaTwitch({channel,keyword,startDate,endDate,pageDate,twitchTokens,cancelToken,
    onStart: composeStart,
    onProgress: (p)=>{twProgress=p; composeProgress();},
    onSuspectDates: (dates) => { for (const d of dates) if (!staticGapSet.has(d)) recoveryDates.add(d); },
  });

  const [zonian1Result, twResult] = await Promise.allSettled([zonian1Promise, twPromise]);
  const ext1 = zonian1Result.status === 'fulfilled' ? zonian1Result.value : null;
  const tw = twResult.status === 'fulfilled' ? twResult.value : null;
  if (staticGapDates.length && !ext1) console.warn('[KWS] combined-fast: 1단계 zonian 스캔 실패:', zonian1Result.reason);
  if (!tw) console.warn('[KWS] combined-fast: twitch 스캔 실패:', twResult.reason);

  // 2단계: VOD는 있었지만 채팅이 비었거나 fetch가 실패했던 날짜만, twitch 스캔이
  // 다 끝난 뒤 확정해서 Zonian으로 한 번 더 확인함.
  const recoveryList = Array.from(recoveryDates);
  let ext2 = null;
  if (recoveryList.length) {
    console.log(`[KWS] combined-fast: ${nc} — VOD는 있지만 채팅이 비었거나 fetch 실패한 날짜 ${recoveryList.length}개, Zonian으로 재확인`);
    zonian2Progress = {done:0, total: recoveryList.length};
    composeProgress(); // 분모가 바뀐 걸 바로 반영 — 안 하면 phase 1 완료 시점의 100%가 phase 2 시작할 때까지 그대로 남아있음
    try {
      ext2 = await kws_scanChannelRange({channel,keyword,startDate,endDate,pageDate,logSource:'zonian', onlyDates: recoveryList, cancelToken,
        onStart: () => {}, onProgress: (p)=>{zonian2Progress=p; composeProgress();}});
    } catch (e) {
      console.warn('[KWS] combined-fast: 2단계(재확인) zonian 스캔 실패:', e);
    }
  }

  if (!ext1 && !ext2 && !tw) throw (zonian1Result.reason || twResult.reason || new Error('Zonian and Twitch scans both failed'));

  const matchedGroups = kws_mergeMatchedGroups(kws_mergeMatchedGroups(ext1?.matchedGroups, ext2?.matchedGroups), tw?.matchedGroups);
  const matchedLines = matchedGroups.reduce((s,g)=>s+g.rawMessages.length,0);

  return {
    channel: nc,
    keywords: (ext1||tw)?.keywords || [],
    excludeKeywords: (ext1||tw)?.excludeKeywords || [],
    resolvedEndDate: (ext1||tw)?.resolvedEndDate || resolvedEndDate,
    total: (ext1?.total||0) + (ext2?.total||0) + (tw?.total||0),
    matchedDays: matchedGroups.length,
    matchedLines,
    failedDays: (ext1?.failedDays||0) + (ext2?.failedDays||0) + (tw?.failedDays||0),
    matchedGroups,
  };
}

// 'twitch'/'combined' 결과엔 다운로드용 .txt(text/filename)이 없어서 여기서 공통 생성
function kws_buildExportText(result, {channel, startDate, resolvedEndDate}) {
  if (result.text && result.filename) return result;
  const header=[`Channel: ${channel}`,`Keywords: ${(result.keywords||[]).slice(0,8).join(", ")}${(result.keywords||[]).length>8?" ...":""}`,`Exclude: ${(result.excludeKeywords||[]).join(", ")||"none"}`,`Range: ${startDate} -> ${result.resolvedEndDate||resolvedEndDate}`].join("\n");
  const body=(result.matchedGroups||[]).map(g=>`===== ${g.date} =====\n`+(g.lines||[]).join("\n")).join("\n\n");
  const text=body?`${header}\n\n${body}`:`${header}\n\nNo matches found.`;
  const filename=`twitch_kws_${kws_sanitizeFilePart(channel)}_${kws_sanitizeFilePart(startDate)}_to_${kws_sanitizeFilePart(result.resolvedEndDate||resolvedEndDate||'')}.txt`;
  return {...result, text, filename};
}

// 같은 탭에서 같은 채널을 다시 검색하면 이전 스캔(실행 중/대기 중)을 '교체됨'으로 표시 —
// 이전 스캔이 뒤늦게 보내는 진행/완료/에러 메시지가 새 스캔의 화면 상태를 덮어써서
// "다시 검색했는데 더 이상 검색이 안 되는" 것처럼 보이던 문제를 막음.
const kws_supersededScanIds = new Set();
const kws_latestScanByKey = new Map(); // `${tabId}|${channel}` → scanId
const kws_scanTokens = new Map(); // scanId → { token, tabId, channel }
function kws_stopScansFor(tabId, nc) {
  let runningHit = 0;
  for (const [sid, info] of kws_scanTokens) {
    if (info.tabId === tabId && info.channel === nc) { info.token.cancelled = true; kws_supersededScanIds.add(sid); runningHit++; }
  }
  // 실행 중인 스캔이 없으면(대기열뿐이었으면) 바로 '중지 완료'를 알림 — 있으면 스캔이 정리된 뒤 finally에서 알림
  if (!runningHit) kws_sendToTab(tabId, { type: 'KWS_SCAN_STOPPED', channel: nc });
  for (let i = KWS_SCAN_QUEUE.length - 1; i >= 0; i--) {
    const q = KWS_SCAN_QUEUE[i];
    if (q.channel === nc && q.tabId === tabId) { kws_supersededScanIds.add(q.scanId); KWS_SCAN_QUEUE.splice(i, 1); }
  }
  kws_broadcastQueueUpdate();
}
function kws_send(tabId, scanId, msg) {
  if (scanId && kws_supersededScanIds.has(scanId)) return;
  kws_sendToTab(tabId, msg);
}

async function kws_run({channel,keyword,startDate,endDate,pageDate,tabId,logSource,twitchTokens}){
  const nc = kws_normalizeChannel(channel);
  const scanId = `${tabId}_${Date.now()}`;
  {
    const key = `${tabId}|${nc}`;
    const prev = kws_latestScanByKey.get(key);
    if (prev) kws_supersededScanIds.add(prev);
    kws_latestScanByKey.set(key, scanId);
    // 같은 탭·같은 채널의 대기열 중복 항목 제거 (이전 요청은 폐기)
    for (let i = KWS_SCAN_QUEUE.length - 1; i >= 0; i--) {
      if (KWS_SCAN_QUEUE[i].channel === nc && KWS_SCAN_QUEUE[i].tabId === tabId) KWS_SCAN_QUEUE.splice(i, 1);
    }
  }

  const active = KWS_ACTIVE_CHANNELS.size;
  const overloaded = kws_isOverloaded();

  // RULE: always allow if nothing is running (guarantee at least 1 scan)
  const belowMin = active < KWS_OVERLOAD.MIN_ACTIVE_CHANNELS;
  // RULE: queue only if BOTH over concurrent limit AND (overloaded OR already at max)
  const tooMany  = active >= KWS_OVERLOAD.MAX_CONCURRENT_CHANNELS;
  const shouldQueue = !belowMin && (tooMany || overloaded);

  if (shouldQueue) {
    // Queue this scan
    const existing = KWS_SCAN_QUEUE.findIndex(q => q.channel === nc && q.tabId === tabId);
    if (existing >= 0) KWS_SCAN_QUEUE.splice(existing, 1);
    KWS_SCAN_QUEUE.push({ channel: nc, keyword, startDate, endDate, pageDate, tabId, scanId, logSource: logSource || 'zonian', twitchTokens });

    const reason = overloaded && tooMany
      ? `Overloaded + ${active} channels scanning — queued`
      : overloaded
        ? `System slow (avg ${kws_getAvgFetchMs()}ms/req) — queued after current scan`
        : `${active} channels scanning simultaneously — queued`;

    kws_sendToTab(tabId, {
      type: 'KWS_QUEUED',
      channel: nc,
      scanId,
      reason,
      queuePos: KWS_SCAN_QUEUE.length,
      activeChannels: Array.from(KWS_ACTIVE_CHANNELS),
    });
    await kws_broadcastQueueUpdate();
    return;
  }

  kws_runActual({ channel: nc, keyword, startDate, endDate, pageDate, tabId, scanId, logSource, twitchTokens });
}

async function kws_runActual({channel,keyword,startDate,endDate,pageDate,tabId,scanId,logSource,twitchTokens}){
  const nc = kws_normalizeChannel(channel);
  if (!scanId) scanId = `${tabId}_${Date.now()}`;
  kws_jobs.delete(tabId);
  kws_activeScans.set(tabId, { scanId, channel: nc, running: true });
  const cancelToken = { cancelled: false };
  kws_scanTokens.set(scanId, { token: cancelToken, tabId, channel: nc });
  KWS_ACTIVE_CHANNELS.add(nc);
  await kws_broadcastQueueUpdate();

  try{
    const rawResult=await kws_scanChannelRangeDispatch({
      channel: nc, keyword, startDate, endDate, pageDate, logSource: logSource || 'zonian', twitchTokens, cancelToken,
      onStart:(p)=>kws_send(tabId,scanId,{type:"KWS_SCAN_STARTED",...p,scanId,channel:nc}),
      onProgress:(p)=>kws_send(tabId,scanId,{type:"KWS_SCAN_PROGRESS",...p,scanId,channel:nc})
    });
    const result=kws_buildExportText(rawResult,{channel:nc,startDate,resolvedEndDate:rawResult.resolvedEndDate});
    kws_jobs.set(tabId,{text:result.text,filename:result.filename,summary:{matchedDays:result.matchedDays,matchedLines:result.matchedLines}});
    kws_send(tabId,scanId,{type:"KWS_SCAN_COMPLETE",...result,scanId,channel:nc});
    broadcastToTwitchTracker({type:'KWS_TT_STATE',channel:nc,state:'done',percent:100});
  }catch(e){
    kws_send(tabId,scanId,{type:"KWS_SCAN_ERROR",message:e?.message||String(e),scanId,channel:nc});
  }finally{
    kws_activeScans.delete(tabId);
    // 교체된(옛) 스캔이 끝났다고 새 스캔의 '실행 중 채널' 표시까지 지우지 않게 함
    const _key = `${tabId}|${nc}`;
    const _isLatest = kws_latestScanByKey.get(_key) === scanId;
    if (_isLatest) kws_latestScanByKey.delete(_key);
    if (_isLatest || !kws_latestScanByKey.has(_key)) KWS_ACTIVE_CHANNELS.delete(nc);
    kws_supersededScanIds.delete(scanId);
    kws_scanTokens.delete(scanId);
    if (cancelToken.cancelled) kws_sendToTab(tabId, { type: 'KWS_SCAN_STOPPED', channel: nc }); // 슬롯 반환 완료 신호
    await kws_broadcastQueueUpdate();
    // Try to start queued scans
    setTimeout(kws_drainQueue, 500);
  }
}

// ── Directory Crawler (no auto re-scan, manual Start/Stop only) ─────────────────

const KWS_DIRECTORY_PAGE="https://www.twitch.tv/directory/category/just-chatting";
const KWS_DIRECTORY_EXCLUDED_PATHS=new Set(["directory","downloads","jobs","turbo","p","settings","wallet","subscriptions","inventory","messages","friends","search","embed","login","signup"]);
let kws_directoryRunPromise=null;

async function kws_getDirectoryState(){
  const data=await chrome.storage.local.get(["kwsDirectoryCrawler"]);
  return data?.kwsDirectoryCrawler||null;
}
async function kws_setDirectoryState(state){
  await chrome.storage.local.set({kwsDirectoryCrawler:state});
  await kws_broadcastDirectoryStatus(state);
  return state;
}
async function kws_patchDirectoryState(patch){
  const current=await kws_getDirectoryState();
  return kws_setDirectoryState({...(current||{}),...patch});
}
async function kws_broadcastDirectoryStatus(state){
  try{
    const tabs=await chrome.tabs.query({url:["https://www.twitch.tv/*"]});
    for(const tab of tabs){
      if(typeof tab.id==="number"){
        try{chrome.tabs.sendMessage(tab.id,{type:"KWS_DIRECTORY_STATUS",state});}catch(e){}
      }
    }
  }catch(e){}
}

async function kws_broadcastToCrawlerTabs(payload){
  try{
    const tabs=await chrome.tabs.query({url:["https://www.twitch.tv/*"]});
    for(const tab of tabs){
      if(typeof tab.id==="number"){
        try{chrome.tabs.sendMessage(tab.id,payload);}catch(e){}
      }
    }
  }catch(e){}
}

async function kws_broadcastCrawlerHit({channel,result,downloadName}){
  await kws_broadcastToCrawlerTabs({
    type:"KWS_CRAWLER_HIT",
    channel,
    downloadName,
    matchedLines:result.matchedLines,
    matchedDays:result.matchedDays,
    keywords:result.keywords,
    matchedGroups:result.matchedGroups
  });
}

async function kws_broadcastChannelDone({channel,result,index,total,scannedChannels,matchedChannels}){
  await kws_broadcastToCrawlerTabs({
    type:"KWS_CRAWLER_CHANNEL_DONE",
    channel,
    index,
    total,
    hasHit: result.matchedLines > 0,
    matchedLines: result.matchedLines || 0,
    totalScanned: Object.keys(scannedChannels).length,
    totalMatched: Object.keys(matchedChannels).length,
    percent: Math.round((index+1)/total*100)
  });
}

async function kws_broadcastChannelError({channel,error,index,total}){
  await kws_broadcastToCrawlerTabs({
    type:"KWS_CRAWLER_CHANNEL_ERROR",
    channel, error, index, total,
    percent: Math.round((index+1)/total*100)
  });
}


async function kws_requestChannelsFromTab(tabId,retries=10){
  for(let attempt=0;attempt<retries;attempt++){
    try{
      const response=await chrome.tabs.sendMessage(tabId,{type:"KWS_COLLECT_DIRECTORY_CHANNELS"});
      if(response?.channels?.length)return response.channels.map(kws_normalizeChannel).filter(Boolean);
    }catch(e){}
    await kws_sleep(1200);
  }
  return[];
}

async function kws_collectChannelsFromOpenDirectoryTab(){
  const tabs=await chrome.tabs.query({url:[KWS_DIRECTORY_PAGE,`${KWS_DIRECTORY_PAGE}*`]});
  for(const tab of tabs){
    if(typeof tab.id!=="number")continue;
    const channels=await kws_requestChannelsFromTab(tab.id,3);
    if(channels.length)return channels;
  }
  return[];
}

// Collect live channel list from Just Chatting via GQL
async function kws_fetchDirectoryChannelsViaGQL(slug,maxPages=10){
  const allChannels=[];
  let cursor=null;
  let hasNext=true;
  let page=0;
  while(hasNext&&page<maxPages){
    const body=JSON.stringify([{
      operationName:"DirectoryPage_Game",
      variables:{
        slug:slug||"just-chatting",
        options:{sort:"VIEWER_COUNT",freeformTags:null,tags:[],broadcasterLanguages:[],systemFilters:[]},
        sortTypeIsRecency:false,limit:30,
        ...(cursor?{cursor}:{})
      },
      extensions:{persistedQuery:{version:1,sha256Hash:"df4bb6cc45055237bfaf3ead608bbafb79815c7100b6ee126719fac3762ddf8b"}}
    }]);
    try{
      const d=await getGQL({body});
      const result=Array.isArray(d)?d[0]:d;
      const edges=result?.data?.game?.streams?.edges||[];
      const pageInfo=result?.data?.game?.streams?.pageInfo||{};
      for(const edge of edges){
        const login=edge?.node?.broadcaster?.login;
        if(login)allChannels.push(kws_normalizeChannel(login));
        cursor=edge?.cursor||null;
      }
      hasNext=pageInfo.hasNextPage&&edges.length>0&&!!cursor;
    }catch(e){console.warn("[KWS_GQL] failed:",e.message);break;}
    page++;
    await kws_sleep(300);
  }
  return allChannels.filter(Boolean);
}

async function kws_fetchDirectoryChannels(){
  // Priority 1: DOM of open Just Chatting tab
  const visible=await kws_collectChannelsFromOpenDirectoryTab();
  if(visible.length)return Array.from(new Set(visible));

  // Priority 2: GQL API (most reliable)
  try{
    const gql=await kws_fetchDirectoryChannelsViaGQL("just-chatting");
    if(gql.length)return Array.from(new Set(gql));
  }catch(e){console.warn("[KWS] GQL failed:",e.message);}

  throw new Error("Could not fetch channel list. Make sure you are logged into Twitch and have a Just Chatting page open.");
}

function kws_encodeDownloadData(text){
  return"data:text/plain;charset=utf-8,"+encodeURIComponent(text);
}
async function kws_downloadTextFile(filename,text){
  await chrome.downloads.download({url:kws_encodeDownloadData(text),filename:`kws_directory/${filename}`,conflictAction:"uniquify",saveAs:false});
}

async function kws_startDirectoryCrawler(config,sourceTabId){
  const normalizedKeyword=String(config?.keyword||"").trim();
  const startDate=String(config?.startDate||"").trim();
  const endDate=String(config?.endDate||"").trim();
  if(!startDate)throw new Error("Start date is required.");

  const previous=await kws_getDirectoryState();
  const signature=JSON.stringify({keyword:normalizedKeyword,startDate,endDate});
  const scannedChannels=previous?.configSignature===signature&&previous?.scannedChannels?previous.scannedChannels:{};
  const matchedChannels=previous?.configSignature===signature&&previous?.matchedChannels?previous.matchedChannels:{};

  const state={
    enabled:true,running:false,
    sourceTabId:typeof sourceTabId==="number"?sourceTabId:(previous?.sourceTabId||null),
    startedAt:previous?.startedAt||Date.now(),
    lastRunAt:null,lastCompletedAt:null,lastError:null,
    currentChannel:null,keyword:normalizedKeyword,startDate,endDate,configSignature:signature,
    scannedChannels,matchedChannels,
    stats:{
      totalSeen:previous?.configSignature===signature?(previous?.stats?.totalSeen||0):0,
      totalScanned:Object.keys(scannedChannels).length,
      totalMatchedChannels:Object.keys(matchedChannels).length,
      totalMatchedLines:previous?.configSignature===signature?(previous?.stats?.totalMatchedLines||0):0,
      lastRunNewChannels:0,lastRunMatches:0
    }
  };
  await kws_setDirectoryState(state);
  // No alarm — manual start only
  kws_runDirectoryCrawler("manual").catch(err=>console.error("[KWS_DIRECTORY]",err));
  return state;
}

async function kws_stopDirectoryCrawler(){
  const current=await kws_getDirectoryState();
  if(current)await kws_setDirectoryState({...current,enabled:false,running:false,currentChannel:null});
}

async function kws_resetDirectoryCrawlerHistory(){
  const current=await kws_getDirectoryState();
  if(!current)return null;
  const next={...current,scannedChannels:{},matchedChannels:{},
    stats:{...(current.stats||{}),totalScanned:0,totalMatchedChannels:0,totalMatchedLines:0,lastRunNewChannels:0,lastRunMatches:0}};
  await kws_setDirectoryState(next);
  return next;
}

async function kws_runDirectoryCrawler(reason="manual"){
  if(kws_directoryRunPromise)return kws_directoryRunPromise;

  kws_directoryRunPromise=(async()=>{
    const current=await kws_getDirectoryState();
    if(!current?.enabled)return null;

    await kws_patchDirectoryState({running:true,lastRunAt:Date.now(),lastError:null,currentChannel:null,progressLabel:"Fetching channel list..."});

    try{
      const channels=await kws_fetchDirectoryChannels();
      const latest=await kws_getDirectoryState();
      const scannedChannels={...(latest?.scannedChannels||{})};
      const matchedChannels={...(latest?.matchedChannels||{})};
      const newChannels=channels.filter(ch=>!scannedChannels[ch]);
      let lastRunMatches=0;

      await kws_patchDirectoryState({
        stats:{...(latest?.stats||{}),totalSeen:channels.length,totalScanned:Object.keys(scannedChannels).length,
          totalMatchedChannels:Object.keys(matchedChannels).length,totalMatchedLines:latest?.stats?.totalMatchedLines||0,
          lastRunNewChannels:newChannels.length,lastRunMatches:0}
      });

      for(let i=0;i<newChannels.length;i++){
        // check if stopped
        const checkState=await kws_getDirectoryState();
        if(!checkState?.enabled)break;

        const channel=newChannels[i];
        await kws_patchDirectoryState({currentChannel:channel,progressLabel:`${i+1} / ${newChannels.length}`});
        try{
          const result=await kws_scanChannelRange({
            channel,keyword:current.keyword,startDate:current.startDate,endDate:current.endDate,pageDate:""
          });
          scannedChannels[channel]=Date.now();
          if(result.matchedLines>0){
            lastRunMatches++;
            matchedChannels[channel]={at:Date.now(),matchedLines:result.matchedLines,filename:result.filename};
            const stamp=kws_format(new Date())+"_"+new Date().toTimeString().slice(0,8).replace(/:/g,"-");
            const downloadName=`just_chatting_${kws_sanitizeFilePart(channel)}_${stamp}.txt`;
            await kws_downloadTextFile(downloadName,result.text);
            // broadcast live hit
            await kws_broadcastCrawlerHit({ channel, result, downloadName });
          }
          // broadcast channel done (regardless of hits)
          await kws_broadcastChannelDone({ channel, result, index: i, total: newChannels.length, scannedChannels, matchedChannels });
        }catch(err){
          console.error("[KWS_DIRECTORY] channel failed",channel,err);
          await kws_broadcastChannelError({ channel, error: err?.message || String(err), index: i, total: newChannels.length });
        }

        const prevState=await kws_getDirectoryState();
        await kws_setDirectoryState({
          ...(prevState||current),enabled:true,running:true,currentChannel:channel,
          scannedChannels,matchedChannels,lastError:null,
          stats:{...(prevState?.stats||current.stats||{}),
            totalSeen:channels.length,totalScanned:Object.keys(scannedChannels).length,
            totalMatchedChannels:Object.keys(matchedChannels).length,
            totalMatchedLines:Object.values(matchedChannels).reduce((s,v)=>s+(v?.matchedLines||0),0),
            lastRunNewChannels:newChannels.length,lastRunMatches}
        });
      }

      const finalState=await kws_getDirectoryState();
      await kws_setDirectoryState({
        ...(finalState||current),enabled:false,running:false,currentChannel:null,
        progressLabel:newChannels.length?`Done: ${newChannels.length} channels scanned`:"No new channels",
        lastCompletedAt:Date.now(),lastError:null
      });
      return{channels,newChannels};
    }catch(e){
      const failedState=await kws_getDirectoryState();
      await kws_setDirectoryState({...(failedState||current),enabled:false,running:false,currentChannel:null,
        lastError:e?.message||String(e),progressLabel:"Failed to fetch channels"});
      throw e;
    }finally{kws_directoryRunPromise=null;}
  })();
  return kws_directoryRunPromise;
}


// ── SOOP VOD Tab Functions ────────────────────────────────────────────
const SOOP_CAPTURES = {};
let soop_captureVodTabId = null;

function soop_waitTabComplete(tabId, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { chrome.tabs.onUpdated.removeListener(l); reject(new Error('timeout')); }, timeoutMs);
    const l = (id, info) => {
      if (id === tabId && info.status === 'complete') {
        clearTimeout(timer); chrome.tabs.onUpdated.removeListener(l); resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(l);
    chrome.tabs.get(tabId).then(t => {
      if (t?.status === 'complete') { clearTimeout(timer); chrome.tabs.onUpdated.removeListener(l); resolve(); }
    }).catch(() => {});
  });
}

let _vodTabOpenCount = 0;
const _vodTabWaitQueue = [];
const MAX_CONCURRENT_VOD_TABS = 8; // 탭 여는 것 자체가 무거운 작업이라 별도로 제한 — API 모드의 폴백이든 TAB 모드든 이 값까지 동시에 열림

async function openVodTabGated(playerUrl) {
  if (_vodTabOpenCount >= MAX_CONCURRENT_VOD_TABS) {
    await new Promise(resolve => _vodTabWaitQueue.push(resolve));
  }
  _vodTabOpenCount++;
  try {
    return await openVodTab(playerUrl);
  } finally {
    _vodTabOpenCount--;
    const next = _vodTabWaitQueue.shift();
    if (next) next();
  }
}

// vodCore.fileItems가 실제로 채워지기까지 탭의 'complete' 이벤트 이후로도 몇 초씩 더
// 걸릴 수 있음(광고/분석 스크립트, HLS 매니페스트 요청, React 하이드레이션 등) — 특히
// 여러 탭을 동시에 열어 스캔 중일 때(MAX_CONCURRENT_VOD_TABS=8)는 CPU/네트워크가
// 나눠쓰여서 이 시간이 훨씬 더 늘어남. 예전엔 'complete' 이후 고정 800ms + (실패 시)
// 1500ms 한 번 더, 총 2.3초만 기다리고 포기했는데 — 이게 시스템이 한가할 땐 통과하고
// 바쁠 땐 실패하는 "가끔 나오고 가끔 안 나오는" 불안정성의 원인이었음. 실측해보면
// 탐색 시작부터 vodCore.fileItems가 다 채워지기까지 평범한 경우에도 6~7초 걸림.
// 그래서 고정 대기 대신, 백그라운드(서비스워커) 쪽에서 직접 폴링하도록 바꿈 — 탭이
// 백그라운드(비활성)라서 탭 내부의 setInterval/setTimeout 자체가 브라우저에 의해
// 스로틀링될 수 있는데, 폴링을 서비스워커 쪽 setTimeout으로 주도하고 매번 짧은
// executeScript 한 번씩만 찔러보는 방식이라 그 스로틀링의 영향을 받지 않음.
const VOD_TAB_POLL_INTERVAL_MS = 500;
const VOD_TAB_POLL_TOTAL_MS = 20000; // 'complete' 이후 최대 20초까지 재시도

// tabId -> { resolve } — vod_corewatch.js(document_start, MAIN world)가 그 탭에서
// vodCore.fileItems가 준비되는 즉시 VOD_CORE_READY 메시지를 보내주면, 여기 등록된
// resolve를 바로 불러서 openVodTab이 폴링을 기다릴 필요 없이 즉시 끝나게 함.
// (아래 chrome.runtime.onMessage 리스너에서 채워줌)
const _vodCoreWaiters = new Map();

async function openVodTab(playerUrl) {
  const tab = await chrome.tabs.create({ url: playerUrl, active: false });
  const tabId = tab.id;
  try {
    // vod_corewatch.js는 document_start부터 즉시 감시를 시작하므로, 탭의 'complete'를
    // 기다리기 전에 먼저 리스너를 걸어둬야 그 사이에 오는 메시지도 놓치지 않음.
    const messagePromise = new Promise((resolve) => {
      _vodCoreWaiters.set(tabId, { resolve });
    });

    await soop_waitTabComplete(tabId, 30000);
    const extract = () => {
      try {
        const vc = window.vodCore;
        if (!vc?.fileItems?.length) return null;
        return vc.fileItems.map((f, i) => ({
          file_info_key: f.fileInfoKey || '', duration: Math.floor(f.duration || 0),
          file_order: f.fileOrder || (i + 1), url: f.url || ''
        }));
      } catch { return null; }
    };

    // executeScript로 매번 왕복하며 찔러보는 폴링은 백업 경로로 계속 돌리고,
    // vod_corewatch.js가 보내주는 메시지(더 빠름 — 페이지 자체 컨텍스트에서 100ms
    // 간격으로 감시하다가 되는 즉시 알려줌)와 경쟁시켜서 먼저 오는 쪽을 씀.
    let attempts = 0;
    const pollStart = Date.now();
    const pollPromise = (async () => {
      while (Date.now() - pollStart < VOD_TAB_POLL_TOTAL_MS) {
        attempts++;
        try {
          const res = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: extract });
          const r = res?.[0]?.result;
          if (r?.length) return r;
        } catch (e) {
          // 탭이 아직 executeScript를 받을 준비가 안 됐거나 이동 중일 수 있음 — 다음 폴에서 재시도
        }
        await new Promise(r => setTimeout(r, VOD_TAB_POLL_INTERVAL_MS));
      }
      return null;
    })();

    const fi = await Promise.race([messagePromise, pollPromise]);
    _vodCoreWaiters.delete(tabId);
    console.log('[SOOP KWS] openVodTab finished:', playerUrl, 'pollAttempts=', attempts, 'elapsedMs=', Date.now() - pollStart, 'found=', !!fi?.length);
    chrome.tabs.remove(tabId).catch(() => {});
    return fi?.length ? { success: true, fileItems: fi } : { success: false, error: 'no fileItems (polled ' + attempts + 'x over ' + (Date.now() - pollStart) + 'ms)' };
  } catch(e) {
    _vodCoreWaiters.delete(tabId);
    chrome.tabs.remove(tabId).catch(() => {});
    return { success: false, error: e.message };
  }
}

// TAB 모드 전용 — 탭 하나 열어서 그 안에서 파일목록 취득 + 채팅 fetch + 키워드 매칭까지 전부 끝내고 결과만 반환
// (구독 여부 판단 없이, 이미 구독 불필요/구독 중인 것으로 확인된 VOD에만 사용됨)
async function scanVodTabFull(playerUrl, parsedKw, chunkConc) {
  const tab = await chrome.tabs.create({ url: playerUrl, active: false });
  const tabId = tab.id;
  try {
    await soop_waitTabComplete(tabId, 30000);
    await new Promise(r => setTimeout(r, 500));
    const res = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      args: [parsedKw, chunkConc],
      func: async (parsedKwArg, chunkConcArg) => {
        const wholeWordCache = new Map();
        function soopWholeWord(text, word) {
          let cached = wholeWordCache.get(word);
          if (cached === undefined) {
            if (/[\u4E00-\u9FFF\u3040-\u30FF\u0E00-\u0E7F]/i.test(word)) { cached = null; }
            else {
              const esc = word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
              try { cached = new RegExp(`(?<![\\p{L}\\p{N}])${esc}(?![\\p{L}\\p{N}])`, 'iu'); }
              catch (e) { cached = null; }
            }
            wholeWordCache.set(word, cached);
          }
          return cached ? cached.test(text) : text.includes(word);
        }
        function p2(n) { return String(n).padStart(2, '0'); }
        function toHMS(s) { s = Math.max(0, Math.floor(s)); return `[${p2(Math.floor(s/3600))}:${p2(Math.floor((s%3600)/60))}:${p2(s%60)}]`; }

        function waitForVodCore() {
          return new Promise((resolve, reject) => {
            let elapsed = 0; const intervalMs = 400; const maxMs = 25000;
            const timer = setInterval(() => {
              elapsed += intervalMs;
              let candidate = null;
              try { if (window.vodCore) candidate = window.vodCore; } catch (_) {}
              if (candidate && Array.isArray(candidate.fileItems)) { clearInterval(timer); resolve(candidate); return; }
              if (elapsed >= maxMs) { clearInterval(timer); reject(new Error('vodCore를 못 찾음')); }
            }, intervalMs);
          });
        }

        async function mapConc(items, n, fn) {
          const results = new Array(items.length);
          let cursor = 0;
          const workers = Array.from({ length: Math.min(n, items.length || 1) }, async () => {
            while (cursor < items.length) { const i = cursor++; results[i] = await fn(items[i], i); }
          });
          await Promise.all(workers);
          return results;
        }

        try {
          const vodCoreRef = await waitForVodCore();
          const fileItems = vodCoreRef.fileItems;
          if (!fileItems || !fileItems.length) return { success: false, error: 'no fileItems' };

          let accTime = 0, matchCount = 0;
          const lines = [], matches = [];

          for (const item of fileItems) {
            const duration = Number(item.duration || 0);
            const key = item.fileInfoKey;
            if (!key) { accTime += duration; continue; }
            const isClip = String(key).includes('clip_');
            const baseUrl = isClip
              ? `https://vod-normal-kr-cdn-z01.sooplive.co.kr/${String(key).split('_').join('/')}_c.xml?type=clip&rowKey=${key}_c`
              : `https://videoimg.sooplive.com/php/ChatLoadSplit.php?rowKey=${key}_c`;
            const startTimes = [];
            for (let t = 0; t <= duration; t += 300) startTimes.push(t);
            const accTimeForFile = accTime;

            await mapConc(startTimes, chunkConcArg, async (t) => {
              try {
                const sep = baseUrl.includes('?') ? '&' : '?';
                const resp = await fetch(`${baseUrl}${sep}startTime=${t}`, { cache: 'no-store' });
                if (!resp.ok) return;
                const xml = new DOMParser().parseFromString(await resp.text(), 'text/xml');
                const chats = xml.querySelectorAll('chat');
                for (const c of chats) {
                  const rawT = parseFloat(c.querySelector('t')?.textContent || '0') || 0;
                  const u = (c.querySelector('u')?.textContent || '').split('(')[0];
                  const n = c.querySelector('n')?.textContent || '';
                  const m = c.querySelector('m')?.textContent || '';
                  const lowerM = m.toLowerCase();
                  if (parsedKwArg.exclude.some(x => x && lowerM.includes(x))) continue;
                  const hit = parsedKwArg.include
                    .filter(k => k.word && (k.substring ? lowerM.includes(k.word) : soopWholeWord(lowerM, k.word)))
                    .map(k => k.word);
                  if (!hit.length) continue;
                  const secs = Math.max(0, Math.floor(rawT + accTimeForFile));
                  const label = toHMS(secs);
                  matchCount++;
                  lines.push(`${label} ${n}(${u}): ${m} {매칭: ${hit.join(', ')}}`);
                  matches.push({ seconds: secs, timeLabel: label.replace(/^\[|\]$/g, ''), userId: u, nickname: n, message: m, matchedKeywords: hit });
                }
              } catch (_) {}
            });
            accTime += duration;
          }
          return { success: true, matchCount, lines, matches };
        } catch (e) {
          return { success: false, error: e.message };
        }
      }
    });
    return res?.[0]?.result || { success: false, error: 'executeScript failed' };
  } catch (e) {
    return { success: false, error: e.message };
  } finally {
    chrome.tabs.remove(tabId).catch(() => {});
  }
}

let _fullScanTabOpenCount = 0;
const _fullScanTabWaitQueue = [];
let _fullScanMaxConcurrent = 6;

async function scanVodTabFullGated(playerUrl, parsedKw, chunkConc, maxConcurrentTabs) {
  if (typeof maxConcurrentTabs === 'number' && maxConcurrentTabs > 0) _fullScanMaxConcurrent = maxConcurrentTabs;
  if (_fullScanTabOpenCount >= _fullScanMaxConcurrent) {
    await new Promise(resolve => _fullScanTabWaitQueue.push(resolve));
  }
  _fullScanTabOpenCount++;
  try {
    return await scanVodTabFull(playerUrl, parsedKw, chunkConc);
  } finally {
    _fullScanTabOpenCount--;
    const next = _fullScanTabWaitQueue.shift();
    if (next) next();
  }
}

async function startVodCapture({ playerUrl, startSec, endSec, captureSpeed }) {
  const captureId = Date.now().toString(36) + Math.random().toString(36).slice(2);
  SOOP_CAPTURES[captureId] = { chunks: [], captured: 0, done: false, error: null, startSec, endSec };
  const captureUrl = playerUrl + (playerUrl.includes('?') ? '&' : '?') +
    `soop_cap=${captureId}&soop_start=${startSec}&soop_end=${endSec}&soop_speed=${captureSpeed}`;
  const tab = await chrome.tabs.create({ url: captureUrl, active: true });
  soop_captureVodTabId = tab.id;
  return { captureId };
}

async function saveVodCapture(captureId, filename, senderTabId) {
  const c = SOOP_CAPTURES[captureId];
  if (!c?.chunks?.length) {
    if (senderTabId) chrome.tabs.sendMessage(senderTabId, { type: 'CAPTURE_SAVED', error: 'No data captured' }).catch(() => {});
    return;
  }
  const totalBytes = c.chunks.reduce((s, b) => s + b.byteLength, 0);
  const merged = new Uint8Array(totalBytes);
  let offset = 0;
  for (const chunk of c.chunks) { merged.set(new Uint8Array(chunk), offset); offset += chunk.byteLength; }
  let binary = '';
  const CHUNK = 8192;
  for (let i = 0; i < merged.byteLength; i += CHUNK)
    binary += String.fromCharCode(...merged.subarray(i, Math.min(i + CHUNK, merged.byteLength)));
  const dataUrl = 'data:video/mp4;base64,' + btoa(binary);
  delete SOOP_CAPTURES[captureId];
  if (senderTabId) chrome.tabs.sendMessage(senderTabId, { type: 'CAPTURE_SAVED', dataUrl, filename }).catch(() => {});
}

// ── YouTube KWS: 채팅 리플레이 fetch ──

async function ytGetChatContinuation(params) {
  // 영상 페이지 HTML을 받아서 ytInitialData에서 continuation 토큰 추출
  try {
    const { videoId } = params;
    const res = await fetch(`https://www.youtube.com/watch?v=${videoId}`, {
      credentials: 'include',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36',
        'Accept-Language': 'en-US,en;q=0.9'
      }
    });
    const html = await res.text();

    // ytInitialData 추출
    const match = /(?:var ytInitialData|window\["ytInitialData"\])\s*=\s*(\{.+?\});\s*(?:\/\/|<\/script>|var |window\[)/.exec(html);
    if (!match) {
      // fallback: 더 넓게 시도
      const m2 = /ytInitialData\s*=\s*(\{[\s\S]+?\});\s*<\/script>/.exec(html);
      if (!m2) return { error: 'no ytInitialData' };
      const data = JSON.parse(m2[1]);
      return { continuation: extractYTContinuation(data) };
    }
    const data = JSON.parse(match[1]);
    return { continuation: extractYTContinuation(data) };
  } catch (e) {
    return { error: e.message };
  }
}

function extractYTContinuation(data) {
  try {
    // 라이브 채팅 리플레이 continuation 위치
    const bar = data?.contents?.twoColumnWatchNextResults?.conversationBar;
    const lr = bar?.liveChatRenderer;
    if (!lr) return null;
    const conts = lr?.continuations || [];
    for (const c of conts) {
      const token = c?.reloadContinuationData?.continuation
        || c?.invalidationContinuationData?.continuation
        || c?.liveChatReplayContinuationData?.continuation;
      if (token) return token;
    }
    return null;
  } catch { return null; }
}

async function ytFetchChatPage(params) {
  try {
    const { continuation, videoId } = params;

    const body = {
      context: {
        client: {
          clientName: 'WEB',
          clientVersion: '2.20250101.00.00',
          hl: 'en',
          gl: 'US',
          userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
          browserName: 'Chrome',
          browserVersion: '124.0.0.0',
          osName: 'Windows',
          osVersion: '10.0',
          platform: 'DESKTOP'
        }
      },
      continuation
    };

    const res = await fetch(
      'https://www.youtube.com/youtubei/v1/live_chat/get_live_chat_replay?prettyPrint=false',
      {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-YouTube-Client-Name': '1',
          'X-YouTube-Client-Version': '2.20250101.00.00',
          'X-Origin': 'https://www.youtube.com',
          'Origin': 'https://www.youtube.com',
          'Referer': `https://www.youtube.com/watch?v=${videoId || ''}`
        },
        body: JSON.stringify(body)
      }
    );

    const text = await res.text();
    let data;
    try { data = JSON.parse(text); }
    catch(e) { return { error: 'Invalid JSON: ' + text.slice(0,100), messages: [], nextContinuation: null }; }

    const continuation_data = data?.continuationContents?.liveChatContinuation;
    if (!continuation_data) return { messages: [], nextContinuation: null };

    const actions = continuation_data?.actions || [];
    const messages = [];
    for (const action of actions) {
      const item = action?.replayChatItemAction?.actions?.[0]?.addChatItemAction?.item;
      if (!item) continue;
      const renderer = item?.liveChatTextMessageRenderer || item?.liveChatPaidMessageRenderer;
      if (!renderer) continue;
      const text2 = (renderer?.message?.runs || []).map(r => r.text || '').join('');
      if (!text2) continue;
      const author = renderer?.authorName?.simpleText || '';
      const offsetMs = parseInt(action?.replayChatItemAction?.videoOffsetTimeMsec || '0');
      messages.push({ text: text2, author, offsetMs });
    }

    const conts = continuation_data?.continuations || [];
    let nextContinuation = null;
    for (const c of conts) {
      nextContinuation = c?.liveChatReplayContinuationData?.continuation
        || c?.playerSeekContinuationData?.continuation
        || null;
      if (nextContinuation) break;
    }

    return { messages, nextContinuation };
  } catch(e) {
    return { error: e.message, messages: [], nextContinuation: null };
  }
}

function ytParseInitialData(params) {
  try {
    const data = JSON.parse(params.html);
    const results = [];
    const tabs = data?.contents?.twoColumnBrowseResultsRenderer?.tabs || [];
    for (const tab of tabs) {
      const sections = tab?.tabRenderer?.content?.sectionListRenderer?.contents || [];
      for (const section of sections) {
        const items = section?.itemSectionRenderer?.contents || [];
        for (const item of items) {
          const vr = item?.videoRenderer;
          if (!vr?.videoId) continue;
          results.push({
            videoId: vr.videoId,
            title: vr?.title?.runs?.[0]?.text || vr?.title?.simpleText || '',
            date: vr?.publishedTimeText?.simpleText || '',
            duration: vr?.lengthText?.simpleText || ''
          });
        }
      }
    }
    return { vods: results };
  } catch(e) {
    return { vods: [], error: e.message };
  }
}

async function ytGetChannelVODs(params, tabId) {
  if (!tabId) return { vods: [], error: 'no tabId' };
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      args: [String((params && params.url) || '')],
      func: async (pageUrl) => {
        // richGridRenderer.contents 배열(비디오 항목들 + 맨 끝의 continuationItemRenderer)을
        // 파싱해서 {vods, continuation} 형태로 반환 — 최초 페이지/후속 페이지 공용
        function parseRichGrid(contents) {
          const out = [];
          let continuation = null;
          for (const item of (contents || [])) {
            if (item?.continuationItemRenderer) {
              continuation = item.continuationItemRenderer?.continuationEndpoint?.continuationCommand?.token || null;
              continue;
            }
            const lvm = item?.richItemRenderer?.content?.lockupViewModel;
            if (!lvm) continue;

            const thumbUrl = lvm?.contentImage?.thumbnailViewModel?.image?.sources?.[0]?.url || '';
            const vidMatch = /\/vi\/([a-zA-Z0-9_-]{11})\//.exec(thumbUrl);
            if (!vidMatch) continue;
            const videoId = vidMatch[1];

            const meta = lvm?.metadata?.lockupMetadataViewModel;
            const title = meta?.title?.content || meta?.title?.runs?.[0]?.text || '';

            let date = '';
            for (const row of (meta?.metadataRows || [])) {
              for (const part of (row?.metadataParts || [])) {
                const t = part?.text?.content || part?.text?.simpleText || '';
                if (t) { date = t; break; }
              }
              if (date) break;
            }

            const badge = lvm?.contentImage?.thumbnailViewModel?.overlays?.[0]
              ?.thumbnailBottomOverlayViewModel?.badges?.[0]
              ?.thumbnailBadgeViewModel?.text || '';

            out.push({ videoId, title, date, duration: badge });
          }
          return { vods: out, continuation };
        }

        // 1.2.5.46: window.ytInitialData is only the data of the FIRST page loaded in the tab — YouTube
        // moves between pages without reloading, so after the hub's tab went on to the next channel
        // it still held the previous page ("Could not load the stream list. Refresh the page").
        // Read the current page's data from a fresh copy of its HTML instead (fallback: the global).
        const gridOf = (data) => {
          const tabs = data?.contents?.twoColumnBrowseResultsRenderer?.tabs || [];
          const selected = tabs.find(t => t?.tabRenderer?.selected) || tabs[0];
          return selected?.tabRenderer?.content?.richGridRenderer?.contents || [];
        };
        async function freshInitialData(url) {
          const res = await fetch(url, { credentials: 'include', headers: { 'Accept-Language': 'en-US,en;q=0.9' } });
          const html = await res.text();
          const start = html.indexOf('var ytInitialData = ');
          if (start < 0) return null;
          const jsonStart = html.indexOf('{', start);
          let depth = 0, i = jsonStart, inStr = false, esc = false;
          for (; i < html.length; i++) {
            const ch = html[i];
            if (inStr) { if (esc) esc = false; else if (ch === '\\') esc = true; else if (ch === '"') inStr = false; continue; }
            if (ch === '"') inStr = true;
            else if (ch === '{') depth++;
            else if (ch === '}') { depth--; if (depth === 0) break; }
          }
          return JSON.parse(html.slice(jsonStart, i + 1));
        }
        try {
          let contents = [];
          const url = pageUrl || location.href;
          let noLive = false;
          try {
            const fresh = await freshInitialData(url);
            if (fresh) {
              contents = gridOf(fresh);
              // a channel without a Live tab: YouTube answers /streams with its Home tab
              const tabs = fresh?.contents?.twoColumnBrowseResultsRenderer?.tabs || [];
              const sel = tabs.find(t => t?.tabRenderer?.selected);
              const selUrl = sel?.tabRenderer?.endpoint?.commandMetadata?.webCommandMetadata?.url || '';
              if (sel && !/\/streams(?:[?#]|$)/.test(selUrl)) { noLive = true; contents = []; }
            }
          } catch (_) {}
          if (!contents.length && !noLive && window.ytInitialData && url === location.href) contents = gridOf(window.ytInitialData);
          if (!contents.length) return { vods: [], noLive, error: noLive ? 'no Live tab' : 'no stream list in the page data' };
          let { vods, continuation } = parseRichGrid(contents);

          // 페이지가 이미 로드한 진짜 API 키/컨텍스트를 그대로 씀 — 추측/정규식 파싱 불필요, 항상 정확함
          const apiKey = window.ytcfg?.get ? window.ytcfg.get('INNERTUBE_API_KEY') : null;
          const context = (window.ytcfg?.get ? window.ytcfg.get('INNERTUBE_CONTEXT') : null)
            || { client: { clientName: 'WEB', clientVersion: '2.20250101.00.00', hl: 'en', gl: 'US' } };
          if (!apiKey) return { vods, error: 'no INNERTUBE_API_KEY on page' };

          let pageGuard = 0;
          while (continuation && pageGuard < 30) {
            pageGuard++;
            try {
              const res = await fetch(`https://www.youtube.com/youtubei/v1/browse?key=${apiKey}`, {
                method: 'POST',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ context, continuation })
              });
              if (!res.ok) break;
              const cdata = await res.json();
              const actions = cdata?.onResponseReceivedActions || [];
              let items = null;
              for (const action of actions) {
                items = action?.appendContinuationItemsAction?.continuationItems
                  || action?.reloadContinuationItemsCommand?.continuationItems;
                if (items?.length) break;
              }
              if (!items?.length) break;
              const parsed = parseRichGrid(items);
              if (!parsed.vods.length && !parsed.continuation) break;
              vods = vods.concat(parsed.vods);
              continuation = parsed.continuation;
            } catch (e) { break; }
          }
          return { vods };
        } catch (e) {
          return { vods: [], error: e.message };
        }
      }
    });
    return results?.[0]?.result || { vods: [], error: 'executeScript failed' };
  } catch (e) {
    return { vods: [], error: e.message };
  }
}
