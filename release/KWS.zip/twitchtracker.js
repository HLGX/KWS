// VOD KWS — TwitchTracker badge injector
(async function() {
  'use strict';
  // 1.2.6.8: Settings → Connected services → TwitchTracker badge switch (on by default)
  try { if ((await chrome.storage.local.get('kwsBadgeTwitchTracker')).kwsBadgeTwitchTracker === false) return; } catch (_) {}

  const STORAGE_KEY = 'twitchKwsHistory';
  const SCAN_CACHE = {}; // channel → { state: 'running'|'queued', percent }
  const LOCAL_SET_AT = {}; // channel → timestamp of last local (optimistic) write
  const LOCAL_GRACE_MS = 6000; // 이 시간 동안은 서버 폴링이 로컬에서 방금 세팅한 값을 못 지움

  // 히스토리 로드
  async function loadHistory() {
    try {
      const r = await chrome.storage.local.get(STORAGE_KEY);
      return r[STORAGE_KEY] || {};
    } catch { return {}; }
  }

  function setLocal(ch, entry) {
    SCAN_CACHE[ch] = entry;
    LOCAL_SET_AT[ch] = Date.now();
  }

  // background에서 현재 스캔 상태 조회
  async function fetchScanState() {
    try {
      const res = await chrome.runtime.sendMessage({ type: 'KWS_TT_GET_STATUS' });
      if (!res) return;
      const now = Date.now();
      const fresh = {};
      for (const ch of (res.activeChannels || [])) {
        fresh[ch.toLowerCase()] = { state: 'running', percent: 0 };
      }
      for (const q of (res.queue || [])) {
        const ch = q.channel?.toLowerCase();
        if (ch && !fresh[ch]) fresh[ch] = { state: 'queued', percent: 0 };
      }
      // 방금(LOCAL_GRACE_MS 이내) 로컬에서 낙관적으로 세팅한 항목은 서버가 아직 못 따라왔을 수 있으니 유지
      for (const ch of Object.keys(SCAN_CACHE)) {
        if (!fresh[ch] && LOCAL_SET_AT[ch] && (now - LOCAL_SET_AT[ch] < LOCAL_GRACE_MS)) {
          fresh[ch] = SCAN_CACHE[ch];
        }
      }
      for (const k of Object.keys(SCAN_CACHE)) delete SCAN_CACHE[k];
      Object.assign(SCAN_CACHE, fresh);
    } catch {}
  }

  let HISTORY = await loadHistory();
  await fetchScanState();

  // 스토리지 변경 감지 (히스토리 업데이트)
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes[STORAGE_KEY]) return;
    HISTORY = changes[STORAGE_KEY].newValue || {};
    scheduleInject();
  });

  // background에서 실시간 상태 수신
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'KWS_TT_STATE' && msg.channel) {
      const ch = msg.channel.toLowerCase();
      if (msg.state === 'done') {
        delete SCAN_CACHE[ch]; delete LOCAL_SET_AT[ch];
      } else {
        setLocal(ch, { state: msg.state, percent: msg.percent || 0 });
      }
      scheduleInject();
    }
  });

  // 배지 스타일
  if (!document.getElementById('kws-tt-style')) {
    const s = document.createElement('style');
    s.id = 'kws-tt-style';
    s.textContent = `.kws-tt-badge{display:inline-flex;align-items:center;padding:1px 7px;border-radius:99px;font-size:10px;font-weight:700;white-space:nowrap;vertical-align:middle;margin-left:6px;cursor:pointer;font-family:-apple-system,sans-serif;line-height:1.6;letter-spacing:0.01em;transition:all 0.15s;}`;
    document.head.appendChild(s);
  }

  const SKIP = new Set(['channels','games','clips','statistics','languages','subscribers','directory','search','personality','following']);

  function makeBadge(slug) {
    const h = HISTORY[slug];
    const sc = SCAN_CACHE[slug];
    const badge = document.createElement('span');
    badge.className = 'kws-tt-badge';
    badge.dataset.kwsSlug = slug;

    if (sc?.state === 'running') {
      badge.textContent = `⏳ ${sc.percent || 0}%`;
      badge.style.cssText = 'background:rgba(251,146,60,0.15);border:1px solid rgba(251,146,60,0.4);color:#fb923c;cursor:default;';
      badge.title = `Scanning ${slug}...`;
    } else if (sc?.state === 'queued') {
      badge.textContent = 'queued';
      badge.style.cssText = 'background:rgba(6,182,212,0.12);border:1px solid rgba(6,182,212,0.35);color:#22d3ee;cursor:default;';
      badge.title = 'Queued — waiting for slot';
    } else if (!h) {
      badge.textContent = 'KWS ▶';
      badge.style.cssText = 'background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.3);color:#f87171;';
      badge.title = `Search ${slug} on Twitch KWS`;
      badge.addEventListener('mouseenter', () => badge.style.background = 'rgba(239,68,68,0.22)');
      badge.addEventListener('mouseleave', () => badge.style.background = 'rgba(239,68,68,0.12)');
      badge.addEventListener('click', e => {
        e.preventDefault(); e.stopPropagation();
        setLocal(slug, { state: 'queued', percent: 0 });
        scheduleInject();
        chrome.runtime.sendMessage({ type: 'KWS_SP_EXTERNAL_SCAN', platform: 'twitch', channel: slug });
      });
    } else {
      const daysAgo = h.searchedAt ? Math.floor((Date.now() - new Date(h.searchedAt)) / 86400000) : null;
      const isRecent = daysAgo !== null && daysAgo <= 1;
      const label = daysAgo === 0 ? 'Today ↺' : daysAgo === 1 ? 'Yesterday ↺' : daysAgo !== null ? `${daysAgo}d ago ↺` : 'KWS ↺';
      const col = isRecent
        ? { bg: 'rgba(34,197,94,0.12)', bdr: 'rgba(34,197,94,0.35)', txt: '#4ade80', hov: 'rgba(34,197,94,0.22)' }
        : { bg: 'rgba(234,179,8,0.12)',  bdr: 'rgba(234,179,8,0.35)',  txt: '#fbbf24', hov: 'rgba(234,179,8,0.22)' };
      badge.textContent = label;
      badge.style.cssText = `background:${col.bg};border:1px solid ${col.bdr};color:${col.txt};`;
      badge.title = `${h.matchedLines || 0} hits · Click to re-scan`;
      badge.addEventListener('mouseenter', () => badge.style.background = col.hov);
      badge.addEventListener('mouseleave', () => badge.style.background = col.bg);
      badge.addEventListener('click', e => {
        e.preventDefault(); e.stopPropagation();
        setLocal(slug, { state: 'queued', percent: 0 });
        scheduleInject();
        chrome.runtime.sendMessage({ type: 'KWS_SP_EXTERNAL_SCAN', platform: 'twitch', channel: slug }); // 외부 사이트에서는 confirm() 팝업이 백그라운드 탭에서 무시될 수 있어서 무조건 풀스캔
      });
    }

    return badge;
  }

  function injectBadges() {
    document.querySelectorAll('.kws-tt-badge').forEach(el => el.remove());

    const seen = new Set();

    function tryInject(el) {
      if (seen.has(el)) return; seen.add(el);
      const text = el.textContent.trim();
      if (!text) return;
      const m = /twitchtracker\.com\/([a-zA-Z0-9_]{3,25})(\/clips)?(\/|$)/.exec(el.href);
      if (!m) return;
      const slug = m[1].toLowerCase();
      if (SKIP.has(slug)) return;
      el.insertAdjacentElement('afterend', makeBadge(slug));
    }

    // 채널 목록/랭킹 페이지: td a
    document.querySelectorAll('td a').forEach(tryInject);

    // 클립 페이지: .clip-channel-name
    document.querySelectorAll('a.clip-channel-name').forEach(tryInject);

    // 게임 클립 페이지 등 기타 채널 링크
    document.querySelectorAll('a.channel-link, a.streamer-link, a[class*="channel-name"]').forEach(tryInject);

    // 스트리머 개인 페이지
    const ttMatch = /^\/([a-zA-Z0-9_]{3,25})(\/|$)/.exec(location.pathname);
    if (ttMatch) {
      const slug = ttMatch[1].toLowerCase();
      if (!SKIP.has(slug)) {
        const h1 = document.querySelector('h1, .channel-name, .streamer-name');
        if (h1 && !h1.querySelector('.kws-tt-badge')) {
          h1.appendChild(makeBadge(slug));
        }
      }
    }
  }

  let _timer;
  function scheduleInject() { clearTimeout(_timer); _timer = setTimeout(injectBadges, 400); }

  [0, 500, 1000, 2000].forEach(d => setTimeout(injectBadges, d));
  new MutationObserver(scheduleInject).observe(document.body, { childList: true, subtree: true });

  // 3초마다 상태 폴링 (스캔 진행률 업데이트)
  setInterval(async () => {
    await fetchScanState();
    scheduleInject();
  }, 3000);

})();
