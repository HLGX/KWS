// soop_main.js — www.sooplive.com MAIN world에서 실행
(function() {
  let _hls = null;
  let _HlsCtor = null;
  let _loadingHls = false;

  async function ensureHlsCtor() {
    const pageCtor = window.hlsStream?.constructor || window.Hls || null;
    if (pageCtor && pageCtor.version) { _HlsCtor = pageCtor; return pageCtor; }
    if (_HlsCtor) return _HlsCtor;
    if (_loadingHls) {
      await new Promise(res => {
        const check = setInterval(() => { if (_HlsCtor || !_loadingHls) { clearInterval(check); res(); } }, 200);
      });
      return _HlsCtor;
    }
    _loadingHls = true;
    return new Promise((res) => {
      const s = document.createElement('script');
      s.src = 'https://cdn.jsdelivr.net/npm/hls.js@1.5.13/dist/hls.min.js';
      s.onload = () => { _HlsCtor = window.Hls || null; _loadingHls = false; res(_HlsCtor); };
      s.onerror = () => { _loadingHls = false; res(null); };
      document.head.appendChild(s);
    });
  }

  window.addEventListener('__soop_hls_cmd', async (e) => {
    const { cmd, url, seekSecs, volume, levelIndex } = e.detail || {};

    if (cmd === 'ping') {
      const ctor = window.hlsStream?.constructor || window.Hls || _HlsCtor;
      window.dispatchEvent(new CustomEvent('__soop_hls_evt', {
        detail: { type: 'pong', hasHls: !!(ctor && ctor.version) }
      }));
      return;
    }

    if (cmd === 'destroy') {
      if (_hls) { try { _hls.destroy(); } catch(e) {} _hls = null; }
      return;
    }

    if (cmd === 'load') {
      const HlsCtor = await ensureHlsCtor();
      if (!HlsCtor) {
        window.dispatchEvent(new CustomEvent('__soop_hls_evt', { detail: { type: 'error', msg: 'No Hls constructor' } }));
        return;
      }

      if (_hls) { try { _hls.destroy(); } catch(e) {} _hls = null; }

      const vid = document.getElementById('__soop_inline_video');
      if (!vid) {
        window.dispatchEvent(new CustomEvent('__soop_hls_evt', { detail: { type: 'error', msg: 'No video element' } }));
        return;
      }

      vid.volume = volume != null ? volume : 0.8;
      vid.muted = false;
      vid.src = ''; vid.load();

      const hls = new HlsCtor({ enableWorker: false });
      _hls = hls;

      hls.on('hlsManifestParsed', (e, data) => {
        // levelIndex가 있으면 해당 화질 레벨 고정 (오래된 VOD master playlist)
        if (levelIndex != null && data?.levels?.length > levelIndex) {
          hls.currentLevel = levelIndex;
          hls.loadLevel = levelIndex;
        }
        if (seekSecs > 0) vid.currentTime = seekSecs;
        vid.play().catch(() => {});
        window.dispatchEvent(new CustomEvent('__soop_hls_evt', { detail: { type: 'manifest_parsed' } }));
      });

      hls.on('hlsError', (e, d) => {
        if (d?.fatal) window.dispatchEvent(new CustomEvent('__soop_hls_evt', { detail: { type: 'fatal_error', details: d?.details } }));
      });

      hls.loadSource(url);
      hls.attachMedia(vid);
    }
  });

  window.dispatchEvent(new CustomEvent('__soop_hls_evt', { detail: { type: 'ready' } }));
})();
