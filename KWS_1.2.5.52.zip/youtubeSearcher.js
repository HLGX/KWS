/*
   VOD KWS Ultimate BETA 1.2.0 — YouTube module
   Runs on youtube.com channel streams pages
   Chat log source: YouTube internal get_live_chat_replay API (no login required)
*/

(function () {
  'use strict';
  console.log('[YT-KWS] script injected, url:', window.location.href);
  if (window._ytKwsLoaded) return;
  window._ytKwsLoaded = true;

  const PANEL_ID      = 'yt-kws-panel';
  const STORAGE_KEY   = 'ytKwsSettings';
  const HISTORY_KEY   = 'ytKwsHistory';
  const CACHE_PREFIX  = 'yt_chat_cache_';
  const CACHE_MAX     = 5 * 1024 * 1024;
  const VERSION       = '1.2.0';
  const ACCENT        = 'rgba(255,0,0,0.85)';
  const ACCENT_BORDER = 'rgba(255,80,80,0.35)';
  const ACCENT_DIM    = 'rgba(255,0,0,0.18)';
  // Translator: 서비스 선택/API 키는 Kick·SOOP·Twitch와 동일한 storage 키를 그대로 써서
  // 플랫폼 사이에 자동으로 동기화되게 함 — 언어 선택만 플랫폼별로 분리(ytKwsTranslateLang).
  const TRANSLATE_LANG_KEY     = 'ytKwsTranslateLangV2';

  let SCAN  = { running:false, done:0, total:0, matched:0, aborted:false };
  let GROUPS = [];
  let HISTORY = {};
  let SETTINGS = { keyword:'' };
  let CHANNEL = '';

  const esc = s => String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  const $   = id => document.getElementById(id);
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  function isStreamsPage() {
    return /youtube\.com\/@[^/?#]+\/streams/.test(location.href) ||
           /youtube\.com\/channel\/[^/?#]+\/streams/.test(location.href);
  }

  function guessChannel() {
    const m = /youtube\.com\/@([^/?#]+)\/streams/.exec(location.href)
           || /youtube\.com\/channel\/([^/?#]+)\/streams/.exec(location.href);
    if (!m) return '';
    // URL의 핸들은 한글 등이 퍼센트 인코딩("%EB%B0%B1...")으로 들어옴 — 화면/기록에는 사람이 읽을 수 있게 디코딩해서 씀.
    let h = m[1];
    try { h = decodeURIComponent(h); } catch (_) {}
    return h.toLowerCase();
  }

  // ── 키워드 ──
  function parseKw(v) {
    const parts = String(v||'').split(/[\n,]/).map(x=>x.trim()).filter(Boolean);
    if (!parts.length) return null;
    return {
      include: parts.filter(p=>!p.startsWith('-')).map(p=>({word:p.replace(/^[~+]+/,''), sub:p.startsWith('~')})),
      exclude: parts.filter(p=>p.startsWith('-')).map(p=>p.replace(/^-+/,''))
    };
  }

  function matchesKw(text, parsed) {
    if (!parsed) return false;
    const t = text.toLowerCase();
    if ((parsed.exclude||[]).some(ex => t.includes(ex.toLowerCase()))) return false;
    if (!parsed.include||!parsed.include.length) return true;
    return parsed.include.some(inc => {
      const w = inc.word.toLowerCase();
      if (inc.sub) return t.includes(w);
      // CJK 한자/카나, 태국어만 substring 취급 (띄어쓰기 관습이 없음). 그 외는 유니코드
      // 인식 단어 경계로 통일 — 예전엔 ASCII 경계문자만 체크해서, 러시아어/체코어처럼
      // 악센트·비ASCII 문자로 둘러싸인 whole-word 키워드가 사실상 substring처럼 동작했음
      if (/[\u4E00-\u9FFF\u3040-\u30FF\u0E00-\u0E7F]/i.test(w)) return t.includes(w);
      try {
        return new RegExp('(?<![\\p{L}\\p{N}])'+w.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'(?![\\p{L}\\p{N}])','iu').test(text);
      } catch (e) { return t.includes(w); }
    });
  }

  function hlKw(html, kws) {
    let o = String(html||'');
    const sorted = [...new Set((kws||[]).filter(Boolean))].sort((a,b)=>b.replace(/^~/,'').length-a.replace(/^~/,'').length);
    for (const rawK of sorted) {
      const isSub = rawK.startsWith('~');
      const k = isSub ? rawK.slice(1) : rawK;
      const esc2 = k.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
      const pat = (isSub||!/^[a-z0-9\s'-]+$/i.test(k))
        ? new RegExp(esc2,'gi')
        : new RegExp('(?<![a-zA-Z0-9\'-])'+esc2+'(?![a-zA-Z0-9\'-])','gi');
      o = o.replace(pat,'<mark style="background:rgba(250,204,21,0.28);color:#fde68a;padding:0 2px;border-radius:3px;">$&</mark>');
    }
    return o;
  }

  // ── background 통신 ──
  function bg(msg) {
    return new Promise((res,rej) => {
      try {
        chrome.runtime.sendMessage(msg, r => {
          if (chrome.runtime.lastError) rej(chrome.runtime.lastError);
          else res(r);
        });
      } catch(e) { rej(e); }
    });
  }

  // ── Storage ──
  async function loadStorage() {
    try {
      const d = await chrome.storage.local.get([STORAGE_KEY, HISTORY_KEY]);
      SETTINGS = Object.assign({keyword:''}, d[STORAGE_KEY]||{});
      HISTORY  = d[HISTORY_KEY]||{};
      // 예전 버전은 핸들을 인코딩된 채로 저장함 — 디코딩된 키로 옮겨서 기록이 끊기지 않게 함
      let _migrated = false;
      for (const k of Object.keys(HISTORY)) {
        if (!/%[0-9a-f]{2}/i.test(k)) continue;
        let dk = k; try { dk = decodeURIComponent(k).toLowerCase(); } catch (_) { continue; }
        if (dk !== k) { if (!HISTORY[dk]) HISTORY[dk] = HISTORY[k]; delete HISTORY[k]; _migrated = true; }
      }
      if (_migrated) { try { await chrome.storage.local.set({ [HISTORY_KEY]: HISTORY }); } catch (_) {} }
    } catch { SETTINGS={keyword:''}; HISTORY={}; }
  }

  async function saveSettings() {
    SETTINGS.keyword = ($('yt-kws-keyword')?.value||'').trim();
    try { await chrome.storage.local.set({[STORAGE_KEY]:SETTINGS}); } catch {}
  }

  // ══════════════════════════════════════════════════════════
  //  TRANSLATE — same engine/services as Kick/SOOP/Twitch's
  //  translateTextAuto; API keys & service choice are shared
  //  across platforms via chrome.storage.local.
  // ══════════════════════════════════════════════════════════
  const TRANSLATE_CACHE = new Map();





  function getTranslateLang() {
    const sel = document.getElementById('yt-kws-translate-lang');
    return (sel?.value || localStorage.getItem(TRANSLATE_LANG_KEY) || 'en').trim() || 'en';
  }



  async function translateTextAuto(text, targetLang) {
    const src = String(text || '').trim();
    if (!src) return '';
    const lang = targetLang || getTranslateLang();
    const cacheKey = `${lang}\n${src}`;
    if (TRANSLATE_CACHE.has(cacheKey)) return TRANSLATE_CACHE.get(cacheKey);
    const data = await globalThis.KWSGTranslate(src, lang); // 1.2.5.46: rotates gtx / dict-chrome-ex / at (platform.js)
    const translated = (data?.[0] || []).map(x => x?.[0] || '').join('').trim();
    if (!translated) throw new Error('empty translation');
    TRANSLATE_CACHE.set(cacheKey, translated);
    return translated;
  }

  function openGoogleTranslate(text, targetLang) {
    const lang = targetLang || getTranslateLang();
    const url = `https://translate.google.com/?sl=auto&tl=${encodeURIComponent(lang)}&text=${encodeURIComponent(text || '')}&op=translate`;
    window.open(url, '_blank');
  }

  async function saveHistory(ch, data) {
    HISTORY[ch] = {...(HISTORY[ch]||{}), ...data, searchedAt:new Date().toISOString()};
    try { await chrome.storage.local.set({[HISTORY_KEY]:HISTORY}); } catch {}
  }

  // ── 캐시 ──
  async function getCache(vid) {
    try {
      const d = await chrome.storage.local.get([CACHE_PREFIX+vid]);
      return d[CACHE_PREFIX+vid] ? JSON.parse(d[CACHE_PREFIX+vid]) : null;
    } catch { return null; }
  }

  async function setCache(vid, msgs) {
    try {
      const v = JSON.stringify(msgs);
      if (v.length <= CACHE_MAX) { try { await chrome.storage.local.set({[CACHE_PREFIX+vid]:v}); } catch (_) {} }
    } catch {}
  }

  // ── VOD 목록 ──
  // 1.2.5.46: the list is read from a fresh copy of this channel's Live page (background.js); one quiet
  // retry when it comes back empty; `fetchVODs.noLive` = the channel has no Live (past streams) tab.
  async function fetchVODs() {
    fetchVODs.noLive = false;
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const result = await bg({cmd:'ytGetChannelVODs', params:{url: location.href}});
        if (result?.vods?.length) return result.vods;
        if (result?.noLive) { fetchVODs.noLive = true; return []; }
      } catch {}
      // (a hidden tab's own timers are throttled — wait in the service worker, as the SOOP engine does)
      if (attempt === 0) { try { await chrome.runtime.sendMessage({ type: 'KWS_SP_SLEEP', ms: 1500 }); } catch (_) { await new Promise((r) => setTimeout(r, 1500)); } }
    }
    return [];
  }
  const YT_NO_LIST = () => fetchVODs.noLive ? 'This channel has no Live tab (no past live streams to search).' : 'Could not load the stream list. Refresh the page and try again.';

  // ── 채팅 fetch ──
  // ── continuation 추출 (content script에서 직접 fetch) ──
  async function getContinuation(videoId) {
    try {
      const res = await fetch(`https://www.youtube.com/watch?v=${videoId}`, {
        credentials: 'include',
        headers: { 'Accept-Language': 'en-US,en;q=0.9' }
      });
      const html = await res.text();
      const start = html.indexOf('var ytInitialData = ');
      if (start < 0) return null;
      const jsonStart = html.indexOf('{', start);
      let depth = 0, i = jsonStart;
      for (; i < html.length; i++) {
        if (html[i] === '{') depth++;
        else if (html[i] === '}') { depth--; if (depth === 0) break; }
      }
      const data = JSON.parse(html.slice(jsonStart, i + 1));
      const bar = data?.contents?.twoColumnWatchNextResults?.conversationBar;
      const conts = bar?.liveChatRenderer?.continuations || [];
      for (const c of conts) {
        const token = c?.reloadContinuationData?.continuation
          || c?.invalidationContinuationData?.continuation
          || c?.liveChatReplayContinuationData?.continuation;
        if (token) return token;
      }
      return null;
    } catch { return null; }
  }

  // ── 채팅 페이지 fetch (content script에서 직접, 쿠키 자동 포함) ──
  async function fetchChatPage(continuation, videoId) {
    try {
      const body = {
        context: { client: { clientName:'WEB', clientVersion:'2.20250101.00.00', hl:'en', gl:'US' } },
        continuation
      };
      const res = await fetch(
        'https://www.youtube.com/youtubei/v1/live_chat/get_live_chat_replay?prettyPrint=false',
        {
          method: 'POST',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json',
            'X-YouTube-Client-Name': '1',
            'X-YouTube-Client-Version': '2.20250101.00.00',
            'X-Origin': 'https://www.youtube.com',
            'Origin': 'https://www.youtube.com',
            'Referer': `https://www.youtube.com/watch?v=${videoId}`
          },
          body: JSON.stringify(body)
        }
      );
      const data = await res.json();
      const contData = data?.continuationContents?.liveChatContinuation;
      if (!contData) return { messages: [], next: null };
      const messages = [];
      for (const action of (contData?.actions || [])) {
        const item = action?.replayChatItemAction?.actions?.[0]?.addChatItemAction?.item;
        if (!item) continue;
        const renderer = item?.liveChatTextMessageRenderer || item?.liveChatPaidMessageRenderer;
        if (!renderer) continue;
        const text = (renderer?.message?.runs || []).map(r => r.text || '').join('');
        if (!text) continue;
        messages.push({
          text, author: renderer?.authorName?.simpleText || '',
          offsetMs: parseInt(action?.replayChatItemAction?.videoOffsetTimeMsec || '0')
        });
      }
      let next = null;
      for (const c of (contData?.continuations || [])) {
        // liveChatReplayContinuationData = 실제로 더 가져올 아카이브 채팅이 있다는 뜻.
        // playerSeekContinuationData는 라이브 상태 추격용 토큰이라, 끝난 VOD 리플레이에서는
        // 이게 계속 반복 응답돼서 무한루프에 빠지는 원인이 됐음 — next-page 취급하면 안 됨.
        if (c?.liveChatReplayContinuationData?.continuation) {
          next = c.liveChatReplayContinuationData.continuation;
          break;
        }
      }
      return { messages, next };
    } catch(e) { return { messages: [], next: null, _failed: true }; }
  }

  // ── 채팅 fetch ──
  async function fetchChat(videoId, onProgress) {
    const cached = _ytSkipCache ? null : await getCache(videoId);
    if (cached) { onProgress&&onProgress({cached:true,total:cached.length}); return cached; }
    const msgs = [];
    let incomplete = false;
    try {
      const cont = await getContinuation(videoId);
      if (!cont) return msgs;
      let token = cont, page = 0, emptyStreak = 0;
      const MAX_PAGES = 3000; // 안전장치 — 이 이상은 정상적인 VOD라면 거의 나올 일 없음
      while (token && !SCAN.aborted && page < MAX_PAGES) {
        page++;
        let r = await fetchChatPage(token, videoId);
        // ⚠ 요청 자체가 실패한 것(네트워크 문제)과 "이 페이지엔 새 메시지가 없음"(정상)을
        // 구분해야 함 — 예전엔 fetchChatPage가 실패하든 진짜로 안 끝났든 똑같이
        // {messages:[], next:null}을 반환해서, 네트워크가 한 번만 삐끗해도 next 토큰이
        // null이 되어버려 그 뒤로 남은 채팅을 전부 못 가져오고 "정상 종료"인 것처럼
        // 조용히 끝나버렸음(재시도 없음). continuation 토큰 기반이라 SOOP처럼 나중에
        // 조각 하나만 다시 받아올 수도 없어서, 여기서 실패하면 그 뒤 채팅 전체가 통째로
        // 유실되는 더 심각한 케이스였음.
        if (r._failed) {
          let recovered = false;
          for (let attempt = 0; attempt < 3; attempt++) {
            await new Promise(res => setTimeout(res, 500 * (attempt + 1)));
            r = await fetchChatPage(token, videoId);
            if (!r._failed) { recovered = true; break; }
          }
          if (!recovered) {
            // 재시도까지 실패 — 여기서부터는 못 가져온 것으로 인정하고 스캔을 멈추되,
            // "다 끝났다"고 속이지 않고 incomplete로 표시해서 캐시에 영구 저장하지 않음
            incomplete = true;
            console.warn('[YT-KWS] chat fetch failed after retries for', videoId, 'at page', page, '— stopping early, marking incomplete');
            break;
          }
        }
        msgs.push(...(r.messages||[]));
        // 빈 페이지가 여러 번 연속되면 사실상 끝난 것으로 간주 (토큰이 계속 나와도 새 데이터가 없으면 중단)
        // — 실패 후 재시도로 회복된 페이지는 진짜 "성공한 빈 페이지"이므로 그대로 카운트
        emptyStreak = (r.messages && r.messages.length) ? 0 : emptyStreak + 1;
        if (emptyStreak >= 10) break;
        token = r.next||null;
        onProgress&&onProgress({fetched:msgs.length, page});
        await null; // (setTimeout here gets throttled to once a minute in a background tab)
      }
      // incomplete(재시도까지 실패)면 불완전한 데이터를 캐시에 영구 저장하지 않음 —
      // 캐시되면 다음 검색 때도 계속 이 잘린 데이터를 "완료된 결과"로 믿고 재사용하게 됨
      if (msgs.length && !incomplete) await setCache(videoId, msgs);
    } catch {}
    if (incomplete) msgs._incomplete = true;
    return msgs;
  }

  // Twitch/Kick/SOOP과 동일한 "이어 검색 / 처음부터" 팝업 — 이전 검색 기록이 있을 때만 표시
  function runSearchWithRescanPopup() {
    if (SCAN.running) return;
    const ch = (CHANNEL || guessChannel() || '').toLowerCase();
    const h = HISTORY[ch] || Object.entries(HISTORY).find(([k]) => k.toLowerCase() === ch || k.toLowerCase().replace(/^@/, '') === ch.replace(/^@/, ''))?.[1];
    if (h?.lastDate && typeof window.showRescanPopup === 'function') {
      window.showRescanPopup(ch, '', h.displayName || ch, h.lastDate,
        () => { runSearch({ fresh: true }); updateBtn(); },
        () => { runSearch({ newOnly: true }); updateBtn(); }
      );
    } else {
      runSearch(); updateBtn();
    }
  }

  // ── 검색 ──
  // 재검색 팝업 선택값: fresh=캐시 무시하고 전부 다시 받기("Full rescan"),
  // newOnly=이미 검색(캐시)된 VOD는 건너뛰고 새 VOD만("New VODs only")
  let _ytSkipCache = false;
  async function runSearch(opts) {
    opts = opts || {};
    if (SCAN.running) return;
    _ytSkipCache = !!opts.fresh;
    const kwRaw = ($('yt-kws-keyword')?.value||'').trim();
    const parsed = parseKw(kwRaw);
    SCAN = {running:true, done:0, total:0, matched:0, aborted:false};
    ytSetPageGuard(true);
    GROUPS = [];
    await saveSettings();
    renderResults();
    setWarn(true);

    // 탭을 여러 개 띄워놓고 돌리다가 스캔 도중에 탭을 그냥 닫아버리면, 맨 아래에서 스캔
    // "완료" 시점에만 한 번 호출되던 saveHistory가 아예 실행될 기회도 없이 탭과 함께
    // 사라져서 History에 검색했던 기록 자체가 전혀 안 남는 버그가 있었음. 완료를 기다리지
    // 않고 스캔을 "시작"하는 시점에 바로 한 번 저장해서, 중간에 탭이 닫혀도 최소한 "이
    // 채널을 이 날짜에 검색했다"는 기록은 남도록 함 (끝까지 가면 아래에서 matchedLines 등을
    // 다시 saveHistory로 덮어써서 최종 결과로 갱신됨).
    {
      const chStart = CHANNEL||guessChannel();
      if (chStart) await saveHistory(chStart, {displayName:chStart, lastDate:new Date().toISOString().slice(0,10)});
    }

    try {
      setStatus('📋 Loading stream list...');
      const vods = await fetchVODs();
      if (!vods.length) {
        setStatus('❌ ' + YT_NO_LIST());
        SCAN.running=false; setWarn(false); updateBtn(); return;
      }
      SCAN.total = vods.length;
      setProgress(0, vods.length);

      let incompleteCount = 0;
      for (let i=0; i<vods.length; i++) {
        if (SCAN.aborted) break;
        const vod = vods[i];
        if (opts.newOnly && await getCache(vod.videoId)) { SCAN.done = i+1; setProgress(i+1, vods.length); continue; }
        setStatus(`🔍 VOD ${i+1}/${vods.length}: ${esc(vod.title||vod.videoId)}`);
        const msgs = await fetchChat(vod.videoId, ({fetched,cached,total})=>{
          if (cached) setStatus(`⚡ Cached (${i+1}/${vods.length}): ${esc(vod.title||vod.videoId)} — ${total} msgs`);
          else setStatus(`🔍 VOD ${i+1}/${vods.length}: ${esc(vod.title||vod.videoId)} — ${fetched||0} collected`);
        });
        if (msgs._incomplete) incompleteCount++;
        const matched = msgs.filter(m=>matchesKw(m.text, parsed));
        if (matched.length || msgs._incomplete) {
          SCAN.matched += matched.length;
          GROUPS.push({videoId:vod.videoId, title:vod.title, date:vod.date, matches:matched, incomplete: !!msgs._incomplete});
          renderResults();
        }
        SCAN.done = i+1;
        setProgress(i+1, vods.length);
      }

      const ch = CHANNEL||guessChannel();
      await saveHistory(ch, {displayName:ch, matchedLines:SCAN.matched, lastDate:new Date().toISOString().slice(0,10)});
      const incompleteNote = incompleteCount ? ` · ⚠️ ${incompleteCount} VOD(s) partially scanned due to network issues (may be missing matches)` : '';
      setStatus(SCAN.aborted
        ? `⏹ Stopped — ${SCAN.done}/${SCAN.total} VODs, ${SCAN.matched} matches${incompleteNote}`
        : `✅ Done — ${SCAN.total} VODs, ${SCAN.matched} matches${incompleteNote}`);
    } catch(e) {
      setStatus('❌ Error: '+(e?.message||e));
    }
    SCAN.running=false; setWarn(false); updateBtn();
  }

  // ── UI 헬퍼 ──
  function setStatus(t) { const e=$('yt-kws-status'); if(e) e.innerHTML=t; }
  function setProgress(done,total) {
    const b=$('yt-kws-bar'), l=$('yt-kws-prog');
    if(b) b.style.width = total ? Math.round(done/total*100)+'%' : '0%';
    if(l) l.textContent = total ? done+' / '+total : '';
  }
  function setWarn(v) { const e=$('yt-kws-warn'); if(e) e.style.display=v?'flex':'none'; }
  // 스캔 중 탭을 닫거나 이동하려 하면 브라우저 확인 팝업 — 다른 KWS와 동일 (스캔이 끝나거나 멈추면 해제)
  const _ytBeforeUnload = e => { e.preventDefault(); e.returnValue = ''; };
  function ytSetPageGuard(active) {
    if (active) window.addEventListener('beforeunload', _ytBeforeUnload);
    else window.removeEventListener('beforeunload', _ytBeforeUnload);
  }
  function updateBtn() {
    ytSetPageGuard(!!SCAN.running);
    const b=$('yt-kws-run');
    if(!b) return;
    if(SCAN.running) { b.textContent='■ Stop'; b.style.background='linear-gradient(135deg,rgba(220,38,38,0.85),rgba(239,68,68,0.85))'; }
    else { b.textContent='▶ Start Scan'; b.style.background='linear-gradient(135deg,rgba(180,0,0,0.9),rgba(220,38,38,0.9))'; }
  }

  // 이 메시지에 실제로 걸린 검색어들 (결과 칩 표시용 — 다른 KWS와 동일하게 "무슨 키워드로 잡혔는지" 보여줌)
  function matchedWordsOf(text) {
    const parsed = parseKw(($('yt-kws-keyword')?.value||'').trim());
    if (!parsed || !parsed.include?.length) return [];
    return parsed.include.filter(inc => matchesKw(text, { include:[inc], exclude:[] })).map(inc => inc.word);
  }
  function matchedChip(text) {
    const w = matchedWordsOf(text);
    if (!w.length) return '';
    const shown = w.slice(0,3).join(', ') + (w.length>3 ? ' +'+(w.length-3) : '');
    return `<div style="display:inline-block;margin-bottom:3px;padding:1px 6px;background:rgba(234,179,8,0.15);color:#fde047;border:1px solid rgba(234,179,8,0.25);border-radius:5px;font-size:9px;font-weight:700;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;vertical-align:top;">${esc(shown)}</div>`;
  }

  // ── 결과 렌더링 ──
  function renderResults() {
    const cont = $('yt-kws-results');
    if (!cont) return;
    { const sumEl = $('yt-kws-summary');
      if (sumEl) sumEl.textContent = window.KWSHitsText(GROUPS.reduce((a, g) => a + ((g.matches || []).length), 0), false); }
    if (!GROUPS.length) {
      cont.innerHTML = '<div style="font-size:12px;color:rgba(255,255,255,0.3);padding:12px 0;text-align:center;">No results</div>';
      return;
    }
    const kwRaw = ($('yt-kws-keyword')?.value||'').trim();
    const kws = kwRaw ? kwRaw.split(/[\n,]/).map(x=>x.trim()).filter(x=>x&&!x.startsWith('-')) : [];

    cont.innerHTML = GROUPS.map((g,gi) => {
      // 비슷한 시간대(인접 180초 미만)는 한 클러스터로 묶어 강조 — Kick/SOOP/Twitch KWS와 같은 방식(YouTube는 빨강 테마)
      const ms = g.matches;
      const inCluster = new Array(ms.length).fill(-1);
      let gid = 0, ci = 0;
      while (ci < ms.length) {
        let cj = ci + 1;
        while (cj < ms.length && ((ms[cj].offsetMs||0) - (ms[cj-1].offsetMs||0)) < 180000) cj++;
        if (cj - ci >= 2) { for (let k = ci; k < cj; k++) inCluster[k] = gid; gid++; }
        ci = cj;
      }
      const items = ms.map((m,mi) => {
        const tsKey = m.offsetMs!=null ? String(Math.floor(m.offsetMs/1000)) : '';
        const clicked = HISTORY[CHANNEL]?.clickedTimes?.[g.videoId+'_'+tsKey] ? 'yt-kws-visited' : '';
        const tBox = 'margin-top:4px;padding:5px 7px;border-radius:7px;background:rgba(14,165,233,0.07);border:1px solid rgba(14,165,233,0.14);color:#bae6fd;font-size:11px;line-height:1.45;word-break:break-word;';
        const translatedHtml = `<div class="yt-kws-translated" data-gi="${gi}" data-mi="${mi}" style="display:none;${tBox}"></div>`;
        const g0 = inCluster[mi], isC = g0 >= 0;
        const first = isC && inCluster[mi-1] !== g0, last = isC && inCluster[mi+1] !== g0;
        const br = isC ? `${first?'9px 9px':'0 0'} ${last?'9px 9px':'0 0'}` : '9px';
        const bc = isC ? 'rgba(239,68,68,0.5)' : 'rgba(255,255,255,0.06)';
        const bb = isC && !last ? '1px solid rgba(239,68,68,0.22)' : '1px solid ' + bc;
        const mt = (isC && first && mi > 0) ? 'margin-top:6px;' : '';
        return `<div class="yt-kws-row${isC?' yt-kws-cluster':''}" style="padding:6px 9px;border-radius:${br};background:${isC?'rgba(239,68,68,0.07)':'rgba(255,255,255,0.03)'};border:1px solid ${bc};border-bottom:${bb};${isC&&first?'box-shadow:0 0 8px rgba(239,68,68,0.18);':''}${mt}">
        <div style="display:flex;align-items:flex-start;gap:8px;">
          <button class="yt-kws-tbtn ${clicked}" data-vid="${esc(g.videoId)}" data-ts="${esc(tsKey)}" data-ms="${esc(m.offsetMs)}"
            style="flex-shrink:0;padding:5px 8px;border-radius:8px;font-size:11px;font-weight:700;font-family:monospace;min-width:66px;display:flex;align-items:center;justify-content:center;cursor:pointer;white-space:nowrap;
            background:${ACCENT_DIM};color:#fca5a5;border:1px solid ${ACCENT_BORDER};">
            ▶ ${esc(fmtOffset(m.offsetMs))}
          </button>
          <div style="font-size:12px;color:#cbd5e1;line-height:1.45;word-break:break-word;min-width:0;">
            ${matchedChip(m.text||'')}<div><span style="color:#a5b4fc;font-weight:600;">${esc((m.author||'').replace(/^@/,''))}</span>: ${hlKw(esc(m.text||''),kws)}</div>
          </div>
        </div>
        ${translatedHtml}
        </div>`;
      }).join('');

      return `<div style="margin-bottom:9px;padding:11px 13px;border-radius:14px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;font-weight:800;font-size:12px;line-height:1.4;color:#fca5a5;margin-bottom:7px;padding-bottom:5px;border-bottom:1px solid rgba(255,255,255,0.06);">
          <span title="${esc(g.title||g.videoId)}" style="cursor:help;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">📅 ${esc(g.date||g.title||g.videoId)}  (${g.matches.length} hits)</span>
          <span style="flex-shrink:0;display:flex;align-items:center;gap:4px;">
            <button type="button" class="yt-kws-gtr" data-gi="${gi}" style="flex-shrink:0;font-size:9px;font-weight:800;padding:2px 7px;border-radius:99px;letter-spacing:0.02em;cursor:pointer;font-family:inherit;line-height:1.3;background:rgba(14,165,233,0.14);color:#7dd3fc;border:1px solid rgba(14,165,233,0.3);"></button>
            ${g.incomplete ? `<span title="Network issue — couldn't fetch the full chat log; matches may be undercounted" style="font-size:9px;font-weight:800;padding:2px 7px;border-radius:99px;background:rgba(239,68,68,0.18);color:#fca5a5;border:1px solid rgba(239,68,68,0.35);">⚠ Partial</span>` : ''}
          </span>
        </div>
        <div style="display:flex;flex-direction:column;gap:5px;">${items || '<div style="font-size:11px;color:rgba(255,255,255,0.35);">No matches (partial scan)</div>'}</div>
      </div>`;
    }).join('');

    cont.querySelectorAll('.yt-kws-tbtn').forEach(btn => {
      btn.addEventListener('click', async e => {
        e.stopPropagation();
        const vid = btn.dataset.vid, tsKey = btn.dataset.ts;
        const sec = Math.floor((parseInt(btn.dataset.ms)||0)/1000);
        // Kick/SOOP 등 다른 KWS처럼 매칭된 바로 그 순간이 아니라 30초 전부터 틀어줘서
        // 앞뒤 맥락을 놓치지 않게 함 — 기록(clickedTimes)에 남기는 tsKey는 매칭된 정확한
        // 시점 그대로 두고, 새 탭에서 여는 재생 시작 위치만 당김.
        const seekSec = Math.max(0, sec - 30);
        window.open(`https://www.youtube.com/watch?v=${vid}&t=${seekSec}s`,'_blank');
        btn.classList.add('yt-kws-visited');
        try {
          const ch = CHANNEL||guessChannel();
          const cur = HISTORY[ch]||{};
          const ct = cur.clickedTimes||{};
          ct[vid+'_'+tsKey]=true;
          await saveHistory(ch, {...cur, clickedTimes:ct});
        } catch {}
      });
    });

    // 🌐 묶음(VOD) 단위 일괄 번역 — renderResults()가 스캔 중 주기적으로 전체를 다시 그리므로
    // 번역 결과는 m._kwsTranslation에 저장해뒀다가 리렌더 때 KWSBatchTranslate가 복원함.
    cont.querySelectorAll('.yt-kws-gtr').forEach(btn => {
      const gi = parseInt(btn.dataset.gi,10);
      const g = GROUPS[gi];
      if (!g) return;
      const rows = (g.matches||[]).map((m, mi) => ({
        text: m.text || '',
        box: cont.querySelector(`.yt-kws-translated[data-gi="${gi}"][data-mi="${mi}"]`),
        cached: m._kwsTranslation,
        onDone: (l, t) => { m._kwsTranslation = { lang: l, text: t }; },
        onHide: () => { m._kwsTranslation = null; },
      })).filter(r => r.box);
      if (!rows.length) { btn.style.display = 'none'; return; }
      window.KWSBatchTranslate(btn, rows, getTranslateLang, translateTextAuto, openGoogleTranslate);
    });
  }

  function updateKwPreview() {
    const pr = $('yt-kws-kw-preview');
    if (!pr) return;
    const val = ($('yt-kws-keyword')?.value||'').trim();
    if (!val) { pr.textContent = '✦ Default keywords active'; pr.style.color='rgba(255,255,255,0.45)'; return; }
    const parts = val.split(/[\n,]/).map(x=>x.trim()).filter(Boolean);
    const inc = parts.filter(x=>!x.startsWith('-'));
    const exc = parts.filter(x=>x.startsWith('-'));
    pr.textContent = '+'+inc.length+' words'+(exc.length?' · -'+exc.length:'');
    pr.style.color = '#fff';
  }

  // 채널 표시명(닉네임) — 페이지에서 읽어옴. 로딩이 늦을 수 있어 buildPanel 후 몇 번 재시도.
  function guessNick() {
    const sels = ['#page-header yt-dynamic-text-view-model h1', 'yt-dynamic-text-view-model h1', 'ytd-channel-name yt-formatted-string#text', '#channel-name #text', '#page-header h1'];
    for (const q of sels) {
      const t = document.querySelector(q)?.textContent?.trim();
      if (t) return t;
    }
    return document.querySelector('meta[property="og:title"]')?.getAttribute('content')?.trim() || '';
  }
  function refreshChannelField() {
    const n = $('yt-kws-channel-nick'), h = $('yt-kws-channel-handle');
    if (!n || !h) return;
    const ch = CHANNEL || guessChannel();
    const nick = guessNick();
    n.textContent = nick || (ch ? '@' + ch : '');
    h.textContent = nick && ch ? '@' + ch : '';
    const box = $('yt-kws-channel');
    if (box) box.title = (nick ? nick + ' ' : '') + (ch ? '@' + ch : '');
  }

  function fmtOffset(ms) {
    if (ms==null) return '?';
    const t=Math.floor(ms/1000), h=Math.floor(t/3600), m=Math.floor((t%3600)/60), s=t%60;
    return h>0 ? `${h}h${String(m).padStart(2,'0')}m${String(s).padStart(2,'0')}s` : `${m}m${String(s).padStart(2,'0')}s`;
  }

  // ── 히스토리 윈도우 ──
  function createHistoryWindow() {
    if (!window.KWSHistoryUI) return;
    window.KWSHistoryUI.open({
      platform: 'youtube',
      HISTORY,
      HISTORY_KEY,
      accentColor: '#f87171',
      onGetScanState: (id) => {
        const curCh = (CHANNEL || guessChannel() || '').toLowerCase();
        if (SCAN.running && curCh === id?.toLowerCase()) return 'running';
        return 'idle';
      },
      onIdClick: (id) => { CHANNEL = id; },
      onScan: (id) => {
        const curCh = (CHANNEL || guessChannel() || '').toLowerCase();
        if (curCh === id?.toLowerCase()) {
          // 이미 해당 채널 페이지에 있으면 바로 스캔 시작
          CHANNEL = id;
          if (!SCAN.running) { runSearchWithRescanPopup(); }
        } else {
          // 다른 채널 페이지에 있으면 해당 채널의 Live 탭(스트림 목록)을 새 탭으로 열고,
          // streamrecorder.io 뱃지와 동일하게 ?kws_autoscan=1로 자동으로 검색까지 시작시킴 —
          // 예전엔 탭만 열고 검색은 사용자가 직접 Start Scan을 눌러야 했음.
          window.open(`https://www.youtube.com/@${id}/streams?kws_autoscan=1`, '_blank');
        }
      }
    });
  }

  // ── 드래그 ──
  // topZIndexer()는 domUtils.js에 있는 공용 함수인데, YouTube 모듈은 그 파일을 로드하지 않아서
  // (manifest에 안 들어있음) 여기서 그냥 호출하면 "topZIndexer is not defined"로 mousedown
  // 핸들러가 즉시 throw돼서 mousemove 리스너가 아예 붙지 못했음 — 그래서 헤더를 드래그해도
  // 패널이 전혀 움직이지 않는 버그였음. 다른 파일에 기대지 않도록 이 파일 안에서만 쓰는
  // 작은 z-index 카운터를 직접 둠.
  let _ytZIndexCounter = 2147483640;
  function ytTopZIndexer() { return ++_ytZIndexCounter; }

  function enableDrag(panel, handle) {
    let ox=0, oy=0;
    handle.addEventListener('mousedown', e => {
      if (e.target.tagName==='BUTTON'||e.target.tagName==='INPUT'||e.target.tagName==='TEXTAREA') return;
      e.preventDefault();
      panel.style.zIndex = ytTopZIndexer();
      ox=e.clientX-panel.offsetLeft; oy=e.clientY-panel.offsetTop;
      const move = e2 => {
        panel.style.left = Math.max(0,Math.min(window.innerWidth-panel.offsetWidth,e2.clientX-ox))+'px';
        panel.style.top  = Math.max(0,Math.min(window.innerHeight-panel.offsetHeight,e2.clientY-oy))+'px';
        panel.style.right='auto';
      };
      document.addEventListener('mousemove',move);
      document.addEventListener('mouseup',()=>document.removeEventListener('mousemove',move),{once:true});
    });
  }

  // ── 패널 빌드 ──
  function buildPanel() {
    if ($('yt-kws-panel')) return;
    CHANNEL = guessChannel();

    const panel = document.createElement('div');
    panel.id = PANEL_ID;
    panel.style.cssText = `position:fixed;top:80px;right:16px;z-index:2147483640;width:420px;max-width:calc(100vw - 24px);
      max-height:calc(100vh - 40px);overflow:hidden;display:flex;flex-direction:column;
      background:linear-gradient(180deg,rgba(255,255,255,0.07) 0,rgba(255,255,255,0) 110px),rgba(18,12,14,0.82);border:1px solid rgba(255,255,255,0.16);border-radius:26px;
      box-shadow:0 40px 80px rgba(0,0,0,0.55),inset 0 1px 0 rgba(255,255,255,0.14),0 0 0 1px rgba(239,68,68,0.10);backdrop-filter:saturate(150%) blur(24px);-webkit-backdrop-filter:saturate(150%) blur(24px);
      font-family:-apple-system,BlinkMacSystemFont,sans-serif;color:#e2e8f0;font-size:13px;user-select:none;`;

    panel.innerHTML = `
      <!-- 헤더 (드래그 핸들) -->
      <div id="yt-kws-header" style="display:flex;align-items:center;padding:14px 16px 13px;
        border-bottom:1px solid rgba(255,255,255,0.06);cursor:move;
        background:linear-gradient(180deg,rgba(255,255,255,0.07) 0%,rgba(255,255,255,0) 100%);">
        <div>
          <div style="font-size:13px;font-weight:700;letter-spacing:-0.01em;color:#fff;line-height:1.2;">YouTube KWS</div>
          <div style="display:flex;align-items:center;gap:6px;margin-top:2px;">
            <span id="yt-kws-version-badge" style="font-size:10px;font-weight:700;letter-spacing:0.04em;color:rgba(255,80,80,0.9);
              background:${ACCENT_DIM};border:1px solid ${ACCENT_BORDER};border-radius:5px;padding:1px 6px;">HLGX</span>
          </div>
        </div>
        <div style="margin-left:auto;display:flex;gap:6px;align-items:center;">
          <button id="yt-kws-settings-btn" title="Toggle settings" style="width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:14px;
            background:${ACCENT_DIM};border:1px solid ${ACCENT_BORDER};color:rgba(255,255,255,0.85);
            display:flex;align-items:center;justify-content:center;">⚙</button>
          <button id="yt-kws-discover-btn" title="Find more streamers to search" style="width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:13px;
            background:${ACCENT_DIM};border:1px solid ${ACCENT_BORDER};color:rgba(255,255,255,0.85);
            display:flex;align-items:center;justify-content:center;">🔍</button>
          <button id="yt-kws-history-btn" title="Search History" style="width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:13px;
            background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);color:rgba(255,255,255,0.7);
            display:flex;align-items:center;justify-content:center;">📋</button>
          <button id="yt-kws-close" style="width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:16px;
            background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);color:rgba(255,255,255,0.6);
            display:flex;align-items:center;justify-content:center;">×</button>
        </div>
      </div>

      <!-- 탭 경고 -->
      <div id="yt-kws-warn" style="display:none;align-items:center;gap:8px;padding:8px 16px;
        background:rgba(220,38,38,0.15);border-bottom:1px solid rgba(220,38,38,0.3);">
        <span style="font-size:14px;">🔴</span>
        <span style="font-size:11px;font-weight:700;color:#fca5a5;">Don't close this tab while scanning — closing it will stop the scan.</span>
      </div>

      <!-- 본문 -->
      <div style="overflow-y:auto;flex:1;padding:14px 16px;display:flex;flex-direction:column;gap:12px;">

        <!-- 설정(번역) -->
        <div id="yt-kws-settings-section" style="display:none;padding:12px 14px;border-radius:12px;background:rgba(255,80,80,0.05);border:1px solid rgba(255,80,80,0.15);">
          <div style="font-size:10px;font-weight:800;letter-spacing:0.07em;text-transform:uppercase;color:rgba(255,80,80,0.75);margin-bottom:9px;text-align:center;" title="Chat messages are translated with Google Translate (free)">Translate to</div>
          <select id="yt-kws-translate-lang" title="Translate result messages to this language (Google Translate)" style="width:100%;height:36px;border-radius:10px;border:1px solid ${ACCENT_BORDER};background:#14101d;color:#ffffff;font-size:11px;font-weight:700;padding:0 12px;outline:none;font-family:inherit;box-sizing:border-box;color-scheme:dark;cursor:pointer;"><option value="en" style="background:#14101d;color:#ffffff;">English</option><option value="ko" style="background:#14101d;color:#ffffff;">한국어</option><option value="ja" style="background:#14101d;color:#ffffff;">日本語</option><option value="zh-CN" style="background:#14101d;color:#ffffff;">中文</option><option value="es" style="background:#14101d;color:#ffffff;">Español</option><option value="ru" style="background:#14101d;color:#ffffff;">Русский</option><option value="de" style="background:#14101d;color:#ffffff;">Deutsch</option><option value="fr" style="background:#14101d;color:#ffffff;">Français</option><option value="pt" style="background:#14101d;color:#ffffff;">Português</option><option value="id" style="background:#14101d;color:#ffffff;">Bahasa Indonesia</option><option value="th" style="background:#14101d;color:#ffffff;">ไทย</option><option value="vi" style="background:#14101d;color:#ffffff;">Tiếng Việt</option></select>
        </div>

        <!-- 채널 (고정 표시 — 입력 불가, 현재 보고 있는 채널이 자동으로 들어감) -->
        <div>
          <div style="font-size:10px;font-weight:600;letter-spacing:0.08em;text-transform:uppercase;color:rgba(255,255,255,0.55);margin-bottom:6px;">Channel</div>
          <div id="yt-kws-channel" title="Click to copy channel" style="width:100%;box-sizing:border-box;padding:2px 0;color:#fff;font-size:13px;display:flex;align-items:baseline;gap:8px;cursor:pointer;overflow:hidden;user-select:text;">
            <span id="yt-kws-channel-nick" style="font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0;flex:0 1 auto;"></span>
            <span id="yt-kws-channel-handle" style="color:rgba(255,255,255,0.45);font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0;flex:1 1 0;"></span>
          </div>
        </div>

        <!-- 키워드 -->
        <div>
          <div style="font-size:10px;font-weight:600;letter-spacing:0.08em;text-transform:uppercase;color:rgba(255,255,255,0.55);margin-bottom:6px;">Keywords</div>
          <button id="yt-kws-kw-btn" type="button" style="width:100%;height:40px;padding:0 14px;border-radius:12px;
            border:1px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.07);color:#fff;font-size:12px;
            text-align:left;display:flex;align-items:center;justify-content:space-between;gap:8px;
            cursor:pointer;font-family:inherit;">
            <span id="yt-kws-kw-preview" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:rgba(255,255,255,0.65);"></span>
            <span style="font-size:10px;color:rgba(255,80,80,0.8);flex-shrink:0;">✏️ Edit</span>
          </button>
          <input type="hidden" id="yt-kws-keyword" value="">
        </div>

        <!-- 버튼 -->
        <div style="display:flex;gap:8px;">
          <button id="yt-kws-run" style="flex:1;height:42px;border:none;border-radius:13px;cursor:pointer;
            display:flex;align-items:center;justify-content:center;gap:6px;font-size:13px;font-weight:700;color:#fff;
            background:linear-gradient(135deg,rgba(180,0,0,0.9),rgba(220,38,38,0.9));
            box-shadow:0 4px 16px rgba(220,38,38,0.3),inset 0 1px 0 rgba(255,255,255,0.12);">▶ Start Scan</button>
        </div>

        <!-- 상태 -->
        <div style="padding:10px 13px;border-radius:12px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07);">
          <div style="font-size:9px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:rgba(255,255,255,0.5);margin-bottom:4px;">Status</div>
          <div id="yt-kws-status" style="color:rgba(255,255,255,0.9);font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">Idle</div>
        </div>

        <!-- 진행률 -->
        <div>
          <div style="display:flex;justify-content:space-between;margin-bottom:5px;">
            <span style="font-size:10px;color:rgba(255,255,255,0.5);">Progress</span>
            <span id="yt-kws-prog" style="font-size:10px;color:rgba(255,255,255,0.6);"></span>
          </div>
          <div style="height:4px;background:rgba(255,255,255,0.06);border-radius:99px;overflow:hidden;">
            <div id="yt-kws-bar" style="height:100%;width:0%;background:linear-gradient(90deg,#dc2626,#ef4444);border-radius:99px;transition:width 0.4s cubic-bezier(0.4,0,0.2,1);"></div>
          </div>
        </div>

        <!-- 결과 -->
        <div>
          ${window.KWSResultsHeaderHTML('yt-kws-summary','yt-kws-clear')}
          <div id="yt-kws-results"></div>
        </div>

      </div>
    `;

    // CSS
    const style = document.createElement('style');
    style.textContent = `
      .yt-kws-tbtn { transition:background 0.15s,color 0.15s; }
      .yt-kws-visited { background:rgba(16,185,129,0.18)!important;color:#86efac!important;border-color:rgba(16,185,129,0.45)!important; }
      #yt-kws-panel *::-webkit-scrollbar { width:8px; }
      #yt-kws-panel *::-webkit-scrollbar-track { background:transparent; }
      #yt-kws-panel *::-webkit-scrollbar-thumb { background:rgba(255,255,255,0.15);border-radius:99px; }
    `;
    document.head.appendChild(style);
    document.body.appendChild(panel);
    refreshChannelField(); [800, 2000, 4500].forEach(d => setTimeout(refreshChannelField, d));

    try {
      const vBadge = $('yt-kws-version-badge');
      if (vBadge) vBadge.textContent = 'HLGX V' + (chrome.runtime.getManifest().version || VERSION);
    } catch(e) {}

    enableDrag(panel, $('yt-kws-header'));

    $('yt-kws-close').addEventListener('click', () => {
      if (SCAN.running && !confirm('A scan is in progress. Stop it and close?')) return;
      SCAN.aborted=true; panel.remove();
    });

    $('yt-kws-run').addEventListener('click', () => {
      if (SCAN.running) { SCAN.aborted=true; SCAN.running=false; setWarn(false); updateBtn(); }
      else { runSearch(); updateBtn(); }
    });

    $('yt-kws-history-btn').addEventListener('click', createHistoryWindow);

    $('yt-kws-discover-btn').addEventListener('click', () => window.showKwsDiscoverPopup && window.showKwsDiscoverPopup());

    // ⚙(Settings) 섹션: 항상 접힌 상태로 시작 (다른 KWS와 동일) — ⚙를 누를 때만 펼침.
    let settingsVisible = false;
    $('yt-kws-settings-btn').addEventListener('click', async () => {
      settingsVisible = !settingsVisible;
      const sec = $('yt-kws-settings-section'); if (sec) sec.style.display = settingsVisible ? 'block' : 'none';
    });

    // 번역 서비스/언어 설정 초기화
    try {
      const savedLang = localStorage.getItem(TRANSLATE_LANG_KEY) || 'en';
      if ($('yt-kws-translate-lang')) $('yt-kws-translate-lang').value = savedLang;
    } catch (_) {}
    $('yt-kws-translate-lang')?.addEventListener('change', () => {
      try { localStorage.setItem(TRANSLATE_LANG_KEY, $('yt-kws-translate-lang').value); } catch (_) {}
    });

    if (SETTINGS.keyword) {
      $('yt-kws-keyword').value = SETTINGS.keyword;
      updateKwPreview();
    } else {
      updateKwPreview();
    }

    $('yt-kws-kw-btn').addEventListener('click', () => {
      if (typeof KWSSharedKeywordEditor === 'undefined') return;
      KWSSharedKeywordEditor.open({
        modalId: 'yt-kws-kw-modal',
        inputId: 'yt-kws-keyword',
        previewId: 'yt-kws-kw-preview',
        accent: 'rgba(220,38,38,0.9)',
        storageKey: STORAGE_KEY,
        historyKey: HISTORY_KEY,
        onSaved: (val, profile) => {
          SETTINGS.keyword = val;
          if (typeof KWSSharedKeywordEditor !== 'undefined')
            KWSSharedKeywordEditor.saveToAllPlatforms(val, profile).catch(()=>{});
          updateKwPreview();
        }
      });
    });
    $('yt-kws-clear')?.addEventListener('click', () => {
      if (!GROUPS.length) return;
      window.KWSClearDialog({
        running: [],
        currentLabel: null,
        tabCount: 1,
        onAll: () => { GROUPS = []; renderResults(); },
      });
    });
    renderResults();

    // streamrecorder.io/latest/yt 뱃지에서 열린 탭인 경우 — 채널 ID만 채워놓고 마는 게 아니라
    // 바로 스캔을 시작함 (Kick/SOOP의 streamrecorder 뱃지와 같은 동작). YouTube는 UI가 달라서
    // (한 탭에 패널 하나만 뜨는 구조) 탭 재사용 없이 뱃지를 누를 때마다 매번 새 탭을 여는데,
    // 그 탭에서 자동으로 스캔까지 시작되도록 하는 역할. history.replaceState로 쿼리스트링을
    // 지워서 새로고침해도 스캔이 다시 시작되지 않게 함.
    if (/(?:^|[?&])kws_autoscan=1(?:&|$)/.test(location.search)) {
      try {
        const cleanUrl = location.pathname + location.hash;
        history.replaceState(null, '', cleanUrl);
      } catch (e) {}
      const kwInput = $('yt-kws-keyword');
      if (kwInput && !kwInput.value.trim() && typeof KWSSharedKeywordEditor !== 'undefined') {
        const def = KWSSharedKeywordEditor.defaultValue();
        if (def) { kwInput.value = def; SETTINGS.keyword = def; updateKwPreview(); }
      }
      setTimeout(() => { if (!SCAN.running) runSearchWithRescanPopup(); }, 400);
    }
  }

  // ══════════════════════════════════════════════════════════
  //  1.2.5 side panel mode — the scan runs here (the chat replay API needs this page), started
  //  and shown by the side panel through the background scan hub. No on-page panel.
  // ══════════════════════════════════════════════════════════
  const SP_MODE = true;
  const SP_RUNS = new Map(); // hub scan id → true while running (one scan per tab, as in 1.2.4)
  function spEmit(id, kind, payload) {
    try { chrome.runtime.sendMessage({ type: 'KWS_SP_PAGE_EVENT', platform: 'youtube', id, kind, ...(payload || {}) }).catch(() => {}); } catch (_) {}
  }
  function spGroups(ch) {
    return GROUPS.map((g, i) => ({
      key: g.videoId, order: i, date: g.date || '', displayDate: g.date || g.title || g.videoId, vodTitle: g.title || '',
      incomplete: !!g.incomplete,
      messages: (g.matches || []).map((m) => {
        const sec = m.offsetMs != null ? Math.floor(m.offsetMs / 1000) : 0;
        const hms = Math.floor(sec / 3600) + ':' + String(Math.floor(sec % 3600 / 60)).padStart(2, '0') + ':' + String(sec % 60).padStart(2, '0');
        return { ts: hms, playback_ts: hms, playback_offset: sec, username: String(m.author || '').replace(/^@/, ''),
          message: m.text || '', keywords: matchedWordsOfParsed(m.text || ''), vod_id: g.videoId, vod_title: g.title || '', vod_channel: ch };
      }),
    }));
  }
  let _spParsed = null;
  function matchedWordsOfParsed(text) {
    if (!_spParsed || !_spParsed.include?.length) return [];
    return _spParsed.include.filter((inc) => matchesKw(text, { include: [inc], exclude: [] })).map((inc) => inc.word);
  }
  async function spRunScan({ id, channel, params }) {
    if (SCAN.running) return;
    const ch = String(channel || CHANNEL || guessChannel() || '').toLowerCase();
    let kw = (params && params.keyword) || '';
    if (!kw && typeof KWSSharedKeywordEditor !== 'undefined') kw = KWSSharedKeywordEditor.defaultValue() || '';
    _spParsed = parseKw(kw);
    _ytSkipCache = !!(params && params.fresh);
    const newOnly = !!(params && params.newOnly);
    SCAN = { running: true, done: 0, total: 0, matched: 0, aborted: false };
    GROUPS = [];
    SP_RUNS.set(id, true); // runs in the hub's own background tab: no leave-page warning
    spEmit(id, 'start', { keywords: kw.split(/[\n,]/).map((x) => x.trim()).filter((x) => x && !x.startsWith('-')) });
    // 1.2.4 saved a history entry at the start too, so closing the tab mid-scan still leaves a record.
    if (ch) await saveHistory(ch, { displayName: ch, lastDate: new Date().toISOString().slice(0, 10) });
    let incomplete = 0;
    const snap = () => ({ done: SCAN.done, total: SCAN.total, matchedLines: SCAN.matched, matchedDays: GROUPS.filter((g) => g.matches.length).length,
      totalSessions: SCAN.total, groups: spGroups(ch), failed: incomplete, historyPatch: { displayName: ch } });
    try {
      const vods = await fetchVODs();
      if (!vods.length) throw new Error(YT_NO_LIST());
      SCAN.total = vods.length;
      spEmit(id, 'progress', snap());
      for (let i = 0; i < vods.length; i++) {
        if (SCAN.aborted) break;
        const vod = vods[i];
        if (newOnly && await getCache(vod.videoId)) { SCAN.done = i + 1; continue; }
        const msgs = await fetchChat(vod.videoId, null);
        if (msgs._incomplete) incomplete++;
        const matched = msgs.filter((m) => matchesKw(m.text, _spParsed));
        if (matched.length || msgs._incomplete) {
          SCAN.matched += matched.length;
          GROUPS.push({ videoId: vod.videoId, title: vod.title, date: vod.date, matches: matched, incomplete: !!msgs._incomplete });
        }
        SCAN.done = i + 1;
        spEmit(id, 'progress', snap());
      }
      spEmit(id, 'done', { ...snap(), stopped: SCAN.aborted });
    } catch (e) {
      spEmit(id, 'ended', { ...snap(), error: (e && e.message) || String(e) });
    } finally {
      SCAN.running = false;
      SP_RUNS.delete(id);
    }
  }

  // Hub worker tab: keep "KWS 스캔 중 · <site title>" as the tab title so it isn't closed as a stray tab.
  function kwsMarkWorker(title) {
    if (!title || window.__kwsWorkerMark) return;
    window.__kwsWorkerMark = true;
    const prefix = '[' + title + '] ';
    const fix = () => { const t = document.title || ''; if (!t.startsWith(prefix)) document.title = prefix + t.replace(/^\[[^\]]*\]\s*/, ''); };
    // The worker tab is never looked at: stop the site's own video (SOOP main autoplays a live
    // stream) so it doesn't take the CPU the scan needs.
    const quiet = () => { fix(); document.querySelectorAll('video').forEach((v) => { try { v.muted = true; if (!v.paused) v.pause(); } catch (_) {} }); };
    quiet();
    // A plain timer, not a MutationObserver: when the site resets its own title, an observer and
    // the site would rewrite it back and forth without end and hang the page.
    setInterval(quiet, 3000);
  }
  if (SP_MODE) {
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (msg && msg.type === 'KWS_SP_PAGE_PING') { sendResponse({ ok: true, running: [...SP_RUNS.keys()] }); return; }
      if (!msg || msg.platform !== 'youtube') return;
      if (msg.type === 'KWS_SP_PAGE_RUN') { kwsMarkWorker(msg.worker);
        if (SCAN.running) { sendResponse({ ok: false, busy: true }); return; }
        loadStorage().then(() => spRunScan(msg));
        sendResponse({ ok: true });
      } else if (msg.type === 'KWS_SP_PAGE_STOP') {
        if (SP_RUNS.has(msg.id)) SCAN.aborted = true;
        sendResponse({ ok: true });
      }
    });
    // streamrecorder.io / history (?kws_autoscan=1): start in the hub; the panel shows it.
    if (isStreamsPage() && /(?:^|[?&])kws_autoscan=1(?:&|$)/.test(location.search)) {
      try { history.replaceState(null, '', location.pathname + location.hash); } catch (e) {}
      const ch = guessChannel();
      setTimeout(() => {
        try { chrome.runtime.sendMessage({ type: 'KWS_SP_BADGE_SCAN', platform: 'youtube', channel: ch, mode: 'full', openPanel: false }).catch(() => {}); } catch (_) {}
      }, 400);
    }
  }

  // ── 네비게이션 감지 ──
  let _lastLoadedChannel = null;
  function onNav() {
    if (isStreamsPage()) {
      const ch = guessChannel();
      // 패널이 이미 있어도 "다른 채널"로 넘어온 거면 다시 불러와야 함 —
      // 예전엔 패널 존재 여부만 보고 있어서, 스트리머를 바꿔도 최초에 로드된 채널의
      // VOD 목록이 그대로 남아있는 버그가 있었음
      if (!$('yt-kws-panel') || ch !== _lastLoadedChannel) {
        _lastLoadedChannel = ch;
        $('yt-kws-panel')?.remove();
        loadStorage().then(buildPanel);
      }
    } else {
      _lastLoadedChannel = null;
      $('yt-kws-panel')?.remove();
    }
  }

  if (!SP_MODE) window.addEventListener('yt-navigate-finish', onNav);

  const _push = history.pushState.bind(history);
  if (!SP_MODE) {
    history.pushState = function(...args) { _push(...args); setTimeout(onNav, 800); };
    window.addEventListener('popstate', () => setTimeout(onNav, 800));
  }

  // 초기 실행
  if (!SP_MODE && isStreamsPage()) {
    _lastLoadedChannel = guessChannel();
    loadStorage().then(buildPanel);
  }

})();
