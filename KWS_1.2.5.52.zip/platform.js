// KWS 1.2.5 — URL → platform / channel. Shared by the side panel and the floating button.
// Mirrors the rules each 1.2.4 searcher already uses (guessChannel / guessChannelFromUrl /
// guessStreamerIdFromUrl), so the panel recognizes exactly the channels the scanners do.
(function (global) {
  'use strict';

  const TWITCH_SKIP = new Set(['videos', 'directory', 'search', 'settings', 'subscriptions', 'following', 'moderator', 'clips', 'downloads', 'jobs', 'turbo', 'p', 'wallet', 'inventory', 'messages', 'friends', 'login', 'signup', 'drops']);
  const KICK_SKIP = new Set(['browse', 'search', 'categories', 'settings', 'help', 'about', 'live', 'following', 'clips', 'videos', 'en', 'dashboard']);

  function safeDecode(s) { try { return decodeURIComponent(s); } catch (_) { return s; } }

  // Returns { platform, channel, ytLiveTab, ytHandle } or null for unsupported sites.
  //   platform  : 'twitch' | 'kick' | 'soop' | 'youtube'
  //   channel   : '' when the page belongs to the platform but no channel can be read from it
  //   ytLiveTab : YouTube only — true on /@handle/streams or /channel/<id>/streams (the only place it can scan)
  //   ytHandle  : YouTube only — '@handle' or 'channel/<id>' when the URL names a channel, for "open Live tab"
  function parseVodUrl(href) {
    let u;
    try { u = new URL(href); } catch (_) { return null; }
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
    const host = u.hostname.toLowerCase();
    const seg = u.pathname.split('/').filter(Boolean);

    if (host === 'www.twitch.tv' || host === 'twitch.tv' || host === 'm.twitch.tv') {
      const first = (seg[0] || '').toLowerCase();
      return { platform: 'twitch', channel: first && !TWITCH_SKIP.has(first) ? first : '' };
    }

    if (host === 'kick.com' || host === 'www.kick.com') {
      const first = (seg[0] || '').toLowerCase();
      return { platform: 'kick', channel: first && !KICK_SKIP.has(first) ? first : '' };
    }

    if (host === 'sooplive.com' || host.endsWith('.sooplive.com') || host.endsWith('.sooplive.co.kr')) {
      let channel = '';
      const station = u.pathname.match(/\/station\/([^/?#]+)/i);
      if (station) channel = safeDecode(station[1]);
      else if ((host === 'play.sooplive.com' || host === 'play.sooplive.co.kr' || host === 'ch.sooplive.co.kr') && seg[0]) channel = safeDecode(seg[0]);
      return { platform: 'soop', channel: channel.toLowerCase() };
    }

    if (host === 'www.youtube.com' || host === 'youtube.com' || host === 'm.youtube.com') {
      let ytHandle = '';
      let channel = '';
      let ytLiveTab = false;
      if (seg[0] && seg[0].startsWith('@')) {
        ytHandle = seg[0];
        ytLiveTab = seg[1] === 'streams';
        if (ytLiveTab) channel = safeDecode(seg[0].slice(1)).toLowerCase();
      } else if (seg[0] === 'channel' && seg[1]) {
        ytHandle = 'channel/' + seg[1];
        ytLiveTab = seg[2] === 'streams';
        if (ytLiveTab) channel = safeDecode(seg[1]).toLowerCase();
      }
      return { platform: 'youtube', channel, ytLiveTab, ytHandle };
    }

    if (host === 'chzzk.naver.com' || host === 'm.chzzk.naver.com') {
      // /{channelId}, /live/{channelId}, /{channelId}/videos … — the channel ID is a 32-hex hash
      const id = seg.find((x) => /^[0-9a-f]{32}$/i.test(x)) || '';
      return { platform: 'chzzk', channel: id.toLowerCase() };
    }

    return null;
  }

  // Channel page to open from a history row.
  function channelUrl(platform, id) {
    const e = encodeURIComponent(id);
    switch (platform) {
      case 'twitch': return 'https://www.twitch.tv/' + e;
      case 'kick': return 'https://kick.com/' + e;
      case 'soop': return 'https://www.sooplive.com/station/' + e;
      case 'youtube': return /^uc[\w-]{22}$/i.test(id)
        ? 'https://www.youtube.com/channel/' + id + '/streams'
        : 'https://www.youtube.com/@' + e + '/streams';
      case 'chzzk': return 'https://chzzk.naver.com/' + e;
    }
    return null;
  }

  // chrome.storage.local keys written by the 1.2.4 searchers (unchanged in 1.2.5).
  const HISTORY_KEYS = { twitch: 'twitchKwsHistory', kick: 'kickKwsHistory', soop: 'soopSearchHistory', youtube: 'ytKwsHistory', chzzk: 'chzzkKwsHistory' };
  const PLATFORM_NAMES = { twitch: 'Twitch', kick: 'Kick', soop: 'SOOP', youtube: 'YouTube', chzzk: 'CHZZK' };

  global.KWSPlatform = { parseVodUrl, channelUrl, HISTORY_KEYS, PLATFORM_NAMES };
})(globalThis);

// 1.2.5.45/48 — inline VOD players, YouTube-style:
//  · double-click the left / right part of the picture → back / forward 10 s, with YouTube's white
//    half-circle ripple and ◀◀◀ / ▶▶▶ arrows; quick repeats add up (10 → 20 → 30 s …)
//  · press and hold on the picture while it plays → 4× speed ("4배속 ▶▶" pill at the top), back to the
//    old speed on release; the click that ends the hold does not pause the video
//  · the middle keeps its old double-click (fullscreen). `seek(delta)` is the player's own seek.
(function (global) {
  if (global.KWSDblSeek) return;
  const KO = /^ko/i.test(navigator.language || '');
  function css() {
    if (document.getElementById('kws-dblseek-style')) return;
    const st = document.createElement('style');
    st.id = 'kws-dblseek-style';
    st.textContent = `
.kws-ds-side{position:absolute;top:0;bottom:0;width:38%;z-index:8;pointer-events:none;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;color:#fff;opacity:0;transition:opacity .25s ease;overflow:hidden}
.kws-ds-side.on{opacity:1;transition:opacity .08s ease}
.kws-ds-side.l{left:0;border-radius:0 50% 50% 0 / 0 50% 50% 0}
.kws-ds-side.r{right:0;border-radius:50% 0 0 50% / 50% 0 0 50%}
.kws-ds-side::before{content:'';position:absolute;inset:0;background:rgba(255,255,255,.18)}
.kws-ds-side .kws-ds-ripple{position:absolute;top:50%;width:60px;height:60px;margin-top:-30px;border-radius:50%;background:rgba(255,255,255,.32);transform:scale(0);pointer-events:none}
.kws-ds-side.l .kws-ds-ripple{left:30%}.kws-ds-side.r .kws-ds-ripple{right:30%}
.kws-ds-side .kws-ds-ripple.go{animation:kwsDsRipple .55s ease-out}
@keyframes kwsDsRipple{from{transform:scale(0);opacity:1}to{transform:scale(7);opacity:0}}
.kws-ds-arrows{position:relative;display:flex;gap:3px;filter:drop-shadow(0 1px 3px rgba(0,0,0,.45))}
.kws-ds-arrows i{width:0;height:0;border-top:16px solid transparent;border-bottom:16px solid transparent;opacity:.25;animation:kwsDsArrow .9s infinite}
.kws-ds-side.r .kws-ds-arrows i{border-left:24px solid #fff}
.kws-ds-side.l .kws-ds-arrows i{border-right:24px solid #fff}
.kws-ds-side.r .kws-ds-arrows i:nth-child(2),.kws-ds-side.l .kws-ds-arrows i:nth-child(2){animation-delay:.15s}
.kws-ds-side.r .kws-ds-arrows i:nth-child(3){animation-delay:.3s}
.kws-ds-side.l .kws-ds-arrows i:nth-child(1){animation-delay:.3s}
.kws-ds-side.l .kws-ds-arrows i:nth-child(3){animation-delay:0s}
@keyframes kwsDsArrow{0%,100%{opacity:.3}40%{opacity:1}}
.kws-ds-txt{position:relative;font:800 22px/1 -apple-system,"Malgun Gothic",sans-serif;text-shadow:0 1px 4px rgba(0,0,0,.5)}
.kws-ds-fast{position:absolute;top:14%;left:50%;transform:translateX(-50%);z-index:9;pointer-events:none;display:none;align-items:center;gap:8px;padding:10px 20px;border-radius:999px;background:rgba(0,0,0,.62);color:#fff;font:800 19px/1 -apple-system,"Malgun Gothic",sans-serif}
.kws-ds-fast.on{display:flex}
.kws-ds-fast b{display:flex;gap:2px}
.kws-ds-fast b i{width:0;height:0;border-top:9px solid transparent;border-bottom:9px solid transparent;border-left:13px solid #fff;animation:kwsDsArrow .9s infinite}
.kws-ds-fast b i:nth-child(2){animation-delay:.2s}`;
    document.head.appendChild(st);
  }
  function sidePanel(host, left) {
    let el = host.querySelector(':scope > .kws-ds-side.' + (left ? 'l' : 'r'));
    if (!el) {
      el = document.createElement('div');
      el.className = 'kws-ds-side ' + (left ? 'l' : 'r');
      el.innerHTML = '<span class="kws-ds-ripple"></span><span class="kws-ds-arrows"><i></i><i></i><i></i></span><span class="kws-ds-txt"></span>';
      host.appendChild(el);
    }
    return el;
  }
  global.KWSDblSeek = function (video, opts) {
    if (!video || video._kwsDblSeek) return;
    video._kwsDblSeek = true;
    css();
    const step = (opts && opts.step) || 10;
    const host = () => (opts && opts.host) || video.parentElement;
    const seek = (opts && opts.seek) || ((d) => {
      const dur = isFinite(video.duration) && video.duration > 0 ? video.duration : Infinity;
      video.currentTime = Math.max(0, Math.min(dur - 0.5, (video.currentTime || 0) + d));
    });
    // ── double-click seek with the ripple ──
    let acc = 0, accSide = null, accTimer = null;
    video.addEventListener('dblclick', (e) => {
      const r = video.getBoundingClientRect();
      if (!r.width) return;
      const x = (e.clientX - r.left) / r.width;
      if (x > 0.35 && x < 0.65) return; // middle → fullscreen as before
      e.preventDefault(); e.stopImmediatePropagation();
      const back = x <= 0.35;
      seek(back ? -step : step);
      const h = host(); if (!h) return;
      if (accSide !== back) acc = 0;
      accSide = back; acc += step;
      const el = sidePanel(h, back);
      el.querySelector('.kws-ds-txt').textContent = KO ? acc + '초' : acc + ' seconds';
      const rp = el.querySelector('.kws-ds-ripple'); rp.classList.remove('go'); void rp.offsetWidth; rp.classList.add('go');
      el.classList.add('on');
      clearTimeout(accTimer);
      accTimer = setTimeout(() => { el.classList.remove('on'); acc = 0; accSide = null; }, 900);
    }, true);
    // ── press and hold → 4× ──
    const FAST = (opts && opts.holdRate) || 4;
    let holdTimer = null, holding = false, prevRate = 1, swallowClick = false, sx = 0, sy = 0;
    const fastPill = () => {
      const h = host(); if (!h) return null;
      let p = h.querySelector(':scope > .kws-ds-fast');
      if (!p) { p = document.createElement('div'); p.className = 'kws-ds-fast'; p.innerHTML = '<span></span><b><i></i><i></i></b>'; h.appendChild(p); }
      p.querySelector('span').textContent = KO ? FAST + '배속' : FAST + 'x';
      return p;
    };
    const endHold = () => {
      clearTimeout(holdTimer); holdTimer = null;
      if (!holding) return;
      holding = false;
      setTimeout(() => { swallowClick = false; }, 300); // released outside the video: no click comes
      video.playbackRate = prevRate;
      const p = fastPill(); if (p) p.classList.remove('on');
    };
    video.addEventListener('pointerdown', (e) => {
      if (e.button !== 0 || video.paused) return;
      sx = e.clientX; sy = e.clientY;
      clearTimeout(holdTimer);
      holdTimer = setTimeout(() => {
        holdTimer = null;
        if (video.paused) return;
        holding = true; swallowClick = true;
        prevRate = video.playbackRate || 1;
        video.playbackRate = FAST;
        const p = fastPill(); if (p) p.classList.add('on');
      }, 500);
    });
    // moving the pointer (dragging the player window) cancels a hold that hasn't started yet
    video.addEventListener('pointermove', (e) => { if (holdTimer && (Math.abs(e.clientX - sx) > 6 || Math.abs(e.clientY - sy) > 6)) { clearTimeout(holdTimer); holdTimer = null; } });
    window.addEventListener('pointerup', endHold, true);
    window.addEventListener('pointercancel', endHold, true);
    video.addEventListener('pointerleave', () => { if (!holding) { clearTimeout(holdTimer); holdTimer = null; } });
    window.addEventListener('blur', endHold);
    // the click that ends a hold must not toggle play / pause (runs before the players' own click)
    video.addEventListener('click', (e) => { if (swallowClick) { swallowClick = false; e.preventDefault(); e.stopImmediatePropagation(); } }, true);
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);

// 1.2.5.46 — Google Translate's free endpoint: Google blocks one `client=` value at a time and then
// another (gtx blocked in Oct, then at). Try each in turn, start with the last one that worked
// (remembered per browser), and treat a non-JSON answer (the "sorry" bot page) as blocked.
(function (global) {
  if (global.KWSGTranslate) return;
  const CLIENTS = ['gtx', 'dict-chrome-ex', 'at'];
  const KEY = 'kwsGtClient';
  let good = null;
  try { chrome.storage.local.get(KEY).then((d) => { if (CLIENTS.includes(d[KEY])) good = good || d[KEY]; }).catch(() => {}); } catch (_) {}
  global.KWSGTranslate = async function (text, lang) {
    const order = good ? [good, ...CLIENTS.filter((c) => c !== good)] : CLIENTS.slice();
    let lastErr = null;
    for (const c of order) {
      try {
        const url = `https://translate.googleapis.com/translate_a/single?client=${c}&sl=auto&tl=${encodeURIComponent(lang)}&dt=t&q=${encodeURIComponent(text)}`;
        const res = await fetch(url);
        if (!res.ok) { lastErr = new Error(`HTTP ${res.status} (${c})`); continue; }
        let data;
        try { data = JSON.parse(await res.text()); } catch (_) { lastErr = new Error(`blocked (${c})`); continue; }
        if (!Array.isArray(data) || !Array.isArray(data[0])) { lastErr = new Error(`bad reply (${c})`); continue; }
        if (good !== c) { good = c; try { chrome.storage.local.set({ [KEY]: c }); } catch (_) {} }
        return data;
      } catch (e) { lastErr = new Error(`${(e && e.message) || e} (${c})`); }
    }
    throw lastErr || new Error('translate failed');
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
